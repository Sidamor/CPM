cd /home/CPM/ddns
./DDNS &
exit 0
