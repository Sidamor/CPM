cd /home/CPM/CPM
./CPM &
exit 0
