cd /home/CPM/ntpclient
./NTPClient &
exit 0
