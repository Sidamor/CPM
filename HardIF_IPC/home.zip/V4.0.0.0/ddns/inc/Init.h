#ifndef __INIT_H__
#define __INIT_H__
#include <string>
#include "DDNSClient.h"
#include "IniFile.h"

class CInit {

public :
	CInit(){};
 ~CInit(){};
  bool Initialize(void);
};
#endif

