#ifndef __CODE_UTIL_H__
#define __CODE_UTIL_H__


void Unicode2GB(char *rec,char *dest,int len);
int GB2UniCode(char *input, unsigned char *encoded);
#endif
