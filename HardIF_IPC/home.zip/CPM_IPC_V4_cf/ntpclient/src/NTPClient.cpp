#include "NTPClient.h"

NTPClient::NTPClient()
{
	
}
 
NTPClient::~NTPClient()
{
	
}

bool NTPClient::init()
{
	m_Status = 0;
	memset(m_Hour,  0, sizeof(m_Hour));
	memset(m_SvrIp, 0, sizeof(m_SvrIp));
	
	get_ini_int("Config.ini",    "NTP", "NTPStatus", -1, &m_Status);
	get_ini_string("Config.ini", "NTP", "NTPHour", "=", m_Hour,  sizeof(m_Hour));
	get_ini_string("Config.ini", "NTP", "NTPSvr",  "=", m_SvrIp, sizeof(m_SvrIp));
	
	if(NULL == m_Hour || 0 == strlen(m_Hour))
	{
		memset(m_Hour, 0, sizeof(m_Hour));
		memcpy(m_Hour, "1", sizeof(m_Hour));
	}
	
	if(NULL == m_SvrIp || 0 == strlen(m_SvrIp))
	{
		memset(m_SvrIp, 0, sizeof(m_SvrIp));
		memcpy(m_SvrIp, "0.0.0.0", sizeof(m_SvrIp));
	}
	
	SendRunThrdRun();
	
	return true;
}

//�����߳�
void NTPClient::SendRunThrdRun()
{
	while(1)
	{
		if(1 == m_Status)
		{
			char syscmd[256] = {0};
			sprintf(syscmd, "ntpdate %s", m_SvrIp);
			
			printf("syscmd:%s\n", syscmd);
			
			system(syscmd);
		}	
		sleep(atoi(m_Hour)*3600);
	}
}
