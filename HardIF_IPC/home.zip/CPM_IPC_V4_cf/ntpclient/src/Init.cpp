#include "Init.h"
#include "NTPClient.h"

NTPClient g_clsNTPClient;

bool CInit::Initialize(void)
{
	int m_Status = 0;
	get_ini_int("Config.ini", "NTP", "NTPStatus", -1, &m_Status);
	
	if(0 == m_Status)
	{
		return false;
	}
	
	if(!g_clsNTPClient.init()) 
	{
		return false;
	}
	
	return true;
}
