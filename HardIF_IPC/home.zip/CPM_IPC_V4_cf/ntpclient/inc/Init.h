#ifndef __INIT_H__
#define __INIT_H__
#include <string>
#include "NTPClient.h"
#include "IniFile.h"

class CInit {

public :
	CInit(){};
 ~CInit(){};
  bool Initialize(void);
};
#endif

