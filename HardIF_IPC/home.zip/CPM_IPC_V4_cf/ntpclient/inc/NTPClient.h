#ifndef _NTPClient_H_
#define _NTPClient_H_
#include "constDef.h"
#include "IniFile.h"

class NTPClient
{
	public:
		NTPClient();
	 ~NTPClient();
		bool init();
		
	private:
		void SendRunThrdRun();
		
	private:
		int  m_Status;
		char m_Hour[5];
		char m_SvrIp[20];
};
#endif
