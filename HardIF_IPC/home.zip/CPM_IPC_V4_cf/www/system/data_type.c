#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

//��������
char Sql[1024] = {0};
int cnt = 0;
char cmd[4] = {0};

//��data_type
char id[3] = {0};					//���
char cname[13] = {0};			//����
char unit[13] = {0};			//��λ
char memo[128] = {0};     //��ע
  
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);

static void QueryData();//��ѯ
static void UpdateData();//�޸�
static void DeleteData();//ɾ��
static void AddData();//����
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);//���ݿ�ص�����
static void QueryDataForAdd();//��������ҳ��
static void AddDataUnique();//����ʱidΨһ��֤
static int sqlite3_exec_callback_unique(void *data, int n_columns, char **col_values, char **col_names);//���ݿ�ص�����
static void QueryDataSingle();//������ѯ

int cgiMain()
{
	cgiHeaderContentType("text/html");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{		
				case 0://��ѯ
					QueryData();
					break;
				case 1://��������ҳ��
					QueryDataForAdd();
					break;
				case 2://������ѯ
					QueryDataSingle();
					break;
				case 10://����ʱidΨһ��֤
					AddDataUnique();
					if(cnt == 1)
					{
						QueryDataForAdd();
						fprintf(cgiOut, "<script language='javascript'>document.getElementById('msg').innerText = '��ǰ����Ѵ��ڣ������¶��壡'</script>\n");
					}
					else
					{
						AddData();
						sprintf(cmd, "%s", "0");
						QueryData();
					}
					break;
				case 11://�޸�
					UpdateData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 12://ɾ��
					DeleteData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;		
			}		
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{  
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("unit", unit, sizeof(unit));
	cgiFormString("memo", memo, sizeof(memo));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      strcat(Sql, "select t.id, t.cname, t.unit, t.memo from data_type t order by t.id");
			break;
		case 1://����ʱidΨһ�ж�
      strcat(Sql, "select t.id, t.cname, t.unit, t.memo from data_type t where t.id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 2://������ѯ
			strcat(Sql, "select t.id, t.cname, t.unit, t.memo from data_type t where t.id = '");
			strcat(Sql, id);
			strcat(Sql, "' order by t.id");
			break;
		case 10://����
      strcat(Sql, "insert into data_type(id, cname, unit, memo)values('");
			strcat(Sql, id);
			strcat(Sql, "', '");
      strcat(Sql, cname);
			strcat(Sql, "', '");
			strcat(Sql, unit);
			strcat(Sql, "', '");
			strcat(Sql, memo);
			strcat(Sql, "')");
			break;
		case 11://����
      strcat(Sql, "update data_type set cname = '");
      strcat(Sql, cname);
			strcat(Sql, "', unit = '");
     	strcat(Sql, unit);  
     	strcat(Sql, "', memo = '");
     	strcat(Sql, memo); 	   
      strcat(Sql, "' where id = '");
			strcat(Sql, id);
      strcat(Sql, "'");
			break;
		case 12://ɾ��
			strcat(Sql, "delete from data_type where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
	}
	return Sql;
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>������Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"data_type\" action=\"data_type.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "  <div id=\"cap\"><img src=\"../skin/images/data_type.gif\"/></div><br>\n");
	fprintf(cgiOut, "  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "    <table width=\"80%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='right'><img src=\"../skin/images/mini_button_add.gif\" style='cursor:hand;' onClick='doAdd()'/></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "          <table width=\"100%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "            <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "              <td width='10%%' align='center' class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "              <td width='10%%' align='center' class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "              <td width='10%%' align='center' class=\"table_deep_blue\">�� λ</td>\n");
	fprintf(cgiOut, "              <td width='30%%' align='center' class=\"table_deep_blue\">�� ע</td>\n");
	fprintf(cgiOut, "              <td width='10%%' align='center' class=\"table_deep_blue\">ɾ ��</td>\n");
	fprintf(cgiOut, "            </tr>\n");
	
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "          </table>\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'data_type.cgi?cmd=1';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doDelete(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ��ɾ��?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'data_type.cgi?cmd=12&id='+pId;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

//�޸�
void UpdateData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(11), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

//ɾ��
void DeleteData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(12), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

//����
void AddData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(10), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

//��ѯ����
int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{  
	cnt++;
	if(cnt%2 == 0)
	{
		fprintf(cgiOut, "<tr class='table_blue' height='30' valign='middle'>\n");
	}
	else
	{
		fprintf(cgiOut, "<tr class='table_white_l' height='30' valign='middle'>\n");
	}
	fprintf(cgiOut, "  <td width='10%%' align='center'><a href='data_type.cgi?cmd=2&id=%s&cname=%s&unit=%s&memo=%s' target='mainFrame'><font color=red>%s</font></a></td>\n", col_values[0], col_values[1], col_values[2], col_values[3], col_values[0]);
	fprintf(cgiOut, "  <td width='10%%' align='left'>%s</td>\n", col_values[1]);
	fprintf(cgiOut, "  <td width='10%%' align='left'>%s&nbsp</td>\n", col_values[2]);
	fprintf(cgiOut, "  <td width='30%%' align='left'>%s&nbsp</td>\n", col_values[3]);
	fprintf(cgiOut, "  <td width='10%%' align='center' style='cursor:hand;color:red;' title='���ɾ��' onClick=doDelete('%s')>ɾ ��</td>\n", col_values[0]);
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

//����idΨһ��֤
void AddDataUnique()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_unique, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_unique(void *data, int n_columns, char **col_values, char **col_names)
{  
	cnt++;
	return 0;
}

//��������ҳ��
void QueryDataForAdd()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>������Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"data_type\" action=\"data_type.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "  <div id=\"cap\"><img src=\"../skin/images/data_type.gif\"/></div><br>\n");
	fprintf(cgiOut, "  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "    <table width=\"50%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='right'><img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doAdd()'><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "    <table width=\"50%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='id' name='id' value='' style='width:60%%;height:25px;' maxlength=2></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='cname' name='cname' value='' style='width:60%%;height:25px;' maxlength=8></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� λ</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='unit' name='unit' value='' style='width:60%%;height:25px;' maxlength=8></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ע</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='memo' name='memo' value='' style='width:60%%;height:25px;' maxlength=128></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "<div id='msg' style='color:red;text-align:center;'></div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='10'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'data_type.cgi?cmd=0';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(data_type.id.value.length < 1){alert('����д 01-99 �����λ���');return;}\n");
	fprintf(cgiOut, "  if(data_type.cname.value.length < 1){alert('����д����');return;}\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    data_type.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

//������ѯ
void QueryDataSingle()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>������Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"data_type\" action=\"data_type.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "  <div id=\"cap\"><img src=\"../skin/images/data_type.gif\"/></div><br>\n");
	fprintf(cgiOut, "  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "    <table width=\"50%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='right'><img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doEdit()'><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "    <table width=\"50%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'>%s<input type='hidden' id='id' name='id' value='%s'></td>\n", id, id);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='cname' name='cname' value='%s' style='width:60%%;height:25px;' maxlength=8></td>\n", cname);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� λ</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='unit' name='unit' value='%s' style='width:60%%;height:25px;' maxlength=8></td>\n", unit);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ע</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='memo' name='memo' value='%s' style='width:60%%;height:25px;' maxlength=128></td>\n", memo);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='11'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'data_type.cgi?cmd=0';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doEdit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(data_type.cname.value.length < 1){alert('����д����');return;}\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    data_type.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}
