#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>

//��������
char Sql[1024] = {0};
int count = 0;
char cmd[4] = {0};
char func_id[4] = {0};

//��user_info
char id[30] = {0};
char pwd[20] = {0};
char cname[20] = {0};
char sex[10] = {0};
char birthday[20] = {0};
char addr[50] = {0};
char tel[20] = {0};
char status[10] = {0};
char sp_role[10] = {0};
char hj_role[10] = {0};
char qx[10] = {0};
char newpwd[20] = {0};

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ��¼
static void QueryData();
//���¼�¼
static int UpdateData();
//��ѯ����
static void SingleQuery();
//������֤�������޸�
static void SingleValidate();
static void AddHtml();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_validate(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			count = 0;
			switch(atoi(cmd))
			{
				case 10://����
				case 11://�޸�
				case 12://ɾ��
					UpdateData();
					sprintf(cmd, "%s", "0");
				case 0:
					QueryData();
					break;
				case 20://������ѯ
					SingleQuery();
					break;
				case 21:
					AddHtml();
					break;
				case 13://�޸�����
					SingleValidate();
					if(count == 1)
					{
						UpdateData();
						printf("�����޸ĳɹ�!");
					}
					else
					{
						printf("�û������������!");
					}
					break;
				case 14:
					sprintf(cmd, "%s", "13");
					UpdateData();			
					printf("�������óɹ�!");
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("func_id", func_id, sizeof(func_id));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("pwd", pwd, sizeof(pwd));
	cgiFormString("cname", cname, sizeof(cname));	
	cgiFormString("sex", sex, sizeof(sex));
	cgiFormString("birthday", birthday, sizeof(birthday));
	cgiFormString("addr", addr, sizeof(addr));
	cgiFormString("tel", tel, sizeof(tel));
	cgiFormString("status", status, sizeof(status));
	cgiFormString("sp_role", sp_role, sizeof(sp_role));
	cgiFormString("hj_role", hj_role, sizeof(hj_role));
	cgiFormString("qx", qx, sizeof(qx));
	cgiFormString("newpwd", newpwd, sizeof(newpwd));
}
static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0:
			strcat(Sql, "select t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role from user_info t");
			break;
		case 1:
			strcat(Sql, "select t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role from user_info t where t.id = '");
			strcat(Sql, id);
			strcat(Sql, "' and t.pwd = '");
			strcat(Sql, pwd);
			strcat(Sql, "' ");
			break;
		case 10:
			strcat(Sql, "insert into user_info(id, cname, qx, sex, birthday, addr, tel, status, sp_role, hj_role) values('");
			strcat(Sql, id);
			strcat(Sql, "', '");
			strcat(Sql, cname);
			strcat(Sql, "', '");
			strcat(Sql, qx);
			strcat(Sql, "', '");
			strcat(Sql, sex);
			strcat(Sql, "', '");
			strcat(Sql, birthday);
			strcat(Sql, "', '");
			strcat(Sql, addr);
			strcat(Sql, "', '");
			strcat(Sql, tel);
			strcat(Sql, "', '");
			strcat(Sql, status);
			strcat(Sql, "', '");
			strcat(Sql, sp_role);
			strcat(Sql, "', '");
			strcat(Sql, hj_role);
			strcat(Sql, "') ");
			break;
		case 11:
			strcat(Sql, "update user_info set id='");
			strcat(Sql, id);
			strcat(Sql, "', cname = '");
			strcat(Sql, cname);
			strcat(Sql, "', sex = '");
			strcat(Sql, sex);
			strcat(Sql, "', birthday = '");
			strcat(Sql, birthday);
			strcat(Sql, "', addr = '");
			strcat(Sql, addr);
			strcat(Sql, "', tel = '");
			strcat(Sql, tel);
			strcat(Sql, "', status = '");
			strcat(Sql, status);
			strcat(Sql, "', sp_role = '");
			strcat(Sql, sp_role);
			strcat(Sql, "', hj_role = '");
			strcat(Sql, hj_role);
			strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
		case 12:
			strcat(Sql, "delete from user_info t where t.id='");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
		case 13:
			strcat(Sql, "update user_info set pwd='");
			strcat(Sql, newpwd);
			strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
		case 20:
			strcat(Sql, "select t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role from user_info t where t.id = '");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
	}
	return Sql;
}

static void QueryData()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>user_info</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"User_Info\" action=\"user_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div class=\"sjtop\">\n");
	fprintf(cgiOut, "  <table cellpadding=\"2\" cellspacing=\"2\" border=\"0\" width=\"100%%\">\n");
  fprintf(cgiOut, "    <tr>\n");
	fprintf(cgiOut, "      <td width=\"100%%\" align=\"right\"><a href=\"user_info.cgi?cmd=0\" target=\"mainFrame\"><img style=\"cursor:hand\" src=\"../skin/images/mini_button_search.gif\"></a><a href=\"user_info.cgi?cmd=21\" target=\"mainFrame\"><img style=\"cursor:hand\" src=\"../skin/images/mini_button_add.gif\"></a></td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id=\"right_cap\">\n");
	fprintf(cgiOut, "<div id=\"right_table_center2\">\n");
	fprintf(cgiOut, "  <table cellpadding=\"1\" cellspacing=\"1\" border=\"0\" class=\"table_bg\" width=\"100%%\">\n");
	fprintf(cgiOut, "    <tr>\n");
	fprintf(cgiOut, "      <td width=\"5%%\"  class=\"table_deep_blue\">���</td>\n");
	fprintf(cgiOut, "      <td width=\"10%%\" class=\"table_deep_blue\">�˺�</td>\n");
	fprintf(cgiOut, "      <td width=\"10%%\" class=\"table_deep_blue\">����</td>\n");
	fprintf(cgiOut, "      <td width=\"5%%\"  class=\"table_deep_blue\">�Ա�</td>\n");
	fprintf(cgiOut, "      <td width=\"10%%\" class=\"table_deep_blue\">��������</td>\n");
	fprintf(cgiOut, "      <td width=\"10%%\" class=\"table_deep_blue\">Ȩ��</td>\n");
	fprintf(cgiOut, "      <td width=\"20%%\" class=\"table_deep_blue\">��ϵ�绰</td>\n");
	fprintf(cgiOut, "      <td width=\"30%%\" class=\"table_deep_blue\">��ַ</td>\n");
	fprintf(cgiOut, "    </tr>\n");
	
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "</HTML>\n");
}

static void SingleQuery()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title></title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style=\"background:#CADFFF\" onload=\"doAuto()\">\n");
	fprintf(cgiOut, "<form name=\"User_Add\" action=\"user_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "		<div id=\"cap\">\n");
	fprintf(cgiOut, "			<img src=\"../skin/images/cap_user_edit.gif\"/>\n");
	fprintf(cgiOut, "		</div>\n");
	fprintf(cgiOut, "		<div id=\"right_cap2\">\n");
	fprintf(cgiOut, "			<div id=\"cap_l\"><img src=\"../skin/images/cap_l.gif\"/></div>\n");
	fprintf(cgiOut, "			<div id=\"cap_r\"><img src=\"../skin/images/cap_r.gif\"/></div>\n");
	fprintf(cgiOut, "		</div>\n");
	fprintf(cgiOut, "	  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "				<table width=\"550px\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "					 	<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">�˺�</td>\n");
	fprintf(cgiOut, "							<td width=\"150px\"><input type=\"text\" name=\"id\" style=\"width:150px;height:22px;\" maxlength=\"30\" value=\"%s\"></td>\n", id);
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">����</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\"><input type=\"text\" name=\"cname\" style=\"width:150px;height:22px;\"  maxlength=\"20\" value=\"%s\"></td>\n", cname);
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��ϵ�绰</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\"><input type=\"text\" name=\"tel\" style=\"width:150px;height:22px;\" maxlength=\"20\" value=\"%s\"></td>\n", tel);
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">�Ա�</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\">\n");
	fprintf(cgiOut, "					      <select name=\"sex\" style=\"width:100px;height:22px\">	\n");
	if(0 == strcmp(sex, "0"))
	{
		fprintf(cgiOut, "					      	 <option value=\"0\" selected>��</option><option value=\"1\">Ů</option>\n");
	}
	else
	{
		fprintf(cgiOut, "					      	 <option value=\"0\" >��</option><option value=\"1\" selected>Ů</option>\n");
	}

	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��������</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\"><input type=\"text\" name=\"birthday\" onClick=\"WdatePicker({readOnly:true})\" class=\"Wdate\" size=\"10\" maxlength=\"10\" value=\"%s\"></td>\n", birthday);
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">״̬</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\">\n");
	fprintf(cgiOut, "					      <select name=\"status\" style=\"width:100px;height:22px\">	\n");
	if(0 == strcmp(status, "0"))
	{
		fprintf(cgiOut, "					      	 <option value=\"0\" selected>����</option><option value=\"1\">ע��</option>\n");
	}
	else
	{
		fprintf(cgiOut, "					      	 <option value=\"0\" >����</option><option value=\"1\" selected>ע��</option>\n");
	}
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��Ƶ����</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\">\n");
	fprintf(cgiOut, "					      <select id=\"sp_role\" name=\"sp_role\" style=\"width:100px;height:22px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��������</td>\n");
	fprintf(cgiOut, "							<td width=\"150px\">\n");
	fprintf(cgiOut, "					      <select id=\"hj_role\" name=\"hj_role\" style=\"width:100px;height:22px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">Ȩ��</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\">��ͨ�û�</td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��ַ</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\"><input type=\"text\" name=\"addr\" style=\"width:300px;height:22px;\" maxlength=\"50\" value=\"%s\"></td>\n", addr);
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				</table>\n");
	fprintf(cgiOut, "		 </div>\n");
	fprintf(cgiOut, "     <div style=\"text-align:center\">\n");
	fprintf(cgiOut, "			  <img style=\"cursor:hand\" onClick=\"doSubmit()\" src=\"../skin/images/mini_button_submit.gif\">\n");
	fprintf(cgiOut, "			  <img style=\"cursor:hand\" onClick=\"doPwdReset()\" src=\"../skin/images/mini_button_pwd_reset.gif\">\n");
	fprintf(cgiOut, "			  <img style=\"cursor:hand\" onClick=\"doCancel()\" src=\"../skin/images/mini_button_cancel.gif\">\n");
	fprintf(cgiOut, "		 </div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "</center>\n");
	fprintf(cgiOut, "<input type=\"hidden\" name=\"cmd\" value=\"11\">\n");
	fprintf(cgiOut, "<input type=\"hidden\" name=\"qx\" value=\"2\">\n");
	fprintf(cgiOut, "<input type=\"hidden\" name=\"role1\" value=\"%s\">\n", sp_role);
	fprintf(cgiOut, "<input type=\"hidden\" name=\"role2\" value=\"%s\">\n", hj_role);
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "	\n");
	fprintf(cgiOut, "function doAuto()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	doSPArea();\n");
	fprintf(cgiOut, "	doHJArea();\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function doPwdReset()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_Pwd = createXHR();\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "   if(m_Pwd)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_Pwd.onreadystatechange=callbackForPwdReset;\n");
	fprintf(cgiOut, "      var url = \"user_info.cgi?cmd=14&newpwd=111111&id=%s&currtime=\"+new Date();\n", id);
	fprintf(cgiOut, "      m_Pwd.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_Pwd.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function doSPArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_SPArea = createXHR();\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "   if(m_SPArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_SPArea.onreadystatechange=callbackForSPArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=05&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_SPArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_SPArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doHJArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_HJArea = createXHR();\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "   if(m_HJArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_HJArea.onreadystatechange=callbackForHJArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=06&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_HJArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_HJArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{ \n");
	fprintf(cgiOut, "	 var id = User_Add.id.value;\n");
	fprintf(cgiOut, "	 var cname = User_Add.cname.value;\n");
	fprintf(cgiOut, "	 var tel = User_Add.tel.value;\n");
	fprintf(cgiOut, "	 var sex = User_Add.sex.value;\n");
	fprintf(cgiOut, "	 var birthday = User_Add.birthday.value;\n");
	fprintf(cgiOut, "	 var status = User_Add.status.value;\n");
	fprintf(cgiOut, "	 var sp_role = User_Add.sp_role.value;\n");
	fprintf(cgiOut, "	 var hj_role = User_Add.hj_role.value;\n");
	fprintf(cgiOut, "	 var addr = User_Add.addr.value;\n");
	fprintf(cgiOut, "	 \n");
	fprintf(cgiOut, "	 if(User_Add.id.value == null || User_Add.id.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�˺Ų���Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.cname.value == null || User_Add.cname.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"��������Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 \n");
	fprintf(cgiOut, "	 if(confirm(\"ȷ���������û�?\"))\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	 	  var currURL = \"user_info.cgi?cmd=11&qx=2&id=\"+id+\"&cname=\"+cname+\"&tel=\"+tel+\"&sex=\"+sex+\"&birthday=\"+birthday+\"&status=\"+status+\"&sp_role=\"+sp_role+\"&hj_role=\"+hj_role+\"&addr=\"+addr;\n");
	fprintf(cgiOut, "	    location = currURL;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, " \n");
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{ \n");
	fprintf(cgiOut, "	 location = \"user_info.cgi?cmd=0\";\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "/*\n");
	fprintf(cgiOut, " *�����첽���ʶ���\n");
	fprintf(cgiOut, " */\n");
	fprintf(cgiOut, "function createXHR() \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    var xhr;\n");
	fprintf(cgiOut, "    try \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        xhr = new ActiveXObject(\"Msxml2.XMLHTTP\");\n");
	fprintf(cgiOut, "    } \n");
	fprintf(cgiOut, "    catch (e) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        try \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            xhr = new ActiveXObject(\"Microsoft.XMLHTTP\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        catch(E) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            xhr = false;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "    if (!xhr && typeof XMLHttpRequest != 'undefined') \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        xhr = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "    return xhr;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "/*\n");
	fprintf(cgiOut, " *�첽�ص���������\n");
	fprintf(cgiOut, " */\n");
	fprintf(cgiOut, "function callbackForSPArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_SPArea.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_SPArea.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_SPArea.responseText;\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               document.getElementById(\"sp_role\").options.length = 0;\n");
	fprintf(cgiOut, "				 \n");
	fprintf(cgiOut, "						   var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "						   \n");
	fprintf(cgiOut, "						   for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "						   {\n");
	fprintf(cgiOut, "						      var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						      if(User_Add.role1.value == TempArray[i].split(\",\")[0]){objOption.selected = true;}\n");
	
	fprintf(cgiOut, "						      objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						      objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						      document.getElementById(\"sp_role\").add(objOption);\n");
	fprintf(cgiOut, "						   }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackForHJArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_HJArea.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_HJArea.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_HJArea.responseText;\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               document.getElementById(\"hj_role\").options.length = 0;\n");
	fprintf(cgiOut, "				 \n");
	fprintf(cgiOut, "						   var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "						   \n");
	fprintf(cgiOut, "						   for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "						   {\n");
	fprintf(cgiOut, "						      var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						      if(User_Add.role2.value == TempArray[i].split(\",\")[0]){objOption.selected = true;}\n");
	fprintf(cgiOut, "						      objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						      objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						      document.getElementById(\"hj_role\").add(objOption);\n");
	fprintf(cgiOut, "						   }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function callbackForPwdReset()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_Pwd.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_Pwd.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_Pwd.responseText;\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "            alert(returnValue);\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</html>\n");
}
int UpdateData()
{
    int ret = 0;

    int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
   
   ret = 1;
   return ret;
}
static void SingleValidate()
{
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(1);
	
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_validate, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}
void AddHtml()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title></title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\"> \n");
	fprintf(cgiOut, "<META HTTP-EQUIV=\"Cache-Control\" CONTENT=\"no-cache\"> \n");
	fprintf(cgiOut, "<META HTTP-EQUIV=\"Expires\" CONTENT=\"0\">\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "<body style=\"background:#CADFFF\" onload=\"doAuto()\">\n");
	fprintf(cgiOut, "<form name=\"User_Add\" action=\"user_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "		<div id=\"cap\">\n");
	fprintf(cgiOut, "			<img src=\"../skin/images/cap_user_add.gif\"/>\n");
	fprintf(cgiOut, "		</div>\n");
	fprintf(cgiOut, "		<div id=\"right_cap2\">\n");
	fprintf(cgiOut, "			<div id=\"cap_l\"><img src=\"../skin/images/cap_l.gif\"/></div>\n");
	fprintf(cgiOut, "			<div id=\"cap_r\"><img src=\"../skin/images/cap_r.gif\"/></div>\n");
	fprintf(cgiOut, "		</div>\n");
	fprintf(cgiOut, "	  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "				<table width=\"550px\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "					 	<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">�˺�</td>\n");
	fprintf(cgiOut, "							<td width=\"150px\"><input type=\"text\" name=\"id\" style=\"width:150px;height:22px;\" maxlength=\"30\"></td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">����</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\"><input type=\"text\" name=\"cname\" style=\"width:150px;height:22px;\"  maxlength=\"20\"></td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��ϵ�绰</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\"><input type=\"text\" name=\"tel\" style=\"width:150px;height:22px;\" maxlength=\"20\"></td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">�Ա�</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\">\n");
	fprintf(cgiOut, "					      <select name=\"sex\" style=\"width:100px;height:22px\">	\n");
	fprintf(cgiOut, "					      	 <option value=\"0\">��</option>\n");
	fprintf(cgiOut, "					      	 <option value=\"1\">Ů</option> \n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��������</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\"><input type=\"text\" name=\"birthday\" onClick=\"WdatePicker({readOnly:true})\" class=\"Wdate\" size=\"10\" maxlength=\"10\"></td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">״̬</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\">\n");
	fprintf(cgiOut, "					      <select name=\"status\" style=\"width:100px;height:22px\">	\n");
	fprintf(cgiOut, "					      	 <option value=\"0\">����</option>\n");
	fprintf(cgiOut, "					      	 <option value=\"1\">ע��</option> \n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��Ƶ����</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\">\n");
	fprintf(cgiOut, "					      <select id=\"sp_role\" name=\"sp_role\" style=\"width:100px;height:22px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��������</td>\n");
	fprintf(cgiOut, "							<td width=\"150px\">\n");
	fprintf(cgiOut, "					      <select id=\"hj_role\" name=\"hj_role\" style=\"width:100px;height:22px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">Ȩ��</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\">��ͨ�û�</td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"100px\" valign=\"middle\" align=\"center\">��ַ</td>\n");
	fprintf(cgiOut, "					    <td width=\"150px\"><input type=\"text\" name=\"addr\" style=\"width:300px;height:22px;\" maxlength=\"50\"></td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				</table>\n");
	fprintf(cgiOut, "		 </div>\n");
	fprintf(cgiOut, "     <div style=\"text-align:center\">\n");
	fprintf(cgiOut, "			  <img style=\"cursor:hand\" onClick=\"doSubmit()\" src=\"../skin/images/mini_button_submit.gif\">\n");
	fprintf(cgiOut, "			  <img style=\"cursor:hand\" onClick=\"doCancel()\" src=\"../skin/images/mini_button_cancel.gif\">\n");
	fprintf(cgiOut, "		 </div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "</center>\n");
	fprintf(cgiOut, "<input type=\"hidden\" name=\"cmd\" value=\"10\">\n");
	fprintf(cgiOut, "<input type=\"hidden\" name=\"qx\" value=\"2\">\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "	\n");
	fprintf(cgiOut, "function doAuto()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	doSPArea();\n");
	fprintf(cgiOut, "	doHJArea();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSPArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_SPArea = createXHR();\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "   if(m_SPArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_SPArea.onreadystatechange=callbackForSPArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=05&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_SPArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_SPArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doHJArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_HJArea = createXHR();\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "   if(m_HJArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_HJArea.onreadystatechange=callbackForHJArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=06&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_HJArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_HJArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{ \n");
	fprintf(cgiOut, "	 var id = User_Add.id.value;\n");
	fprintf(cgiOut, "	 var cname = User_Add.cname.value;\n");
	fprintf(cgiOut, "	 var tel = User_Add.tel.value;\n");
	fprintf(cgiOut, "	 var sex = User_Add.sex.value;\n");
	fprintf(cgiOut, "	 var birthday = User_Add.birthday.value;\n");
	fprintf(cgiOut, "	 var status = User_Add.status.value;\n");
	fprintf(cgiOut, "	 var sp_role = User_Add.sp_role.value;\n");
	fprintf(cgiOut, "	 var hj_role = User_Add.hj_role.value;\n");
	fprintf(cgiOut, "	 var addr = User_Add.addr.value;\n");
	fprintf(cgiOut, "	 \n");
	fprintf(cgiOut, "	 if(User_Add.id.value == null || User_Add.id.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�˺Ų���Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.cname.value == null || User_Add.cname.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"��������Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 \n");
	fprintf(cgiOut, "	 if(confirm(\"ȷ���������û�?\"))\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	 	  var currURL = \"user_info.cgi?cmd=10&qx=2&id=\"+id+\"&cname=\"+cname+\"&tel=\"+tel+\"&sex=\"+sex+\"&birthday=\"+birthday+\"&status=\"+status+\"&sp_role=\"+sp_role+\"&hj_role=\"+hj_role+\"&addr=\"+addr;\n");
	fprintf(cgiOut, "	    location = currURL;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, " \n");
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{ \n");
	fprintf(cgiOut, "	 location = \"user_info.cgi?cmd=0\";\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "/*\n");
	fprintf(cgiOut, " *�����첽���ʶ���\n");
	fprintf(cgiOut, " */\n");
	fprintf(cgiOut, "function createXHR() \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    var xhr;\n");
	fprintf(cgiOut, "    try \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        xhr = new ActiveXObject(\"Msxml2.XMLHTTP\");\n");
	fprintf(cgiOut, "    } \n");
	fprintf(cgiOut, "    catch (e) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        try \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            xhr = new ActiveXObject(\"Microsoft.XMLHTTP\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        catch(E) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            xhr = false;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "    if (!xhr && typeof XMLHttpRequest != 'undefined') \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        xhr = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "    return xhr;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "/*\n");
	fprintf(cgiOut, " *�첽�ص���������\n");
	fprintf(cgiOut, " */\n");
	fprintf(cgiOut, "function callbackForSPArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_SPArea.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_SPArea.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_SPArea.responseText;\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               document.getElementById(\"sp_role\").options.length = 0;\n");
	fprintf(cgiOut, "				 \n");
	fprintf(cgiOut, "						   var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "						   \n");
	fprintf(cgiOut, "						   for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "						   {\n");
	fprintf(cgiOut, "						      var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						      objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						      objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						      document.getElementById(\"sp_role\").add(objOption);\n");
	fprintf(cgiOut, "						   }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackForHJArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_HJArea.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_HJArea.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_HJArea.responseText;\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               document.getElementById(\"hj_role\").options.length = 0;\n");
	fprintf(cgiOut, "				 \n");
	fprintf(cgiOut, "						   var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "						   \n");
	fprintf(cgiOut, "						   for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "						   {\n");
	fprintf(cgiOut, "						      var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						      objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						      objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						      document.getElementById(\"hj_role\").add(objOption);\n");
	fprintf(cgiOut, "						   }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</html>\n");

}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	char StrLimit[20] = {0};
	char StrSex[5] = {0};
    if(0 != strcmp(col_values[0], "system") && 0 != strcmp(col_values[0], "admin"))
	{
		count++;
		if(count%2== 0)
		{
			fprintf(cgiOut, "<tr class='table_blue'>\n");
		}
		else
		{
			fprintf(cgiOut, "<tr class='table_white_l'>\n");
		}
		switch(atoi(col_values[3]))
		{
			case 0:
				strcat(StrLimit, "ϵͳ����Ա");
				break;
			case 1:
				strcat(StrLimit, "��������Ա");
				break;
			case 2:
				strcat(StrLimit, "��ͨ�û�");
				break;
		}
		switch(atoi(col_values[4]))
		{
			case 0:
				strcat(StrSex, "��");
				break;
			case 1:
				strcat(StrSex, "Ů");
				break;
		}
		fprintf(cgiOut, "<td>%d</td>\n", count);
		//t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role
		fprintf(cgiOut, "<td><a href=\"user_info.cgi?cmd=20&id=%s&cname=%s&qx=%s&sex=%s&birthday=%s&addr=%s&tel=%s&status=%s&sp_role=%s&hj_role=%s\" target=\"mainFrame\">%s</a></td>\n", col_values[0], col_values[1], col_values[3], col_values[4], col_values[5], col_values[6], col_values[7], col_values[8], col_values[9], col_values[10], col_values[0]);
		fprintf(cgiOut, "<td>%s</td>\n", col_values[1]);
		fprintf(cgiOut, "<td>%s</td>\n", StrSex);
		fprintf(cgiOut, "<td>%s</td>\n", col_values[5]);
		fprintf(cgiOut, "<td>%s</td>\n", StrLimit);
		fprintf(cgiOut, "<td>%s</td>\n", col_values[7]);
		fprintf(cgiOut, "<td>%s</td>\n", col_values[6]);
		fprintf(cgiOut, "<td>%s</td>\n", "");
		fprintf(cgiOut, "</tr>\n");
	}
	
	return 0;
}

int sqlite3_exec_callback_validate(void *data, int n_columns, char **col_values, char **col_names)
{
	count++;
	return 0;
}
