#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

//��������
char Sql[1024] = {0};
char cmd[4] = {0};
int cnt = 0;
char chgflag[2] = {0};
char tablelist[4096] = {0};

char colltmaxrecode[5]   = {0};//�ɼ���¼��
char hoursmaxrecode[5]   = {0};//Сʱ��ֵ��¼��
char daysmaxrecode[5]    = {0};//�վ�ֵ��¼��
char alertmaxrecode[5]   = {0};//�澯��¼��
char alarmmaxrecode[5]   = {0};//������¼��
char atsinfomaxrecode[5] = {0};//������ϸ��¼��
char atsldgmaxrecode[5]  = {0};//����ͳ�Ƽ�¼��
char colltstoremode[2]   = {0};//�ɼ���¼�洢ģʽ

char maxrecodecnt01[9]   = {0};//���û�����
char maxrecodecnt02[9]   = {0};//���豸����
char maxrecodecnt03[9]   = {0};//����������
char maxrecodecnt04[9]   = {0};//����������
char maxrecodecnt05[9]   = {0};//�ܶ�ʱ��������
char maxrecodecnt06[9]   = {0};//��������������

char maxrecodecnt07[9]   = {0};//���緢�Ͷ�������
char maxrecodecnt08[9]   = {0};//������ն�������
char maxrecodecnt09[9]   = {0};//�ͻ������緢�Ͷ�������
char maxrecodecnt10[9]   = {0};//�ͻ���������ն�������

char maxrecodecnt11[9]   = {0};//485-1������Ϣ����
char maxrecodecnt12[9]   = {0};//485-2������Ϣ����
char maxrecodecnt13[9]   = {0};//485-3������Ϣ����
char maxrecodecnt14[9]   = {0};//485-4������Ϣ����
char maxrecodecnt15[9]   = {0};//485-5������Ϣ����
char maxrecodecnt16[9]   = {0};//485-6������Ϣ����
char maxrecodecnt17[9]   = {0};//485-7������Ϣ����
char maxrecodecnt18[9]   = {0};//485-8������Ϣ����
char maxrecodecnt19[9]   = {0};//ADS������Ϣ����
char maxrecodecnt20[9]   = {0};//GSM������Ϣ����

char maxrecodecnt21[9]   = {0};//�ܶ�������
char maxrecodecnt22[9]   = {0};//�����ֶζ�
char maxrecodecnt23[9]   = {0};//�����ֶ���
char maxrecodecnt24[9]   = {0};//�����ֶ���
char maxrecodecnt25[9]   = {0};//�����ֶ���
char maxrecodecnt26[9]   = {0};//�����ֶ���
char maxrecodecnt27[9]   = {0};//�����ֶ���
char maxrecodecnt28[9]   = {0};//�����ֶΰ�
char maxrecodecnt29[9]   = {0};//�����ֶξ�
char maxrecodecnt30[9]   = {0};//�����ֶ�ʮ

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_table(void *data, int n_columns, char **col_values, char **col_names);
static void Updata();
static void doDBOperater();
static void doCPM();

int cgiMain()
{
	cgiHeaderContentType("text/html");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{
				case 10://����
					Updata();
					sprintf(cmd, "%s", "0");
				case 0://��ѯ
					QueryData();
					break;
				case 1://��������
					doCPM();
					fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.ConfButton.click();</script>\n");
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{  
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("chgflag", chgflag, sizeof(chgflag));
	cgiFormString("colltmaxrecode", colltmaxrecode, sizeof(colltmaxrecode));
	cgiFormString("hoursmaxrecode", hoursmaxrecode, sizeof(hoursmaxrecode));
	cgiFormString("daysmaxrecode", daysmaxrecode, sizeof(daysmaxrecode));
	cgiFormString("alertmaxrecode", alertmaxrecode, sizeof(alertmaxrecode));
	cgiFormString("alarmmaxrecode", alarmmaxrecode, sizeof(alarmmaxrecode));
	cgiFormString("atsinfomaxrecode", atsinfomaxrecode, sizeof(atsinfomaxrecode));
	cgiFormString("atsldgmaxrecode", atsldgmaxrecode, sizeof(atsldgmaxrecode));
	cgiFormString("colltstoremode", colltstoremode, sizeof(colltstoremode));
	cgiFormString("maxrecodecnt01", maxrecodecnt01, sizeof(maxrecodecnt01));
	cgiFormString("maxrecodecnt02", maxrecodecnt02, sizeof(maxrecodecnt02));
	cgiFormString("maxrecodecnt03", maxrecodecnt03, sizeof(maxrecodecnt03));
	cgiFormString("maxrecodecnt04", maxrecodecnt04, sizeof(maxrecodecnt04));
	cgiFormString("maxrecodecnt05", maxrecodecnt05, sizeof(maxrecodecnt05));
	cgiFormString("maxrecodecnt06", maxrecodecnt06, sizeof(maxrecodecnt06));
	cgiFormString("maxrecodecnt07", maxrecodecnt07, sizeof(maxrecodecnt07));
	cgiFormString("maxrecodecnt08", maxrecodecnt08, sizeof(maxrecodecnt08));
	cgiFormString("maxrecodecnt09", maxrecodecnt09, sizeof(maxrecodecnt09));
	cgiFormString("maxrecodecnt10", maxrecodecnt10, sizeof(maxrecodecnt10));
	cgiFormString("maxrecodecnt11", maxrecodecnt11, sizeof(maxrecodecnt11));
	cgiFormString("maxrecodecnt12", maxrecodecnt12, sizeof(maxrecodecnt12));
	cgiFormString("maxrecodecnt13", maxrecodecnt13, sizeof(maxrecodecnt13));
	cgiFormString("maxrecodecnt14", maxrecodecnt14, sizeof(maxrecodecnt14));
	cgiFormString("maxrecodecnt15", maxrecodecnt15, sizeof(maxrecodecnt15));
	cgiFormString("maxrecodecnt16", maxrecodecnt16, sizeof(maxrecodecnt16));
	cgiFormString("maxrecodecnt17", maxrecodecnt17, sizeof(maxrecodecnt17));
	cgiFormString("maxrecodecnt18", maxrecodecnt18, sizeof(maxrecodecnt18));
	cgiFormString("maxrecodecnt19", maxrecodecnt19, sizeof(maxrecodecnt19));
	cgiFormString("maxrecodecnt20", maxrecodecnt20, sizeof(maxrecodecnt20));
	cgiFormString("maxrecodecnt21", maxrecodecnt21, sizeof(maxrecodecnt21));
	cgiFormString("maxrecodecnt22", maxrecodecnt22, sizeof(maxrecodecnt22));
	cgiFormString("maxrecodecnt23", maxrecodecnt23, sizeof(maxrecodecnt23));
	cgiFormString("maxrecodecnt24", maxrecodecnt24, sizeof(maxrecodecnt24));
	cgiFormString("maxrecodecnt25", maxrecodecnt25, sizeof(maxrecodecnt25));
	cgiFormString("maxrecodecnt26", maxrecodecnt26, sizeof(maxrecodecnt26));
	cgiFormString("maxrecodecnt27", maxrecodecnt27, sizeof(maxrecodecnt27));
	cgiFormString("maxrecodecnt28", maxrecodecnt28, sizeof(maxrecodecnt28));
	cgiFormString("maxrecodecnt29", maxrecodecnt29, sizeof(maxrecodecnt29));
	cgiFormString("maxrecodecnt30", maxrecodecnt30, sizeof(maxrecodecnt30));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      	strcat(Sql, "select t.colltmaxrecode, t.alertmaxrecode, t.alarmmaxrecode, t.hoursmaxrecode, t.daysmaxrecode, t.atsinfomaxrecode, t.atsldgmaxrecode, t.colltstoremode, ");
				strcat(Sql, "t.maxrecodecnt01, t.maxrecodecnt02, t.maxrecodecnt03, t.maxrecodecnt04, t.maxrecodecnt05, t.maxrecodecnt06, t.maxrecodecnt07, t.maxrecodecnt08, t.maxrecodecnt09, t.maxrecodecnt10, ");
				strcat(Sql, "t.maxrecodecnt11, t.maxrecodecnt12, t.maxrecodecnt13, t.maxrecodecnt14, t.maxrecodecnt15, t.maxrecodecnt16, t.maxrecodecnt17, t.maxrecodecnt18, t.maxrecodecnt19, t.maxrecodecnt20, ");
				strcat(Sql, "t.maxrecodecnt21, t.maxrecodecnt22, t.maxrecodecnt23, t.maxrecodecnt24, t.maxrecodecnt25, t.maxrecodecnt26, t.maxrecodecnt27, t.maxrecodecnt28, t.maxrecodecnt29, t.maxrecodecnt30 ");
				strcat(Sql, "from config t");
			break;
		case 10://����
	      strcat(Sql, "insert into config(colltmaxrecode, alertmaxrecode, alarmmaxrecode, hoursmaxrecode, daysmaxrecode, atsinfomaxrecode, atsldgmaxrecode, colltstoremode, ");
	      strcat(Sql, "maxrecodecnt01, maxrecodecnt02, maxrecodecnt03, maxrecodecnt04, maxrecodecnt05, maxrecodecnt06, maxrecodecnt07, maxrecodecnt08, maxrecodecnt09, maxrecodecnt10, ");
	      strcat(Sql, "maxrecodecnt11, maxrecodecnt12, maxrecodecnt13, maxrecodecnt14, maxrecodecnt15, maxrecodecnt16, maxrecodecnt17, maxrecodecnt18, maxrecodecnt19, maxrecodecnt20, ");
	      strcat(Sql, "maxrecodecnt21, maxrecodecnt22, maxrecodecnt23, maxrecodecnt24, maxrecodecnt25, maxrecodecnt26, maxrecodecnt27, maxrecodecnt28, maxrecodecnt29, maxrecodecnt30)");
	      strcat(Sql, "values('");
	      strcat(Sql, colltmaxrecode);
	      strcat(Sql, "', '");
	      strcat(Sql, alertmaxrecode);
	      strcat(Sql, "', '");
	      strcat(Sql, alarmmaxrecode);
	      strcat(Sql, "', '");
	      strcat(Sql, hoursmaxrecode);
	      strcat(Sql, "', '");
	      strcat(Sql, daysmaxrecode);
	      strcat(Sql, "', '");
	      strcat(Sql, atsinfomaxrecode);
	      strcat(Sql, "', '");
	      strcat(Sql, atsldgmaxrecode);
	      strcat(Sql, "', '");
	      strcat(Sql, colltstoremode);
	      strcat(Sql, "', '");      
	      strcat(Sql, maxrecodecnt01);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt02);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt03);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt04);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt05);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt06);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt07);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt08);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt09);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt10);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt11);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt12);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt13);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt14);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt15);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt16);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt17);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt18);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt19);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt20);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt21);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt22);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt23);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt24);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt25);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt26);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt27);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt28);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt29);
	      strcat(Sql, "', '");
	      strcat(Sql, maxrecodecnt30);
	      strcat(Sql, "')");
			break;
		case 11://ɾ��
      	strcat(Sql, "delete from config");
			break;
		case 12://���ұ���
				strcat(Sql, "select name from sqlite_master where type='table' and (name like 'DATA_%' or name like 'data_%') and name <> 'sqlite_sequence' and name <> 'DATA_HOURAVG' and name <> 'DATA_NOW' and name <> 'DATA_TYPE' and name <> 'DATA_DAYSAVG' order by name");
			break;
	}
	return Sql;
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-ϵͳ����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html; charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/util.js'></script>\n");
	fprintf(cgiOut, "<style>\n");
	fprintf(cgiOut, "  html{height:100%%}\n");
	fprintf(cgiOut, "  body{height:100%%; margin:0px; padding:0px}\n");
	fprintf(cgiOut, "  #container{height:100%%}\n");
	fprintf(cgiOut, "  html,body{width:100%%; height:100%%; margin:0; padding:0;}\n");
	fprintf(cgiOut, "  .mesWindow{border:#C7C5C6 1px solid;background:#CADFFF;}\n");
	fprintf(cgiOut, "  .mesWindowTop{background:#3ea3f9;padding:5px;margin:0;font-weight:bold;text-align:left;font-size:12px; clear:both; line-height:1.5em; position:relative; clear:both;}\n");
	fprintf(cgiOut, "  .mesWindowTop span{ position:absolute; right:5px; top:3px;}\n");
	fprintf(cgiOut, "  .mesWindowContent{margin:4px;font-size:12px; clear:both;}\n");
	fprintf(cgiOut, "  .mesWindow .close{height:15px;width:28px; cursor:pointer;text-decoration:underline;background:#fff}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style='background:#CADFFF'>\n");
	fprintf(cgiOut, "<form name='config' action='config.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "<div id='down_bg_2'>\n");
	fprintf(cgiOut, "<div id='cap'><img src='../../skin/images/config.gif'/></div><br>\n");
	fprintf(cgiOut, "<div id='right_table_center'>\n");
	fprintf(cgiOut, "<table width='60%%' style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'> \n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right'>\n");
	fprintf(cgiOut, "      <img src='../skin/images/mini_button_cpm.gif'    style='cursor:hand;' onClick='doCPM()'/>\n");
	fprintf(cgiOut, "      <img src='../skin/images/mini_button_submit.gif' style='cursor:hand;' onClick='doEdit()'/>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "      <table width='100%%' border=1 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "          <td width='100%%'  align='center' colspan=2><B>����һ</B></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�ɼ���������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' >\n");
	fprintf(cgiOut, "            <input type='text' name='colltmaxrecode' style='width:80px;height:20px;' maxlength=3> ����\n");
	fprintf(cgiOut, "            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�洢ģʽ:\n");
	fprintf(cgiOut, "            <select id='colltstoremode' name='colltstoremode' style='width:100px;height:20px;'>\n");
	fprintf(cgiOut, "              <option value='0'>���ֱ�</option>\n");
	fprintf(cgiOut, "              <option value='1'>������Ѯ</option>\n");
	fprintf(cgiOut, "              <option value='2'>����</option>\n");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >ʱ��ͳ������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='hoursmaxrecode' style='width:80px;height:20px;' maxlength=3> ����</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�վ�ͳ������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='daysmaxrecode' style='width:80px;height:20px;' maxlength=3> ����</td>\n");
	fprintf(cgiOut, "        </tr>\n");	
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�澯��־����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='alertmaxrecode' style='width:80px;height:20px;' maxlength=3> ����</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >������־����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='alarmmaxrecode' style='width:80px;height:20px;' maxlength=3> ����</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >������ϸ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='atsinfomaxrecode' style='width:80px;height:20px;' maxlength=3> ����</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >����ͳ������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='atsldgmaxrecode' style='width:80px;height:20px;' maxlength=3> ����</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	fprintf(cgiOut, "        <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "          <td width='100%%'  align='center' colspan=2><B>���ö�</B></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >���û�����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt01' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >���豸����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt02' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >����������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt03' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�ܶ�������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt21' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >����������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt04' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�ܶ�ʱ��������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt05' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >��������������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt06' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	fprintf(cgiOut, "        <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "          <td width='100%%'  align='center' colspan=2><B>������</B></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >���緢�Ͷ�������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt07' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >������ն�������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt08' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�ͻ������緢�Ͷ�������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt09' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�ͻ���������ն�������</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt10' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	fprintf(cgiOut, "        <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "          <td width='100%%'  align='center' colspan=2><B>������</B></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >485-1������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt11' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >485-2������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt12' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >485-3������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt13' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >485-4������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt14' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >485-5������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt15' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >485-6������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt16' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >485-7������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt17' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >485-8������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt18' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >ADS������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt19' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >GSM������Ϣ����</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt20' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	fprintf(cgiOut, "        <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "          <td width='100%%'  align='center' colspan=2><B>������</B></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�����ֶζ�</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt22' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�����ֶ���</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt23' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�����ֶ���</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt24' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�����ֶ���</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt25' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�����ֶ���</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt26' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�����ֶ���</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt27' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�����ֶΰ�</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt28' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�����ֶξ�</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt29' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center' >�����ֶ�ʮ</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left' ><input type='text' name='maxrecodecnt30' style='width:80px;height:20px;' maxlength=8> ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'     value='10'>\n");
	fprintf(cgiOut, "<input type='hidden' name='oldmode' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='chgflag' value='0'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	//��������
	fprintf(cgiOut, "function doCPM()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ����������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'config.cgi?cmd=1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	//�༭
	fprintf(cgiOut, "function doEdit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(config.colltmaxrecode.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�ɼ���������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.colltmaxrecode.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.colltmaxrecode.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�ɼ������������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(config.hoursmaxrecode.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����дʱ��ͳ������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.hoursmaxrecode.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.hoursmaxrecode.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('ʱ��ͳ���������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(config.daysmaxrecode.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�վ�ͳ������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.daysmaxrecode.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.daysmaxrecode.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�վ�ͳ���������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(config.alertmaxrecode.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�澯��־����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.alertmaxrecode.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.alertmaxrecode.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�澯��־�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(config.alarmmaxrecode.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д������־����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.alarmmaxrecode.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.alarmmaxrecode.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('������־�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(config.atsinfomaxrecode.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д������ϸ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.atsinfomaxrecode.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.atsinfomaxrecode.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('������ϸ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(config.atsldgmaxrecode.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д����ͳ������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.atsldgmaxrecode.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.atsldgmaxrecode.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('����ͳ���������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt01.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д���û�����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt01.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt01.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('���û��������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt02.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д���豸����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt02.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt02.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('���豸�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt03.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д����������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt03.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt03.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�������������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt04.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д����������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt04.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt04.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�������������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt05.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�ܶ�ʱ��������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt05.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt05.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�ܶ�ʱ�����������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt06.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д��������������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt06.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt06.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����������������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt07.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д���緢�Ͷ�������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt07.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt07.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('���緢�Ͷ����������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt08.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д������ն�������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt08.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt08.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('������ն����������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt09.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�ͻ������緢�Ͷ�������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt09.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt09.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�ͻ������緢�Ͷ����������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt10.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�ͻ���������ն�������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt10.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt10.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�ͻ���������ն����������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt11.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д485-1������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt11.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt11.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('485-1������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt12.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д485-2������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt12.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt12.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('485-2������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt13.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д485-3������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt13.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt13.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('485-3������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt14.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д485-4������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt14.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt14.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('485-4������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt15.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д485-5������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt15.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt15.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('485-5������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt16.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д485-6������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt16.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt16.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('485-6������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt17.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д485-7������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt17.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt17.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('485-7������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt18.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д485-8������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt18.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt18.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('485-8������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt19.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����дADS������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt19.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt19.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('ADS������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt20.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����дGSM������Ϣ����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt20.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt20.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('GSM������Ϣ�������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt21.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�ܶ�������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt21.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt21.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�ܶ����������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt22.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�����ֶζ�!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt22.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt22.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����ֶζ����뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt23.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�����ֶ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt23.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt23.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����ֶ������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt24.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�����ֶ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt24.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt24.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����ֶ������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt25.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�����ֶ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt25.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt25.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����ֶ������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt26.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�����ֶ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt26.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt26.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����ֶ������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt27.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�����ֶ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt27.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt27.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����ֶ������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt28.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�����ֶΰ�!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt28.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt28.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����ֶΰ����뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt29.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�����ֶξ�!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt29.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt29.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����ֶξ����뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.maxrecodecnt30.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�����ֶ�ʮ!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<config.maxrecodecnt30.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(config.maxrecodecnt30.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����ֶ�ʮ���뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(config.oldmode.value == config.colltstoremode.value)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "  	 if(confirm('ȷ���ύ?'))\n");
	fprintf(cgiOut, "  	 {\n");
	fprintf(cgiOut, "    	 config.submit();\n");
	fprintf(cgiOut, "  	 }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var messContent = '';\n");
	fprintf(cgiOut, "    messContent += \"<div style='text-align:center;'>\";\n");
	fprintf(cgiOut, "    messContent += \"  <font color=red size=4><B>ע��</B></font>\";\n");
	fprintf(cgiOut, "    messContent += \"  <br>\";\n");
	fprintf(cgiOut, "    messContent += \"  �ɼ������Ĵ洢ģʽ�����仯����ȷ��ִ�У�\";\n");
	fprintf(cgiOut, "    messContent += \"  <br>\";\n");
	fprintf(cgiOut, "    messContent += \"  ��ϵͳ�Զ�ɾ��cpm.db�е�����DATA_YYYYMMDD���ݱ���\";\n");
	fprintf(cgiOut, "    messContent += \"  <br>\";\n");
	fprintf(cgiOut, "    messContent += \"  �������е������ݱ��ݣ��ٽ���ģʽ��������ѡ��:\";\n");
	fprintf(cgiOut, "    messContent += \"  <br>\";\n");
	fprintf(cgiOut, "    messContent += \"  <br>\";\n");
	fprintf(cgiOut, "    messContent += \"  <br>\";\n");
	fprintf(cgiOut, "    messContent += \"  <a href='#' onclick='doIO()'><font size=4><U>��������</U></font></a>\";\n");
	fprintf(cgiOut, "    messContent += \"  &nbsp;&nbsp;&nbsp;\";\n");
	fprintf(cgiOut, "    messContent += \"  <a href='#' onclick='doGO()'><font size=4><U>�����ύ</U></font></a>\";\n");
	fprintf(cgiOut, "    messContent += \"</div>\";\n");
	fprintf(cgiOut, "    showMessageBox('������ʾ', messContent , 400, 200);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doIO()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  window.parent.mainFrame.location = 'data_io.cgi?cmd=0';\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doGO()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  config.chgflag.value = '1';\n");
	fprintf(cgiOut, "  config.submit();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

//��ѯ����
int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{  
	cnt++;
	if(cnt > 0)
	{
		fprintf(cgiOut, "config.colltmaxrecode.value   = '%s';\n", col_values[0]);
		fprintf(cgiOut, "config.alertmaxrecode.value   = '%s';\n", col_values[1]);
		fprintf(cgiOut, "config.alarmmaxrecode.value   = '%s';\n", col_values[2]);
		fprintf(cgiOut, "config.hoursmaxrecode.value   = '%s';\n", col_values[3]);
		fprintf(cgiOut, "config.daysmaxrecode.value    = '%s';\n", col_values[4]);
		fprintf(cgiOut, "config.atsinfomaxrecode.value = '%s';\n", col_values[5]);
		fprintf(cgiOut, "config.atsldgmaxrecode.value  = '%s';\n", col_values[6]);
		fprintf(cgiOut, "config.oldmode.value          = '%s';\n", col_values[7]);
		fprintf(cgiOut, "var list = document.getElementById('colltstoremode').options;\n");
		fprintf(cgiOut, "for(var i=0; i<list.length; i++)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(list[i].value == '%s')\n", col_values[7]);
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    list[i].selected = true;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "config.maxrecodecnt01.value   = '%s';\n", col_values[8]);
		fprintf(cgiOut, "config.maxrecodecnt02.value   = '%s';\n", col_values[9]);
		fprintf(cgiOut, "config.maxrecodecnt03.value   = '%s';\n", col_values[10]);
		fprintf(cgiOut, "config.maxrecodecnt04.value   = '%s';\n", col_values[11]);
		fprintf(cgiOut, "config.maxrecodecnt05.value   = '%s';\n", col_values[12]);
		fprintf(cgiOut, "config.maxrecodecnt06.value   = '%s';\n", col_values[13]);
		fprintf(cgiOut, "config.maxrecodecnt07.value   = '%s';\n", col_values[14]);
		fprintf(cgiOut, "config.maxrecodecnt08.value   = '%s';\n", col_values[15]);
		fprintf(cgiOut, "config.maxrecodecnt09.value   = '%s';\n", col_values[16]);
		fprintf(cgiOut, "config.maxrecodecnt10.value   = '%s';\n", col_values[17]);
		fprintf(cgiOut, "config.maxrecodecnt11.value   = '%s';\n", col_values[18]);
		fprintf(cgiOut, "config.maxrecodecnt12.value   = '%s';\n", col_values[19]);
		fprintf(cgiOut, "config.maxrecodecnt13.value   = '%s';\n", col_values[20]);
		fprintf(cgiOut, "config.maxrecodecnt14.value   = '%s';\n", col_values[21]);
		fprintf(cgiOut, "config.maxrecodecnt15.value   = '%s';\n", col_values[22]);
		fprintf(cgiOut, "config.maxrecodecnt16.value   = '%s';\n", col_values[23]);
		fprintf(cgiOut, "config.maxrecodecnt17.value   = '%s';\n", col_values[24]);
		fprintf(cgiOut, "config.maxrecodecnt18.value   = '%s';\n", col_values[25]);
		fprintf(cgiOut, "config.maxrecodecnt19.value   = '%s';\n", col_values[26]);
		fprintf(cgiOut, "config.maxrecodecnt20.value   = '%s';\n", col_values[27]);
		fprintf(cgiOut, "config.maxrecodecnt21.value   = '%s';\n", col_values[28]);
		fprintf(cgiOut, "config.maxrecodecnt22.value   = '%s';\n", col_values[29]);
		fprintf(cgiOut, "config.maxrecodecnt23.value   = '%s';\n", col_values[30]);
		fprintf(cgiOut, "config.maxrecodecnt24.value   = '%s';\n", col_values[31]);
		fprintf(cgiOut, "config.maxrecodecnt25.value   = '%s';\n", col_values[32]);
		fprintf(cgiOut, "config.maxrecodecnt26.value   = '%s';\n", col_values[33]);
		fprintf(cgiOut, "config.maxrecodecnt27.value   = '%s';\n", col_values[34]);
		fprintf(cgiOut, "config.maxrecodecnt28.value   = '%s';\n", col_values[35]);
		fprintf(cgiOut, "config.maxrecodecnt29.value   = '%s';\n", col_values[36]);
		fprintf(cgiOut, "config.maxrecodecnt30.value   = '%s';\n", col_values[37]);
	}
	return 0;
}

void Updata()
{
	if(0 == strcmp(chgflag, "1"))
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *cpmdb = open_db(DB_PATH_BAK);
		rc = sqlite3_exec(cpmdb, getSql(12), &sqlite3_exec_callback_table, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		  err_msg(1);
		else
		{
			//ɾ��DATA_YYYYMMDD��
			char syscmd[4096*2] = {0};
			sprintf(syscmd, "sqlite3 %s \"%s\"", DB_PATH_BAK, tablelist);
			if(0 == system(syscmd))
			{
				//��ִ��DB����
				doDBOperater();
			}
			else
			{
				fprintf(cgiOut, "<script>alert('����ʧ��');</script>\n");
			}
		}
		sqlite3_close(cpmdb);
	}
	else
		doDBOperater();
}

int sqlite3_exec_callback_table(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat(tablelist, "drop table ");
	strcat(tablelist, col_values[0]);
	strcat(tablelist, ";");
	return 0;
}

void doDBOperater()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	rc = sqlite3_exec(db, getSql(11), NULL, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	
	rc = sqlite3_exec(db, getSql(10), NULL, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	
	sqlite3_close(db);
}

void doCPM()
{
	system("killall CPM");
	system("/home/CPM/CPM/startCPM.sh");
	fprintf(cgiOut, "<script language='javascript'>alert('���������ɹ�');</script>\n");
}
