#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"
#include <unistd.h>
#include <fcntl.h>

//��������
char cmd[4] = {0};
int cnt = 0;
char DBFlag[2]   = {0};
char DBName[64]  = {0};
char DBFile[256] = {0};

//��������
static void getHtmlData();
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static void doO();
static bool doI();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://����
					doO();
					break;
				case 2://����
					if(doI())
					{
						fprintf(cgiOut, "<script language='javascript'>alert('����ɹ�');</script>\n");
					}
					else
					{
						fprintf(cgiOut, "<script language='javascript'>alert('����ʧ��');</script>\n");
					}
					//��ѯ
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("DBFlag", DBFlag, sizeof(DBFlag));
	cgiFormString("DBName", DBName, sizeof(DBName));
	cgiFormString("DBFile", DBFile, sizeof(DBFile));
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<html>\n");
  fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<title>���´���������ƽ̨-���뵼��</title>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style='background:#CADFFF'>\n");
	fprintf(cgiOut, "<form name='data_io' action='data_io.cgi' method='post' target='mainFrame' enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "<div id='down_bg_2'>\n");
	fprintf(cgiOut, "<div id='cap'><img src='../skin/images/data_io.gif'/></div><br><br>\n");
	fprintf(cgiOut, "<div id='right_table_center'>\n");
	fprintf(cgiOut, "<table width='70%%' style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "  <tr height='30' class='table_blue'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=3><B>tmp.db���뵼��</B></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	int rc;
	char * zErrMsg = 0;
	char sql[256] = {0};
	strcat(sql, "select name from sqlite_master where type='table' and name <> 'sqlite_sequence' order by name");
	
	sqlite3 *tmpdb = open_db(DB_PATH);
	rc = sqlite3_exec(tmpdb, sql, &sqlite3_exec_callback, (char *)"1", &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(tmpdb);
	
	fprintf(cgiOut, "  <tr height='30' class='table_blue'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=3><B>cpm.db���뵼��</B></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	sqlite3 *cpmdb = open_db(DB_PATH_BAK);
	rc = sqlite3_exec(cpmdb, sql, &sqlite3_exec_callback, (char *)"2", &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(cpmdb);
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'    value='2'>\n");
	fprintf(cgiOut, "<input type='hidden' name='DBFlag' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='DBName' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='DBFile' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<script language=javascript>\n");
	fprintf(cgiOut, "function doO(pDB, pTable)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var currfirm = '';\n");
	fprintf(cgiOut, "  switch(parseInt(pDB))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "      currfirm = 'ȷ�ϴ�[tmp.db]�е���['+pTable+']��������ϸ?';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "      currfirm = 'ȷ�ϴ�[cpm.db]�е���['+pTable+']��������ϸ?';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm(currfirm))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqO = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqO = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqO.onreadystatechange = function()\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var state = reqO.readyState;\n");
	fprintf(cgiOut, "      if(state == 4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(reqO.status == 200)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Resp = reqO.responseText;\n");
	fprintf(cgiOut, "          if(null != Resp && Resp.substring(0, 4) == '0000')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            location.href = Resp.substring(4);\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          else\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    };\n");
	fprintf(cgiOut, "    var url = 'data_io.cgi?cmd=1&DBFlag='+pDB+'&DBName='+pTable+'&currtime='+new Date();\n");
	fprintf(cgiOut, "    reqO.open('GET',url,false);\n");
	fprintf(cgiOut, "    reqO.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doI(pDB, pTable, pIndex)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var currfirm = '';\n");
	fprintf(cgiOut, "  switch(parseInt(pDB))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "      if(document.getElementById('file'+pIndex).value.indexOf('tmp_' + pTable + '.dat') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('��ѡ����ȷ�ĵ����ļ�');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      currfirm = 'ȷ�ϴ�[tmp.db]�е����滻['+pTable+']��������ϸ?';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "      if(document.getElementById('file'+pIndex).value.indexOf('cpm_' + pTable + '.dat') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('��ѡ����ȷ�ĵ����ļ�');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      currfirm = 'ȷ�ϴ�[cpm.db]�е����滻['+pTable+']��������ϸ?';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  data_io.DBFlag.value = pDB;\n");
	fprintf(cgiOut, "  data_io.DBName.value = pTable;\n");
	fprintf(cgiOut, "  data_io.DBFile.value = pIndex;\n");
	fprintf(cgiOut, "  if(confirm(currfirm))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    data_io.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</html>\n");
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<tr height='30'>\n");
	fprintf(cgiOut, "  <td width='30%%' align='center'>%s</td>\n", col_values[0]);
	fprintf(cgiOut, "  <td width='20%%' align='center'>\n");
	fprintf(cgiOut, "    <input type='button' value='����' onclick=\"doO('%s', '%s')\">\n", (char *)data, col_values[0]);
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "  <td width='50%%' align='center'>\n");
	fprintf(cgiOut, "    <input type='file' id='file%d' name='file%d' title='��ѡ���ļ�' value='���' style='width:80%%;height:20px'>\n", cnt, cnt);
	fprintf(cgiOut, "    <input type='button' value='����' onclick=\"doI('%s', '%s', '%d')\">\n", (char *)data, col_values[0], cnt);
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "</tr>\n");
	cnt++;
	return 0;
}

void doO()
{
	//�����ԭ��ȫ��
	char syscmd[256] = {0};
	sprintf(syscmd, "rm -rf /home/www/system/file/*.dat");
	if(0 == system(syscmd))
	{
		//�����������ļ�
		switch(atoi(DBFlag))
		{
			case 1:
				memset(syscmd, 0, sizeof(syscmd));
				sprintf(syscmd, "sqlite3 %s \"select * from %s\" > /home/www/system/file/tmp_%s.dat", DB_PATH, DBName, DBName);
				break;
			case 2:
				memset(syscmd, 0, sizeof(syscmd));
				sprintf(syscmd, "sqlite3 %s \"select * from %s\" > /home/www/system/file/cpm_%s.dat", DB_PATH_BAK, DBName, DBName);
				break;
		}
		if(0 == system(syscmd))
			printf("0000file/%s_%s.dat\n", 0 == strcmp(DBFlag, "1")?"tmp":"cpm", DBName);
		else
			printf("3006\n");
	}
	else
	{
		printf("3006\n");
	}
}

bool doI()
{
	cgiFilePtr file;
	int targetFile;
	mode_t mode;
	char name[256];
	char buffer[10240];
	int got;
	
	char fimename[20] = {0};
	strcat(fimename, "file");
	strcat(fimename, DBFile);
	
	char fileNameOnServer[256] = {0};
	sprintf(fileNameOnServer, "/home/www/system/file/%s_%s.dit", 0 == strcmp(DBFlag, "1")?"tmp":"cpm", DBName);
	
	if(cgiFormFileName(fimename, name, sizeof(name)) != cgiFormSuccess)
	{
		//δ֪�ļ�
		return false;
	}
	
	if(cgiFormFileOpen(fimename, &file) != cgiFormSuccess)
	{
		//�ļ�����
		return false;
	}
	
	mode = S_IRWXU|S_IRGRP|S_IROTH;
	targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode);
	if(targetFile < 0)
	{
		//�ļ�����
		return false;
	}
	
	while(cgiFormFileRead(file, buffer, 10240, &got) == cgiFormSuccess)
	{
		if(got > 0)
		{
			write(targetFile, buffer, got);
		}
	}
	
	cgiFormFileClose(file);
	close(targetFile);
	
	//�������
	char syscmd[256] = {0};
	sprintf(syscmd, "sqlite3 %s \"delete from %s\"", 0 == strcmp(DBFlag, "1")?DB_PATH:DB_PATH_BAK, DBName);
	if(0 != system(syscmd))
		return false;
	
	//�����ļ�
	memset(syscmd, 0, sizeof(syscmd));
	sprintf(syscmd, "sqlite3 %s \".import /home/www/system/file/%s_%s.dit %s\"", 0 == strcmp(DBFlag, "1")?DB_PATH:DB_PATH_BAK, 0 == strcmp(DBFlag, "1")?"tmp":"cpm", DBName, DBName);
	if(0 != system(syscmd))
		return false;
		
	//ɾ���ļ�
	memset(syscmd, 0, sizeof(syscmd));
	sprintf(syscmd, "rm -rf /home/www/system/file/%s_%s.dit", 0 == strcmp(DBFlag, "1")?"tmp":"cpm", DBName);
	system(syscmd);
	return true;
}
