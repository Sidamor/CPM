#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

//��������
char Sql[1024] = {0};
char cmd[4] = {0};
char pro_seq[21] = {0};  //��Ʒ���к�
char pro_ver[21] = {0};  //��Ʒ�汾��
char pro_agt[65] = {0};  //��Ʒ����
char pro_cat[21] = {0};  //��ϵ��ʽ
char pro_date[11]= {0};  //��ֹ����
char pro_sim[20] = {0};  //��ƷIMSI
char pro_tel[13] = {0};  //��Ʒ����
char is_ctrl[2]  = {0};  //������Ч
char is_gsm[2]   = {0};  //���Ż�ִ

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ
static void QueryData();
static void doSet();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);	
	switch(ret)
	{
		case 0:
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://����
					doSet();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("pro_seq", pro_seq, sizeof(pro_seq));
	cgiFormString("pro_ver", pro_ver, sizeof(pro_ver));
	cgiFormString("pro_agt", pro_agt, sizeof(pro_agt));
	cgiFormString("pro_cat", pro_cat, sizeof(pro_cat));
	cgiFormString("pro_date", pro_date, sizeof(pro_date));
	cgiFormString("pro_sim", pro_sim, sizeof(pro_sim));
	cgiFormString("pro_tel", pro_tel, sizeof(pro_tel));
	cgiFormString("is_ctrl", is_ctrl, sizeof(is_ctrl));
	cgiFormString("is_gsm", is_gsm, sizeof(is_gsm));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      	strcat(Sql, "select t.pro_seq, t.pro_ver, t.pro_agt, t.pro_cat, t.pro_date, t.pro_sim, t.pro_tel, t.is_ctrl, t.is_gsm from pro_ctrl t");
			break;
		case 10://ɾ��
        strcat(Sql, "delete from pro_ctrl");
			break;
		case 11://����
				strcat(Sql, "insert into pro_ctrl(pro_seq, pro_ver, pro_agt, pro_cat, pro_date, pro_sim, pro_tel, is_ctrl, is_gsm)values('");
        strcat(Sql, pro_seq);
				strcat(Sql, "', '");
				strcat(Sql, pro_ver);
				strcat(Sql, "', '");
				strcat(Sql, pro_agt);
				strcat(Sql, "', '");
				strcat(Sql, pro_cat);
				strcat(Sql, "', '");
				strcat(Sql, pro_date);
				strcat(Sql, "', '");
				strcat(Sql, pro_sim);
				strcat(Sql, "', '");
				strcat(Sql, pro_tel);
				strcat(Sql, "', '");
				strcat(Sql, is_ctrl);
				strcat(Sql, "', '");
				strcat(Sql, is_gsm);
				strcat(Sql, "')");
			break;
	}
	return Sql;
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML>\n");
  fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>��Ʒ����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"pro_ctrl\" action=\"pro_ctrl.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/pro_ctrl.gif\"/></div><br><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"70%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right'>\n");
	fprintf(cgiOut, "      <img src='../skin/images/mini_button_submit.gif' style='cursor:hand;' onClick='doSet()'/>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "      <table width=\"100%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "        		<td width='30%%' align=center>��Ʒ���к�</td>\n");
	fprintf(cgiOut, "        		<td width='70%%' align=left>\n");
	fprintf(cgiOut, "        		  <input type='text' id='pro_seq' name='pro_seq' style='width:96%%;height:20px;' maxlength='20'>\n");
	fprintf(cgiOut, "       	  </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "        		<td width='30%%' align=center>��Ʒ�汾��</td>\n");
	fprintf(cgiOut, "        		<td width='70%%' align=left>\n");
	fprintf(cgiOut, "        		  <input type='text' id='pro_ver' name='pro_ver' style='width:96%%;height:20px;' maxlength='20'>\n");
	fprintf(cgiOut, "       	  </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "        		<td width='30%%' align=center>��Ʒ����</td>\n");
	fprintf(cgiOut, "        		<td width='70%%' align=left>\n");
	fprintf(cgiOut, "        		  <input type='text' id='pro_agt' name='pro_agt' style='width:96%%;height:20px;' maxlength='32'>\n");
	fprintf(cgiOut, "       	  </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "        		<td width='30%%' align=center>��ϵ��ʽ</td>\n");
	fprintf(cgiOut, "        		<td width='70%%' align=left>\n");
	fprintf(cgiOut, "        		  <input type='text' id='pro_cat' name='pro_cat' style='width:96%%;height:20px;' maxlength='20'>\n");
	fprintf(cgiOut, "       	  </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "        		<td width='30%%' align=center>��ֹ����</td>\n");
	fprintf(cgiOut, "        		<td width='70%%' align=left>\n");
	fprintf(cgiOut, "        		  <input type='text' id='pro_date' name='pro_date' onClick='WdatePicker({readOnly:true})' class='Wdate' size='10' maxlength='10' style='width:90px;'>\n");
	fprintf(cgiOut, "       	  </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "        		<td width='30%%' align=center>��ƷIMSI</td>\n");
	fprintf(cgiOut, "        		<td width='70%%' align=left>\n");
	fprintf(cgiOut, "        		  <input type='text' id='pro_sim' name='pro_sim' style='width:96%%;height:20px;' maxlength='16'>\n");
	fprintf(cgiOut, "       	  </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "        		<td width='30%%' align=center>��Ʒ����</td>\n");
	fprintf(cgiOut, "        		<td width='70%%' align=left>\n");
	fprintf(cgiOut, "        		  <input type='text' id='pro_tel' name='pro_tel' style='width:96%%;height:20px;' maxlength='12'>\n");
	fprintf(cgiOut, "       	  </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "        		<td width='30%%' align=center>������Ч</td>\n");
	fprintf(cgiOut, "        		<td width='70%%' align=left>\n");
	fprintf(cgiOut, "            <select id='is_ctrl' name='is_ctrl' style='width:90px;height:20px;'>\n");
	fprintf(cgiOut, "              <option value='0'>��</option>\n");
	fprintf(cgiOut, "              <option value='1'>��</option>\n");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "       	  </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "        		<td width='30%%' align=center>���Ż�ִ</td>\n");
	fprintf(cgiOut, "        		<td width='70%%' align=left>\n");
	fprintf(cgiOut, "            <select id='is_gsm' name='is_gsm' style='width:90px;height:20px;'>\n");
	fprintf(cgiOut, "              <option value='0'>�ر�</option>\n");
	fprintf(cgiOut, "              <option value='1'>����</option>\n");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "       	  </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='1'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(2);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "function doSet()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(pro_ctrl.pro_seq.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д��Ʒ���к�')\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(pro_ctrl.pro_ver.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д��Ʒ�汾��')\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(pro_ctrl.pro_agt.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д��Ʒ����')\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(pro_ctrl.pro_cat.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д��ϵ��ʽ')\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('��Ϣ����ȷ���ύ?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    pro_ctrl.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "document.getElementById('pro_seq').value = '%s';\n", col_values[0]);
	fprintf(cgiOut, "document.getElementById('pro_ver').value = '%s';\n", col_values[1]);
	fprintf(cgiOut, "document.getElementById('pro_agt').value = '%s';\n", col_values[2]);
	fprintf(cgiOut, "document.getElementById('pro_cat').value = '%s';\n", col_values[3]);
	fprintf(cgiOut, "document.getElementById('pro_date').value = '%s';\n", col_values[4]);
	fprintf(cgiOut, "document.getElementById('pro_sim').value = '%s';\n", col_values[5]);
	fprintf(cgiOut, "document.getElementById('pro_tel').value = '%s';\n", col_values[6]);
	fprintf(cgiOut, "var list = document.getElementById('is_ctrl').options;\n");
	fprintf(cgiOut, "for(var i=0; i<list.length; i++)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(list[i].value == '%s')\n", col_values[7]);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    list[i].selected = true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "var list = document.getElementById('is_gsm').options;\n");
	fprintf(cgiOut, "for(var i=0; i<list.length; i++)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(list[i].value == '%s')\n", col_values[8]);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    list[i].selected = true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	return 0;
}

void doSet()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	//ɾ��
	rc = sqlite3_exec(db, getSql(10), NULL, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	
	//����
	rc = sqlite3_exec(db, getSql(11), NULL, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	
	sqlite3_close(db);
}
