#include <stdio.h>
#include <string.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <stdlib.h>
#include <unistd.h>    
#include <fcntl.h>
#include "util.h"

//��������
char Sql[4096*8] = {0};
char sql[4096*8] = {0};
int cnt = 0;
char cmd[4] = {0};
char agentid[5] = {0};
char uploadflag[2] = {0};
char uploadret[2] = {0};

//��device_info
char id[7] = {0};					      //����(3)+����(1)+���(2)
char cname[51] = {0};		        //����
char icon[61] = {0};			      //��ͼ�洢(����)
char s_icon[61] ={0};           //Сͼ�洢(����)
char r_icon[61] ={0};           //��ͼ�洢(�쳣)
char g_icon[61] ={0};           //��ͼ�洢(����)
char b_icon[61] ={0};           //��ͼ�洢(����)
char c_icon[61] ={0};           //��ͼ�洢(��)
char o_icon[61] ={0};           //��ͼ�洢(��)
char composition[4096*8] = {0}; //�豸�ӿ�����
char private_attr[256] = {0};		//˽������
char channel_type[128] = {0};   //�ӿ�����
char agentname[51] = {0};       //��������
char ctype1[3] = {0};           //����1
char ctype2[3] = {0};           //����2
char ctype3[5] = {0};           //����3
char status[2] = {0};           //״̬
char mode_list[512] = {0};      //ģʽ
char dev_type[2] = {0};         //����(��ֵ��˫ֵ����ֵ������������)
char idlist[2048] = {0};			  //���������豸�б�

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_agent(void *data, int n_columns, char **col_values, char **col_names);
//������ѯ
static void QueryDataSingle();
static int sqlite3_exec_callback_single(void *data, int n_columns, char **col_values, char **col_names);
//��������
static void UpdateData();
//���Ӳ�ѯ
static void QueryDataForAdd();
static int sqlite3_exec_callback_foradd(void *data, int n_columns, char **col_values, char **col_names);
//����
static void AddData();
static int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names);
//ɾ��
static void DeleteData();
//ͼƬ�ϴ�
static void ImgUpload(char *flag);
//���ƹ���
static void DevCopy();
static void DevCopyTrue();
//��������
static void PL_Sta();
static void PL_StaTrue();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://������ѯ
					QueryDataSingle();
					break;
				case 2://���Ӳ�ѯ
					QueryDataForAdd();
					break;
				case 3://ͼƬ����
					ImgUpload(uploadflag);
					if(0 == strcmp(uploadret, "1"))
					{
						fprintf(cgiOut, "<script language='javascript'>alert('ͼƬ�����ϴ�ʧ�ܣ�����100K����!');</script>\n");
					}
					sprintf(cmd, "%s", "1");
					QueryDataSingle();
					break;
				case 4://���ƹ���
					DevCopy();
					break;
				case 5://���ƹ���
					DevCopyTrue();
					break;
				case 6://��������
					PL_Sta();
					break;
				case 7://��������
					PL_StaTrue();
					break;
				case 10://����
					AddData();
					if(cnt == 1)
					{
						QueryDataForAdd();
					}
					else
					{
						sprintf(cmd, "%s", "0");
						QueryData();
						if(0 == strcmp(uploadret, "1"))
						{
							fprintf(cgiOut, "<script language='javascript'>alert('ͼƬ�����ϴ�ʧ�ܣ�����100K����!');</script>\n");
						}
					}
					break;
				case 11://����
					UpdateData();
					sprintf(cmd, "%s", "1");
					QueryDataSingle();
					break;
				case 12://ɾ��
					DeleteData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}	
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{ 
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("icon", icon, sizeof(icon));
	cgiFormString("s_icon", s_icon, sizeof(s_icon));
	cgiFormString("r_icon", r_icon, sizeof(r_icon));
	cgiFormString("g_icon", g_icon, sizeof(g_icon));
	cgiFormString("b_icon", b_icon, sizeof(b_icon));
	cgiFormString("c_icon", c_icon, sizeof(c_icon));
	cgiFormString("o_icon", o_icon, sizeof(o_icon));
	cgiFormString("composition", composition, sizeof(composition));
	cgiFormString("private_attr", private_attr, sizeof(private_attr));
	cgiFormString("channel_type", channel_type, sizeof(channel_type));
	cgiFormString("ctype1", ctype1, sizeof(ctype1));
	cgiFormString("ctype2", ctype2, sizeof(ctype2));
	cgiFormString("ctype3", ctype3, sizeof(ctype3));
	cgiFormString("status", status, sizeof(status));
	cgiFormString("mode_list", mode_list, sizeof(mode_list));
	cgiFormString("dev_type", dev_type, sizeof(dev_type));
	cgiFormString("idlist", idlist, sizeof(idlist));
	
	cgiFormString("agentname", agentname, sizeof(agentname));
	cgiFormString("agentid", agentid, sizeof(agentid));
	cgiFormString("uploadflag", uploadflag, sizeof(uploadflag));	
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0://��ѯ	
      strcat(Sql, "select t.id, t.cname, t.icon, t.s_icon, t.composition, t.private_attr, a.brief, t.channel_type, t.ctype1, t.ctype2, t.ctype3, t.status, t.mode_list, t.r_icon, t.g_icon, t.b_icon, t.dev_type, t.c_icon, t.o_icon from device_info t, manufacturer a where substr(t.id,1,3) = a.id and a.id like '");
      strcat(Sql, agentid);
      strcat(Sql, "%' order by t.id");
			break;
		case 1://���̲�ѯ
			strcat(Sql, "select t.id, t.brief, t.cname, t.addr, t.tel, t.contact from manufacturer t order by t.id");
			break;
		case 3://����idΨһ��֤
      strcat(Sql, "select t.id, t.cname, t.icon, t.s_icon, t.composition, t.private_attr, a.brief, t.channel_type, t.ctype1, t.ctype2, t.ctype3, t.status, t.mode_list, t.r_icon, t.g_icon, t.b_icon, t.dev_type, t.c_icon, t.o_icon from device_info t, manufacturer a where substr(t.id,1,3) = a.id and t.id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 10://����
			strcat(Sql, "insert into device_info(id, cname, composition, private_attr, channel_type, ctype1, ctype2, ctype3, status, mode_list, dev_type)values('");
			strcat(Sql, id);
			strcat(Sql, "', '");
      strcat(Sql, cname);
			strcat(Sql, "', '");
			strcat(Sql, composition);
			strcat(Sql, "', '");
			strcat(Sql, private_attr);
			strcat(Sql, "', '");
			strcat(Sql, channel_type);
			strcat(Sql, "', '");
			strcat(Sql, ctype1);
			strcat(Sql, "', '");
			strcat(Sql, ctype2);
			strcat(Sql, "', '");
			strcat(Sql, ctype3);
			strcat(Sql, "', '");
			strcat(Sql, status);
			strcat(Sql, "', '");
			strcat(Sql, mode_list);
			strcat(Sql, "', '");
			strcat(Sql, dev_type);
			strcat(Sql, "')");
			break;
		case 11://����
			strcat(Sql, "update device_info set cname = '");
      strcat(Sql, cname);
			strcat(Sql, "', composition = '");
      strcat(Sql, composition);
			strcat(Sql, "', private_attr = '");
      strcat(Sql, private_attr);
      strcat(Sql, "', channel_type = '");
      strcat(Sql, channel_type);
      strcat(Sql, "', ctype1 = '");
      strcat(Sql, ctype1);
      strcat(Sql, "', ctype2 = '");
      strcat(Sql, ctype2);
      strcat(Sql, "', ctype3 = '");
      strcat(Sql, ctype3);
      strcat(Sql, "', status = '");
      strcat(Sql, status);
      strcat(Sql, "', mode_list = '");
      strcat(Sql, mode_list);
      strcat(Sql, "', dev_type = '");
      strcat(Sql, dev_type);
      strcat(Sql, "' where id = '");
      strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 12://ɾ���豸��Ϣ
			strcat(Sql, "delete from device_info where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 13://ɾ���ɼ�����
			strcat(Sql, "delete from device_attr where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 14://ɾ����������
			strcat(Sql, "delete from device_cmd where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 15://��ͼ����(����)
			strcat(Sql, "update device_info set icon = '");
      strcat(Sql, icon);
      strcat(Sql, "' where id = '");
      strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 16://Сͼ����(����)
			strcat(Sql, "update device_info set s_icon = '");
      strcat(Sql, icon);
      strcat(Sql, "' where id = '");
      strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 17://��ͼ����(�쳣)
			strcat(Sql, "update device_info set r_icon = '");
      strcat(Sql, icon);
      strcat(Sql, "' where id = '");
      strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 18://��ͼ����(����)
			strcat(Sql, "update device_info set g_icon = '");
      strcat(Sql, icon);
      strcat(Sql, "' where id = '");
      strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 19://��ͼ����(����)
			strcat(Sql, "update device_info set b_icon = '");
      strcat(Sql, icon);
      strcat(Sql, "' where id = '");
      strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 20://��ͼ����(��)
			strcat(Sql, "update device_info set c_icon = '");
      strcat(Sql, icon);
      strcat(Sql, "' where id = '");
      strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 21://��ͼ����(��)
			strcat(Sql, "update device_info set o_icon = '");
      strcat(Sql, icon);
      strcat(Sql, "' where id = '");
      strcat(Sql, id);
			strcat(Sql, "'");
			break;
			
	}
	return Sql;
}

//��ѯ
void QueryData()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>�豸��Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/style.css'    rel='stylesheet'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/subModal.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/common.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/subModal.js'></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"device_info\" action=\"device_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "  <div id=\"cap\"><img src=\"../skin/images/device_info.gif\"/></div><br>\n");
	fprintf(cgiOut, "  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "    <table width=\"80%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='left'>\n");
	fprintf(cgiOut, "        <select id='agentid' name='agentid' style='width:120px;height:20px;' onchange='doSelect()'>\n");
	
	if(0 == strlen(agentid))
	{
		fprintf(cgiOut, "        <option value='' selected>ȫ��</option>\n");
	}
	else
	{
		fprintf(cgiOut, "        <option value=''>ȫ��</option>\n");
	}
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_agent, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='right' colspan=4>\n");
	fprintf(cgiOut, "        <img src='../skin/images/pl_status.gif'       style='cursor:hand;' onClick='doPls()'/>\n");
	fprintf(cgiOut, "        <img src='../skin/images/mini_button_add.gif' style='cursor:hand;' onClick='doAdd()'/>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right' colspan=5>\n");
	fprintf(cgiOut, "        <table width=\"100%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "          <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "            <td width=\"5%%\"  class=\"table_deep_blue\"><input type='checkbox' id='All' name='All' value='0' onClick='selectAll()' title='ȫѡ'/></td>\n");
	fprintf(cgiOut, "            <td width=\"10%%\" class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "            <td width=\"18%%\" class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "            <td width=\"12%%\" class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "            <td width=\"10%%\" class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "            <td width=\"10%%\" class=\"table_deep_blue\">�ɼ�����</td>\n");
	fprintf(cgiOut, "            <td width=\"10%%\" class=\"table_deep_blue\">��������</td>\n");
	fprintf(cgiOut, "            <td width=\"10%%\" class=\"table_deep_blue\">ɾ ��</td>\n");
	fprintf(cgiOut, "            <td width=\"10%%\" class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "          </tr>\n");
	
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//��ѯ
	fprintf(cgiOut, "function doSelect()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'device_info.cgi?cmd=0&agentid='+device_info.agentid.value;\n");
	fprintf(cgiOut, "}\n");
	//��������/ע��
	fprintf(cgiOut, "function selectAll()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  for(var i=1; i<=%d; i++)\n", cnt);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('cbx'+i).checked = document.getElementById('All').checked;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doPls()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var IdList = '';\n");
	fprintf(cgiOut, "  for(var i=1; i<=%d; i++)\n", cnt);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('cbx'+i).checked)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      IdList += document.getElementById('cbx'+i).value + ',';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(IdList.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ѡ��Ҫ�����������豸��Ϣ!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(IdList.length > 700)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ѡ�����������100�������������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var url = 'device_info.cgi?cmd=6&idlist='+IdList+'&agentid=%s';\n", agentid);
	fprintf(cgiOut, "  showPopWin('', url, 360, 80, null, true, false);\n");
	fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'device_info.cgi?cmd=2&agentid=%s';\n", agentid);
	fprintf(cgiOut, "}\n");
	//�ɼ�����
	fprintf(cgiOut, "function doCollectAttr(pId, pCName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'device_attr.cgi?cmd=0&id='+pId+'&cname='+pCName+'&agentid=%s';\n", agentid);
	fprintf(cgiOut, "}\n");
	//��������
	fprintf(cgiOut, "function doDeviceCmd(pId, pCName, pMode_List)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'device_cmd.cgi?cmd=0&id='+pId+'&cname='+pCName+'&mode_list='+pMode_List+'&agentid=%s';\n", agentid);
	fprintf(cgiOut, "}\n");
	//ɾ��
	fprintf(cgiOut, "function doDelete(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ɾ��ʱ,�ɼ���������������Ƚ�һ��ɾ��,ȷ��?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'device_info.cgi?cmd=12&id='+pId+'&agentid=%s';\n", agentid);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doCopy(pId, pCName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var url = 'device_info.cgi?cmd=4&id='+pId+'&cname='+pCName+'&agentid=%s';\n", agentid);
	fprintf(cgiOut, "  showPopWin(pCName, url, 360, 200, null, true, false);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_agent(void *data, int n_columns, char **col_values, char **col_names)
{
	if(0 != strlen(agentid) && 0 == strcmp(col_values[0], agentid))
	{
		fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", col_values[0], col_values[1]);
	}
	else
	{
		fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	}
	return 0;
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(cnt%2 == 0)
	{
		fprintf(cgiOut, "<tr class='table_blue' height='30' valign='middle'>\n");
	}
	else
	{
		fprintf(cgiOut, "<tr class='table_white_l' height='30' valign='middle'>\n");
	}
	
	char ctypename[60] = {0};
	switch(atoi(col_values[16]))
	{
		case 0:
				strcat(ctypename, "�����");
			break;
		case 1:
				strcat(ctypename, "��ֵ��");
			break;
		case 2:
				strcat(ctypename, "��ֵ��");
			break;
		case 3:
				strcat(ctypename, "��ֵ��");
			break;
		case 4:
				strcat(ctypename, "������");
			break;
		case 5:
				strcat(ctypename, "������");
			break;
	}
	
	fprintf(cgiOut, "  <td %s align='center'><input type='checkbox' name='cbx%d' id='cbx%d' value='%s'></td>\n", 0 == strcmp(col_values[11], "0")?"class='font_gray'":"", cnt, cnt, col_values[0]);
	fprintf(cgiOut, "  <td %s align='center' style='cursor:hand;color:red;' title='�����ѯ��ϸ��Ϣ' ><a href='device_info.cgi?cmd=1&id=%s&agentid=%s' target='mainFrame'><font color=red>%s</font></a></td>\n", 0 == strcmp(col_values[11], "0")?"class='font_gray'":"", col_values[0], agentid, col_values[0]);
	fprintf(cgiOut, "  <td %s align='left'>%s</td>\n", 0 == strcmp(col_values[11], "0")?"class='font_gray'":"", col_values[1]);	
	fprintf(cgiOut, "  <td %s align='left'>%s</td>\n", 0 == strcmp(col_values[11], "0")?"class='font_gray'":"", col_values[6]);
	fprintf(cgiOut, "  <td %s align='center'>%s</td>\n", 0 == strcmp(col_values[11], "0")?"class='font_gray'":"", ctypename);
	fprintf(cgiOut, "  <td %s align='center' style='cursor:hand;color:red;' title='�����ѯ�ɼ�����' onClick='doCollectAttr(\"%s\", \"%s\")'>�ɼ�����</td>\n", 0 == strcmp(col_values[11], "0")?"class='font_gray'":"", col_values[0], col_values[1]);
	fprintf(cgiOut, "  <td %s align='center' style='cursor:hand;color:red;' title='�����ѯ��������' onClick='doDeviceCmd(\"%s\", \"%s\", \"%s\")'>��������</td>\n", 0 == strcmp(col_values[11], "0")?"class='font_gray'":"", col_values[0], col_values[1], col_values[12]);
	fprintf(cgiOut, "  <td %s align='center' style='cursor:hand;color:red;' title='���ɾ��' onClick='doDelete(\"%s\")'>ɾ ��</td>\n", 0 == strcmp(col_values[11], "0")?"class='font_gray'":"", col_values[0]);
	fprintf(cgiOut, "  <td %s align='center' style='cursor:hand;color:red;' title='�������' onClick='doCopy(\"%s\", \"%s\")'>�� ��</td>\n", 0 == strcmp(col_values[11], "0")?"class='font_gray'":"", col_values[0], col_values[1]);
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

//��������
void PL_Sta()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<title>���ƹ���</title>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style='background:#CADFFF'>\n");
	fprintf(cgiOut, "<form name='device_info' action='device_info.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "  <table width='100%%' style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "    <tr height='40px'>\n");
	fprintf(cgiOut, "      <td width='50%%' align='center'>\n");
	fprintf(cgiOut, "        <input type='radio' id='radio1' name='radio1' value='1' onClick=\"doChange('1');\">ͳһ����\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='50%%' align='center'>\n");
	fprintf(cgiOut, "        <input type='radio' id='radio2' name='radio2' value='2' onClick=\"doChange('2');\">ͳһע��\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='39px'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='center' colspan=2>\n");
	fprintf(cgiOut, "        <img style='cursor:hand' src='../skin/images/mini_button_submit.gif' onclick='doPL_Sta()'>\n");
	fprintf(cgiOut, "        <img style='cursor:hand' src='../skin/images/button10.gif'           onclick='doReturn()'>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.hidePopWin(false);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doChange(pSelected)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  switch(parseInt(pSelected))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "      device_info.radio1.checked = true;\n");
	fprintf(cgiOut, "      device_info.radio2.checked = false;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "      device_info.radio1.checked = false;\n");
	fprintf(cgiOut, "      device_info.radio2.checked = true;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doPL_Sta()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var status = '';\n");
	fprintf(cgiOut, "  if(false == device_info.radio1.checked && false == device_info.radio2.checked)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ѡ�����״̬!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_info.radio1.checked)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    status = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_info.radio2.checked)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    status = '0';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqPlSta = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqPlSta = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqPlSta.onreadystatechange = function()\n");
	fprintf(cgiOut, "  	 {\n");
	fprintf(cgiOut, "    	 var state = reqPlSta.readyState;\n");
	fprintf(cgiOut, "      if(state == 4)\n");
	fprintf(cgiOut, "    	 {\n");
	fprintf(cgiOut, "      	 var resp = reqPlSta.responseText;\n");
	fprintf(cgiOut, "        if(null != resp && resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('�ɹ�');\n");
	fprintf(cgiOut, "          parent.location = 'device_info.cgi?cmd=0&agentid=%s';\n", agentid);
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('ʧ��,�����²���');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    };\n");
	fprintf(cgiOut, "    var url = 'device_info.cgi?cmd=7&idlist=%s&status='+status+'&agentid=%s&currtime='+new Date();\n", idlist, agentid);
	fprintf(cgiOut, "    reqPlSta.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqPlSta.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqPlSta.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</html>\n");
}

void PL_StaTrue()
{
	char sql1[4096] = {0};
	sprintf(sql1, "update device_info set status = '%s' where contain('%s', id) = 1", status, idlist);
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
	rc = sqlite3_exec(db, sql1, NULL, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		printf("3006\n");
	}
	else
	{
		printf("0000\n");
	}
	sqlite3_close(db);
}

//���ƹ���
void DevCopy()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<title>���ƹ���</title>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style='background:#CADFFF'>\n");
	fprintf(cgiOut, "<form name='device_info' action='device_info.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "  <table width='100%%' style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "    <tr height='40px'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>Դ �� ��</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'>%s</td>\n", id);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='40px'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>Դ �� ��</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'>%s</td>\n", cname);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='40px'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>�½����</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "        <select id='agentid' name='agentid' style='width:120px;height:20px;'>\n");
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_agent, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "        <input type='text' name='id' value='' style='width:100px;height:20px;' maxlength=2>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='40px'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>�½�����</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "        <input type='text' name='cname' value='' style='width:224px;height:20px;' maxlength=20>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='39px'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='center' colspan=2>\n");
	fprintf(cgiOut, "        <img style='cursor:hand' src='../skin/images/mini_button_submit.gif' onclick='doReCopy()'>\n");
	fprintf(cgiOut, "        <img style='cursor:hand' src='../skin/images/button10.gif'           onclick='doReturn()'>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.hidePopWin(false);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doReCopy()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_info.agentid.value.length < 1){alert('�������ӳ�����Ϣ');return;}\n");
	fprintf(cgiOut, "  if(device_info.id.value.length < 1){alert('������ 01-99 �����λ���');return;}\n");
	fprintf(cgiOut, "  if(device_info.cname.value.length < 1){alert('����������');return;}\n");
	fprintf(cgiOut, "  var id = device_info.agentid.value + '1' + device_info.id.value;\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqCopy = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqCopy = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqCopy.onreadystatechange = function()\n");
	fprintf(cgiOut, "  	 {\n");
	fprintf(cgiOut, "    	 var state = reqCopy.readyState;\n");
	fprintf(cgiOut, "      if(state == 4)\n");
	fprintf(cgiOut, "    	 {\n");
	fprintf(cgiOut, "      	 var resp = reqCopy.responseText;\n");
	fprintf(cgiOut, "        if(null != resp && resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('�ɹ�');\n");
	fprintf(cgiOut, "          parent.location = 'device_info.cgi?cmd=0&agentid='+device_info.agentid.value;\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else if(null != resp && resp.indexOf('3006') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('��ǰ����Ѵ��ڣ������¶���!');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('ʧ��,�����²���');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    };\n");
	fprintf(cgiOut, "    var url = 'device_info.cgi?cmd=5&copyid=%s&id='+id+'&cname='+device_info.cname.value+'&agentid='+device_info.agentid.value+'&currtime='+new Date();\n", id);
	fprintf(cgiOut, "    reqCopy.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqCopy.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqCopy.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</html>\n");
}

void DevCopyTrue()
{
	char copyid[7] = {0};
	cgiFormString("copyid", copyid, sizeof(copyid));
	
	//�ж�idΨһ��
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(3), &sqlite3_exec_callback_add, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(2);
	}
	else
	{
		if(cnt == 0)
		{
			//�豸��Ϣ
			char copysql[1024] = {0};
			sprintf(copysql, "insert into device_info(id, cname, composition, private_attr, channel_type, ctype1, ctype2, ctype3, status, mode_list, dev_type)select '%s', '%s', a.composition, a.private_attr, a.channel_type, a.ctype1, a.ctype2, a.ctype3, a.status, a.mode_list, a.dev_type from device_info a where a.id = '%s'", id, cname, copyid);
			rc = sqlite3_exec(db, copysql, NULL, 0, &zErrMsg);
			if(rc != SQLITE_OK)
			{
				err_msg(2);
			}
			else
			{
				//�ɼ�����
				memset(copysql, 0, sizeof(copysql));
				sprintf(copysql, "insert into device_attr(id, sn, attr_id, attr_name, r_format, rd_format, rd_comparison_table, ck_format, private_attr, s_define, value_limit, ctype, ledger, card)select '%s', a.sn, a.attr_id, a.attr_name, a.r_format, a.rd_format, a.rd_comparison_table, a.ck_format, a.private_attr, a.s_define, a.value_limit, a.ctype, a.ledger, a.card from device_attr a where a.id = '%s' order by a.sn", id, copyid);
				rc = sqlite3_exec(db, copysql, NULL, 0, &zErrMsg);
				
				//��������
				memset(copysql, 0, sizeof(copysql));
				sprintf(copysql, "insert into device_cmd(id, sn, cmdname, object, w_format, wd_format, wd_comparison_table, ck_format, private_attr, ctype, flag, flag2, flag3, b_sn, n_sn, flag1, cmd_type)select '%s', a.sn, a.cmdname, a.object, a.w_format, a.wd_format, a.wd_comparison_table, a.ck_format, a.private_attr, a.ctype, a.flag, a.flag2, a.flag3, a.b_sn, a.n_sn, a.flag1, a.cmd_type from device_cmd a where a.id = '%s' order by a.sn", id, copyid);
				rc = sqlite3_exec(db, copysql, NULL, 0, &zErrMsg);
				
				printf("0000\n");
			}
		}
		else
		{
			printf("3006\n");
		}
	}
	sqlite3_close(db);
}

//������ѯ
void QueryDataSingle()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(3), &sqlite3_exec_callback_single, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db); 
}

int sqlite3_exec_callback_single(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>�豸��Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style='background:#CADFFF'>\n");
	fprintf(cgiOut, "<form name=\"device_info\" action=\"device_info.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");	
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/device_info.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"60%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"100%%\" align='right'><img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doEdit()'><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<table width=\"60%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>%s</td>\n", col_values[6]);
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <select name='dev_type' style='width:99%%;height:25px;'>\n");
	fprintf(cgiOut, "        <option value='0' %s>�����</option>\n", 0 == strcmp(col_values[16], "0")?"selected":"");
	fprintf(cgiOut, "        <option value='1' %s>��ֵ��</option>\n", 0 == strcmp(col_values[16], "1")?"selected":"");
	fprintf(cgiOut, "        <option value='2' %s>��ֵ��</option>\n", 0 == strcmp(col_values[16], "2")?"selected":"");
	fprintf(cgiOut, "        <option value='3' %s>��ֵ��</option>\n", 0 == strcmp(col_values[16], "3")?"selected":"");
	fprintf(cgiOut, "        <option value='4' %s>������</option>\n", 0 == strcmp(col_values[16], "4")?"selected":"");
	fprintf(cgiOut, "        <option value='5' %s>������</option>\n", 0 == strcmp(col_values[16], "5")?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>%s<input type='hidden' name='id' value='%s'></td>\n", col_values[0], col_values[0]);
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'><input type='text' name='cname' value='%s' style='width:99%%;height:25px;' maxlength=20></td>\n", col_values[1]);
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>�豸ͼ��</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <table width='100%%'>\n");
	fprintf(cgiOut, "        <tr height=70px>\n");
	fprintf(cgiOut, "          <td align='left'  width=50%% valign='top'><img src='%s' style='width:64px;height:64px;'></td>\n", col_values[2]);
	fprintf(cgiOut, "          <td align='right' width=50%% valign='top'><img src='%s' style='width:16px;height:16px;'></td>\n", col_values[3]);
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr>\n");
	fprintf(cgiOut, "          <td align='left'  width=50%%><input id='file' name='file1' type='file' style='width:70px;height:20px;' onchange='UploadPic(this.value, 1)' title='64*64(����)�ϴ�'></td>\n");
	fprintf(cgiOut, "          <td align='right' width=50%%><input id='file' name='file2' type='file' style='width:70px;height:20px;' onchange='UploadPic(this.value, 2)' title='16*16(����)�ϴ�'></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height=70px>\n");
	fprintf(cgiOut, "          <td align='left'  width=50%% valign='top'><img src='%s' style='width:64px;height:64px;'></td>\n", col_values[13]);
	fprintf(cgiOut, "          <td align='right' width=50%% valign='top'><img src='%s' style='width:64px;height:64px;'></td>\n", col_values[14]);
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr>\n");
	fprintf(cgiOut, "          <td align='left'  width=50%%><input id='file' name='file3' type='file' style='width:70px;height:20px;' onchange='UploadPic(this.value, 3)' title='64*64(�쳣)�ϴ�'></td>\n");
	fprintf(cgiOut, "          <td align='right' width=50%%><input id='file' name='file4' type='file' style='width:70px;height:20px;' onchange='UploadPic(this.value, 4)' title='64*64(����)�ϴ�'></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height=70px>\n");
	fprintf(cgiOut, "          <td align='left'  width=50%% valign='top'><img src='%s' style='width:64px;height:64px;'></td>\n", col_values[15]);
	fprintf(cgiOut, "          <td align='right' width=50%% valign='top'><img src='%s' style='width:64px;height:64px;'></td>\n", col_values[17]);
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr>\n");
	fprintf(cgiOut, "          <td align='left'  width=50%%><input id='file' name='file5' type='file' style='width:70px;height:20px;' onchange='UploadPic(this.value, 5)' title='64*64(����)�ϴ�'></td>\n");
	fprintf(cgiOut, "          <td align='right' width=50%%><input id='file' name='file6' type='file' style='width:70px;height:20px;' onchange='UploadPic(this.value, 6)' title='64*64(�ر�)�ϴ�'></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height=70px>\n");
	fprintf(cgiOut, "          <td align='left'  width=100%% valign='top' colspan=2><img src='%s' style='width:64px;height:64px;'></td>\n", col_values[18]);
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr>\n");
	fprintf(cgiOut, "          <td align='left'  width=100%% colspan=2><input id='file' name='file7' type='file' style='width:70px;height:20px;' onchange='UploadPic(this.value, 7)' title='64*64(����)�ϴ�'></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>�豸����</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'><textarea name='composition' rows='25' cols='26' maxlength=1024>%s</textarea></td>\n", col_values[4]);
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <select name='ctype1' style='width:80%%;height:25px;'>\n");
	fprintf(cgiOut, "        <option value=''   %s>��</option>\n",     0 == strcmp(col_values[8], "")?"selected":"");
	fprintf(cgiOut, "        <option value='03' %s>������</option>\n", 0 == strcmp(col_values[8], "03")?"selected":"");
	fprintf(cgiOut, "        <option value='11' %s>�̵���</option>\n", 0 == strcmp(col_values[8], "11")?"selected":"");
	fprintf(cgiOut, "        <option value='12' %s>������</option>\n", 0 == strcmp(col_values[8], "12")?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��֧����</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <select name='ctype2' style='width:80%%;height:25px;'>\n");
	fprintf(cgiOut, "        <option value=''   %s>��</option>\n",       0 == strcmp(col_values[9], "")?"selected":"");
	fprintf(cgiOut, "        <option value='01' %s>�龰ģʽ</option>\n", 0 == strcmp(col_values[9], "01")?"selected":"");
	fprintf(cgiOut, "        <option value='02' %s>��Ƶϵͳ</option>\n", 0 == strcmp(col_values[9], "02")?"selected":"");
	fprintf(cgiOut, "        <option value='03' %s>����ϵͳ</option>\n", 0 == strcmp(col_values[9], "03")?"selected":"");
	//fprintf(cgiOut, "        <option value='04' %s>����ϵͳ</option>\n", 0 == strcmp(col_values[9], "04")?"selected":"");
	fprintf(cgiOut, "        <option value='11' %s>�̵���</option>\n",   0 == strcmp(col_values[9], "11")?"selected":"");
	fprintf(cgiOut, "        <option value='12' %s>������</option>\n",   0 == strcmp(col_values[9], "12")?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��֧�ӿ�</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <select name='ctype3' style='width:80%%;height:25px;'>\n");
	fprintf(cgiOut, "        <option value=''     %s>��</option>\n",          0 == strcmp(col_values[10], "")?"selected":"");
	fprintf(cgiOut, "        <option value='0100' %s>����-�޷�ʽ</option>\n", 0 == strcmp(col_values[10], "0100")?"selected":"");
	fprintf(cgiOut, "        <option value='0101' %s>����-����ʽ</option>\n", 0 == strcmp(col_values[10], "0101")?"selected":"");
	fprintf(cgiOut, "        <option value='0102' %s>����-����ʽ</option>\n", 0 == strcmp(col_values[10], "0102")?"selected":"");
	fprintf(cgiOut, "        <option value='0103' %s>����-����ʽ</option>\n", 0 == strcmp(col_values[10], "0103")?"selected":"");
	fprintf(cgiOut, "        <option value='0200' %s>˫��-�޷�ʽ</option>\n", 0 == strcmp(col_values[10], "0200")?"selected":"");
	fprintf(cgiOut, "        <option value='0201' %s>˫��-����ʽ</option>\n", 0 == strcmp(col_values[10], "0201")?"selected":"");
	fprintf(cgiOut, "        <option value='0202' %s>˫��-����ʽ</option>\n", 0 == strcmp(col_values[10], "0202")?"selected":"");
	fprintf(cgiOut, "        <option value='0203' %s>˫��-����ʽ</option>\n", 0 == strcmp(col_values[10], "0203")?"selected":"");
	fprintf(cgiOut, "        <option value='0300' %s>����-�޷�ʽ</option>\n", 0 == strcmp(col_values[10], "0300")?"selected":"");
	fprintf(cgiOut, "        <option value='0301' %s>����-����ʽ</option>\n", 0 == strcmp(col_values[10], "0301")?"selected":"");
	fprintf(cgiOut, "        <option value='0302' %s>����-����ʽ</option>\n", 0 == strcmp(col_values[10], "0302")?"selected":"");
	fprintf(cgiOut, "        <option value='0303' %s>����-����ʽ</option>\n", 0 == strcmp(col_values[10], "0303")?"selected":"");
	fprintf(cgiOut, "        <option value='0400' %s>�Ŀ�-�޷�ʽ</option>\n", 0 == strcmp(col_values[10], "0400")?"selected":"");
	fprintf(cgiOut, "        <option value='0401' %s>�Ŀ�-����ʽ</option>\n", 0 == strcmp(col_values[10], "0401")?"selected":"");
	fprintf(cgiOut, "        <option value='0402' %s>�Ŀ�-����ʽ</option>\n", 0 == strcmp(col_values[10], "0402")?"selected":"");
	fprintf(cgiOut, "        <option value='0403' %s>�Ŀ�-����ʽ</option>\n", 0 == strcmp(col_values[10], "0403")?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <select name='status' style='width:80%%;height:25px;'>\n");
	fprintf(cgiOut, "        <option value='1' %s>����</option>\n",0 == strcmp(col_values[11], "1")?"selected":"");
	fprintf(cgiOut, "        <option value='0' %s>ע��</option>\n",0 == strcmp(col_values[11], "0")?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>����ģʽ</td>\n");
	fprintf(cgiOut, "    <td width=\"80%%\" align='left' colspan=3>\n");
	fprintf(cgiOut, "       <input type='text' name='mode_list' style='width:99%%;height:25px;' maxlength=256 value='%s'>\n", col_values[12]);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>�豸����</td>\n");
	fprintf(cgiOut, "    <td width=\"80%%\" align='left' colspan=3>\n");
	fprintf(cgiOut, "    <table width='100%%'>\n");
	fprintf(cgiOut, "      <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox1' id='checkbox1' value='outip,'>����IP\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox2' id='checkbox2' value='outport,'>�����˿�\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox3' id='checkbox3' value='inip,'>����IP\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox4' id='checkbox4' value='inport,'>�����˿�\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox5' id='checkbox5' value='login_id,'>�����ʺ�\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox6' id='checkbox6' value='login_pwd,'>�������\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox7' id='checkbox7' value='code_stream,'>��������\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox15' id='checkbox15' value='cover_flag,'>��¼����\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox8' id='checkbox8'  value='pan_tilt,'>��̨����\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox9' id='checkbox9' value='authmode,'>��������\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox10' id='checkbox10' value='self_id,'>��ͨ����\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox16' id='checkbox16' value='rolltimeout,'>��Ѳ��ʱ\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox11' id='checkbox11' value='bpt,'>������\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox12' id='checkbox12' value='databyte,'>����λ\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox13' id='checkbox13' value='stopbyte,'>ֹͣλ\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='25%%'>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox14' id='checkbox14' value='checkbyte,'>У��λ\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' colspan=4>\n");
	fprintf(cgiOut, "        <input type='checkbox' name='checkbox17' id='checkbox17' value='isUpload,'>�Ƿ��ϴ�\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
			
  if(strstr(col_values[5], "outip,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox1').checked = true;</script>\n");
		
	if(strstr(col_values[5], "outport,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox2').checked = true;</script>\n");
			
	if(strstr(col_values[5], "inip,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox3').checked = true;</script>\n");

	if(strstr(col_values[5], "inport,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox4').checked = true;</script>\n");
		
	if(strstr(col_values[5], "login_id,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox5').checked = true;</script>\n");

	if(strstr(col_values[5], "login_pwd,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox6').checked = true;</script>\n");
			
	if(strstr(col_values[5], "code_stream,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox7').checked = true;</script>\n");
		
	if(strstr(col_values[5], "pan_tilt,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox8').checked = true;</script>\n");
		
	if(strstr(col_values[5], "authmode,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox9').checked = true;</script>\n");
		
	if(strstr(col_values[5], "self_id,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox10').checked = true;</script>\n");
		
	if(strstr(col_values[5], "bpt,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox11').checked = true;</script>\n");
		
	if(strstr(col_values[5], "databyte,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox12').checked = true;</script>\n");
		
	if(strstr(col_values[5], "stopbyte,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox13').checked = true;</script>\n");
		
	if(strstr(col_values[5], "checkbyte,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox14').checked = true;</script>\n");
	
	if(strstr(col_values[5], "cover_flag,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox15').checked = true;</script>\n");	
	
	if(strstr(col_values[5], "rolltimeout,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox16').checked = true;</script>\n");	
	
	if(strstr(col_values[5], "isUpload,"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox17').checked = true;</script>\n");
	
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "  <td width=\"20%%\" align='center'>�ӿ�����</td>\n");
	fprintf(cgiOut, "  <td width=\"80%%\" align='left' colspan=3>\n");	
	fprintf(cgiOut, "    <table width='100%%'>\n");
	fprintf(cgiOut, "      <tr height='25'>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox31' id='checkbox31' value='1,'>RS485\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox32' id='checkbox32' value='2,'>ģ���������\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='50%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox33' id='checkbox33' value='3,'>ģ���ѹ����\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='25'>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox34' id='checkbox34' value='4,'>����������\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox35' id='checkbox35' value='5,'>���������\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='50%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox36' id='checkbox36' value='6,'>�̵�����Դ���\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='25'>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox37' id='checkbox37' value='7,'>GSM\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox38' id='checkbox38' value='8,'>�龰ģʽ\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='50%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox39' id='checkbox39' value='9,'>������չ�ӿ�\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='25'>\n");
	fprintf(cgiOut, "        <td width='100%%' colspan=3>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox30' id='checkbox30' value='0,'>DVRͨ��\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	if(strstr(col_values[7], "0,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox30').checked = true;</script>\n");
	if(strstr(col_values[7], "1,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox31').checked = true;</script>\n");
	if(strstr(col_values[7], "2,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox32').checked = true;</script>\n");
	if(strstr(col_values[7], "3,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox33').checked = true;</script>\n");
	if(strstr(col_values[7], "4,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox34').checked = true;</script>\n");
	if(strstr(col_values[7], "5,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox35').checked = true;</script>\n");
	if(strstr(col_values[7], "6,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox36').checked = true;</script>\n");
	if(strstr(col_values[7], "7,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox37').checked = true;</script>\n");
	if(strstr(col_values[7], "8,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox38').checked = true;</script>\n");
	if(strstr(col_values[7], "9,"))
	  fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox39').checked = true;</script>\n");
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'          value='3'>\n");
	fprintf(cgiOut, "<input type='hidden' name='private_attr' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='channel_type' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='uploadflag'   value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='agentid'      value='%s'>\n", agentid);
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");	
	//��Ƭ�ϴ�
	fprintf(cgiOut, "function UploadPic(pUrl, pIndex)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(pUrl.indexOf('.jpg') == -1 && pUrl.indexOf('.JPG') == -1 && pUrl.indexOf('.gif') == -1 && pUrl.indexOf('.GIF') == -1 && pUrl.indexOf('.bmp') == -1 && pUrl.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n"); 
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  device_info.uploadflag.value = pIndex;\n");
	fprintf(cgiOut, "  device_info.submit();\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doEdit()\n");
	fprintf(cgiOut, "{\n");	
	fprintf(cgiOut, "  if(device_info.cname.value.length < 1){alert('����������');return;}\n");
	fprintf(cgiOut, "  var private_attr = '';\n");
	fprintf(cgiOut, "  var channel_type = '';\n");
	fprintf(cgiOut, "  for(var i=1; i<=17; i++)\n");
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(document.getElementById('checkbox' + i).checked)\n");
	fprintf(cgiOut, "    {\n");			
	fprintf(cgiOut, "      private_attr += document.getElementById('checkbox' + i).value;\n");
	fprintf(cgiOut, "    }\n");	
	fprintf(cgiOut, "  }\n");		
	fprintf(cgiOut, "  device_info.private_attr.value = private_attr;\n");
	
	fprintf(cgiOut, "  for(var i=30; i<=39; i++)\n");
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(document.getElementById('checkbox' + i).checked)\n");
	fprintf(cgiOut, "    {\n");			
	fprintf(cgiOut, "      channel_type += document.getElementById('checkbox' + i).value;\n");
	fprintf(cgiOut, "    }\n");	
	fprintf(cgiOut, "  }\n");		
	fprintf(cgiOut, "  device_info.channel_type.value = channel_type;\n");
	
	fprintf(cgiOut, "  if(confirm('ȷ���༭?'))\n");
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    device_info.cmd.value = '11';\n");	
	fprintf(cgiOut, "    device_info.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");	

	fprintf(cgiOut, "function doReturn(){location = 'device_info.cgi?cmd=0&agentid=%s';}\n", agentid);
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");	
	return 0;
}

//��������
void UpdateData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(11), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

//ɾ��
void DeleteData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(12), &sqlite3_exec_callback, 0, &zErrMsg);
	rc = sqlite3_exec(db, getSql(13), &sqlite3_exec_callback, 0, &zErrMsg);
	rc = sqlite3_exec(db, getSql(14), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

//���Ӳ�ѯ
void QueryDataForAdd()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>�豸��Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style='background:#CADFFF'>\n");
	fprintf(cgiOut, "<form name=\"device_info\" action=\"device_info.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/device_info.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");	
	fprintf(cgiOut, "<table width=\"60%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	if(cnt == 1)
	{
		fprintf(cgiOut, "  <div id='msg' style='color:red;text-align:center;'>��ǰ����Ѵ��ڣ������¶���!</div>\n");
	}
	fprintf(cgiOut, "    <td width=\"100%%\" align='right'><img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doAdd()'><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'></td>\n");
	fprintf(cgiOut, "  </tr>\n");
  fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<table width=\"60%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "  <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "  <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "    <select name='agentid' style='width:99%%;height:25px'>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);		
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_foradd, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "    </select>\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "  <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "  <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "     <select name='dev_type' style='width:99%%;height:25px'>\n");
	fprintf(cgiOut, "       <option value='0'>�����</option>\n");
	fprintf(cgiOut, "       <option value='1'>��ֵ��</option>\n");
	fprintf(cgiOut, "       <option value='2'>��ֵ��</option>\n");
	fprintf(cgiOut, "       <option value='3'>��ֵ��</option>\n");
	fprintf(cgiOut, "       <option value='4'>������</option>\n");
	fprintf(cgiOut, "       <option value='5'>������</option>\n");
	fprintf(cgiOut, "     </select>\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "</tr>\n");
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "  <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "  <td width=\"30%%\" align='left'><input type='text' name='id' value='' style='width:99%%;height:25px;' maxlength=2></td>\n");
	fprintf(cgiOut, "  <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "  <td width=\"30%%\" align='left'><input type='text' name='cname' value='' style='width:99%%;height:25px;' maxlength=20></td>\n");
	fprintf(cgiOut, "</tr>\n");
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "  <td width=\"20%%\" align='center'>�豸ͼ��</td>\n");
	fprintf(cgiOut, "  <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "    <table width='100%%'>\n");
	fprintf(cgiOut, "      <tr height=70px>\n");
	fprintf(cgiOut, "        <td align='left'  width=50%% valign='top'><img src='' style='width:64px;height:64px;'></td>\n");
	fprintf(cgiOut, "        <td align='right' width=50%% valign='top'><img src='' style='width:16px;height:16px;'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr>\n");
	fprintf(cgiOut, "        <td align='left'  width=50%%><input id='file' name='file1' type='file'  title='64*64(����)�ϴ�' value='���' style='width:70px;height:20px'></td>\n");
	fprintf(cgiOut, "        <td align='right' width=50%%><input id='file' name='file2' type='file'  title='16*16(����)�ϴ�' value='���' style='width:70px;height:20px'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height=70px>\n");
	fprintf(cgiOut, "        <td align='left'  width=50%% valign='top'><img src='' style='width:64px;height:64px;'></td>\n");
	fprintf(cgiOut, "        <td align='right' width=50%% valign='top'><img src='' style='width:64px;height:64px;'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr>\n");
	fprintf(cgiOut, "        <td align='left'  width=50%%><input id='file' name='file3' type='file'  title='64*64(�쳣)�ϴ�' value='���' style='width:70px;height:20px'></td>\n");
	fprintf(cgiOut, "        <td align='right' width=50%%><input id='file' name='file4' type='file'  title='64*64(����)�ϴ�' value='���' style='width:70px;height:20px'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height=70px>\n");
	fprintf(cgiOut, "        <td align='left'  width=50%% valign='top'><img src='' style='width:64px;height:64px;'></td>\n");
	fprintf(cgiOut, "        <td align='right' width=50%% valign='top'><img src='' style='width:64px;height:64px;'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr>\n");
	fprintf(cgiOut, "        <td align='left'  width=50%%><input id='file' name='file5' type='file'  title='64*64(����)�ϴ�' value='���' style='width:70px;height:20px'></td>\n");
	fprintf(cgiOut, "        <td align='right' width=50%%><input id='file' name='file6' type='file'  title='64*64(�ر�)�ϴ�' value='���' style='width:70px;height:20px'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height=70px>\n");
	fprintf(cgiOut, "        <td align='left'  width=100%% valign='top' colspan=2><img src='' style='width:64px;height:64px;'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr>\n");
	fprintf(cgiOut, "        <td align='left'  width=100%% colspan=2><input id='file' name='file7' type='file'  title='64*64(����)�ϴ�' value='���' style='width:70px;height:20px'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "  <td width=\"20%%\" align='center'>�豸����</td>\n");
	fprintf(cgiOut, "  <td width=\"30%%\" align='left'><textarea name='composition' rows='25' cols='26' maxlength=1024></textarea></td>\n");
	fprintf(cgiOut, "</tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <select name='ctype1' style='width:80%%;height:25px;'>\n");
	fprintf(cgiOut, "        <option value=''  >��</option>\n");
	fprintf(cgiOut, "        <option value='03'>������</option>\n");
	fprintf(cgiOut, "        <option value='11'>�̵���</option>\n");
	fprintf(cgiOut, "        <option value='12'>������</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��֧����</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <select name='ctype2' style='width:80%%;height:25px;'>\n");
	fprintf(cgiOut, "        <option value=''  >��</option>\n");
	fprintf(cgiOut, "        <option value='01'>�龰ģʽ</option>\n");
	fprintf(cgiOut, "        <option value='02'>��Ƶϵͳ</option>\n");
	fprintf(cgiOut, "        <option value='03'>����ϵͳ</option>\n");
	//fprintf(cgiOut, "        <option value='04'>����ϵͳ</option>\n");
	fprintf(cgiOut, "        <option value='11'>�̵���</option>\n");
	fprintf(cgiOut, "        <option value='12'>������</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>��֧�ӿ�</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <select name='ctype3' style='width:80%%;height:25px;'>\n");
	fprintf(cgiOut, "        <option value=''    >��</option>\n");
	fprintf(cgiOut, "        <option value='0100'>����-�޷�ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0101'>����-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0102'>����-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0103'>����-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0200'>˫��-�޷�ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0201'>˫��-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0202'>˫��-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0203'>˫��-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0300'>����-�޷�ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0301'>����-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0302'>����-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0303'>����-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0400'>�Ŀ�-�޷�ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0401'>�Ŀ�-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0402'>�Ŀ�-����ʽ</option>\n");
	fprintf(cgiOut, "        <option value='0403'>�Ŀ�-����ʽ</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "    <td width=\"30%%\" align='left'>\n");
	fprintf(cgiOut, "      <select name='status' style='width:80%%;height:25px;'>\n");
	fprintf(cgiOut, "        <option value='1'>����</option>\n");
	fprintf(cgiOut, "        <option value='0'>ע��</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"20%%\" align='center'>����ģʽ</td>\n");
	fprintf(cgiOut, "    <td width=\"80%%\" align='left' colspan=3>\n");
	fprintf(cgiOut, "       <input type='text' name='mode_list' style='width:99%%;height:25px;' maxlength=256 value=''>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width=\"20%%\" align='center'>�豸����</td>\n");
	fprintf(cgiOut, "<td width=\"80%%\" align='left' colspan=3>\n");
	fprintf(cgiOut, "<table width='100%%'>\n");
	fprintf(cgiOut, "<tr height='25'>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox1' id='checkbox1' value='outip,'>����IP\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox2' id='checkbox2' value='outport,'>�����˿�\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox3' id='checkbox3' value='inip,'>����IP\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox4' id='checkbox4' value='inport,'>�����˿�\n");
	fprintf(cgiOut, "</td>\n");
	
	fprintf(cgiOut, "</tr>\n");
	fprintf(cgiOut, "<tr height='25'>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox5' id='checkbox5' value='login_id,'>�����ʺ�\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox6' id='checkbox6' value='login_pwd,'>�������\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox7' id='checkbox7' value='code_stream,'>��������\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox15' id='checkbox15' value='cover_flag,'>��¼����\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "</tr>\n");

	fprintf(cgiOut, "<tr height='25'>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox8' id='checkbox8'  value='pan_tilt,'>��̨����\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox9' id='checkbox9' value='authmode,'>��������\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox10' id='checkbox10' value='self_id,'>��ͨ����\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "<td width='25%%'>\n");
	fprintf(cgiOut, "<input type='checkbox' name='checkbox16' id='checkbox16' value='rolltimeout,'>��Ѳ��ʱ\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "</tr>\n");

	fprintf(cgiOut, "<tr height='25'>\n");
	fprintf(cgiOut, "  <td width='25%%'>\n");
	fprintf(cgiOut, "    <input type='checkbox' name='checkbox11' id='checkbox11' value='bpt,'>������\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "  <td width='25%%'>\n");
	fprintf(cgiOut, "    <input type='checkbox' name='checkbox12' id='checkbox12' value='databyte,'>����λ\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "  <td width='25%%'>\n");
	fprintf(cgiOut, "    <input type='checkbox' name='checkbox13' id='checkbox13' value='stopbyte,'>ֹͣλ\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "  <td width='25%%'>\n");
	fprintf(cgiOut, "    <input type='checkbox' name='checkbox14' id='checkbox14' value='checkbyte,'>У��λ\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "</tr>\n");	
	fprintf(cgiOut, "<tr height='25'>\n");
	fprintf(cgiOut, "  <td width='100%%' colspan=4>\n");
	fprintf(cgiOut, "    <input type='checkbox' name='checkbox17' id='checkbox17' value='isUpload,'>�Ƿ��ϴ�\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "</tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "  <td width=\"20%%\" align='center'>�ӿ�����</td>\n");
	fprintf(cgiOut, "  <td width=\"80%%\" align='left' colspan=3>\n");	
	fprintf(cgiOut, "    <table width='100%%'>\n");
	fprintf(cgiOut, "      <tr height='25'>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox31' id='checkbox31' value='1,'>RS485\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox32' id='checkbox32' value='2,'>ģ���������\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='50%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox33' id='checkbox33' value='3,'>ģ���ѹ����\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='25'>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox34' id='checkbox34' value='4,'>����������\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox35' id='checkbox35' value='5,'>���������\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='50%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox36' id='checkbox36' value='6,'>�̵�����Դ���\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='25'>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox37' id='checkbox37' value='7,'>GSM\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='25%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox38' id='checkbox38' value='8,'>�龰ģʽ\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "        <td width='50%%'>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox39' id='checkbox39' value='9,'>������չ�ӿ�\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='25'>\n");
	fprintf(cgiOut, "        <td width='100%%' colspan=3>\n");
	fprintf(cgiOut, "          <input type='checkbox' name='checkbox30' id='checkbox30' value='0,'>DVRͨ��\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='10'>\n");
	fprintf(cgiOut, "<input type='hidden' name='private_attr' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='channel_type' value=''>\n");	
	fprintf(cgiOut, "<input type='hidden' name='icon' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='s_icon' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='r_icon' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='g_icon' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='b_icon' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='c_icon' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='o_icon' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");	
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_info.file1.value.length > 0 && device_info.file1.value.indexOf('.jpg') == -1 && device_info.file1.value.indexOf('.JPG') == -1 && device_info.file1.value.indexOf('.gif') == -1 && device_info.file1.value.indexOf('.GIF') == -1 && device_info.file1.value.indexOf('.bmp') == -1 && device_info.file1.value.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n"); 
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_info.file2.value.length > 0 && device_info.file2.value.indexOf('.jpg') == -1 && device_info.file2.value.indexOf('.JPG') == -1 && device_info.file2.value.indexOf('.gif') == -1 && device_info.file2.value.indexOf('.GIF') == -1 && device_info.file2.value.indexOf('.bmp') == -1 && device_info.file2.value.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n"); 
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_info.file3.value.length > 0 && device_info.file3.value.indexOf('.jpg') == -1 && device_info.file3.value.indexOf('.JPG') == -1 && device_info.file3.value.indexOf('.gif') == -1 && device_info.file3.value.indexOf('.GIF') == -1 && device_info.file3.value.indexOf('.bmp') == -1 && device_info.file3.value.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n"); 
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_info.file4.value.length > 0 && device_info.file4.value.indexOf('.jpg') == -1 && device_info.file4.value.indexOf('.JPG') == -1 && device_info.file4.value.indexOf('.gif') == -1 && device_info.file4.value.indexOf('.GIF') == -1 && device_info.file4.value.indexOf('.bmp') == -1 && device_info.file4.value.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n"); 
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_info.file5.value.length > 0 && device_info.file5.value.indexOf('.jpg') == -1 && device_info.file5.value.indexOf('.JPG') == -1 && device_info.file5.value.indexOf('.gif') == -1 && device_info.file5.value.indexOf('.GIF') == -1 && device_info.file5.value.indexOf('.bmp') == -1 && device_info.file5.value.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n"); 
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_info.file6.value.length > 0 && device_info.file6.value.indexOf('.jpg') == -1 && device_info.file6.value.indexOf('.JPG') == -1 && device_info.file6.value.indexOf('.gif') == -1 && device_info.file6.value.indexOf('.GIF') == -1 && device_info.file6.value.indexOf('.bmp') == -1 && device_info.file6.value.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n"); 
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_info.file7.value.length > 0 && device_info.file7.value.indexOf('.jpg') == -1 && device_info.file7.value.indexOf('.JPG') == -1 && device_info.file7.value.indexOf('.gif') == -1 && device_info.file7.value.indexOf('.GIF') == -1 && device_info.file7.value.indexOf('.bmp') == -1 && device_info.file7.value.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n"); 
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(device_info.agentid.value.length < 1){alert('�������ӳ�����Ϣ');return;}\n");
	fprintf(cgiOut, "  if(device_info.id.value.length < 1){alert('������ 01-99 �����λ���');return;}\n");
	fprintf(cgiOut, "  if(device_info.cname.value.length < 1){alert('����������');return;}\n");
	
	fprintf(cgiOut, "  var private_attr = '';\n");
	fprintf(cgiOut, "  var channel_type = '';\n");
	fprintf(cgiOut, "  for(var i=1; i<=17; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('checkbox' + i).checked)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      private_attr += document.getElementById('checkbox' + i).value;\n");		
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  device_info.private_attr.value = private_attr;\n");
	
	fprintf(cgiOut, "  for(var i=30; i<=39; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('checkbox' + i).checked)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      channel_type += document.getElementById('checkbox' + i).value;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  device_info.channel_type.value = channel_type;\n");
	
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    device_info.icon.value   = device_info.file1.value;\n");
	fprintf(cgiOut, "    device_info.s_icon.value = device_info.file2.value;\n");
	fprintf(cgiOut, "    device_info.r_icon.value = device_info.file3.value;\n");
	fprintf(cgiOut, "    device_info.g_icon.value = device_info.file4.value;\n");
	fprintf(cgiOut, "    device_info.b_icon.value = device_info.file5.value;\n");
	fprintf(cgiOut, "    device_info.c_icon.value = device_info.file6.value;\n");
	fprintf(cgiOut, "    device_info.o_icon.value = device_info.file7.value;\n");
	fprintf(cgiOut, "    device_info.id.value = device_info.agentid.value + '1' + device_info.id.value;\n");
	fprintf(cgiOut, "    device_info.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doReturn(){location = 'device_info.cgi?cmd=0&agentid=%s';}\n", agentid);
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}
//���Ӳ�ѯ����
int sqlite3_exec_callback_foradd(void *data, int n_columns, char **col_values, char **col_names)
{ 
	if(0 == strcmp(agentid, col_values[0]))
	{
		fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", col_values[0], col_values[1]);
	}
	else
	{
		fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	}
	return 0;
}

//����
void AddData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);		
	
	rc = sqlite3_exec(db, getSql(3), &sqlite3_exec_callback_add, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	if(cnt == 0)
	{
		rc = sqlite3_exec(db, getSql(10), &sqlite3_exec_callback, 0, &zErrMsg);
		if(rc!=SQLITE_OK)
		{
			err_msg(1);
		}
		else
		{
			//���ӳɹ����ͼ(����)�ϴ�
			if(strlen(icon) > 0)
			{
				ImgUpload("1");
			}
			//���ӳɹ���Сͼ(����)�ϴ�
			if(strlen(s_icon) > 0)
			{
				ImgUpload("2");
			}
			//���ӳɹ����ͼ(�쳣)�ϴ�
			if(strlen(r_icon) > 0)
			{
				ImgUpload("3");
			}
			//���ӳɹ����ͼ(����)�ϴ�
			if(strlen(g_icon) > 0)
			{
				ImgUpload("4");
			}
			//���ӳɹ����ͼ(����)�ϴ�
			if(strlen(b_icon) > 0)
			{
				ImgUpload("5");
			}
			//���ӳɹ����ͼ(�ر�)�ϴ�
			if(strlen(c_icon) > 0)
			{
				ImgUpload("6");
			}
			//���ӳɹ����ͼ(����)�ϴ�
			if(strlen(o_icon) > 0)
			{
				ImgUpload("7");
			}
		}
	}
	sqlite3_close(db);
}

//ͼƬ�ϴ�
void ImgUpload(char *flag)
{
	cgiFilePtr file;
	int targetFile;
	mode_t mode;
	char name[128];
	
	char fileNameOnServer[64] = {0};
	if(0 == strcmp(flag, "1"))
	{
		strcat(fileNameOnServer, "/home/www/system/icon/");
	}
	else if(0 == strcmp(flag, "2"))
	{
		strcat(fileNameOnServer, "/home/www/system/s_icon/");
	}
	else if(0 == strcmp(flag, "3"))
	{
		strcat(fileNameOnServer, "/home/www/system/r_icon/");
	}
	else if(0 == strcmp(flag, "4"))
	{
		strcat(fileNameOnServer, "/home/www/system/g_icon/");
	}
	else if(0 == strcmp(flag, "5"))
	{
		strcat(fileNameOnServer, "/home/www/system/b_icon/");
	}
	else if(0 == strcmp(flag, "6"))
	{
		strcat(fileNameOnServer, "/home/www/system/c_icon/");
	}
	else if(0 == strcmp(flag, "7"))
	{
		strcat(fileNameOnServer, "/home/www/system/o_icon/");
	}
	
	char contentType[1024];
	char buffer[1024];
	int size;
	int got;
	
	char fimename[10] = {0};
	strcat(fimename, "file");
	strcat(fimename, flag);

	//ͼƬ·����ȡ
	if (cgiFormFileName(fimename, name, sizeof(name)) != cgiFormSuccess)
	{    
		fprintf(stderr,"could not retrieve filename\n");
	}

	//ͼƬ����    
	cgiFormFileContentType(fimename, contentType, sizeof(contentType));

	//ͼƬ��С
	cgiFormFileSize(fimename, &size);
	if(size/1024 > 100)
	{
		memcpy(uploadret, "1", 2);
	}
	else
	{
		//Ŀǰ�ļ�������ϵͳ��ʱ�ļ����У�ͨ��Ϊ/tmp��ͨ�����������ʱ�ļ�����ʱ�ļ����������û��ļ������ֲ�ͬ�����Բ���ͨ��·��/tmp/userfilename�ķ�ʽ����ļ�    
		if (cgiFormFileOpen(fimename, &file) != cgiFormSuccess)
		{    
			fprintf(stderr,"could not open the file\n");   
		}

		//��ȡ�ļ���
		strcat(fileNameOnServer, id);
		strcat(fileNameOnServer, ".gif");	
		
		//�ڵ�ǰĿ¼�½����µ��ļ�����һ������ʵ������·�������˴��ĺ�������cgi�������ڵ�Ŀ¼����ǰĿ¼�����������ļ�  
		mode = S_IRWXU|S_IRGRP|S_IROTH;
		targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode); 
		if(targetFile < 0)
		{    
			fprintf(stderr,"could not create the new file,%s\n",fileNameOnServer);    
		}

		//��ϵͳ��ʱ�ļ��ж����ļ����ݣ����ŵ��մ�����Ŀ���ļ���    
		while(cgiFormFileRead(file, buffer, 1024, &got) == cgiFormSuccess)
		{    
			if(got > 0) 
				write(targetFile, buffer, got);    
		}
		cgiFormFileClose(file); 
		close(targetFile); 
		
		goto END;
		END:	
		memset(icon, 0, sizeof(icon));
		memset(sql, 0, sizeof(sql));
		if(0 == strcmp(flag, "1"))
		{
			strcat(icon, "icon/");
			strcat(icon, id);
			strcat(icon, ".gif");
			strcat(sql, getSql(15));
		}
		else if(0 == strcmp(flag, "2"))
		{
			strcat(icon, "s_icon/");
			strcat(icon, id);
			strcat(icon, ".gif");
			strcat(sql, getSql(16));
		}
		else if(0 == strcmp(flag, "3"))
		{
			strcat(icon, "r_icon/");
			strcat(icon, id);
			strcat(icon, ".gif");
			strcat(sql, getSql(17));
		}
		else if(0 == strcmp(flag, "4"))
		{
			strcat(icon, "g_icon/");
			strcat(icon, id);
			strcat(icon, ".gif");
			strcat(sql, getSql(18));
		}
		else if(0 == strcmp(flag, "5"))
		{
			strcat(icon, "b_icon/");
			strcat(icon, id);
			strcat(icon, ".gif");
			strcat(sql, getSql(19));
		}
		else if(0 == strcmp(flag, "6"))
		{
			strcat(icon, "c_icon/");
			strcat(icon, id);
			strcat(icon, ".gif");
			strcat(sql, getSql(20));
		}
		else if(0 == strcmp(flag, "7"))
		{
			strcat(icon, "o_icon/");
			strcat(icon, id);
			strcat(icon, ".gif");
			strcat(sql, getSql(21));
		}
		
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db = open_db(DB_PATH);		
		
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
		if(rc!=SQLITE_OK)
		{
			err_msg(1);
		}

		sqlite3_close(db);
	}
}
//����id��֤
int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names)
{  
	cnt++;
	return 0;
}
