#include <stdio.h>
#include <string.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "util.h"

//��������
char Sql[1024] = {0};
char sql[1024] = {0};
int cnt = 0;
char cmd[4] = {0};
char uploadret[2] = {0};
//��device_amd
char id[7] = {0};			                //���
char sn[9] = {0};					            //Ψһ��
char cmdname[21] = {0};               //��������
char object[2] = {0};                 //�Ƿ���ֵ
char w_format[255] = {0};	            //д��ʽ
char wd_format[255] = {0};			      //д����
char wd_comparison_table[1024] = {0}; //д���
char ck_format[255] = {0};	          //У���ʽ
char private_attr[255] = {0};			    //˽�в���
char ctype[2] = {0};                  //����
char flag[2] = {0};                   //�������±��
char flag1[2] = {0};                  //����������
char flag2[2] = {0};                  //�Ƿ�ִ�е�ǰģʽ
char flag3[2] = {0};                  //�Ƿ�ִ���ϴ�ģʽ
char b_sn[9] = {0};                   //��һ������
char n_sn[9] = {0};                   //��һ������
char icon[60] = {0};                  //����ͼƬ
char cmd_type[2] = {0};               //����Ȩ��

char cname[51] = {0};			            //�豸��Ϣ����
char agentid[5] = {0};			          //���ұ��
char mode_list[512] = {0};            //ģʽ�б�
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
//ɾ��
static void DeleteData();
//���ӡ��༭��
static void CmdSubmit();
static int sqlite3_exec_callback_cmd(void *data, int n_columns, char **col_values, char **col_names);
//����
static void AddData();
static int sqlite3_exec_callback_unique(void *data, int n_columns, char **col_values, char **col_names);
//�༭
static void UdpData();
//ͼƬ�ϴ�
static void ImgUpload(char *flag);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{		
				case 0://��ѯ
					QueryData();
					break;
				case 1://���ӡ��༭��
					CmdSubmit();
					break;
				case 10://����
					AddData();
					sprintf(cmd, "%s", "0");
					QueryData();
					if(0 == strcmp(uploadret, "1"))
					{
						fprintf(cgiOut, "<script language='javascript'>alert('ͼƬ�����ϴ�ʧ�ܣ�����100K����!');</script>\n");
					}
					break;
				case 11://�༭
					UdpData();
					sprintf(cmd, "%s", "0");
					QueryData();
					if(0 == strcmp(uploadret, "1"))
					{
						fprintf(cgiOut, "<script language='javascript'>alert('ͼƬ�����ϴ�ʧ�ܣ�����100K����!');</script>\n");
					}
					break;
				case 12://ɾ��
					DeleteData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}		
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("cmdname", cmdname, sizeof(cmdname));
	cgiFormString("object", object, sizeof(object));
	cgiFormString("w_format", w_format, sizeof(w_format));
	cgiFormString("wd_format", wd_format, sizeof(wd_format));
	cgiFormString("wd_comparison_table", wd_comparison_table, sizeof(wd_comparison_table));
	cgiFormString("ck_format", ck_format, sizeof(ck_format));
	cgiFormString("private_attr", private_attr, sizeof(private_attr));
	cgiFormString("ctype", ctype, sizeof(ctype));
	cgiFormString("flag", flag, sizeof(flag));
	cgiFormString("flag1", flag1, sizeof(flag1));
	cgiFormString("flag2", flag2, sizeof(flag2));
	cgiFormString("flag3", flag3, sizeof(flag3));
	cgiFormString("b_sn", b_sn, sizeof(b_sn));
	cgiFormString("n_sn", n_sn, sizeof(n_sn));
	cgiFormString("icon", icon, sizeof(icon));
	cgiFormString("cmd_type", cmd_type, sizeof(cmd_type));
	
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("agentid", agentid, sizeof(agentid));
	cgiFormString("mode_list", mode_list, sizeof(mode_list));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));	
	switch(pCmd)
	{	
		case 0://��ѯ
      strcat(Sql, "select t.sn, t.id, t.cmdname, t.object, t.w_format, t.wd_format, t.wd_comparison_table, t.ck_format, a.cname, t.private_attr, t.ctype, t.flag, t.flag2, t.flag3, a.mode_list, t.b_sn, t.n_sn, t.flag1, t.icon, t.cmd_type from device_cmd t, device_info a where t.id = a.id and t.id = '");
      strcat(Sql, id);
      strcat(Sql, "' order by t.id");
			break;
		case 1:///�ж�Ψһ
      strcat(Sql, "select t.sn, t.id, t.cmdname, t.object, t.w_format, t.wd_format, t.wd_comparison_table, t.ck_format, a.cname, t.private_attr, t.ctype, t.flag, t.flag2, t.flag3, a.mode_list, t.b_sn, t.n_sn, t.flag1, t.icon, t.cmd_type from device_cmd t, device_info a where t.id = a.id and t.id = '");
      strcat(Sql, id);
       strcat(Sql, "' and t.sn = '");
      strcat(Sql, sn);
      strcat(Sql, "'");
			break;	
		case 10://����
			strcat(Sql, "insert into device_cmd(sn, id, cmdname, object, w_format, wd_format, wd_comparison_table, ck_format, private_attr, ctype, flag, flag2, flag3, b_sn, n_sn, flag1, cmd_type)values('");
			strcat(Sql, sn);
			strcat(Sql, "', '");
			strcat(Sql, id);
			strcat(Sql, "', '");
			strcat(Sql, cmdname);
			strcat(Sql, "', '");
			strcat(Sql, object);
			strcat(Sql, "', '");	
			strcat(Sql, w_format);
			strcat(Sql, "', '");
			strcat(Sql, wd_format);
			strcat(Sql, "', '");
			strcat(Sql, wd_comparison_table);
			strcat(Sql, "', '");
			strcat(Sql, ck_format);
			strcat(Sql, "', '");
			strcat(Sql, private_attr);
			strcat(Sql, "', '");
			strcat(Sql, ctype);
			strcat(Sql, "', '");
			strcat(Sql, flag);
			strcat(Sql, "', '");
			strcat(Sql, flag2);
			strcat(Sql, "', '");
			strcat(Sql, flag3);
			strcat(Sql, "', '");
			strcat(Sql, b_sn);
			strcat(Sql, "', '");
			strcat(Sql, n_sn);
			strcat(Sql, "', '");
			strcat(Sql, flag1);
			strcat(Sql, "', '");
			strcat(Sql, cmd_type);
			strcat(Sql, "')");
			break;
		case 11://�༭
			strcat(Sql, "update device_cmd set cmdname = '");
			strcat(Sql, cmdname);
			strcat(Sql, "', object = '");
			strcat(Sql, object);		
			strcat(Sql, "', w_format = '");
			strcat(Sql, w_format);	
			strcat(Sql, "', wd_format = '");
			strcat(Sql, wd_format);
			strcat(Sql, "', wd_comparison_table = '");
			strcat(Sql, wd_comparison_table);
			strcat(Sql, "', ck_format = '");
			strcat(Sql, ck_format);
			strcat(Sql, "', private_attr = '");
			strcat(Sql, private_attr);
			strcat(Sql, "', ctype = '");
			strcat(Sql, ctype);
			strcat(Sql, "', flag = '");
			strcat(Sql, flag);
			strcat(Sql, "', flag2 = '");
			strcat(Sql, flag2);
			strcat(Sql, "', flag3 = '");
			strcat(Sql, flag3);
			strcat(Sql, "', b_sn = '");
			strcat(Sql, b_sn);
			strcat(Sql, "', n_sn = '");
			strcat(Sql, n_sn);
			strcat(Sql, "', flag1 = '");
			strcat(Sql, flag1);
			strcat(Sql, "', cmd_type = '");
			strcat(Sql, cmd_type);
			strcat(Sql, "' where sn = '");
			strcat(Sql, sn);
			strcat(Sql, "' and id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 12://ɾ��
			strcat(Sql, "delete from device_cmd where sn = '");
      strcat(Sql, sn);
      strcat(Sql, "' and id = '");
      strcat(Sql, id);
      strcat(Sql, "'");
			break;
		case 15://ͼƬ�ϴ�
			strcat(Sql, "update device_cmd set icon = '");
      strcat(Sql, icon);
      strcat(Sql, "' where sn = '");
			strcat(Sql, sn);
			strcat(Sql, "' and id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
	}
	return Sql;
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>��������</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width:  50%%;\n");
	fprintf(cgiOut, "  height: 95%%;\n");
	fprintf(cgiOut, "  left:300px;\n");
	fprintf(cgiOut, "  top:5%%;\n");;
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"data_type\" action=\"data_type.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "  <div id=\"cap\"><img src=\"../skin/images/device_cmd.gif\"/></div><br>\n");
	fprintf(cgiOut, "  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "    <table width=\"80%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30px'>\n");
	fprintf(cgiOut, "        <td width='50%%' align='left'><font color='red'>����:%s</font></td>\n", cname);
	fprintf(cgiOut, "        <td width='50%%' align='right'><img src=\"../skin/images/mini_button_add.gif\" style='cursor:hand;' onClick=\"doCmdSubmit('1', '%s', '%s', '', '', '', '', '', '', '', '', '', '', '', '', '%s', '', '', '', '', '')\"/><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'></td>\n", id, cname, mode_list);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30px'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='center' colspan=2>\n");
	fprintf(cgiOut, "          <table width=\"100%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "            <tr height='30px'>\n");
	fprintf(cgiOut, "              <td width='10%%'  align='center' class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "              <td width='10%%'  align='center' class=\"table_deep_blue\">��������</td>\n");
	fprintf(cgiOut, "              <td width='10%%'  align='center' class=\"table_deep_blue\">����ģʽ</td>\n");
	fprintf(cgiOut, "              <td width='10%%'  align='center' class=\"table_deep_blue\">�Ƿ���ֵ</td>\n");
	fprintf(cgiOut, "              <td width='10%%'  align='center' class=\"table_deep_blue\">��������</td>\n");
	fprintf(cgiOut, "              <td width='10%%'  align='center' class=\"table_deep_blue\">ɾ ��</td>\n");
	fprintf(cgiOut, "            </tr>\n");
	
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(0);
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	if(0 == cnt)
	{
		fprintf(cgiOut, "          <tr height='30px'>\n");
		fprintf(cgiOut, "            <td width='100%%' align='center' colspan=6>��</td>\n");
		fprintf(cgiOut, "          </tr>\n");
	}
	fprintf(cgiOut, "          </table>\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='popDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//����
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'device_info.cgi?cmd=0&agentid=%s';\n", agentid);
	fprintf(cgiOut, "}\n");
  //�򿪵�����
	fprintf(cgiOut, "function doCmdSubmit(pCmd, pId, pCName, pSN, pCmdName, pObject, pW_Format, pWD_Format, pWD_Comparison_Table, pCK_Format, pPrivate_Attr, pCType, pFlag, pFlag2, pFlag3, pMode_List, pB_SN, pN_SN, pFlag1, pIcon, pCmd_Type)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'device_cmd.cgi?cmd=1&actcmd='+pCmd+'&id='+pId+'&cname='+pCName+'&sn='+pSN+'&cmdname='+pCmdName+'&object='+pObject+'&w_format='+pW_Format+'&wd_format='+pWD_Format+'&wd_comparison_table='+pWD_Comparison_Table+'&ck_format='+pCK_Format+'&private_attr='+pPrivate_Attr+'&ctype='+pCType+'&flag='+pFlag+'&flag2='+pFlag2+'&flag3='+pFlag3+'&mode_list='+pMode_List+'&b_sn='+pB_SN+'&n_sn='+pN_SN+'&flag1='+pFlag1+'&icon='+pIcon+'&cmd_type='+pCmd_Type+'&agentid=%s';\n", agentid);
	fprintf(cgiOut, "  document.getElementById('popDiv').innerHTML = \"<iframe id='divFrame' name='divFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//�رյ�����
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//ɾ��
	fprintf(cgiOut, "function doDelete(pSN, pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ��ɾ��?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'device_cmd.cgi?cmd=12&sn='+pSN+'&id='+pId+'&agentid=%s&cname=%s&mode_list=%s';\n",agentid, cname, mode_list);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

//��ѯ����
int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(cnt%2 == 0)
	{
		fprintf(cgiOut, "<tr class='table_blue' height='30px'>\n");
	}
	else
	{
		fprintf(cgiOut, "<tr class='table_white_l' height='30px'>\n");
	}
	
	fprintf(cgiOut, "<td width='10%%'  align='center' style='cursor:hand;color:red;' title='����༭' onClick=\"doCmdSubmit('2', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s');\">%s&nbsp</td>\n", col_values[1], col_values[8], col_values[0], col_values[2], col_values[3], col_values[4], col_values[5], col_values[6], col_values[7], col_values[9], col_values[10], col_values[11], col_values[12], col_values[13], mode_list, col_values[15], col_values[16], col_values[17], col_values[18], col_values[19], col_values[0]);
	fprintf(cgiOut, "<td width='10%%'  align='center'>%s&nbsp</td>\n", col_values[2]);
	
	char modename[64] = {0};
	if(NULL != mode_list && strlen(mode_list) > 0)
	{
		char *p;
		char *buffer = strdup(mode_list);
		p = strtok(buffer, ";");
		int temp = 0;
		while(p != NULL)
		{
			char * save = p+strlen(p)+1;
			temp++;
			
			char *temp_p;
			char *temp_buffer = strdup(p);
			temp_p = strtok(temp_buffer, ",");
			
			//0021,��/��;0022,����;0023,����;0024,ͨ��;0025,����;0026,��ʪ;0027,����;
			char mode_id[10] = {0};  //ģʽ���
			char mode_name[30] = {0};//ģʽ����
			int sn = 0;
			while(temp_p != NULL)
			{
				switch(sn)
				{
					case 0:
							sprintf(mode_id, "%s", temp_p);
						break;
					case 1:
							sprintf(mode_name, "%s", temp_p);
						break;
				}
				temp_p = strtok(NULL, ",");
				sn++;
			}
			if(0 == memcmp(col_values[0], mode_id, 4))
			{
				strcat(modename, mode_name);
				break;
			}	
			p = strtok(save, ";");
		}
	}
	
	char objectname[10] = {0};
	switch(atoi(col_values[3]))
	{
		case 0:
				strcat(objectname, "��");
			break;
		case 1:
				strcat(objectname, "��");
			break;
	}
	
	char cmdtypename[10] = {0};
	switch(atoi(col_values[19]))
	{
		case 0:
				strcat(cmdtypename, "��");
			break;
		case 1:
				strcat(cmdtypename, "��");
			break;
	}
	fprintf(cgiOut, "<td width='10%%'  align='center'>%s&nbsp</td>\n", modename);
	fprintf(cgiOut, "<td width='10%%'  align='center'>%s&nbsp</td>\n", objectname);
	fprintf(cgiOut, "<td width='10%%'  align='center'>%s&nbsp</td>\n", cmdtypename);
	fprintf(cgiOut, "<td width='10%%'  align='center' style='cursor:hand;color:red;' title='���ɾ��' onClick=\"doDelete('%s', '%s');\">ɾ ��</td>\n", col_values[0], col_values[1]);
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

void CmdSubmit()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>��������</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"cmdsubmit\" action=\"device_cmd.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "  <table align='center' width=\"100%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='50%%' align='left' colspan='2'>\n");
	fprintf(cgiOut, "    	   %s\n", cname);
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "  	   <td width='25%%' align='center' rowspan='3'>\n");
	fprintf(cgiOut, "    	   <table width='100%%'>\n");
	fprintf(cgiOut, "          <tr height=30px>\n");
	fprintf(cgiOut, "            <td align='center' width=100%%>\n");
	fprintf(cgiOut, "              <img src='%s' style='width:16px;height:16px;'>\n", icon);
	fprintf(cgiOut, "            </td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "          <tr height=30px>\n");
	fprintf(cgiOut, "            <td align='center' width=100%%>\n");
	fprintf(cgiOut, "    	         <input id='file1' name='file1' type='file' title='ͼƬ�ϴ�' value='���' style='width:70px;height:20px'>\n");
	fprintf(cgiOut, "            </td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>ģ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ʽ</td>\n");
	fprintf(cgiOut, "      <td width='50%%' align='left' colspan='2'>\n");
	if(0 < strlen(sn))
	{
		char tempSN[5] = {0};
		tempSN[0] = sn[0];
		tempSN[1] = sn[1];
		tempSN[2] = sn[2];
		tempSN[3] = sn[3];
		tempSN[4] = '\0';
		
		if(NULL != mode_list && strlen(mode_list) > 0)
		{
			char *p;
			char *buffer = strdup(mode_list);
			p = strtok(buffer, ";");
			int temp = 0;
			while(p != NULL)
			{
				char * save = p+strlen(p)+1;
				temp++;
				
				char *temp_p;
				char *temp_buffer = strdup(p);
				temp_p = strtok(temp_buffer, ",");
				
				//0021,��/��;0022,����;0023,����;0024,ͨ��;0025,����;0026,��ʪ;0027,����;
				char mode_id[10] = {0};  //ģʽ���
				char mode_name[30] = {0};//ģʽ����
				int sn = 0;
				while(temp_p != NULL)
				{
					switch(sn)
					{
						case 0:
								sprintf(mode_id, "%s", temp_p);
							break;
						case 1:
								sprintf(mode_name, "%s", temp_p);
							break;
					}
					temp_p = strtok(NULL, ",");
					sn++;
				}
				
				if(0 == strcmp(tempSN, mode_id))
				{
					fprintf(cgiOut, "%s\n", mode_name);
					break;
				}
				
				p = strtok(save, ";");
			}
		}
	}
	else
	{
		fprintf(cgiOut, "    	 <select name='mode_id' style='width:100px;height:20px;'>\n");
		if(NULL != mode_list && strlen(mode_list) > 0)
		{
			char *p;
			char *buffer = strdup(mode_list);
			p = strtok(buffer, ";");
			int temp = 0;
			while(p != NULL)
			{
				char * save = p+strlen(p)+1;
				temp++;
				
				char *temp_p;
				char *temp_buffer = strdup(p);
				temp_p = strtok(temp_buffer, ",");
				
				//0021,��/��;0022,����;0023,����;0024,ͨ��;0025,����;0026,��ʪ;0027,����;
				char mode_id[10] = {0};  //ģʽ���
				char mode_name[30] = {0};//ģʽ����
				int sn = 0;
				while(temp_p != NULL)
				{
					switch(sn)
					{
						case 0:
								sprintf(mode_id, "%s", temp_p);
							break;
						case 1:
								sprintf(mode_name, "%s", temp_p);
							break;
					}
					temp_p = strtok(NULL, ",");
					sn++;
				}
				
				fprintf(cgiOut, "      <option value='%s'>%s</option>\n", mode_id, mode_name);
				p = strtok(save, ";");
			}
		}
		fprintf(cgiOut, "    	 </select>\n");
	}
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='50%%' align='left' colspan='2'>\n");
	if(0 < strlen(sn))
	{
		char tempSN[5] = {0};
		tempSN[0] = sn[4];
		tempSN[1] = sn[5];
		tempSN[2] = sn[6];
		tempSN[3] = sn[7];
		tempSN[4] = '\0';
		fprintf(cgiOut, "    	   %s\n", tempSN);
	}
	else
	{
		fprintf(cgiOut, "    	 <input type='text' name='mode_sn' value='' style='width:100px;height:20px;' maxlength=4>\n");
	}
	
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "    	   <input type='text' name='cmdname' value='%s' style='width:250px;height:20px;' maxlength=10>\n", cmdname);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>�Ƿ���ֵ</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "    	   <select name='object' style='width:250px;height:20px;' >\n");
	fprintf(cgiOut, "	  			 <option value='0' %s>��</option>\n", 0 == strcmp(object, "0")?"selected":"");
	fprintf(cgiOut, "	  		   <option value='1' %s>��</option>\n", 0 == strcmp(object, "1")?"selected":"");
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>д �� ʽ</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "    	   <input type='text' name='w_format' value='%s' style='width:250px;height:20px;' maxlength=125>\n", w_format);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>д �� ��</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "    	   <input type='text' name='wd_format' value='%s' style='width:250px;height:20px;' maxlength=125>\n", wd_format);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>д �� ��</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "  	     <input type='text' name='wd_comparison_table' value='%s' style='width:250px;height:20px;' maxlength=512>\n", wd_comparison_table);
	fprintf(cgiOut, " 	   </td>\n");
	fprintf(cgiOut, "  	 </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>У���ʽ</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "    	   <input type='text' name='ck_format' value='%s' style='width:250px;height:20px;' maxlength=125>\n", ck_format);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='ctype' style='width:100px;height:20px;'>\n");
	fprintf(cgiOut, "    	   	 <option value='0' %s>ʵ��</option>\n", 0 == strcmp(ctype, "0")?"selected":"");
	fprintf(cgiOut, "    	   	 <option value='1' %s>���</option>\n", 0 == strcmp(ctype, "1")?"selected":"");
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>����Ȩ��</td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='cmd_type' style='width:100px;height:20px;'>\n");
	fprintf(cgiOut, "    	   	 <option value='0' %s>�ɷ���</option>\n",   0 == strcmp(cmd_type, "0")?"selected":"");
	fprintf(cgiOut, "    	   	 <option value='1' %s>���ɷ���</option>\n", 0 == strcmp(cmd_type, "1")?"selected":"");
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>������</td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='flag1' style='width:100px;height:20px;'>\n");
	fprintf(cgiOut, "    	   	 <option value='0' %s>��</option>\n", 0 == strcmp(flag1, "0")?"selected":"");
	fprintf(cgiOut, "    	   	 <option value='1' %s>��</option>\n", 0 == strcmp(flag1, "1")?"selected":"");
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>���±��</td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='flag' style='width:100px;height:20px;'>\n");
	fprintf(cgiOut, "    	   	 <option value='0' %s>��</option>\n", 0 == strcmp(flag, "0")?"selected":"");
	fprintf(cgiOut, "    	     <option value='1' %s>��</option>\n", 0 == strcmp(flag, "1")?"selected":"");
	fprintf(cgiOut, "    	 	   <option value='2' %s>��</option>\n", 0 == strcmp(flag, "2")?"selected":"");
	fprintf(cgiOut, "      	 </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��һ����</td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='b_sn' style='width:100px;height:20px;'>\n");
	fprintf(cgiOut, "    	     <option value='' %s>��</option>\n", 0 == strcmp(b_sn, "")?"selected":"");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql2[256] = {0};
	sprintf(sql2, "select t.sn, t.cmdname from device_cmd t where t.id = '%s' order by t.sn", id);
	rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_cmd, b_sn, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��һ����</td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='n_sn' style='width:100px;height:20px;'>\n");
	fprintf(cgiOut, "    	     <option value='' %s>��</option>\n", 0 == strcmp(n_sn, "")?"selected":"");
		
	rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_cmd, n_sn, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��ǰģʽ</td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='flag2' style='width:100px;height:20px;'>\n");
	fprintf(cgiOut, "    	   	 <option value='0' %s>��ִ��</option>\n", 0 == strcmp(flag2, "0")?"selected":"");
	fprintf(cgiOut, "    	   	 <option value='1' %s>��ִ��</option>\n", 0 == strcmp(flag2, "1")?"selected":"");
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>�ϴ�ģʽ</td>\n");
	fprintf(cgiOut, "      <td width='25%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='flag3' style='width:100px;height:20px;'>\n");
	fprintf(cgiOut, "    	   	 <option value='0' %s>��ִ��</option>\n", 0 == strcmp(flag3, "0")?"selected":"");
	fprintf(cgiOut, "    	   	 <option value='1' %s>��ִ��</option>\n", 0 == strcmp(flag3, "1")?"selected":"");
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "    	   <table width='100%%'>\n");
	fprintf(cgiOut, "    	   	 <tr height='25px'>\n");
	fprintf(cgiOut, "    	   	   <td width='100%%' colspan=3><input type='checkbox' name='checkbox1' id='checkbox1' value='isUpload,'>�Ƿ��ϴ�</td>\n");
	fprintf(cgiOut, "    	   	 </tr>\n");
	fprintf(cgiOut, "    	   </table>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	
	if(strstr(private_attr, "isUpload"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox1').checked = true;</script>\n");
	
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <div style='text-align:center;margin-top:5px;'>\n");
	fprintf(cgiOut, "    <img style='cursor:hand' onClick='doSubmit()' src='../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "	   <img style='cursor:hand' onClick='doCancel()' src='../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='10'>\n");
	fprintf(cgiOut, "  <input type='hidden' name='id' value='%s'>\n", id);
	fprintf(cgiOut, "  <input type='hidden' name='cname' value='%s'>\n", cname);
	fprintf(cgiOut, "  <input type='hidden' name='mode_list' value='%s'>\n", mode_list);
	fprintf(cgiOut, "  <input type='hidden' name='agentid' value='%s'>\n", agentid);
	fprintf(cgiOut, "  <input type='hidden' name='sn' value='%s'>\n", sn);
	fprintf(cgiOut, "  <input type='hidden' name='private_attr' value=''>\n");
	fprintf(cgiOut, "  <input type='hidden' name='icon' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(cmdsubmit.file1.value.length > 0 && cmdsubmit.file1.value.indexOf('.jpg') == -1 && cmdsubmit.file1.value.indexOf('.JPG') == -1 && cmdsubmit.file1.value.indexOf('.gif') == -1 && cmdsubmit.file1.value.indexOf('.GIF') == -1 && cmdsubmit.file1.value.indexOf('.bmp') == -1 && cmdsubmit.file1.value.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n"); 
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	
	if(0 >= strlen(sn))
	{
		fprintf(cgiOut, "if(cmdsubmit.mode_id.value.length != 4)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('��ѡ����ģʽ');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "if(cmdsubmit.mode_sn.value.length != 4)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('����д���,��0001');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "cmdsubmit.sn.value = cmdsubmit.mode_id.value + cmdsubmit.mode_sn.value;\n");
	}
	
	fprintf(cgiOut, "  if(cmdsubmit.cmdname.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д��������');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  var Private_Attr = '';\n");
	fprintf(cgiOut, "  for(var i=1; i<=1; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('checkbox' + i).checked)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      Private_Attr += document.getElementById('checkbox' + i).value;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  cmdsubmit.private_attr.value = Private_Attr;\n");
	
	char actcmd[5] = {0};
	cgiFormString("actcmd", actcmd, sizeof(actcmd));	
	if(0 == strcmp(actcmd, "1"))
	{//����
		fprintf(cgiOut, "if(confirm('ȷ������?'))\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  cmdsubmit.icon.value = cmdsubmit.file1.value;\n");
		fprintf(cgiOut, "  cmdsubmit.cmd.value = '10';\n");
		fprintf(cgiOut, "  cmdsubmit.submit();\n");
		fprintf(cgiOut, "}\n");
	}
	else if(0 == strcmp(actcmd, "2"))
	{//�༭
		fprintf(cgiOut, "if(confirm('ȷ���༭?'))\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  cmdsubmit.icon.value = cmdsubmit.file1.value;\n");
		fprintf(cgiOut, "  cmdsubmit.cmd.value = '11';\n");
		fprintf(cgiOut, "  cmdsubmit.submit();\n");
		fprintf(cgiOut, "}\n");
	}
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_cmd(void *data, int n_columns, char **col_values, char **col_names)
{
	if(0 != strlen((char *)data) && 0 == strcmp(col_values[0], (char *)data))
	{
		fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", col_values[0], col_values[1]);
	}
	else
	{
		fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	}
	return 0;
}

void AddData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
		
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_unique, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	
	if(0 < cnt)
	{
		fprintf(cgiOut, "<script language='javascript'>alert('��ǰ����Ѵ���,�����¶���!');</script>\n");
	}
	else
	{
		rc = sqlite3_exec(db, getSql(10), &sqlite3_exec_callback, 0, &zErrMsg);
		if( rc!=SQLITE_OK )
		{
		  err_msg(1);
		}
		else
		{
			//���ӳɹ���ͼƬ�ϴ�
			if(strlen(icon) > 0)
			{
				ImgUpload("1");
			}
		}
	}
	
	sqlite3_close(db);
}

int sqlite3_exec_callback_unique(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

void UdpData()
{
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	sqlite3 *db = open_db(DB_PATH);
	
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	else
	{
		//�޸ĳɹ���ͼƬ�ϴ�
		if(strlen(icon) > 0)
		{
			ImgUpload("1");
		}
	}
	
	sqlite3_close(db);
}

//ɾ��
void DeleteData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	rc = sqlite3_exec(db, getSql(12), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}	
	
	sqlite3_close(db);
}

//ͼƬ�ϴ�
void ImgUpload(char *flag)
{
	cgiFilePtr file;
	int targetFile;
	mode_t mode;
	char name[128];
	
	char fileNameOnServer[64] = {0};
	if(0 == strcmp(flag, "1"))
	{
		strcat(fileNameOnServer, "/home/www/system/cmdicon/");
	}
	
	char contentType[1024];
	char buffer[1024];
	int size;
	int got;
	
	char fimename[10] = {0};
	strcat(fimename, "file");
	strcat(fimename, flag);
	
	//ͼƬ·����ȡ
	if (cgiFormFileName(fimename, name, sizeof(name)) != cgiFormSuccess)
	{
		fprintf(stderr,"could not retrieve filename\n");
	}
	
	//ͼƬ����
	cgiFormFileContentType(fimename, contentType, sizeof(contentType));
	
	//ͼƬ��С
	cgiFormFileSize(fimename, &size);
	if(size/1024 > 100)
	{
		memcpy(uploadret, "1", 2);
	}
	else
	{
		//Ŀǰ�ļ�������ϵͳ��ʱ�ļ����У�ͨ��Ϊ/tmp��ͨ�����������ʱ�ļ�����ʱ�ļ����������û��ļ������ֲ�ͬ�����Բ���ͨ��·��/tmp/userfilename�ķ�ʽ����ļ�    
		if (cgiFormFileOpen(fimename, &file) != cgiFormSuccess)
		{
			fprintf(stderr,"could not open the file\n");
		}
		
		//��ȡ�ļ���
		strcat(fileNameOnServer, id);
		strcat(fileNameOnServer, sn);
		strcat(fileNameOnServer, ".gif");
		
		//�ڵ�ǰĿ¼�½����µ��ļ�����һ������ʵ������·�������˴��ĺ�������cgi�������ڵ�Ŀ¼����ǰĿ¼�����������ļ�  
		mode = S_IRWXU|S_IRGRP|S_IROTH;
		targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode);
		if(targetFile < 0)
		{
			fprintf(stderr,"could not create the new file,%s\n",fileNameOnServer);
		}
		
		//��ϵͳ��ʱ�ļ��ж����ļ����ݣ����ŵ��մ�����Ŀ���ļ���
		while(cgiFormFileRead(file, buffer, 1024, &got) == cgiFormSuccess)
		{
			if(got > 0)
				write(targetFile, buffer, got);
		}
		cgiFormFileClose(file);
		close(targetFile);
		
		goto END;
		END:
		memset(icon, 0, sizeof(icon));
		memset(sql, 0, sizeof(sql));
		if(0 == strcmp(flag, "1"))
		{
			strcat(icon, "cmdicon/");
			strcat(icon, id);
			strcat(icon, sn);
			strcat(icon, ".gif");
			strcat(sql, getSql(15));
		}
		
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db = open_db(DB_PATH);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(1);
		}
		sqlite3_close(db);
	}
}
