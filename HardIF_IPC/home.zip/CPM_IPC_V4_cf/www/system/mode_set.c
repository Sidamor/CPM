#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <dirent.h> 
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"
#include "IniFile.h"
#include "DES_Util.h"

//��������
char Sql[1024] = {0};
char cmd[4] = {0};
int cnt = 0;
char id[1024] = {0};
char status[2] = {0};

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
//����
static void doSet();
//��������
static void doCPM();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);	
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://����
					doSet();
					break;
				case 2://��������
					doCPM();
					fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{  
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("status", status, sizeof(status));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      	strcat(Sql, "select t.id, t.cname, t.status from mode_set t order by t.id");
			break;
		case 11://����
        strcat(Sql, "update mode_set set status = '");
        strcat(Sql, status);
				strcat(Sql, "' where id = '");
				strcat(Sql, id);	
				strcat(Sql, "'");
			break;
	}
	return Sql;
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-ģ������</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"mode_set\" action=\"mode_set.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/mode_set.gif\"/></div><br><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"70%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right'>\n");
	fprintf(cgiOut, "      <img src='../skin/images/mini_button_cpm.gif'    style='cursor:hand;' onClick='doCPM()'/>\n");
	fprintf(cgiOut, "      <img src='../skin/images/mini_button_submit.gif' style='cursor:hand;' onClick='doSet()'/>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "      <table width=\"100%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//��������
	fprintf(cgiOut, "function doCPM()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ����������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'mode_set.cgi?cmd=2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "var reqSel = null;\n");
	fprintf(cgiOut, "function doSet()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var Id = '';\n");
	fprintf(cgiOut, "  for(var i=0; i<%d; i++)\n", cnt);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('checkbox'+i))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(document.getElementById('checkbox'+i).checked)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Id += document.getElementById('checkbox'+i).value + ',1;'\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Id += document.getElementById('checkbox'+i).value + ',0;'\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(Id.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�޲�����');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqSel = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqSel = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqSel.onreadystatechange = function()\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var state = reqSel.readyState;\n");
	fprintf(cgiOut, "      if(state == 4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(reqSel.status == 200)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Resp = reqSel.responseText;\n");
	fprintf(cgiOut, "          if(null != Resp && Resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('�ɹ�');\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          else\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    };\n");
	fprintf(cgiOut, "    var url = 'mode_set.cgi?cmd=1&id='+Id+'&currtime='+new Date();\n");
	fprintf(cgiOut, "    reqSel.open('GET',url,false);\n");
	fprintf(cgiOut, "    reqSel.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	if(0 == cnt%2 && cnt > 0)
	{
		fprintf(cgiOut, "</tr>\n");
		fprintf(cgiOut, "<tr height='30px'>\n");
	}
	
	char ischecked[10] = {0};
	switch(atoi(col_values[2]))
	{
		case 0:
				strcat(ischecked, "");
			break;
		case 1:
				strcat(ischecked, "checked");
			break;
	}
	
	fprintf(cgiOut, "<td width='50%%' align='left'>\n");
	fprintf(cgiOut, "  <input type='checkbox' id='checkbox%d' name='checkbox%d' value='%s' %s>%s\n", cnt, cnt, col_values[0], ischecked, col_values[1]);
	fprintf(cgiOut, "</td>\n");
	
	cnt++;
	return 0;
}

void doSet()
{
	int rc;
	char * zErrMsg = 0;
	char sql[256] = {0};
	sqlite3 *db = open_db(DB_PATH);
	
	char *p;
	char *buffer = strdup(id);
	p = strtok(buffer, ";");
	while(NULL != p)
	{
		char s_id[5] = {0};
		char s_sta[2] = {0};
		strncpy(s_id, p, 4);
		strncpy(s_sta,  p+5, 1);
		
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "update mode_set set status = '%s' where id = '%s'", s_sta, s_id);
		rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(2);
		}
		
		p = strtok(NULL, ";");
	}
	
	sqlite3_close(db);
	
	//��������
	//system("killall CPM");
	//system("/home/CPM/CPM/startCPM.sh");
	
	printf("0000\n");
}

void doCPM()
{
	system("killall CPM");
	system("/home/CPM/CPM/startCPM.sh");
	fprintf(cgiOut, "<script language='javascript'>alert('���������ɹ�');</script>\n");
}
