#include <stdio.h>
#include <string.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <stdlib.h>
#include "util.h"

//��������
char Sql[1024] = {0};
int cnt = 0;
char cmd[4] = {0};
//��manufacturer
char id[4] = {0};				//���̱��
char cname[51] = {0};	  //��������
char addr[129] = {0};	  //���̵�ַ
char tel[21] = {0};		  //��ϵ��ʽ
char contact[11] = {0};	//��ϵ��
char brief[13] = {0};		//���Ҽ��

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
//�޸�
static void UpdateData();
//ɾ��
static void DeleteData();
//����
static void AddData();
//��������ҳ��
static void QueryDataForAdd();
//����ʱidΨһ��֤
static void AddDataUnique();
static int sqlite3_exec_callback_unique(void *data, int n_columns, char **col_values, char **col_names);
//������ѯ
static void QueryDataSingle();
static int sqlite3_exec_callback_single(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{		
				case 0://��ѯ
					QueryData();
					break;
				case 1://��������ҳ��
					QueryDataForAdd();
					break;
				case 2://������ѯ
					QueryDataSingle();
					break;
				case 10://����ʱidΨһ��֤
					AddDataUnique();
					if(cnt == 1)
					{
						QueryDataForAdd();
					}
					else
					{
						AddData();
						sprintf(cmd, "%s", "0");
						QueryData();
					}
					break;
				case 11://�޸�
					UpdateData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 12://ɾ��
					DeleteData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;		
			}		
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{  
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("addr", addr, sizeof(addr));
	cgiFormString("tel", tel, sizeof(tel));
	cgiFormString("contact", contact, sizeof(contact));
	cgiFormString("brief", brief, sizeof(brief));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      strcat(Sql, "select t.id, t.cname, t.addr, t.tel, t.contact, t.brief from manufacturer t order by t.id");
			break;
		case 1://����ʱidΨһ�ж�
      strcat(Sql, "select t.id, t.cname, t.addr, t.tel, t.contact, t.brief from manufacturer t where t.id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 2://������ѯ
			strcat(Sql, "select t.id, t.cname, t.addr, t.tel, t.contact, t.brief from manufacturer t where t.id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 3://ɾ��ʱ��ѯ�豸��Ϣ
			strcat(Sql, "select t.id from device_info t where substr(t.id,1,3) = '");
			strcat(Sql, id);
			strcat(Sql, "' order by t.id");
			break;
		case 10://����
      strcat(Sql, "insert into manufacturer(id, cname, addr, tel, contact, brief)values('");
			strcat(Sql, id);
			strcat(Sql, "', '");
      strcat(Sql, cname);
			strcat(Sql, "', '");
			strcat(Sql, addr);	
			strcat(Sql, "', '");
			strcat(Sql, tel);
			strcat(Sql, "', '");
			strcat(Sql, contact);
			strcat(Sql, "', '");
			strcat(Sql, brief);
			strcat(Sql, "')");
			break;
		case 11://����
      strcat(Sql, "update manufacturer set cname = '");
      strcat(Sql, cname);
			strcat(Sql, "', brief = '");
      strcat(Sql, brief);
      strcat(Sql, "', addr = '");
      strcat(Sql, addr);
			strcat(Sql, "', tel = '");
      strcat(Sql, tel);
			strcat(Sql, "', contact = '");
      strcat(Sql, contact);
      strcat(Sql, "' where id = '");
			strcat(Sql, id);
      strcat(Sql, "'");
			break;
		case 12://����ɾ��
			strcat(Sql, "delete from manufacturer where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 13://�豸��Ϣɾ��
			strcat(Sql, "delete from device_info where substr(id,1,3) = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 14://�ɼ�����ɾ��
			strcat(Sql, "delete from device_attr where substr(id,1,3) = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 15://��������ɾ��
			strcat(Sql, "delete from device_cmd where substr(id,1,3) = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
	}
	return Sql;
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>������Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"device_agent\" action=\"manufacturer.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "  <div id=\"cap\"><img src=\"../skin/images/device_agent.gif\"/></div><br>\n");
	fprintf(cgiOut, "  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "    <table width=\"80%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='right' colspan=7><img src=\"../skin/images/mini_button_add.gif\" style='cursor:hand;' onClick='doAdd()'/></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='center' colspan=7>\n");
	fprintf(cgiOut, "          <table width=\"100%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "            <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "              <td width='8%%'  align='center' class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "              <td width='16%%' align='center' class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "              <td width='10%%' align='center' class=\"table_deep_blue\">��ϵ��</td>\n");
	fprintf(cgiOut, "              <td width='12%%' align='center' class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "              <td width='35%%' align='center' class=\"table_deep_blue\">�� ַ</td>\n");
	fprintf(cgiOut, "              <td width='10%%' align='center' class=\"table_deep_blue\">ɾ ��</td>\n");
	fprintf(cgiOut, "            </tr>\n");
	
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "          </table>\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'manufacturer.cgi?cmd=1';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doDelete(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ע��:ɾ��������Ϣ,��Ӧ�豸����Ҳ��ȫ��ɾ��,ȷ��?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'manufacturer.cgi?cmd=12&id='+pId;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

//��ѯ����
int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{  
	cnt++;
	if(cnt%2 == 0)
	{
		fprintf(cgiOut, "<tr class='table_blue' height='30' valign='middle'>\n");
	}
	else
	{
		fprintf(cgiOut, "<tr class='table_white_l' height='30' valign='middle'>\n");
	}
	fprintf(cgiOut, "  <td width='8%%'  align='center'><a href='manufacturer.cgi?cmd=2&id=%s' target='mainFrame'><font color=red>%s</font></a></td>\n", col_values[0], col_values[0]);
	fprintf(cgiOut, "  <td width='20%%' align='left'>%s</td>\n", col_values[5]);
	fprintf(cgiOut, "  <td width='10%%' align='left'>%s</td>\n", col_values[4]);
	fprintf(cgiOut, "  <td width='19%%' align='left'>%s</td>\n", col_values[3]);
	fprintf(cgiOut, "  <td width='35%%' align='left'>%s</td>\n", col_values[2]);
	fprintf(cgiOut, "  <td width='8%%'  align='center' style='cursor:hand;color:red;' title='���ɾ��' onClick=doDelete('%s')>ɾ ��</td>\n", col_values[0]);
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

//�޸�
void UpdateData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(11), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);	
}

//ɾ��
void DeleteData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(12), &sqlite3_exec_callback, 0, &zErrMsg);
	rc = sqlite3_exec(db, getSql(13), &sqlite3_exec_callback, 0, &zErrMsg);
	rc = sqlite3_exec(db, getSql(14), &sqlite3_exec_callback, 0, &zErrMsg);
	rc = sqlite3_exec(db, getSql(15), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

//����
void AddData()
{
	int rc;
	char * zErrMsg = 0;
	
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(10), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

//����idΨһ��֤
void AddDataUnique()
{
	int rc;
	char * zErrMsg = 0;
	
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_unique, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_unique(void *data, int n_columns, char **col_values, char **col_names)
{  
	cnt++;
	return 0;
}

//��������ҳ��
void QueryDataForAdd()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>������Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"device_agent\" action=\"manufacturer.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "  <div id=\"cap\"><img src=\"../skin/images/device_agent.gif\"/></div><br>\n");
	fprintf(cgiOut, "  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "    <table width=\"50%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	if(1 == cnt)
	{
		fprintf(cgiOut, "      <div id='msg' style='color:red;text-align:center;'>��ǰ���ұ���Ѵ��ڣ������¶���!</div>\n");
	}	
	fprintf(cgiOut, "        <td width='100%%' align='right'><img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doAdd()'><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "    <table width=\"50%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='id' name='id' value='' style='width:90%%;height:25px;' maxlength=3></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='cname' name='cname' value='' style='width:90%%;height:25px;' maxlength=25></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='brief' name='brief' value='' style='width:90%%;height:25px;' maxlength=6></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>��ϵ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='contact' name='contact' value='' style='width:90%%;height:25px;' maxlength=6></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='tel' name='tel' value='' style='width:90%%;height:25px;' maxlength=20></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ַ</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='addr' name='addr' value='' style='width:90%%;height:25px;' maxlength=60></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='10'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'manufacturer.cgi?cmd=0';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_agent.id.value.length != 3){alert('����д 001-999 �����λ���');return;}\n");
	fprintf(cgiOut, "  if(device_agent.cname.value.length < 1){alert('����д����');return;}\n");
	fprintf(cgiOut, "  if(device_agent.brief.value.length < 1){alert('����д���');return;}\n");
	fprintf(cgiOut, "  if(device_agent.contact.value.length < 1){alert('����д��ϵ��');return;}\n");
	fprintf(cgiOut, "  if(device_agent.tel.value.length < 1){alert('����д�绰');return;}\n");
	fprintf(cgiOut, "  if(device_agent.addr.value.length < 1){alert('����д��ַ');return;}\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    device_agent.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}


//������ѯ
void QueryDataSingle()
{
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_single, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);   
}

//������ѯ����
int sqlite3_exec_callback_single(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>������Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"device_agent\" action=\"manufacturer.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "  <div id=\"cap\"><img src=\"../skin/images/device_agent.gif\"/></div><br>\n");
	fprintf(cgiOut, "  <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "    <table width=\"50%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='right'><img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doEdit()'><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'></td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "    <table width=\"50%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'>%s<input type='hidden' id='id' name='id' value='%s'></td>\n", id, id);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='cname' name='cname' value='%s' style='width:90%%;height:25px;' maxlength=25></td>\n", col_values[1]);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='brief' name='brief' value='%s' style='width:90%%;height:25px;' maxlength=6></td>\n", col_values[5]);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>��ϵ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='contact' name='contact' value='%s' style='width:90%%;height:25px;' maxlength=6></td>\n", col_values[4]);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='tel' name='tel' value='%s' style='width:90%%;height:25px;' maxlength=20></td>\n", col_values[3]);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "        <td width='30%%' align='center'>�� ַ</td>\n");
	fprintf(cgiOut, "        <td width='70%%' align='left'><input type='text' id='addr' name='addr' value='%s' style='width:90%%;height:25px;' maxlength=60></td>\n", col_values[2]);
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='11'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'manufacturer.cgi?cmd=0';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doEdit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_agent.cname.value.length < 1){alert('����д����');return;}\n");
	fprintf(cgiOut, "  if(device_agent.brief.value.length < 1){alert('����д���');return;}\n");
	fprintf(cgiOut, "  if(device_agent.contact.value.length < 1){alert('����д��ϵ��');return;}\n");
	fprintf(cgiOut, "  if(device_agent.tel.value.length < 1){alert('����д�绰');return;}\n");
	fprintf(cgiOut, "  if(device_agent.addr.value.length < 1){alert('����д��ַ');return;}\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    device_agent.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
	return 0;
}
