#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <dirent.h> 
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"
#include "IniFile.h"
#include "DES_Util.h"

//��������
char cmd[4] = {0};
char port[10] = {0};

//��������
static void getHtmlData();
static void QueryData();
static bool doSet();
static void doBOA();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://����
					if(doSet())
						printf("0000\n");
					else
						printf("3006\n");
					break;
				case 2://��������
					doBOA();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("port", port, sizeof(port));
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-�˿�����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"port_set\" action=\"port_set.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/port_set.gif\"/></div><br><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"70%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='30%%' align='center'>�˿�����</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' id='port' name='port' value='' style='width:96%%;height:20px;' maxlength=5>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='center'>\n");
	fprintf(cgiOut, "      <img src='../skin/images/mini_button_submit.gif' style='cursor:hand;' onClick='doSet()'/>\n");
	fprintf(cgiOut, "      <img src='../skin/images/mini_button_boa.gif'    style='cursor:hand;' onClick='doBOA()'/>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	
	//��ȡ�˿�
	FILE *boainfo = fopen("/etc/boa/boa.conf", "rb+");
	char buffer[1024] = {0};
	if(NULL != boainfo)
	{
		int i = 0;
		while(fgets(buffer, 1024, boainfo) != NULL)
	 	{
 			buffer[strlen(buffer)-1] = '\0';//ȥ���з�
			if(NULL != buffer && strlen(buffer) > 0 && !strstr(buffer, "#"))
			{
				if(0 == i)
				{
					fprintf(cgiOut, "document.getElementById('port').value = '%s'.substring(5);\n", buffer);
				}
				i++;
			}
	 	}
	}
	
	//BOA����
	fprintf(cgiOut, "function doBOA()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ����������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'port_set.cgi?cmd=2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	//����
	fprintf(cgiOut, "var reqSel = null;\n");
	fprintf(cgiOut, "function doSet()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(port_set.port.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�˿ں�');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<port_set.port.value.length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(isNaN(port_set.port.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�˿ں����뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ���ύ?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqSel = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqSel = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqSel.onreadystatechange = function()\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var state = reqSel.readyState;\n");
	fprintf(cgiOut, "      if(state == 4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(reqSel.status == 200)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Resp = reqSel.responseText;\n");
	fprintf(cgiOut, "          if(null != Resp && Resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('�ɹ�');\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          else\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    };\n");
	fprintf(cgiOut, "    var url = 'port_set.cgi?cmd=1&port='+port_set.port.value+'&currtime='+new Date();\n");
	fprintf(cgiOut, "    reqSel.open('GET',url,false);\n");
	fprintf(cgiOut, "    reqSel.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

bool doSet()
{
	//�����ļ�
	FILE *boa_bak = fopen("/etc/boa/boa_bak.conf", "w");
	if(NULL == boa_bak)
	{
		return false;
	}
	
	//��ȡԴ�ļ�
	FILE *boainfo = fopen("/etc/boa/boa.conf", "rb+");
	char buffer[1024] = {0};
	if(NULL != boainfo)
	{
		int i = 0;
		while(fgets(buffer, 1024, boainfo) != NULL)
	 	{
 			buffer[strlen(buffer)-1] = '\0';//ȥ���з�
			if(NULL != buffer && strlen(buffer) > 0 && !strstr(buffer, "#"))
			{
				if(0 == i)
				{
					char EditRow[64] = {0};
					sprintf(EditRow, "Port %s", port);
					fputs(EditRow, boa_bak);
					fputs("\n", boa_bak);
				}
				else
				{
					fputs(buffer, boa_bak);
					fputs("\n", boa_bak);
				}
				i++;
			}
			else
			{
				fputs(buffer, boa_bak);
				fputs("\n", boa_bak);
			}
	 	}
	}
	fclose(boainfo);
	fclose(boa_bak);
	
	//�ļ���Ȩ�滻
	chmod("/etc/boa/boa_bak.conf", 0777);
	if(0 != remove("/etc/boa/boa.conf") || 0 != rename("/etc/boa/boa_bak.conf", "/etc/boa/boa.conf"))
	{
		return false;
	}
	
	//����
	return true;
}

void doBOA()
{
	system("killall boa");
	system("killall DDNS");
	system("killall CPM");
	system("/sbin/reboot");
	fprintf(cgiOut, "<script language='javascript'>alert('���������ɹ�');</script>\n");
}
