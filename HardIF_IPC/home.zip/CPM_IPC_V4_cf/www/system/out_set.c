#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"
#include <unistd.h>
#include <fcntl.h>

//��������
char Sql[1024] = {0};
char cmd[4] = {0};
int count = 0;
char id[1024] = {0};
char status[2] = {0};
 
//LOGO
char uploadret[2] = {0};
char flag[2] = {0};

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
//����
static void doHig();
//ѡ��
static void doSel();
//LOGO
static void ImgUpload();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);	
	switch(ret)
	{
		case 0:
			count = 0;
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://����
					doHig();
					break;
				case 2://ѡ��
					doSel();
					break;
				case 3://LOGO
					ImgUpload();
					if(0 == strcmp(uploadret, "1"))
					{
						fprintf(cgiOut, "<script language='javascript'>alert('ͼƬ�����ϴ�ʧ�ܣ�����200K����!');</script>\n");
					}
					else
					{
						fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�! ΪʹͼƬʵʱ��Ч, ��ɾ������������ر���������´򿪵���!');</script>\n");
					}
					sprintf(cmd, "%s", "0");
					QueryData();				
					break;
			}		
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{  
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("status", status, sizeof(status));
	cgiFormString("flag", flag, sizeof(flag));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      	strcat(Sql, "select t.id, t.cname, t.status from out_set t order by t.id");
			break;
		case 11://����
        strcat(Sql, "update out_set set status = '");
        strcat(Sql, status);
				strcat(Sql, "' where id = '");
				strcat(Sql, id);	
				strcat(Sql, "'");
			break;
	}
	return Sql;
}

//LOGO
void ImgUpload()
{
	cgiFilePtr file;
	int targetFile;
	mode_t mode;
	char name[128];
	
	//�ļ���
	char fimename[10] = {0};
	strcat(fimename, "file");
	strcat(fimename, flag);
	
	//�洢��
	char fileNameOnServer[64] = {0};
	if(0 == strcmp(flag, "1"))
	{
		strcat(fileNameOnServer, "/home/www/skin/images/logo_main_znwl.jpg");
	}
	else if(0 == strcmp(flag, "2"))
	{
		strcat(fileNameOnServer, "/home/www/skin/images/logo_sub_system_manage.gif");
	}
	
	char contentType[1024];
	char buffer[1024];
	int size;
	int got;

	//ͼƬ·����ȡ
	if (cgiFormFileName(fimename, name, sizeof(name)) != cgiFormSuccess)
	{    
		fprintf(stderr,"could not retrieve filename\n");
	}

	//ͼƬ����    
	cgiFormFileContentType(fimename, contentType, sizeof(contentType));

	//ͼƬ��С
	cgiFormFileSize(fimename, &size);
	if(size/1024 > 200)
	{
		memcpy(uploadret, "1", 2);
	}
	else
	{
		//Ŀǰ�ļ�������ϵͳ��ʱ�ļ����У�ͨ��Ϊ/tmp��ͨ�����������ʱ�ļ�����ʱ�ļ����������û��ļ������ֲ�ͬ�����Բ���ͨ��·��/tmp/userfilename�ķ�ʽ����ļ�    
		if (cgiFormFileOpen(fimename, &file) != cgiFormSuccess)
		{    
			fprintf(stderr,"could not open the file\n");   
		}
		
		//�ڵ�ǰĿ¼�½����µ��ļ�����һ������ʵ������·�������˴��ĺ�������cgi�������ڵ�Ŀ¼����ǰĿ¼�����������ļ�  
		mode = S_IRWXU|S_IRGRP|S_IROTH;
		targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode); 
		if(targetFile < 0)
		{    
			fprintf(stderr,"could not create the new file,%s\n",fileNameOnServer);    
		}
		
		//��ϵͳ��ʱ�ļ��ж����ļ����ݣ����ŵ��մ�����Ŀ���ļ���
		while(cgiFormFileRead(file, buffer, 1024, &got) == cgiFormSuccess)
		{
			if(got > 0)
				write(targetFile, buffer, got);
		}
		cgiFormFileClose(file);
		close(targetFile);
		
		goto END;
		END:
		if(0 == strcmp(flag, "2"))
		{
			system("cp /home/www/skin/images/logo_sub_system_manage.gif /home/www/skin/images/logo_sub_device_manage.gif");
			system("cp /home/www/skin/images/logo_sub_system_manage.gif /home/www/skin/images/logo_sub_application_manage.gif");
		}
	}
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-������׼</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"out_set\" action=\"out_set.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/out_set.gif\"/></div><br><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"70%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='100px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' valign=top colspan=2>\n");
	fprintf(cgiOut, "      <div style='margin-top:3px;'><font size=4><B>LOGO����</B></font></div>\n");
	fprintf(cgiOut, "      <div style='margin-top:3px;text-align:center;'>\n");
	fprintf(cgiOut, "        <table width=\"98%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "          <tr height='30px'>\n");
	fprintf(cgiOut, "            <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "              ����ҳLOGO:\n");
	fprintf(cgiOut, "          	   <input type='file'   name='file1' title='��ѡ��ͼƬ' value='���' style='width:70%%;height:20px'>\n");
	fprintf(cgiOut, "          	   <input type='button' style='width:50px;height:20px;' value='����' onClick=\"doUpload('1')\">\n");
	fprintf(cgiOut, "            </td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "          <tr height='30px'>\n");
	fprintf(cgiOut, "            <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "              ����ҳLOGO:\n");
	fprintf(cgiOut, "          	   <input type='file'   name='file2' title='��ѡ��ͼƬ' value='���' style='width:70%%;height:20px'>\n");
	fprintf(cgiOut, "          	   <input type='button' style='width:50px;height:20px;' value='����' onClick=\"doUpload('2')\">\n");
	fprintf(cgiOut, "            </td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </div>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='100px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' valign=top colspan=2>\n");
	fprintf(cgiOut, "      <div style='margin-top:3px;'><font size=4><B>����</B></font>&nbsp;<font color='green'>��</font></div>\n");
	fprintf(cgiOut, "      <div style='margin-top:3px;text-align:center;'>\n");
	fprintf(cgiOut, "        <table width=\"98%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "          <tr height='30px'>\n");
	fprintf(cgiOut, "            <td width='50%%' align='left'>�ٻ�����Ϣ(����DDNS��)</td>\n");
	fprintf(cgiOut, "            <td width='50%%' align='left'>���豸����(�����������á������豸���龰�豸����Ƶ�豸)</td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "          <tr height='30px'>\n");
	fprintf(cgiOut, "            <td width='50%%' align='left'>�۶��Ź���</td>\n");
	fprintf(cgiOut, "            <td width='50%%' align='left'>����������</td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "          <tr height='30px'>\n");
	fprintf(cgiOut, "            <td width='100%%' align='left' colspan=2>������+��־</td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </div>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='400px'>\n");
	fprintf(cgiOut, "    <td width='50%%' align='center' valign=top>\n");
	fprintf(cgiOut, "      <div style='margin-top:3px;'><font size=4><B>����</B></font>&nbsp;<input type='checkbox' id='checkboxHig' name='checkboxHig'></div>\n");
	fprintf(cgiOut, "      <div style='height:320px;width:100%%;margin-top:3px;text-align:center;'>\n");
	fprintf(cgiOut, "        <table width=\"98%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "          <tr height='30px'>\n");
	fprintf(cgiOut, "            <td width='50%%' align='left'>���û�����</td>\n");
	fprintf(cgiOut, "            <td width='50%%' align='left'>�ڹ���Ȩ��</td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "          <tr height='30px'>\n");
	fprintf(cgiOut, "            <td width='50%%' align='left'>����Ԫ����</td>\n");
	fprintf(cgiOut, "            <td width='50%%' align='left'>�����ݷ���</td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "          <tr height='30px'>\n");
	fprintf(cgiOut, "            <td width='100%%' align='left' colspan=2>����������</td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </div>\n");
	fprintf(cgiOut, "      <div style='height:30px;width:100%%;margin-top:3px;text-align:center;'>\n");
	fprintf(cgiOut, "        <img src='../skin/images/mini_button_submit.gif' style='cursor:hand;' onClick='doHigh()'/>\n");
	fprintf(cgiOut, "      </div>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "    <td width='50%%' align='center' valign=top>\n");
	fprintf(cgiOut, "      <div style='margin-top:3px;'><font size=4><B>ѡ��</B></font>&nbsp;<input type='checkbox' id='checkboxAll' name='checkboxAll' onClick='doSeltAll()'></div>\n");
	fprintf(cgiOut, "      <div style='height:320px;width:100%%;margin-top:3px;text-align:center;'>\n");
	fprintf(cgiOut, "        <table width=\"98%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "				   <tr height='30px'>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </div>\n");
	fprintf(cgiOut, "      <div style='height:30px;width:100%%;margin-top:3px;text-align:center;'>\n");
	fprintf(cgiOut, "        <img src='../skin/images/mini_button_submit.gif' style='cursor:hand;' onClick='doSelt()'/>\n");
	fprintf(cgiOut, "      </div>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'  value='3'>\n");
	fprintf(cgiOut, "<input type='hidden' name='flag' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//LOGO
	fprintf(cgiOut, "function doUpload(pFlag)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var pUrl = '';\n");
	fprintf(cgiOut, "  switch(parseInt(pFlag))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "    	 pUrl = out_set.file1.value\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "      pUrl = out_set.file2.value\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(pUrl.indexOf('.jpg') == -1 && pUrl.indexOf('.JPG') == -1 && pUrl.indexOf('.gif') == -1 && pUrl.indexOf('.GIF') == -1 && pUrl.indexOf('.bmp') == -1 && pUrl.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  out_set.flag.value = pFlag;\n");
	fprintf(cgiOut, "  if(confirm('ȷ������LOGOͼƬ?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    out_set.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "var reqHig = null;\n");
	fprintf(cgiOut, "function doHigh()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var Status = '0';\n");
	fprintf(cgiOut, "  if(document.getElementById('checkboxHig').checked)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Status = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqHig = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqHig = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqHig.onreadystatechange = function()\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var state = reqHig.readyState;\n");
	fprintf(cgiOut, "      if(state == 4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(reqHig.status == 200)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Resp = reqHig.responseText;\n");
	fprintf(cgiOut, "          if(null != Resp && Resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('�ɹ�');\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          else\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    };\n");
	fprintf(cgiOut, "    var url = 'out_set.cgi?cmd=1&id=0001&status='+Status+'&currtime='+new Date();\n");
	fprintf(cgiOut, "    reqHig.open('GET',url,false);\n");
	fprintf(cgiOut, "    reqHig.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//ѡ��
	fprintf(cgiOut, "var reqSel = null;\n");
	fprintf(cgiOut, "function doSelt()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var Id = '';\n");
	fprintf(cgiOut, "  for(var i=0; i<%d; i++)\n", count);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('checkbox'+i))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(document.getElementById('checkbox'+i).checked)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Id += document.getElementById('checkbox'+i).value + ',1;'\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Id += document.getElementById('checkbox'+i).value + ',0;'\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(Id.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�޲�����');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqSel = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqSel = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqSel.onreadystatechange = function()\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var state = reqSel.readyState;\n");
	fprintf(cgiOut, "      if(state == 4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(reqSel.status == 200)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Resp = reqSel.responseText;\n");
	fprintf(cgiOut, "          if(null != Resp && Resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('�ɹ�');\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          else\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "            return;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('ʧ�ܣ������²���');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    };\n");
	fprintf(cgiOut, "    var url = 'out_set.cgi?cmd=2&id='+Id+'&currtime='+new Date();\n");
	fprintf(cgiOut, "    reqSel.open('GET',url,false);\n");
	fprintf(cgiOut, "    reqSel.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//ȫѡ
	fprintf(cgiOut, "function doSeltAll()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(document.getElementById('checkboxAll').checked)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    for(var i=0; i<%d; i++)\n", count);
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "     if(document.getElementById('checkbox'+i))\n");
	fprintf(cgiOut, "     {\n");
	fprintf(cgiOut, "       document.getElementById('checkbox'+i).checked = true;\n");
	fprintf(cgiOut, "     }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    for(var i=0; i<%d; i++)\n", count);
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "     if(document.getElementById('checkbox'+i))\n");
	fprintf(cgiOut, "     {\n");
	fprintf(cgiOut, "       document.getElementById('checkbox'+i).checked = false;\n");
	fprintf(cgiOut, "     }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{  
	if(0 == strcmp(col_values[0], "0001"))
	{//����
		if(0 == strcmp(col_values[2], "1"))
		{
			fprintf(cgiOut, "<script>document.getElementById('checkboxHig').checked = true;</script>\n");
		}
	}
	else
	{//ѡ��
		if(0 == count%2 && count > 0)
		{
			fprintf(cgiOut, "</tr>\n");
			fprintf(cgiOut, "<tr height='30px'>\n");
		}
		
		char ischecked[10] = {0};
		switch(atoi(col_values[2]))
		{
			case 0:
					strcat(ischecked, "");
				break;
			case 1:
					strcat(ischecked, "checked");
				break;
		}
		
		fprintf(cgiOut, "<td width='50%%' align='left'>\n");
		fprintf(cgiOut, "  <input type='checkbox' id='checkbox%d' name='checkbox%d' value='%s' %s>%s\n", count, count, col_values[0], ischecked, col_values[1]);
		fprintf(cgiOut, "</td>\n");
		count++;
	}
	return 0;
}

void doHig()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(11), NULL, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(2);
	}
	sqlite3_close(db);
	printf("0000\n");
}

void doSel()
{
	
	int rc;
	char * zErrMsg = 0;
	char sql[256] = {0};
	sqlite3 *db = open_db(DB_PATH);
	
	char *p;
	char *buffer = strdup(id);
	p = strtok(buffer, ";");
	while(NULL != p)
	{
		char s_id[5] = {0};
		char s_sta[2] = {0};
		strncpy(s_id, p, 4);
		strncpy(s_sta,  p+5, 1);
		
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "update out_set set status = '%s' where id = '%s'", s_sta, s_id);			
		rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(2);
		}
		
		//�޸��豸��Ϣ
		switch(atoi(s_id))
		{
			case 4:
			{
				memset(sql, 0, sizeof(sql));
				sprintf(sql, "update device_info set status = '%s' where ctype2 = '02'", s_sta);
				rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
				break;
			}
			case 5:
			{
				memset(sql, 0, sizeof(sql));
				sprintf(sql, "update device_info set status = '%s' where ctype2 = '01'", s_sta);
				rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
				break;
			}
			case 6:
			{
				memset(sql, 0, sizeof(sql));
				sprintf(sql, "update device_info set status = '%s' where ctype2 = '03'", s_sta);
				rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
				break;
			}
		}
		
		p = strtok(NULL, ";");
	}
	
	sqlite3_close(db);
	printf("0000\n");
}
