#include <stdio.h>
#include <string.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <stdlib.h>   
#include "util.h"

//��Ա��������
char Sql[1024] = {0};
int cnt = 0;
char cmd[4] = {0};

//��device_attr
char id[7] = {0};			                //���
char sn[5] = {0};					            //Ψһ��
char attr_id[3] = {0};                //�������
char attr_name[21] = {0};             //��������
char r_format[255] = {0};	            //����ʽ
char rd_format[255] = {0};			      //������
char rd_comparison_table[1024] = {0}; //�����
char ck_format[255] = {0};			      //У���ʽ
char private_attr[255] = {0};			    //˽�в���
char s_define[128] = {0};             //״̬����
char value_limit[64] = {0};           //ֵ��Χ
char ctype[2] = {0};                  //����
char ledger[2] = {0};                 //ͳ������
char card[2]   = {0};                 //������

char cname[51] = {0};			            //�豸��Ϣ����
char agentid[5] = {0};			          //���ұ��
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
//ɾ��
static void DeleteData();
//���ӡ��༭��
static void AttrSubmit();
//����
static void AddData();
static int sqlite3_exec_callback_unique(void *data, int n_columns, char **col_values, char **col_names);
//�༭
static void UdpData();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{		
				case 0://��ѯ
					QueryData();
					break;
				case 1://���ӡ��༭��
					AttrSubmit();
					break;
				case 10://����
					AddData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 11://�༭
					UdpData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 12://ɾ��
					DeleteData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}		
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("id", id, sizeof(id));	
	cgiFormString("attr_id", attr_id, sizeof(attr_id));
	cgiFormString("attr_name", attr_name, sizeof(attr_name));	
	cgiFormString("r_format", r_format, sizeof(r_format));
	cgiFormString("rd_format", rd_format, sizeof(rd_format));
	cgiFormString("rd_comparison_table", rd_comparison_table, sizeof(rd_comparison_table));
	cgiFormString("ck_format", ck_format, sizeof(ck_format));
	cgiFormString("private_attr", private_attr, sizeof(private_attr));
	cgiFormString("s_define", s_define, sizeof(s_define));
	cgiFormString("value_limit", value_limit, sizeof(value_limit));	
	cgiFormString("ctype", ctype, sizeof(ctype));
	cgiFormString("ledger", ledger, sizeof(ledger));	
	cgiFormString("card", card, sizeof(card));	
	
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("agentid", agentid, sizeof(agentid));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));	
	switch(pCmd)
	{	
		case 0://��ѯ	
      strcat(Sql, "select t.sn, t.id, t.attr_id, t.attr_name, t.r_format, t.rd_format, t.rd_comparison_table, t.ck_format, t.private_attr, '' as status, t.s_define, a.cname, t.value_limit, t.ctype, t.ledger, t.card from device_attr t, device_info a where t.id = a.id and t.id = '");
      strcat(Sql, id);
      strcat(Sql, "' order by t.id");
			break;
		case 1://�ж�Ψһ	
      strcat(Sql, "select t.sn, t.id, t.attr_id, t.attr_name, t.r_format, t.rd_format, t.rd_comparison_table, t.ck_format, t.private_attr, '' as status, t.s_define, a.cname, t.value_limit, t.ctype, t.ledger, t.card from device_attr t, device_info a where t.id = a.id and t.id = '");
      strcat(Sql, id);
      strcat(Sql, "' and t.sn = '");
      strcat(Sql, sn);
      strcat(Sql, "'");
			break;	
		case 10://����
			strcat(Sql, "insert into device_attr(sn, id, attr_id, attr_name, r_format, rd_format, rd_comparison_table, ck_format, private_attr, s_define, value_limit, ctype, ledger, card)values('");
			strcat(Sql, sn);
			strcat(Sql, "', '");
			strcat(Sql, id);
			strcat(Sql, "', '");
			strcat(Sql, attr_id);
			strcat(Sql, "', '");
			strcat(Sql, attr_name);
			strcat(Sql, "', '");
			strcat(Sql, r_format);
			strcat(Sql, "', '");
			strcat(Sql, rd_format);
			strcat(Sql, "', '");
			strcat(Sql, rd_comparison_table);
			strcat(Sql, "', '");
			strcat(Sql, ck_format);
			strcat(Sql, "', '");
			strcat(Sql, private_attr);
			strcat(Sql, "', '");
			strcat(Sql, s_define);
			strcat(Sql, "', '");
			strcat(Sql, value_limit);
			strcat(Sql, "', '");
			strcat(Sql, ctype);
			strcat(Sql, "', '");
			strcat(Sql, ledger);
			strcat(Sql, "', '");
			strcat(Sql, card);	
			strcat(Sql, "')");
			break;
		case 11://�༭
			strcat(Sql, "update device_attr set attr_id = '");
			strcat(Sql, attr_id);
			strcat(Sql, "', attr_name = '");
			strcat(Sql, attr_name);
			strcat(Sql, "', r_format = '");
			strcat(Sql, r_format);	
			strcat(Sql, "', rd_format = '");
			strcat(Sql, rd_format);
			strcat(Sql, "', rd_comparison_table = '");
			strcat(Sql, rd_comparison_table);			
			strcat(Sql, "', ck_format = '");
			strcat(Sql, ck_format);
			strcat(Sql, "', private_attr = '");
			strcat(Sql, private_attr);
			strcat(Sql, "', s_define = '");
			strcat(Sql, s_define);
			strcat(Sql, "', value_limit = '");
			strcat(Sql, value_limit);		
			strcat(Sql, "', ctype = '");
			strcat(Sql, ctype);
			strcat(Sql, "', ledger = '");
			strcat(Sql, ledger);
			strcat(Sql, "', card = '");
			strcat(Sql, card);
			strcat(Sql, "' where sn = '");
			strcat(Sql, sn);
			strcat(Sql, "' and id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 12://ɾ��
			strcat(Sql, "delete from device_attr where sn = '");
      strcat(Sql, sn);
      strcat(Sql, "' and id = '");
      strcat(Sql, id);
      strcat(Sql, "'");
			break;
	}
	return Sql;
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-�ɼ�����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 50%%;\n");
	fprintf(cgiOut, "  height:99%%;\n");
	fprintf(cgiOut, "  left:300px;\n");
	fprintf(cgiOut, "  top:1%%;\n");;
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"data_type\" action=\"data_type.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/device_attr.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"80%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='50%%' align='left'><font color='red'>����:%s</font></td>\n", cname);
	fprintf(cgiOut, "    <td width='50%%' align='right'>\n");
	fprintf(cgiOut, "      <img src=\"../skin/images/mini_button_add.gif\" style='cursor:hand;' onClick=\"doAttrSubmit('1', '', '%s', '%s', '', '', '', '', '', '', '', '', '', '', '0', '1', '0')\"/><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'>\n", id, cname);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>\n");
	fprintf(cgiOut, "      <table width=\"100%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	fprintf(cgiOut, "          <td width='10%%' align='center' class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "          <td width='10%%' align='center' class=\"table_deep_blue\">��������</td>\n");
	fprintf(cgiOut, "          <td width='10%%' align='center' class=\"table_deep_blue\">�������</td>\n");
	fprintf(cgiOut, "          <td width='10%%' align='center' class=\"table_deep_blue\">ɾ ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}	
	sqlite3_close(db);
	
	if(0 == cnt)
	{
		fprintf(cgiOut, "      <tr height='30px'>\n");
		fprintf(cgiOut, "        <td width='100%%' align='center' colspan=4>��</td>\n");
		fprintf(cgiOut, "      </tr>\n");
	}
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='popDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'device_info.cgi?cmd=0&agentid=%s';\n", agentid);
	fprintf(cgiOut, "}\n");
	//ɾ��
	fprintf(cgiOut, "function doDelete(pSN, pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ��ɾ��?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'device_attr.cgi?cmd=12&sn='+pSN+'&id='+pId+'&agentid=%s&cname=%s';\n",agentid, cname);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
  //�򿪵�����
	fprintf(cgiOut, "function doAttrSubmit(pCmd, pSN, pId, pCName, pAttr_Id, pAttr_Name, pR_Format, pRD_Format, pRD_Comparison_Table, pCK_Format, pPrivate_Attr, pStatus, pS_Define, pValue_Limit, pCType, pLedger, pCard)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'device_attr.cgi?cmd=1&actcmd='+pCmd+'&sn='+pSN+'&id='+pId+'&cname='+pCName+'&attr_id='+pAttr_Id+'&attr_name='+pAttr_Name+'&r_format='+pR_Format+'&rd_format='+pRD_Format+'&rd_comparison_table='+pRD_Comparison_Table+'&ck_format='+pCK_Format+'&private_attr='+pPrivate_Attr+'&s_define='+pS_Define+'&value_limit='+pValue_Limit+'&ctype='+pCType+'&ledger='+pLedger+'&card='+pCard+'&agentid=%s';\n", agentid);
	fprintf(cgiOut, "  document.getElementById('popDiv').innerHTML = \"<iframe id='divFrame' name='divFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//�رյ�����
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

//��ѯ����
int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(cnt%2 == 0)
	{
		fprintf(cgiOut, "<tr class='table_blue' height='30px'>\n");
	}
	else
	{
		fprintf(cgiOut, "<tr class='table_white_l' height='30px'>\n");
	}
	
	fprintf(cgiOut, "<td width='10%%'  align='center' style='cursor:hand;color:red;' title='����༭' onClick=\"doAttrSubmit('2', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s');\">%s</td>\n", col_values[0], col_values[1], cname, col_values[2], col_values[3], col_values[4], col_values[5], col_values[6], col_values[7], col_values[8], col_values[9], col_values[10], col_values[12], col_values[13], col_values[14], col_values[15], col_values[0]);	
	fprintf(cgiOut, "<td width='10%%'  align='center'>%s</td>\n", col_values[3]);
	fprintf(cgiOut, "<td width='10%%'  align='center'>%s</td>\n", col_values[2]);
	fprintf(cgiOut, "<td width='10%%'  align='center' style='cursor:hand;color:red;' title='���ɾ��' onClick=\"doDelete('%s', '%s');\">ɾ ��</td>\n", col_values[0], col_values[1]);
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

void AttrSubmit()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-�ɼ�����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"attrsubmit\" action=\"device_attr.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "  <table align='center' width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   %s\n", cname);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	if(0 < strlen(sn))
	{
		fprintf(cgiOut, "    	 %s<input type='hidden' name='sn' value='%s' style='width:250px;height:20px;' maxlength=4>\n", sn, sn);
	}
	else
	{
		fprintf(cgiOut, "    	 <input type='text' name='sn' value='%s' style='width:250px;height:20px;' maxlength=4>\n", sn);
	}
	
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <input type='text' name='attr_name' value='%s' style='width:250px;height:20px;' maxlength=10>\n", attr_name);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>�������</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <input type='text' name='attr_id' value='%s' style='width:250px;height:20px;' maxlength=2>\n", attr_id);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>�� �� ʽ</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <input type='text' name='r_format' value='%s' style='width:250px;height:20px;' maxlength=125>\n", r_format);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>�� �� ��</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <input type='text' name='rd_format' value='%s' style='width:250px;height:20px;' maxlength=125>\n", rd_format);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>�� �� ��</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <input type='text' name='rd_comparison_table' value='%s' style='width:250px;height:20px;' maxlength=512>\n", rd_comparison_table);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>У���ʽ</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <input type='text' name='ck_format' value='%s' style='width:250px;height:20px;' maxlength=125>\n", ck_format);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>״̬����</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <input type='text' name='s_define' value='%s' style='width:250px;height:20px;' maxlength=60>\n", s_define);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>ͼƬ��</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <input type='text' name='value_limit' value='%s' style='width:250px;height:20px;' maxlength=60>\n", value_limit);
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='ctype' style='width:60px;height:20px;'>\n");
	fprintf(cgiOut, "    	   	 <option value='0' %s>ʵ��</option>\n", 0 == strcmp(ctype, "0")?"selected":"");
	fprintf(cgiOut, "    	   	 <option value='1' %s>���</option>\n", 0 == strcmp(ctype, "1")?"selected":"");
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>ͳ������</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='ledger' style='width:60px;height:20px;'>\n");
	fprintf(cgiOut, "    	   	 <option value='0' %s>������</option>\n", 0 == strcmp(ledger, "0")?"selected":"");
	fprintf(cgiOut, "    	   	 <option value='1' %s>����ֵ</option>\n", 0 == strcmp(ledger, "1")?"selected":"");
	fprintf(cgiOut, "    	   	 <option value='2' %s>������</option>\n", 0 == strcmp(ledger, "2")?"selected":"");
	fprintf(cgiOut, "    	   </select>\n");
	fprintf(cgiOut, "    	 </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  	 <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>������</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "    	   <select name='card' style='width:60px;height:20px;'>\n");
	fprintf(cgiOut, "    	   	 <option value='0' %s>��</option>\n", 0 == strcmp(card, "0")?"selected":"");
	fprintf(cgiOut, "    	     <option value='1' %s>��</option>\n", 0 == strcmp(card, "1")?"selected":"");
	fprintf(cgiOut, "    		 </select>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "  	 </tr>\n");
	fprintf(cgiOut, "  	 <tr height='50px'>\n");
	fprintf(cgiOut, "      <td width='25%%' align='center'>�ɼ�����</td>\n");
	fprintf(cgiOut, "      <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "        <table width='100%%'>\n");
	fprintf(cgiOut, "      	   <tr height='25'>\n");
	fprintf(cgiOut, "    	 	     <td width='33%%'><input type='checkbox' name='checkbox1' id='checkbox1' value='interval,'>�ɼ�����</td>\n");
	fprintf(cgiOut, "    	 	     <td width='33%%'><input type='checkbox' name='checkbox2' id='checkbox2' value='standard,'>��׼��Χ</td>\n");
	fprintf(cgiOut, "    	       <td width='33%%'><input type='checkbox' name='checkbox3' id='checkbox3' value='agent,'>��������</td>\n");
	fprintf(cgiOut, "    	     </tr>\n");
	fprintf(cgiOut, "    	     <tr height='25'>\n");
	fprintf(cgiOut, "    	       <td width='33%%'><input type='checkbox' name='checkbox4' id='checkbox4' value='isUpload,'>�Ƿ��ϴ�</td>\n");
	fprintf(cgiOut, "    	       <td width='66%%' colspan=2><input type='checkbox' name='checkbox5' id='checkbox5' value='defence,'>����ʱ��</td>\n");
	fprintf(cgiOut, "    	 	   </tr>\n");
	fprintf(cgiOut, "      	 </table>\n");
	fprintf(cgiOut, "  	   </td>\n");
	fprintf(cgiOut, "    </tr>\n");
			
	if(strstr(private_attr, "interval"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox1').checked = true;</script>\n");
	
	if(strstr(private_attr, "standard"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox2').checked = true;</script>\n");
		
	if(strstr(private_attr, "agent"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox3').checked = true;</script>\n");
		
	if(strstr(private_attr, "isUpload"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox4').checked = true;</script>\n");
		
	if(strstr(private_attr, "defence"))
		fprintf(cgiOut, "<script language='javascript'>document.getElementById('checkbox5').checked = true;</script>\n");
	
	
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <div style='text-align:center;margin-top:5px;'>\n");
	fprintf(cgiOut, "    <img style='cursor:hand' onClick='doSubmit()' src='../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "	   <img style='cursor:hand' onClick='doCancel()' src='../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='10'>\n");
	fprintf(cgiOut, "  <input type='hidden' name='id' value='%s'>\n", id);
	fprintf(cgiOut, "  <input type='hidden' name='private_attr' value=''>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cname' value='%s'>\n", cname);
	fprintf(cgiOut, "  <input type='hidden' name='agentid' value='%s'>\n", agentid);
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{\n");	
	fprintf(cgiOut, "  if(attrsubmit.sn.value.length != 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д���,��0001');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(attrsubmit.attr_id.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�������');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(attrsubmit.attr_name.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д��������');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(attrsubmit.s_define.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    attrsubmit.s_define.value = '';\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  var Private_Attr = '';\n");
	fprintf(cgiOut, "  for(var i=1; i<=5; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('checkbox' + i).checked)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      Private_Attr += document.getElementById('checkbox' + i).value;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  attrsubmit.private_attr.value = Private_Attr;\n");
	
	
	char actcmd[5] = {0};
	cgiFormString("actcmd", actcmd, sizeof(actcmd));	
	if(0 == strcmp(actcmd, "1"))
	{//����
		fprintf(cgiOut, "if(confirm('ȷ������?'))\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  attrsubmit.cmd.value = '10';\n");
		fprintf(cgiOut, "  attrsubmit.submit();\n");
		fprintf(cgiOut, "}\n");
	}
	else if(0 == strcmp(actcmd, "2"))
	{//�༭
		fprintf(cgiOut, "if(confirm('ȷ���༭?'))\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  attrsubmit.cmd.value = '11';\n");
		fprintf(cgiOut, "  attrsubmit.submit();\n");
		fprintf(cgiOut, "}\n");
	}
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

void AddData()
{
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_unique, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	
	if(0 < cnt)
	{
		fprintf(cgiOut, "<script language='javascript'>alert('��ǰ����Ѵ���,�����¶���!');</script>\n");
	}
	else
	{
		rc = sqlite3_exec(db, getSql(10), &sqlite3_exec_callback, 0, &zErrMsg);
		if( rc!=SQLITE_OK )
		{
		  err_msg(1);
		}
	}
	
	sqlite3_close(db);
}

int sqlite3_exec_callback_unique(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

void UdpData()
{
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
}

//ɾ��
void DeleteData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);			
	rc = sqlite3_exec(db, getSql(12), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}	
	sqlite3_close(db);
}
