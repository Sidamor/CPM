#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "util.h"
#include "session.h"
#include "cgic.h"

//��������
int cnt = 0;
char cmd[4] = {0};
char user_id[31] = {0};
FILE *csv_file = NULL;
char Func_Sel_Id[2] = {0};
char Year[5]   = {0};
char Month[3]  = {0};
char BTime[30] = {0};
char ETime[30] = {0};
char id[4096*8] = {0};
char level[2] = {0};
//����Ա
char chg_id[5] = {0};
char chg_name[31] = {0};
int late_cnt   = 0;
int leave_cnt  = 0;
int away_cnt   = 0;
//��������
static void getHtmlData();
bool	ContainsFP(char *pUser_Id, char *pFP_Id);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
//��ϸ
static void doDetail();
static int sqlite3_exec_callback_detail(void *data, int n_columns, char **col_values, char **col_names);
//����
static void ExportData();
static int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names);
//��ϸ����
static void DetailExportData();
static int sqlite3_exec_callback_detail_Export(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	late_cnt  = 0;
	leave_cnt = 0;
	away_cnt  = 0;
	switch(atoi(cmd))
	{
		case 0://��ѯ
			QueryData();
			break;
		case 1://��ϸ
			doDetail();
			break;
		case 2://����
			ExportData();
			break;
		case 3://��ϸ����
			DetailExportData();
			break;
	}
	return 0;
}

void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("id", id, sizeof(id));
	cgiFormString("level", level, sizeof(level));
	cgiFormString("BTime", BTime, sizeof(BTime));
	cgiFormString("ETime", ETime, sizeof(ETime));
	cgiFormString("Year", Year, sizeof(Year));
	cgiFormString("Month", Month, sizeof(Month));
	cgiFormString("Func_Sel_Id", Func_Sel_Id, sizeof(Func_Sel_Id));
	cgiFormString("user_id", user_id, sizeof(user_id));
}

void QueryData()
{
	fprintf(cgiOut, "<HTML>\n");
	fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "  <TITLE>����ͳ��</TITLE>\n");
	fprintf(cgiOut, "  <meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "  <meta http-equiv='x-ua-compatible' content='ie=7'/>\n");
	fprintf(cgiOut, "  <link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "  <script type='text/javascript' src='../../skin/js/My97DatePicker/WdatePicker.js'></script>\n");
	fprintf(cgiOut, "  <script language='javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "  <SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "  <style type='text/css'>\n");
	fprintf(cgiOut, "  html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, "  .mydiv\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    background-color: #e0e6ed;\n");
	fprintf(cgiOut, "    border: 0px solid green;\n");
	fprintf(cgiOut, "    text-align: center;\n");
	fprintf(cgiOut, "    line-height: 40px;\n");
	fprintf(cgiOut, "    font-size: 12px;\n");
	fprintf(cgiOut, "    font-weight: bold;\n");
	fprintf(cgiOut, "    z-index:999;\n");
	fprintf(cgiOut, "    width: 100%%;\n");
	fprintf(cgiOut, "    height:100%%;\n");
	fprintf(cgiOut, "    left:0;\n");
	fprintf(cgiOut, "    top: 0;\n");;
	fprintf(cgiOut, "    position:fixed!important;\n");
	fprintf(cgiOut, "    position:absolute;\n");
	fprintf(cgiOut, "    _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  </style>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style='background:#CADFFF'>\n");
	fprintf(cgiOut, "<form name='ats_ldg' action='ats_ldg.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "<table style='margin:auto' cellpadding='0' cellspacing='0' border='0' width='100%%'>\n");
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "    <td width='50%%' align='left'>\n");
	fprintf(cgiOut, "	     <select name='Func_Sel_Id' style='width:90px;height:20px' onChange='doSelect()'>\n");
	fprintf(cgiOut, "			   <option value='1' %s>�±���</option>\n", 0 == strcmp(Func_Sel_Id, "1")?"selected":"");
	fprintf(cgiOut, "			   <option value='2' %s>�Զ���</option>\n", 0 == strcmp(Func_Sel_Id, "2")?"selected":"");
	fprintf(cgiOut, "		   </select>\n");
	fprintf(cgiOut, "	     <select id='Year' name='Year' style='width:60px;height:20px;display:none;'>\n");
	fprintf(cgiOut, "        <option value='2011' %s>2011��</option>\n", 0 == strcmp(Year, "2011")?"selected":"");
	fprintf(cgiOut, "        <option value='2012' %s>2012��</option>\n", 0 == strcmp(Year, "2012")?"selected":"");
	fprintf(cgiOut, "        <option value='2013' %s>2013��</option>\n", 0 == strcmp(Year, "2013")?"selected":"");
	fprintf(cgiOut, "        <option value='2014' %s>2014��</option>\n", 0 == strcmp(Year, "2014")?"selected":"");
	fprintf(cgiOut, "        <option value='2015' %s>2015��</option>\n", 0 == strcmp(Year, "2015")?"selected":"");
	fprintf(cgiOut, "        <option value='2016' %s>2016��</option>\n", 0 == strcmp(Year, "2016")?"selected":"");
	fprintf(cgiOut, "        <option value='2017' %s>2017��</option>\n", 0 == strcmp(Year, "2017")?"selected":"");
	fprintf(cgiOut, "        <option value='2018' %s>2018��</option>\n", 0 == strcmp(Year, "2018")?"selected":"");
	fprintf(cgiOut, "        <option value='2019' %s>2019��</option>\n", 0 == strcmp(Year, "2019")?"selected":"");
	fprintf(cgiOut, "        <option value='2020' %s>2020��</option>\n", 0 == strcmp(Year, "2020")?"selected":"");
	fprintf(cgiOut, "        <option value='2021' %s>2021��</option>\n", 0 == strcmp(Year, "2021")?"selected":"");
	fprintf(cgiOut, "        <option value='2022' %s>2022��</option>\n", 0 == strcmp(Year, "2022")?"selected":"");
	fprintf(cgiOut, "        <option value='2023' %s>2023��</option>\n", 0 == strcmp(Year, "2023")?"selected":"");
	fprintf(cgiOut, "        <option value='2024' %s>2024��</option>\n", 0 == strcmp(Year, "2024")?"selected":"");
	fprintf(cgiOut, "        <option value='2025' %s>2025��</option>\n", 0 == strcmp(Year, "2025")?"selected":"");
	fprintf(cgiOut, "        <option value='2026' %s>2026��</option>\n", 0 == strcmp(Year, "2026")?"selected":"");
	fprintf(cgiOut, "        <option value='2027' %s>2027��</option>\n", 0 == strcmp(Year, "2027")?"selected":"");
	fprintf(cgiOut, "        <option value='2028' %s>2028��</option>\n", 0 == strcmp(Year, "2028")?"selected":"");
	fprintf(cgiOut, "        <option value='2029' %s>2029��</option>\n", 0 == strcmp(Year, "2029")?"selected":"");
	fprintf(cgiOut, "        <option value='2030' %s>2030��</option>\n", 0 == strcmp(Year, "2030")?"selected":"");					
	fprintf(cgiOut, "	     </select>\n");
	fprintf(cgiOut, "	     <select id='Month' name='Month' style='width:50px;height:20px;display:none;'>\n");
	fprintf(cgiOut, "        <option value='01' %s>1��</option>\n",  0 == strcmp(Month, "01")?"selected":"");
	fprintf(cgiOut, "        <option value='02' %s>2��</option>\n",  0 == strcmp(Month, "02")?"selected":"");
	fprintf(cgiOut, "        <option value='03' %s>3��</option>\n",  0 == strcmp(Month, "03")?"selected":"");
	fprintf(cgiOut, "        <option value='04' %s>4��</option>\n",  0 == strcmp(Month, "04")?"selected":"");
	fprintf(cgiOut, "        <option value='05' %s>5��</option>\n",  0 == strcmp(Month, "05")?"selected":"");
	fprintf(cgiOut, "        <option value='06' %s>6��</option>\n",  0 == strcmp(Month, "06")?"selected":"");
	fprintf(cgiOut, "        <option value='07' %s>7��</option>\n",  0 == strcmp(Month, "07")?"selected":"");
	fprintf(cgiOut, "        <option value='08' %s>8��</option>\n",  0 == strcmp(Month, "08")?"selected":"");
	fprintf(cgiOut, "        <option value='09' %s>9��</option>\n",  0 == strcmp(Month, "09")?"selected":"");
	fprintf(cgiOut, "        <option value='10' %s>10��</option>\n", 0 == strcmp(Month, "10")?"selected":"");
	fprintf(cgiOut, "        <option value='11' %s>11��</option>\n", 0 == strcmp(Month, "11")?"selected":"");
	fprintf(cgiOut, "        <option value='12' %s>12��</option>\n", 0 == strcmp(Month, "12")?"selected":"");
	fprintf(cgiOut, "	     </select>\n");
	fprintf(cgiOut, "	     <input id='BDate' name='BDate' type='text' style='width:90px;height:18px;display:none;' value='%s' onClick='WdatePicker({readOnly:true})' class='Wdate' maxlength='10'>\n", BTime);
	fprintf(cgiOut, "	     -\n");
	fprintf(cgiOut, "	     <input id='EDate' name='EDate' type='text' style='width:90px;height:18px;display:none;' value='%s' onClick='WdatePicker({readOnly:true})' class='Wdate' maxlength='10'>\n", ETime);		
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "		 <td width='50%%' align='right'>\n");
	fprintf(cgiOut, "			 <input name='alert_submit' style='cursor:hand;width:60px;' onClick='doSelect()' value='��ѯ' type='button'>\n");
	fprintf(cgiOut, "			 <input name='alert_export' style='cursor:hand;width:60px;' onClick='doExport()' value='����' type='button'>\n");
	fprintf(cgiOut, "		 </td>\n");
	fprintf(cgiOut, "	 </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<div id='down_bg_2'>\n");
	fprintf(cgiOut, "<table style='margin:auto' cellpadding='0' cellspacing='0' border='1' width='100%%' bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "  <tr height='25px'>\n");
	fprintf(cgiOut, "    <td width='20%%' class='table_deep_blue' align=center>�� Ա</td>\n");
	fprintf(cgiOut, "    <td width='20%%' class='table_deep_blue' align=center>�ϰ�ٵ�(����)</td>\n");
	fprintf(cgiOut, "    <td width='20%%' class='table_deep_blue' align=center>�°�����(����)</td>\n");
	fprintf(cgiOut, "    <td width='20%%' class='table_deep_blue' align=center>δ��(����)</td>\n");
	fprintf(cgiOut, "    <td width='20%%' class='table_deep_blue' align=center>�� ϸ</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	//ͳ��
	if(strlen(id) > 0)
	{
		switch(atoi(level))
		{
			case 0:
			case 1:
			case 2:
					int rc;
					char * zErrMsg = 0;
					sqlite3 *db = open_db(DB_PATH_BAK);
					char sql[4096*8] = {0};
					sprintf(sql, "SELECT A.ID, A.CTIME, A.BELATE, A.BELEAVE, A.BEAWAY, B.CNAME FROM ATS_RESULT A, USER_INFO B WHERE A.ID = B.SYS_ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.ID) = 1 ORDER BY A.ID, A.CTIME ", BTime, ETime, id);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
					sqlite3_close(db);
					
					if(0 < cnt)
					{
						fprintf(cgiOut, "<tr height='30px'>\n");
						fprintf(cgiOut, "  <td width='20%%' align=center>%s</td>\n", chg_name);
						fprintf(cgiOut, "  <td width='20%%' align=center>%d</td>\n", late_cnt);
						fprintf(cgiOut, "  <td width='20%%' align=center>%d</td>\n", leave_cnt);
						fprintf(cgiOut, "  <td width='20%%' align=center>%d</td>\n", away_cnt);
						fprintf(cgiOut, "  <td width='20%%' align=center><a href='#' onClick=\"doDetail('%s', '%s', '%s')\">�� ϸ</a></td>\n", BTime, ETime, chg_id);
						fprintf(cgiOut, "</tr>\n");
					}
				break;
		}
	}
	
	if(0 == cnt)
	{
		fprintf(cgiOut, "<tr height='30px'>\n");
		fprintf(cgiOut, "  <td width='100%%' align=center colspan=5>��!</td>\n");
		fprintf(cgiOut, "</tr>\n");
	}
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='popDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'   value='0'>\n");
	fprintf(cgiOut, "<input type='hidden' name='id'    value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='level' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='BTime' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='ETime' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='user_id'  value='%s'>\n", user_id);
	fprintf(cgiOut, "<input name='DoSubmit' type='hidden' id='DoSubmit' onClick='doSelect()'/>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE='JavaScript'>\n");
	fprintf(cgiOut, "switch(parseInt('%s'))\n", Func_Sel_Id);
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  case 1:\n");
	fprintf(cgiOut, "      document.getElementById('Year').style.display  = '';\n");
	fprintf(cgiOut, "      document.getElementById('Month').style.display = '';\n");
	fprintf(cgiOut, "      document.getElementById('BDate').style.display = 'none';\n");
	fprintf(cgiOut, "      document.getElementById('EDate').style.display = 'none';\n");
	fprintf(cgiOut, "    break;\n");
	fprintf(cgiOut, "  case 2:\n");
	fprintf(cgiOut, "      document.getElementById('Year').style.display  = 'none';\n");
	fprintf(cgiOut, "      document.getElementById('Month').style.display = 'none';\n");
	fprintf(cgiOut, "      document.getElementById('BDate').style.display = '';\n");
	fprintf(cgiOut, "      document.getElementById('EDate').style.display = '';\n");
	fprintf(cgiOut, "    break;\n");
	fprintf(cgiOut, "}\n");
	//��ϸ
  fprintf(cgiOut, "function doSelect()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  switch(parseInt(ats_ldg.Func_Sel_Id.value))\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    case 1:\n");
  fprintf(cgiOut, "    		 ats_ldg.BTime.value = ats_ldg.Year.value + '-' + ats_ldg.Month.value + '-01';\n");
  fprintf(cgiOut, "    	   ats_ldg.ETime.value = ats_ldg.Year.value + '-' + ats_ldg.Month.value + '-31';\n");
  fprintf(cgiOut, "      break;\n");
  fprintf(cgiOut, "    case 2:\n");
  fprintf(cgiOut, "        ats_ldg.BTime.value = ats_ldg.BDate.value;\n");
  fprintf(cgiOut, "        ats_ldg.ETime.value = ats_ldg.EDate.value;\n");
  fprintf(cgiOut, "      break;\n");
  fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  ats_ldg.id.value = window.parent.frames.leftFrame.id.value;\n");
	fprintf(cgiOut, "  ats_ldg.level.value = window.parent.frames.leftFrame.level.value;\n");
  fprintf(cgiOut, "	 ats_ldg.submit();\n");
  fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doExport()\n");
	fprintf(cgiOut, "{\n");
	if(!ContainsFP(user_id, "0504"))
  {
  	fprintf(cgiOut, "alert('����Ȩ�޵���ͳ��!');return;\n");
  }
	fprintf(cgiOut, "  if(%d == 0)\n", cnt);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�޼�¼�ɵ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϵ���?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "  	 switch(parseInt(ats_ldg.Func_Sel_Id.value))\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      case 1:\n");
  fprintf(cgiOut, "    		   ats_ldg.BTime.value = ats_ldg.Year.value + '-' + ats_ldg.Month.value + '-01';\n");
  fprintf(cgiOut, "    	     ats_ldg.ETime.value = ats_ldg.Year.value + '-' + ats_ldg.Month.value + '-31';\n");
  fprintf(cgiOut, "        break;\n");
  fprintf(cgiOut, "      case 2:\n");
  fprintf(cgiOut, "          ats_ldg.BTime.value = ats_ldg.BDate.value;\n");
  fprintf(cgiOut, "          ats_ldg.ETime.value = ats_ldg.EDate.value;\n");
  fprintf(cgiOut, "        break;\n");
  fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    ats_ldg.id.value = window.parent.frames.leftFrame.id.value;\n");
	fprintf(cgiOut, "    ats_ldg.level.value = window.parent.frames.leftFrame.level.value;\n");
	fprintf(cgiOut, "	   if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new XMLHttpRequest();\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   req.onreadystatechange = callbackForName;\n");
	fprintf(cgiOut, "	   var url = 'ats_ldg.cgi?cmd=2&BTime='+ats_ldg.BTime.value+'&ETime='+ats_ldg.ETime.value+'&id='+ats_ldg.id.value+'&level='+ats_ldg.level.value+'&Func_Sel_Id='+ats_ldg.Func_Sel_Id.value+'&Year='+ats_ldg.Year.value+'&Month='+ats_ldg.Month.value+'&user_id=%s';\n", user_id);
	fprintf(cgiOut, "	   req.open('get', url, true);\n");
	fprintf(cgiOut, "	   req.send(null);\n");	
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackForName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var state = req.readyState;\n");
	fprintf(cgiOut, "	 if(4 == state)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 location.href = '../other/%s_E_' + ats_ldg.BDate.value + '_' + ats_ldg.EDate.value + '.csv';\n", user_id);
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	//��ϸ
	fprintf(cgiOut, "function doDetail(pBTime, pETime, pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'ats_ldg.cgi?cmd=1&id='+pId+'&BTime='+pBTime+'&ETime='+pETime+'&level='+ats_ldg.level.value+'&Func_Sel_Id='+ats_ldg.Func_Sel_Id.value+'&Year='+ats_ldg.Year.value+'&Month='+ats_ldg.Month.value+'&user_id=%s';\n", user_id);
	fprintf(cgiOut, "  document.getElementById('popDiv').innerHTML = \"<iframe id='divFrame' name='divFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='auto'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//�ر�
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(0 != strcmp(chg_id, col_values[0]))
	{
		if(strlen(chg_id) > 0)
		{		
			fprintf(cgiOut, "<tr height='30px'>\n");
			fprintf(cgiOut, "  <td width='20%%' align=center>%s</td>\n", chg_name);
			fprintf(cgiOut, "  <td width='20%%' align=center>%d</td>\n", late_cnt);
			fprintf(cgiOut, "  <td width='20%%' align=center>%d</td>\n", leave_cnt);
			fprintf(cgiOut, "  <td width='20%%' align=center>%d</td>\n", away_cnt);
			fprintf(cgiOut, "  <td width='20%%' align=center><a href='#' onClick=\"doDetail('%s', '%s', '%s')\">�� ϸ</a></td>\n", BTime, ETime, chg_id);
			fprintf(cgiOut, "</tr>\n");
			
			late_cnt   = 0;
 			leave_cnt  = 0;
 			away_cnt   = 0;
		}
		
		if(0 == strcmp(col_values[4], "1"))
		{//δ��
			away_cnt++;
		}
		else
		{//�Ѵ�
			if(0 == strcmp(col_values[2], "0"))
			{
				late_cnt++;
			}
			if(0 == strcmp(col_values[3], "0"))
			{
				leave_cnt++;
			}
		}
	}
	else
	{
		if(0 == strcmp(col_values[4], "1"))
		{//δ��
			away_cnt++;
		}
		else
		{//�Ѵ�
			if(0 == strcmp(col_values[2], "0"))
			{
				late_cnt++;
			}
			if(0 == strcmp(col_values[3], "0"))
			{
				leave_cnt++;
			}
		}
	}
	
	memset(chg_id, 0, sizeof(chg_id));
	memset(chg_name, 0, sizeof(chg_name));
	strcat(chg_id, col_values[0]);
	strcat(chg_name, col_values[5]);
	return 0;
}

//�첽����
void ExportData()
{
	char file_path[100] = {0}; 
	strcpy(file_path, "../other/");
	strcat(file_path, user_id);		//�û���
	strcat(file_path, "_E_");			//����
	strcat(file_path, BTime);		  //��ʼʱ��
	strcat(file_path, "_");			  //����
	strcat(file_path, ETime);		  //��ֹʱ��
	strcat(file_path, ".csv");
	if(NULL != file_path)
	{
		csv_file = fopen(file_path, "w");
		chmod(file_path, 777);
		if(NULL != csv_file)
		{
			fputs("��Ա,�ϰ�ٵ�(����),�°�����(����),δ��(����)\n", csv_file);
			//ͳ��
			if(strlen(id) > 0)
			{
				switch(atoi(level))
				{
					case 0:
					case 1:
					case 2:
							int rc;
							char * zErrMsg = 0;
							sqlite3 *db = open_db(DB_PATH_BAK);
							char sql[4096*8] = {0};
							sprintf(sql, "SELECT A.ID, A.CTIME, A.BELATE, A.BELEAVE, A.BEAWAY, B.CNAME FROM ATS_RESULT A, USER_INFO B WHERE A.ID = B.SYS_ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.ID) = 1 ORDER BY A.ID, A.CTIME ", BTime, ETime, id);
							sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
							rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
							sqlite3_close(db);
											
							if(0 < cnt)
							{
								char record[2048] = {0};
								sprintf(record, "%s,%d,%d,%d\n", chg_name, late_cnt, leave_cnt, away_cnt);
								fputs(record, csv_file);
							}
						break;
				}
			}
			
			
			
		}	
		fclose(csv_file);	
	}		
}

int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(0 != strcmp(chg_id, col_values[0]))
	{
		if(strlen(chg_id) > 0)
		{		
			char record[2048] = {0};
			sprintf(record, "%s,%d,%d,%d\n", chg_name, late_cnt, leave_cnt, away_cnt);
			fputs(record, csv_file);
			
			late_cnt   = 0;
 			leave_cnt  = 0;
 			away_cnt   = 0;
		}
		
		if(0 == strcmp(col_values[4], "1"))
		{//δ��
			away_cnt++;
		}
		else
		{//�Ѵ�
			if(0 == strcmp(col_values[2], "0"))
			{
				late_cnt++;
			}
			if(0 == strcmp(col_values[3], "0"))
			{
				leave_cnt++;
			}
		}
	}
	else
	{
		if(0 == strcmp(col_values[4], "1"))
		{//δ��
			away_cnt++;
		}
		else
		{//�Ѵ�
			if(0 == strcmp(col_values[2], "0"))
			{
				late_cnt++;
			}
			if(0 == strcmp(col_values[3], "0"))
			{
				leave_cnt++;
			}
		}
	}
	
	memset(chg_id, 0, sizeof(chg_id));
	memset(chg_name, 0, sizeof(chg_name));
	strcat(chg_id, col_values[0]);
	strcat(chg_name, col_values[5]);
	return 0;
}

//��ϸ
void doDetail()
{
	fprintf(cgiOut, "<HTML>\n");
	fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>��ʷ����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<meta http-equiv='x-ua-compatible' content='ie=7'/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script language='javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name='ats_ldg' action='ats_ldg.cgi' method='post' target='divFrame'>\n");
	fprintf(cgiOut, "  <table align=center style='margin:auto' cellpadding='0' cellspacing='0' border='0' width='100%%'>\n");
	fprintf(cgiOut, "    <tr>\n");
	fprintf(cgiOut, "		   <td width='100%%' align='right'>\n");
	fprintf(cgiOut, "			   <input type='button' style='cursor:hand;width:60px;' onClick='doClose()'  value='����'>\n");
	fprintf(cgiOut, "			   <input type='button' style='cursor:hand;width:60px;' onClick='doExport()' value='����'>\n");
	fprintf(cgiOut, "		   </td>\n");
	fprintf(cgiOut, "	   </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <div id='down_bg_2'>\n");
	fprintf(cgiOut, "  <table align=center style='margin:auto;margin-top:2px;' cellpadding='0' cellspacing='0' border='1' width='100%%' bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25px'>\n");
	fprintf(cgiOut, "	     <td width=\"10%%\" class='table_deep_blue'>�� Ա</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>�� ��</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>�ϰ��</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>�°��</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>�ϰ���</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>�°���</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>�Ƿ��</td>\n");
	fprintf(cgiOut, "	   </tr>\n");
	
	//ͳ����ϸ
	if(strlen(id) > 0)
	{
		switch(atoi(level))
		{
			case 0:
			case 1:
			case 2:
					int rc;
					char * zErrMsg = 0;
					sqlite3 *db = open_db(DB_PATH_BAK);
					char sql[4096*8] = {0};
					sprintf(sql, "SELECT A.ID, A.CTIME, A.R_ON_TIME, A.ON_TIME, A.R_OFF_TIME, A.OFF_TIME, A.BELATE, A.BELEAVE, A.BEAWAY, B.CNAME FROM ATS_RESULT A, USER_INFO B WHERE A.ID = B.SYS_ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND A.ID = '%s' ORDER BY A.CTIME ", BTime, ETime, id);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_detail, 0, &zErrMsg);
					sqlite3_close(db);
				break;
		}
	}
	
	if(0 == cnt)
	{
		fprintf(cgiOut, "<tr height='30px'>\n");
		fprintf(cgiOut, "  <td width='100%%' align=center colspan=7>��!</td>\n");
		fprintf(cgiOut, "</tr>\n");
	}
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE='JavaScript'>\n");
	//�ر�
	fprintf(cgiOut, "function doClose()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  parent.closeDiv();\n");
  fprintf(cgiOut, "}\n");
  //����
	fprintf(cgiOut, "function doExport()\n");
	fprintf(cgiOut, "{\n");
	if(!ContainsFP(user_id, "0504"))
  {
  	fprintf(cgiOut, "alert('����Ȩ�޵���ͳ��!');return;\n");
  }
	fprintf(cgiOut, "  if(%d == 0)\n", cnt);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�޼�¼�ɵ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϵ���?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "	   if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new XMLHttpRequest();\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   req.onreadystatechange = callbackForName;\n");
	fprintf(cgiOut, "	   var url = 'ats_ldg.cgi?cmd=3&BTime=%s&ETime=%s&id=%s&level=%s&Func_Sel_Id=%s&Year=%s&Month=%s&user_id=%s';\n", BTime, ETime, id, level, Func_Sel_Id, Year, Month, user_id);
	fprintf(cgiOut, "	   req.open('get', url, true);\n");
	fprintf(cgiOut, "	   req.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackForName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var state = req.readyState;\n");
	fprintf(cgiOut, "	 if(4 == state)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 location.href = '../other/%s_E_%s_%s.csv';\n", user_id, BTime, ETime);
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_detail(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	char str_BELATE[60]  = {0};
	char str_BELEAVE[60] = {0};
	char str_BEAWAY[60]  = {0};
	if(0 == strcmp(col_values[8], "1"))
	{//δ��
		strcat(str_BELATE, "");
		strcat(str_BELEAVE, "");
		strcat(str_BEAWAY, "<font color=red>δ��</font>");
	}
	else
	{//�Ѵ�
		switch(atoi(col_values[6]))
		{
			case 0:
					strcat(str_BELATE, "<font color=red>�ٵ�</font>");
				break;
			case 1:
					strcat(str_BELATE, "<font color=green>����</font>");
				break;
		}
		switch(atoi(col_values[7]))
		{
			case 0:
					strcat(str_BELEAVE, "<font color=red>����</font>");
				break;
			case 1:
					strcat(str_BELEAVE, "<font color=green>����</font>");
				break;
		}
		strcat(str_BEAWAY, "");
	}
	
	fprintf(cgiOut, "<tr height='30px'>\n");
	fprintf(cgiOut, "  <td width='10%%' align=center>%s</td>\n", col_values[9]);
	fprintf(cgiOut, "  <td width='10%%' align=center>%s</td>\n", col_values[1]);
	fprintf(cgiOut, "  <td width='10%%' align=center title='�涨:%s'>%s&nbsp;</td>\n", col_values[2], col_values[3]);
	fprintf(cgiOut, "  <td width='10%%' align=center title='�涨:%s'>%s&nbsp;</td>\n", col_values[4], col_values[5]);
	fprintf(cgiOut, "  <td width='10%%' align=center>%s&nbsp;</td>\n", str_BELATE);
	fprintf(cgiOut, "  <td width='10%%' align=center>%s&nbsp;</td>\n", str_BELEAVE);
	fprintf(cgiOut, "  <td width='10%%' align=center>%s&nbsp;</td>\n", str_BEAWAY);
	fprintf(cgiOut, "</tr>\n");
	
	return 0;
}

//��ϸ����
void DetailExportData()
{
	char file_path[100] = {0}; 
	strcpy(file_path, "../other/");
	strcat(file_path, user_id);		//�û���
	strcat(file_path, "_E_");			//����
	strcat(file_path, BTime);		  //��ʼʱ��
	strcat(file_path, "_");			  //����
	strcat(file_path, ETime);		  //��ֹʱ��
	strcat(file_path, ".csv");
	if(NULL != file_path)
	{
		csv_file = fopen(file_path, "w");
		chmod(file_path, 777);
		if(NULL != csv_file)
		{
			fputs("��Ա,����,�ϰ��,�°��,�ϰ���,�°���,�Ƿ��\n", csv_file);
			//��ϸ����
			if(strlen(id) > 0)
			{
				switch(atoi(level))
				{
					case 0:
					case 1:
					case 2:
							int rc;
							char * zErrMsg = 0;
							sqlite3 *db = open_db(DB_PATH_BAK);
							char sql[4096*8] = {0};
							sprintf(sql, "SELECT A.ID, A.CTIME, A.R_ON_TIME, A.ON_TIME, A.R_OFF_TIME, A.OFF_TIME, A.BELATE, A.BELEAVE, A.BEAWAY, B.CNAME FROM ATS_RESULT A, USER_INFO B WHERE A.ID = B.SYS_ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND A.ID = '%s' ORDER BY A.CTIME ", BTime, ETime, id);
							rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_detail_Export, 0, &zErrMsg);
							sqlite3_close(db);
						break;
				}
			}
		}
		fclose(csv_file);
	}
}

int sqlite3_exec_callback_detail_Export(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	char str_BELATE[60]  = {0};
	char str_BELEAVE[60] = {0};
	char str_BEAWAY[60]  = {0};
	if(0 == strcmp(col_values[8], "1"))
	{//δ��
		strcat(str_BELATE, "");
		strcat(str_BELEAVE, "");
		strcat(str_BEAWAY, "δ��");
	}
	else
	{//�Ѵ�
		switch(atoi(col_values[6]))
		{
			case 0:
					strcat(str_BELATE, "�ٵ�");
				break;
			case 1:
					strcat(str_BELATE, "����");
				break;
		}
		switch(atoi(col_values[7]))
		{
			case 0:
					strcat(str_BELEAVE, "����");
				break;
			case 1:
					strcat(str_BELEAVE, "����");
				break;
		}
		strcat(str_BEAWAY, "");
	}
	
	char record[2048] = {0};
	sprintf(record, "%s,%s,%s[�涨:%s],%s[�涨:%s],%s,%s,%s\n", col_values[9], col_values[1], col_values[3], col_values[2], col_values[5], col_values[4], str_BELATE, str_BELEAVE, str_BEAWAY);
	fputs(record, csv_file);
	
	return 0;
}
