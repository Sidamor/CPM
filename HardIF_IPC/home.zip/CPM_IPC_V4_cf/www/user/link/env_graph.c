#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "cgic.h"
#include "sqlite3.h"
#include "util.h"
#include "session.h"
#include <time.h>

//��������
char user_id[31] = {0};
int cnt = 0;
char cmd[4] = {0};
char id[15] = {0};
char level[2] = {0};
char BTime[30] = {0};
char Year[5] = {0};
char Month[3] = {0};
char Func_Sel_Id[2] = {0};
char flag[2] = {0};
//��������
static void getHtmlData();
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
bool	ContainsFP(char *pUser_Id, char *pFP_Id);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback_role(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_GroupBy_CType(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain() 
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	switch(atoi(cmd))
	{
		case 0://��ѯ
			QueryData();
			break;
	}
	return 0;
}

void getHtmlData()
{
	cgiFormString("user_id", user_id, sizeof(user_id));
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("id", id, sizeof(id)); 
	cgiFormString("level", level, sizeof(level));
	cgiFormString("BTime", BTime, sizeof(BTime));
	cgiFormString("Year", Year, sizeof(Year));
	cgiFormString("Month", Month, sizeof(Month));
	cgiFormString("Func_Sel_Id", Func_Sel_Id, sizeof(Func_Sel_Id));
	cgiFormString("flag", flag, sizeof(flag));
}

void QueryData()
{	
	if(NULL == Year || strlen(Year) < 1 || NULL == Month || strlen(Month) < 1)
	{
		//��ȡϵͳʱ��
		time_t nowtime;
		struct tm *timeinfo;
		time(&nowtime);
		timeinfo = localtime(&nowtime);
		int year, month;
		year = timeinfo->tm_year + 1900;
		month = timeinfo->tm_mon + 1;		
		memset(Year, 0, sizeof(Year));
		memset(Month, 0, sizeof(Month));
		sprintf(Year, "%d", year);
		sprintf(Month, "%02d", month);
	}
	
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<TITLE>����ͼ��</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script language='javascript' src='../../skin/js/excanvas.min.js'               charset='gb2312'></script>\n");
	fprintf(cgiOut, "<script language='javascript' src='../../skin/js/jquery-1.4.2.js'               charset='gb2312'></script>\n");
	fprintf(cgiOut, "<script language='javascript' src='../../skin/js/jquery.flot.js'                charset='gb2312'></script>\n");
	fprintf(cgiOut, "<script language='javascript' src='../../skin/js/My97DatePicker/WdatePicker.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<script language='javascript' src='../../skin/js/util.js'                       charset='gb2312'></script>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 0px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 100%%;\n");
	fprintf(cgiOut, "  height:100%%;\n");
	fprintf(cgiOut, "  left:0;\n");
	fprintf(cgiOut, "  top: 0;\n");;
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style='background:#CADFFF'>\n");
  fprintf(cgiOut, "<form name='env_graph' action='env_graph.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "  <div id='down_bg_2'>\n");	
	fprintf(cgiOut, "  <table style='margin:auto' cellpadding='0' cellspacing='0' border='0' width='100%%'>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='50%%' align='left'>\n");
	fprintf(cgiOut, "        <select id='Func_Sel_Id' name='Func_Sel_Id' style='width:70px;height:20px' onChange='doChangeSelect(this.value)'>\n");
	fprintf(cgiOut, "          <option value='1' %s>ʱ��ֵ</option>\n", 0 == strcmp(Func_Sel_Id, "1")?"selected":"");
	fprintf(cgiOut, "          <option value='2' %s>�վ�ֵ</option>\n", 0 == strcmp(Func_Sel_Id, "2")?"selected":"");
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "        <input type='text' id='BDate' name='BDate' style='width:90px;height:18px;display:none' value='%s' onClick='WdatePicker({readOnly:true})' class='Wdate' maxlength='10'>\n", BTime);
	fprintf(cgiOut, "        <select id='Year' name='Year' style='width:60px;height:20px;display:none'>\n");
	fprintf(cgiOut, "          <option value='2011' %s>2011��</option>\n", 0 == strcmp(Year, "2011")?"selected":"");
	fprintf(cgiOut, "          <option value='2012' %s>2012��</option>\n", 0 == strcmp(Year, "2012")?"selected":"");
	fprintf(cgiOut, "          <option value='2013' %s>2013��</option>\n", 0 == strcmp(Year, "2013")?"selected":"");
	fprintf(cgiOut, "          <option value='2014' %s>2014��</option>\n", 0 == strcmp(Year, "2014")?"selected":"");
	fprintf(cgiOut, "          <option value='2015' %s>2015��</option>\n", 0 == strcmp(Year, "2015")?"selected":"");
	fprintf(cgiOut, "          <option value='2016' %s>2016��</option>\n", 0 == strcmp(Year, "2016")?"selected":"");
	fprintf(cgiOut, "          <option value='2017' %s>2017��</option>\n", 0 == strcmp(Year, "2017")?"selected":"");
	fprintf(cgiOut, "          <option value='2018' %s>2018��</option>\n", 0 == strcmp(Year, "2018")?"selected":"");
	fprintf(cgiOut, "          <option value='2019' %s>2019��</option>\n", 0 == strcmp(Year, "2019")?"selected":"");
	fprintf(cgiOut, "          <option value='2020' %s>2020��</option>\n", 0 == strcmp(Year, "2020")?"selected":"");
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "        <select id='Month' name='Month' style='width:50px;height:20px;display:none'>\n");
	fprintf(cgiOut, "          <option value='01' %s>1��</option>\n",  0 == strcmp(Month, "01")?"selected":"");
	fprintf(cgiOut, "          <option value='02' %s>2��</option>\n",  0 == strcmp(Month, "02")?"selected":"");
	fprintf(cgiOut, "          <option value='03' %s>3��</option>\n",  0 == strcmp(Month, "03")?"selected":"");
	fprintf(cgiOut, "          <option value='04' %s>4��</option>\n",  0 == strcmp(Month, "04")?"selected":"");
	fprintf(cgiOut, "          <option value='05' %s>5��</option>\n",  0 == strcmp(Month, "05")?"selected":"");
	fprintf(cgiOut, "          <option value='06' %s>6��</option>\n",  0 == strcmp(Month, "06")?"selected":"");
	fprintf(cgiOut, "          <option value='07' %s>7��</option>\n",  0 == strcmp(Month, "07")?"selected":"");
	fprintf(cgiOut, "          <option value='08' %s>8��</option>\n",  0 == strcmp(Month, "08")?"selected":"");
	fprintf(cgiOut, "          <option value='09' %s>9��</option>\n",  0 == strcmp(Month, "09")?"selected":"");
	fprintf(cgiOut, "          <option value='10' %s>10��</option>\n", 0 == strcmp(Month, "10")?"selected":"");
	fprintf(cgiOut, "          <option value='11' %s>11��</option>\n", 0 == strcmp(Month, "11")?"selected":"");
	fprintf(cgiOut, "          <option value='12' %s>12��</option>\n", 0 == strcmp(Month, "12")?"selected":"");
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='50%%' align='right'>\n");
	//fprintf(cgiOut, "        <input type='button' style='cursor:hand;width:80px;' value='�����ϲ�' onClick='doReturn()'>\n");
	fprintf(cgiOut, "        <input type='button' style='cursor:hand;width:80px;' value='����ͼ��' onClick='doSelect()'>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <table style='margin:auto' cellpadding='0' cellspacing='0' border='0' width='100%%'>\n");
	fprintf(cgiOut, "    <tr>\n");
	fprintf(cgiOut, "      <td width='15%%' align='center'>&nbsp</td>\n");
	fprintf(cgiOut, "      <td width='85%%' align='left' colspan=2><p id='choices' style='margin-left:25px'></p></td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr>\n");
	fprintf(cgiOut, "      <td width='15%%' align='center'>&nbsp</td>\n");
	fprintf(cgiOut, "      <td width='55%%' align='left'><div id='placeholder' style='width:100%%;height:350px;'></div></td>\n");
	fprintf(cgiOut, "      <td width='30%%' align='left' valign='bottom'>&nbsp;\n");
	fprintf(cgiOut, "  	     <font color=gray>\n");
	switch(atoi(Func_Sel_Id))
	{
		case 1:
				fprintf(cgiOut, "(Сʱ)\n");
			break;
		case 2:
				fprintf(cgiOut, "(����)\n");
			break;
	}
	fprintf(cgiOut, "  	     </font>\n");
	fprintf(cgiOut, "  	   </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "  <div id='popDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "  <input name='cmd'   type='hidden' value='0'>\n");
	fprintf(cgiOut, "  <input name='id'	   type='hidden' value=''>\n");
	fprintf(cgiOut, "  <input name='level' type='hidden' value=''>\n");
	fprintf(cgiOut, "  <input name='BTime' type='hidden' value=''>\n");
	fprintf(cgiOut, "  <input name='ETime' type='hidden' value=''>\n");
	fprintf(cgiOut, "  <input name='flag'  type='hidden' value=''>\n");
	fprintf(cgiOut, "  <input name='user_id'  type='hidden' value='%s'>\n", user_id);
	fprintf(cgiOut, "  <input name='DoSubmit' type='hidden' id='DoSubmit' onClick='doSelect()'/>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "if(null != window.parent.frames.leftFrame.CurrJsp)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 window.parent.frames.leftFrame.CurrJsp.innerText = 'env_graph.html';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.location = 'index.cgi?user_id=%s';\n", user_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doChangeSelect(pFunc_Sel_Id)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  switch(parseInt(pFunc_Sel_Id))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "        document.all.BDate.style.display = '';\n");
	fprintf(cgiOut, "        document.all.Year.style.display = 'none';\n");
	fprintf(cgiOut, "        document.all.Month.style.display = 'none';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "        document.all.BDate.style.display = 'none';\n");
	fprintf(cgiOut, "        document.all.Year.style.display = '';\n");
	fprintf(cgiOut, "        document.all.Month.style.display = '';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doChangeSelect(env_graph.Func_Sel_Id.value);\n");
	//�رմ���
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//��ʷ��ϸ
	fprintf(cgiOut, "function doDetail(pX, pId)\n");
	fprintf(cgiOut, "{\n");
	if(!ContainsFP(user_id, "020202"))
  {
  	fprintf(cgiOut, "alert('����Ȩ�޲�ѯ��ϸ!');return;\n");
  }
	fprintf(cgiOut, "  switch(parseInt(env_graph.Func_Sel_Id.value))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 1://ʱ��ֵ\n");
	fprintf(cgiOut, "        env_graph.BTime.value = env_graph.BDate.value;\n");
	fprintf(cgiOut, "        env_graph.ETime.value = env_graph.BDate.value;\n");
	fprintf(cgiOut, "        var now = new Date().format('yyyy-MM-dd');\n");
	fprintf(cgiOut, "        if(env_graph.BTime.value >= now)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          env_graph.flag.value = '0';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          env_graph.flag.value = '1';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        env_graph.BTime.value = env_graph.BTime.value + ' ' + StrLeftFillZero(pX.toString(), 2) + ':00:00';\n");
	fprintf(cgiOut, "        env_graph.ETime.value = env_graph.ETime.value + ' ' + StrLeftFillZero(pX.toString(), 2) + ':59:59';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2://�վ�ֵ\n");
	fprintf(cgiOut, "        env_graph.BTime.value = env_graph.Year.value + '-' + env_graph.Month.value + '-' + StrLeftFillZero(pX.toString(), 2) + ' 00:00:00';\n");
	fprintf(cgiOut, "        env_graph.ETime.value = env_graph.Year.value + '-' + env_graph.Month.value + '-' + StrLeftFillZero(pX.toString(), 2) + ' 23:59:59';\n");
	fprintf(cgiOut, "        env_graph.flag.value = '1';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'env_his.cgi?cmd=0&id='+pId.substring(0,10)+'&ctype='+pId.substring(10,14)+'&BTime='+env_graph.BTime.value+'&ETime='+env_graph.ETime.value+'&flag='+env_graph.flag.value+'&Func_Sel_Id=9&user_id=%s';\n", user_id);
	fprintf(cgiOut, "  document.getElementById('popDiv').innerHTML = \"<iframe id='divFrame' name='divFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='auto'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//����ͼ��
	fprintf(cgiOut, "function doSelect()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  env_graph.id.value = window.parent.frames.leftFrame.id.value;\n");
	fprintf(cgiOut, "  env_graph.level.value = window.parent.frames.leftFrame.level.value;\n");
	fprintf(cgiOut, "  if(env_graph.level.value != '3')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    env_graph.id.value = '';\n");
	fprintf(cgiOut, "    env_graph.level.value = '3';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  switch(parseInt(env_graph.Func_Sel_Id.value))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 1://ʱ��ֵ\n");
	fprintf(cgiOut, "        env_graph.BTime.value = env_graph.BDate.value;\n");
	fprintf(cgiOut, "        var now = new Date().format('yyyy-MM-dd');\n");
	fprintf(cgiOut, "        if(env_graph.BTime.value >= now)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          env_graph.flag.value = '0';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          env_graph.flag.value = '1';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2://�վ�ֵ\n");
	fprintf(cgiOut, "        env_graph.BTime.value = env_graph.Year.value + '-' + env_graph.Month.value +'-01';\n");
	fprintf(cgiOut, "        env_graph.flag.value = '1';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "	 env_graph.submit();\n");
	fprintf(cgiOut, "}\n");
	//���ɹ���
	fprintf(cgiOut, "var dataset = [];\n");
	fprintf(cgiOut, "var data = [];\n");
	fprintf(cgiOut, "var data_min;\n");
	fprintf(cgiOut, "var data_max;\n");
	fprintf(cgiOut, "var max_index;\n");	
	fprintf(cgiOut, "var min_index;\n");	
	fprintf(cgiOut, "var highlight = [];\n");
	fprintf(cgiOut, "var TUnit = '';\n");
	fprintf(cgiOut, "switch(parseInt('%s'))\n", Func_Sel_Id);
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	case 1:\n");
	fprintf(cgiOut, "	  	TUnit = 'ʱ';\n");
	fprintf(cgiOut, "		break;\n");
	fprintf(cgiOut, "	case 2:\n");
	fprintf(cgiOut, "	  	TUnit = '��';\n");
	fprintf(cgiOut, "		break;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "var choiceContainer = $('#choices');\n");
	fprintf(cgiOut, "var previousPoint = null;\n");
	
	int rc = 0;
	char * zErrMsg = 0;
	sqlite3 *db;
	if(0 == strcmp(flag, "1"))
	{
		db = open_db(DB_PATH_BAK);
	}
	else
	{
		db = open_db(DB_PATH);
	}
	char sql[4096] = {0};
	switch(atoi(level))
	{
		case 0:
				sprintf(sql, "select a.point from role a where length(a.id) = 8 and a.id like '%s%s' order by a.id", id, "%");
				sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
				rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role, 0, &zErrMsg);
				if(rc != SQLITE_OK)
				{
				}
			break;
		case 1:
				sprintf(sql, "select a.point from role a where length(a.id) = 8 and a.id like '%s%s' order by a.id", id, "%");
				sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
				rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role, 0, &zErrMsg);
				if(rc != SQLITE_OK)
				{
				}
			break;
		case 2:
				if(0 == strcmp(flag, "1"))
				{//��ʷ
					switch(atoi(Func_Sel_Id))
					{
						case 1://ʱ��ֵ		
								sprintf(sql, "SELECT A.ATTR_NAME, C.UNIT, D.CNAME, T.CTYPE, T.ID, E.LEDGER FROM DATA_HOURAVG T, DEVICE_DETAIL D, DATA_TYPE C, DEVICE_ATTR E, role f, DEVICE_ROLL A WHERE T.CTYPE = E.SN AND substr(T.ID,1,6) = E.ID AND T.CTYPE = A.SN AND T.ID = A.ID AND C.ID = E.ATTR_ID AND D.ID = T.ID and contain(f.point, t.id) = 1 and f.id = '%s' and substr(t.ctime,1,10) = '%s' group by t.ctype, t.id order by t.id asc", id, BTime);
								sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
								rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_GroupBy_CType, 0, &zErrMsg);
								if(rc != SQLITE_OK)
								{
								}			
							break;
						case 2://�վ�ֵ			
								sprintf(sql, "SELECT A.ATTR_NAME, C.UNIT, D.CNAME, T.CTYPE, T.ID, E.LEDGER FROM DATA_DAYSAVG T, DEVICE_DETAIL D, DATA_TYPE C, DEVICE_ATTR E, role f, DEVICE_ROLL A WHERE T.CTYPE = E.SN AND substr(T.ID,1,6) = E.ID AND T.CTYPE = A.SN AND T.ID = A.ID AND C.ID = E.ATTR_ID AND D.ID = T.ID and contain(f.point, t.id) = 1 and f.id = '%s' and substr(t.ctime,1,7) = substr('%s',1,7) group by t.ctype, t.id order by t.id asc", id, BTime);
								sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
								rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_GroupBy_CType, 0, &zErrMsg);
								if(rc != SQLITE_OK)
								{
								}			
							break;
					}
				}
				else
				{//����
					sprintf(sql, "SELECT A.ATTR_NAME, C.UNIT, D.CNAME, T.CTYPE, T.ID, E.LEDGER FROM DATA T, DEVICE_DETAIL D, DATA_TYPE C, DEVICE_ATTR E, role f, DEVICE_ROLL A WHERE T.CTYPE = E.SN AND substr(T.ID,1,6) = E.ID AND T.CTYPE = A.SN AND T.ID = A.ID AND C.ID = E.ATTR_ID AND D.ID = T.ID and contain(f.point, t.id) = 1 and f.id = '%s' and substr(t.ctime,1,10) = '%s' group by t.ctype, t.id order by t.id asc", id, BTime);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_GroupBy_CType, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
					}
				}		
			break;
		case 3:
				if(0 == strcmp(flag, "1"))
				{//��ʷ
					switch(atoi(Func_Sel_Id))
					{
						case 1://ʱ��ֵ		
								sprintf(sql, "SELECT A.ATTR_NAME, C.UNIT, D.CNAME, T.CTYPE, T.ID, E.LEDGER FROM DATA_HOURAVG T, DEVICE_DETAIL D, DATA_TYPE C, DEVICE_ATTR E, DEVICE_ROLL A WHERE T.CTYPE = E.SN AND substr(T.ID,1,6) = E.ID AND T.CTYPE = A.SN AND T.ID = A.ID AND C.ID = E.ATTR_ID AND D.ID = T.ID and t.id = substr('%s',1,10) and t.ctype = substr('%s',11,4) and substr(t.ctime,1,10) = '%s' group by t.ctype, t.id order by t.id asc", id, id, BTime);
								sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
								rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_GroupBy_CType, 0, &zErrMsg);
								if(rc != SQLITE_OK)
								{
								}				
							break;
						case 2://�վ�ֵ	
								sprintf(sql, "SELECT A.ATTR_NAME, C.UNIT, D.CNAME, T.CTYPE, T.ID, E.LEDGER FROM DATA_DAYSAVG T, DEVICE_DETAIL D, DATA_TYPE C, DEVICE_ATTR E, DEVICE_ROLL A WHERE T.CTYPE = E.SN AND substr(T.ID,1,6) = E.ID AND T.CTYPE = A.SN AND T.ID = A.ID AND C.ID = E.ATTR_ID AND D.ID = T.ID and t.id = substr('%s',1,10) and t.ctype = substr('%s',11,4) and substr(t.ctime,1,7) = substr('%s',1,7) group by t.ctype, t.id order by t.id asc", id, id, BTime);
								sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
								rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_GroupBy_CType, 0, &zErrMsg);
								if(rc != SQLITE_OK)
								{
								}				
							break;
					}
				}
				else
				{//����
					sprintf(sql, "SELECT A.ATTR_NAME, C.UNIT, D.CNAME, T.CTYPE, T.ID, E.LEDGER FROM DATA T, DEVICE_DETAIL D, DATA_TYPE C, DEVICE_ATTR E, DEVICE_ROLL A WHERE T.CTYPE = E.SN AND substr(T.ID,1,6) = E.ID AND T.CTYPE = A.SN AND T.ID = A.ID AND C.ID = E.ATTR_ID AND D.ID = T.ID and t.id = substr('%s',1,10) and t.ctype = substr('%s',11,4) and t.ctime >= '%s 00:00:00' and t.ctime <= '%s 23:59:59' group by t.ctype, t.id order by t.id asc", id, id, BTime, BTime);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_GroupBy_CType, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
					}
				}
			break;
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "if(0 == dataset.length)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 highlight.push([20, 50]);\n");
	fprintf(cgiOut, "	 dataset.push({'label':'���������', 'data':data, 'id':'0000000000'});\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "var i = 0;\n");
	fprintf(cgiOut, "$.each(dataset, function(key, val)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 if(1 == i)\n");
	fprintf(cgiOut, "		 i++;\n");
	fprintf(cgiOut, "	 val.color = i;\n");
	fprintf(cgiOut, "	 ++i;\n");
	fprintf(cgiOut, "});\n");
	fprintf(cgiOut, "showPIG();\n");
	//�ƶ�
	fprintf(cgiOut, "$('#placeholder').bind('plothover', function (event, pos, item)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  $('#x').text(pos.x.toFixed(2));\n");
	fprintf(cgiOut, "  $('#y').text(pos.y.toFixed(2));\n");
	fprintf(cgiOut, "  if(item)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(previousPoint != item.datapoint)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      previousPoint = item.datapoint;\n");
	fprintf(cgiOut, "      $('#tooltip').remove();\n");
	fprintf(cgiOut, "      var x = item.datapoint[0].toFixed(2),\n");
	fprintf(cgiOut, "      y = item.datapoint[1].toFixed(2);\n");
	//��ȡId
	fprintf(cgiOut, "      var Id = '';\n");
	fprintf(cgiOut, "      var Time = '';\n");
	fprintf(cgiOut, "      var i =0;\n");
	fprintf(cgiOut, "	     choiceContainer.find('input:checked').each(function()\n");
	fprintf(cgiOut, "	     {\n");
	fprintf(cgiOut, "		     var key = $(this).attr('name');\n");
	fprintf(cgiOut, "	       if(item.seriesIndex == i)\n");
	fprintf(cgiOut, "	       {\n");
	fprintf(cgiOut, "	         Id = document.getElementById('id'+key).value;\n");
	fprintf(cgiOut, "	         Time = item.datapoint[0];\n");
	fprintf(cgiOut, "	       }\n");
	fprintf(cgiOut, "	       i++;\n");
	fprintf(cgiOut, "      });\n");
	fprintf(cgiOut, "      var content = 'ʱ��:' + parseInt(x) + TUnit + ';��ֵ:' + y + ';';\n");
	fprintf(cgiOut, "      showTooltip(item.pageX, item.pageY, content, Id, Time);\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    $('#tooltip').remove();\n");
	fprintf(cgiOut, "    previousPoint = null;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "});\n");
	//���
	fprintf(cgiOut, "$('#placeholder').bind('plotclick', function (event, pos, item)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(item)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var i =0;\n");
	fprintf(cgiOut, "	   choiceContainer.find('input:checked').each(function()\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   var key = $(this).attr('name');\n");
	fprintf(cgiOut, "	     if(item.seriesIndex == i)\n");
	fprintf(cgiOut, "	     {\n");
	fprintf(cgiOut, "        doDetail(item.datapoint[0], document.getElementById('id'+key).value);\n");
	fprintf(cgiOut, "	     }\n");
	fprintf(cgiOut, "	     i++;\n");
	fprintf(cgiOut, "    });\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "});\n");
	
	fprintf(cgiOut, "function showPIG()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var i = 0;\n");
	fprintf(cgiOut, "  $.each(dataset, function(key, val)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(i%%3 == 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      choiceContainer.append('<br>');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    choiceContainer.append('<input type=\"checkbox\" name=\"'+ key +'\" checked=\"checked\" id=\"id'+ key +'\" value=\"'+ val.id +'\">' +");
	fprintf(cgiOut, "    '<label for=\"id' + key + '\">' + val.label + '</label>');\n");
	fprintf(cgiOut, "    i++;\n");
	fprintf(cgiOut, "  });\n");
	fprintf(cgiOut, "  choiceContainer.find('input').click(plotAccordingToChoices);\n");
	fprintf(cgiOut, "  plotAccordingToChoices();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function plotAccordingToChoices() \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var data = [];	\n");
	fprintf(cgiOut, "	 var hLight = [];	\n");
	fprintf(cgiOut, "	 choiceContainer.find('input:checked').each(function()\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 var key = $(this).attr('name');\n");
	fprintf(cgiOut, "		 if(key && dataset[key])\n");
	fprintf(cgiOut, "		 {\n");
	fprintf(cgiOut, "			 data.push(dataset[key]);\n");
	fprintf(cgiOut, "			 hLight.push([highlight[key][0], highlight[key][1]]);\n");
	fprintf(cgiOut, "		 }\n");
	fprintf(cgiOut, "	 });\n");
	fprintf(cgiOut, "	 if(data.length > 0)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 var plot = $.plot($('#placeholder'), data, {\n");
	if(0 == strcmp(Func_Sel_Id, "2"))
	{
		fprintf(cgiOut, "	 xaxis: {min:1, max:31},\n");
	}
	else
	{
		fprintf(cgiOut, "	 xaxis: {min:0, max:24},\n");
	}
	fprintf(cgiOut, "		 series:{\n");
	fprintf(cgiOut, "		 lines: { show:true },\n");
	fprintf(cgiOut, "		 points:{ show:true,radius:3,symbol:'circle'}},\n");
	fprintf(cgiOut, "		 grid:  { hoverable:true,clickable:true},\n");
	fprintf(cgiOut, "		 legend:{ noColumns:1,margin:[-180, 0]}\n");
	fprintf(cgiOut, "		 });\n");
	fprintf(cgiOut, "		 $.each(hLight, function(key, val)\n");
	fprintf(cgiOut, "		 {\n");
	fprintf(cgiOut, "			 plot.highlight(key, val[0]);\n");
	fprintf(cgiOut, "			 plot.highlight(key, val[1]);\n");
	fprintf(cgiOut, "		 });\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");				
	fprintf(cgiOut, "function showTooltip(x, y, contents, id, time)\n");
	fprintf(cgiOut, "{\n");	
	fprintf(cgiOut, "  $('<div id=\"tooltip\">' + contents + '</div>').css\n");
	fprintf(cgiOut, "  ({\n");
	fprintf(cgiOut, "    position: 'absolute',\n");
	fprintf(cgiOut, "    display: 'none',\n");
	fprintf(cgiOut, "    top: y + 5,\n");
	fprintf(cgiOut, "    left: x + 5,\n");
	fprintf(cgiOut, "    border: '1px solid #fdd',\n");
	fprintf(cgiOut, "    padding: '2px',\n");
	fprintf(cgiOut, "    'background-color': '#fee',\n");
	fprintf(cgiOut, "    opacity: 0.80\n");
	fprintf(cgiOut, "  }).appendTo(\"body\").fadeIn(200);\n");
	fprintf(cgiOut, "  var obj = \"<div onmouseover=doDetail('\"+time+\"','\"+id+\"')>����鿴��ϸ...</div>\";\n");
	fprintf(cgiOut, "  document.getElementById('tooltip').innerHTML = document.getElementById('tooltip').innerHTML + obj;\n");
	fprintf(cgiOut, "}\n");	
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</html>\n");
}

int sqlite3_exec_callback_role(void *data, int n_columns, char **col_values, char **col_names)
{
	int rc;
	char * zErrMsg = 0;
	char sql[4096] = {0};
	sqlite3 *db;
	if(0 == strcmp(flag, "1"))
	{//��ʷ
		switch(atoi(Func_Sel_Id))
		{
			case 1://ʱ��ֵ			
					sprintf(sql, "SELECT A.ATTR_NAME, C.UNIT, D.CNAME, T.CTYPE, T.ID, E.LEDGER FROM DATA_HOURAVG T, DEVICE_DETAIL D, DATA_TYPE C, DEVICE_ATTR E, DEVICE_ROLL A WHERE T.CTYPE = E.SN AND substr(T.ID,1,6) = E.ID AND T.CTYPE = A.SN AND T.ID = A.ID AND C.ID = E.ATTR_ID AND D.ID = T.ID and contain('%s', t.id) = 1 and substr(t.ctime,1,10) = '%s' group by t.ctype, t.id order by t.id asc", col_values[0], BTime);
				break;
			case 2://�վ�ֵ	
					sprintf(sql, "SELECT A.ATTR_NAME, C.UNIT, D.CNAME, T.CTYPE, T.ID, E.LEDGER FROM DATA_DAYSAVG T, DEVICE_DETAIL D, DATA_TYPE C, DEVICE_ATTR E, DEVICE_ROLL A WHERE T.CTYPE = E.SN AND substr(T.ID,1,6) = E.ID AND T.CTYPE = A.SN AND T.ID = A.ID AND C.ID = E.ATTR_ID AND D.ID = T.ID and contain('%s', t.id) = 1 and substr(t.ctime,1,7) = substr('%s',1,7) group by t.ctype, t.id order by t.id asc", col_values[0], BTime);		
				break;
		}
		db = open_db(DB_PATH_BAK);
		sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_GroupBy_CType, 0, &zErrMsg);
		if( rc!=SQLITE_OK )
		{
		}
	}
	else
	{//����
		sprintf(sql, "SELECT A.ATTR_NAME, C.UNIT, D.CNAME, T.CTYPE, T.ID, E.LEDGER FROM DATA T, DEVICE_DETAIL D, DATA_TYPE C, DEVICE_ATTR E, DEVICE_ROLL A WHERE T.CTYPE = E.SN AND substr(T.ID,1,6) = E.ID AND T.CTYPE = A.SN AND T.ID = A.ID AND C.ID = E.ATTR_ID AND D.ID = T.ID and contain('%s', t.id) = 1 and substr(t.ctime,1,10) = '%s' group by t.ctype, t.id order by t.id asc", col_values[0], BTime);
		db = open_db(DB_PATH);
		sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_GroupBy_CType, 0, &zErrMsg);
		if( rc!=SQLITE_OK )
		{
		}
	}
	sqlite3_close(db);
	return 0;
}

int sqlite3_exec_callback_GroupBy_CType(void *data, int n_columns, char **col_values, char **col_names)
{
	int rc = 0;
	char * zErrMsg = 0;
	char sql[1024] = {0};
	sqlite3 *db;
	if(0 == strcmp(flag, "1"))
	{//��ʷ
		switch(atoi(Func_Sel_Id))
		{
			case 1://ʱ��ֵ			
					sprintf(sql, "select substr(ctime,12,2), value from DATA_HOURAVG where id = '%s' and ctype = '%s' and substr(ctime,1,10) = '%s' order by substr(ctime,12,2) asc", col_values[4], col_values[3], BTime);
				break;
			case 2://�վ�ֵ		
					sprintf(sql, "select substr(ctime, 9,2), value from DATA_DAYSAVG where id = '%s' and ctype = '%s' and substr(ctime,1,7) = substr('%s',1,7) order by substr(ctime, 9,2) asc", col_values[4], col_values[3], BTime);	
				break;
		}
		db = open_db(DB_PATH_BAK);
	}
	else
	{//����
		switch(atoi(col_values[5]))
		{
			case 2://������
			case 0://������
					sprintf(sql, "select substr(ctime,12,2), count(*) from data where id = '%s' and ctype = '%s' and ctime >= '%s 00:00:00' and ctime <= '%s 23:59:59' group by substr(ctime,12,2) order by substr(ctime,12,2) asc", col_values[4], col_values[3], BTime, BTime);
				break;
			case 1://����ֵ
					sprintf(sql, "select substr(ctime,12,2), round(avg(value),2) from data where id = '%s' and ctype = '%s' and ctime >= '%s 00:00:00' and ctime <= '%s 23:59:59' group by substr(ctime,12,2) order by substr(ctime,12,2) asc", col_values[4], col_values[3], BTime, BTime);
				break;
		}
		db = open_db(DB_PATH);
	}
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	}
	sqlite3_close(db);
	fprintf(cgiOut, "if(data.length > 0)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 highlight.push([min_index, max_index]);\n");
	fprintf(cgiOut, "	 dataset.push({'label':'%s[%s][%s] ', 'data':data, 'id':'%s%s'});\n", col_values[2], col_values[0], col_values[1], col_values[4], col_values[3]);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "data = [];\n");
	cnt = 0;
	return 0;
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	if(0 == cnt)
	{
		fprintf(cgiOut, "data_min = %s;\n", col_values[1]);		
		fprintf(cgiOut, "min_index = %d;\n", cnt);	
		fprintf(cgiOut, "data_max = %s;\n", col_values[1]);	
		fprintf(cgiOut, "max_index = %d;\n", cnt);	
	}
	else
	{
		fprintf(cgiOut, "if(%s < data_min)\n", col_values[1]);
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "	 data_min = %s;\n", col_values[1]);	
		fprintf(cgiOut, "	 min_index = %d;\n", cnt);	
		fprintf(cgiOut, "}\n");		
		fprintf(cgiOut, "if(%s > data_max)\n", col_values[1]);	
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "	 data_max = %s;\n", col_values[1]);	
		fprintf(cgiOut, "	 max_index = %d;\n", cnt);	
		fprintf(cgiOut, "}\n");	
	}	
	
	fprintf(cgiOut, "data.push(['%s', '%s']);\n", col_values[0], col_values[1]);
	cnt ++;
	return 0;
}
