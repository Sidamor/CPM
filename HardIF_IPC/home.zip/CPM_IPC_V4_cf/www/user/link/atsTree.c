#include "cgic.h"
#include "sqlite3.h"
#include "session.h"
#include "util.h"

char user_id[31] = {0};
//��������
static void Ats_Tree();
static int sqlite3_exec_callback_tree_dept(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_tree_user(void *data, int n_columns, char **col_values, char **col_names);
bool	ContainsFP(char *pUser_Id, char *pFP_Id);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	cgiFormString("user_id", user_id, sizeof(user_id));
	
	Ats_Tree();
	return 0;
}

void Ats_Tree()
{	
	fprintf(cgiOut, "<HTML>\n");
  fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>����ϵͳ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv='x-ua-compatible' content='ie=7'/>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/zTreeStyle2.css' rel='stylesheet'/>\n");	
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery-1.4.4.min.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.core-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.excheck-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.exedit-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</HEAD>\n");
  fprintf(cgiOut, "<BODY style='background:#0B80CC;'>\n");
  fprintf(cgiOut, "  <div id='PARENT'>\n");
	fprintf(cgiOut, "    <ul id='nav'>\n");
	if(ContainsFP(user_id, "0501"))
  {
		fprintf(cgiOut, "    <li><a href='#' onClick='doAts_Info()'>������ϸ</a></li>\n");
	}
	if(ContainsFP(user_id, "0503"))
  {
		fprintf(cgiOut, "    <li><a href='#' onClick='doAts_Ldg()' >����ͳ��</a></li>\n");
	}
	//fprintf(cgiOut, "      <li><a href='#' onClick='doReturn()'>�����ϲ�</a></li>\n");
	fprintf(cgiOut, "    </ul>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "  <div><ul id='areaTree' class='ztree'></ul></div>\n");
	fprintf(cgiOut, "  <input type='hidden' id='id' name='id' value=''>\n");
	fprintf(cgiOut, "  <input type='hidden' id='level' name='level' value=''>\n");
  fprintf(cgiOut, "</BODY>\n");
  fprintf(cgiOut, "<SCRIPT LANGUAGE='JavaScript'>\n");
  fprintf(cgiOut, "function doAts_Info()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  window.parent.frames.mainFrame.location = 'ats_info.cgi?cmd=0&id='+document.getElementById('id').value+'&level='+document.getElementById('level').value+'&user_id=%s';\n", user_id);
  fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "function doAts_Ldg()\n");
  fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var now = new Date().format('yyyy-MM-dd');\n");
	fprintf(cgiOut, "  var Year = now.substring(0,4);\n");
	fprintf(cgiOut, "  var Month = now.substring(5,7);\n");
	fprintf(cgiOut, "  var BTime = now.substring(0,8) + '01';\n");
	fprintf(cgiOut, "  var ETime = now.substring(0,8) + '31';\n");
  fprintf(cgiOut, "  window.parent.frames.mainFrame.location = 'ats_ldg.cgi?cmd=0&id='+document.getElementById('id').value+'&level='+document.getElementById('level').value+'&Func_Sel_Id=1&BTime='+BTime+'&ETime='+ETime+'&Year='+Year+'&Month='+Month+'&user_id=%s';\n", user_id);
  fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "function doReturn()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  parent.location = 'index.cgi?user_id=%s';\n", user_id);
  fprintf(cgiOut, "}\n");
	//������
	fprintf(cgiOut, "var rootValue = '';\n");
  fprintf(cgiOut, "var Nodes1 = [];\n");
  fprintf(cgiOut, "var setting = \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  edit: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    enable: false\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  data: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    simpleData:{enable: true}\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  callback: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    onClick: zTreeOnClick\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "};\n");
  
	//��Ա�б�
  fprintf(cgiOut, "var node = {id:'-1', name:'��Ա�б�', value:'-1', pId:'-2', isParent:true, open:true, icon:'../../skin/images/4.png'};\n");
	fprintf(cgiOut, "Nodes1.push(node);\n");
			
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = "";
	
	//��������
	memset(sql, 0, sizeof(sql));
	strcat(sql, "select t.dept from corp_info t ");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_tree_dept, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	}
	
	//��Ա����
	memset(sql, 0, sizeof(sql));
	strcat(sql, "select t.sys_id, t.cname, t.dept_id, t.status from user_info t where id <> 'system' and id <> 'admin' order by t.sys_id");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_tree_user, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	}
	sqlite3_close(db);
	
	/*-----------------------------������----------------------------------*/
	fprintf(cgiOut, "$('#areaTree').empty();\n");
	fprintf(cgiOut, "$.fn.zTree.init($('#areaTree'), setting, Nodes1);\n");
	
	/*-----------------------------�����----------------------------------*/
	fprintf(cgiOut, "function zTreeOnClick(event, treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(0 == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('id').value = rootValue;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(1 == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var idlist = '';\n");
	fprintf(cgiOut, "    var z_Tree = $.fn.zTree.getZTreeObj('areaTree');\n");
	fprintf(cgiOut, "    var node = z_Tree.getNodesByParam('pId', treeNode.value, null);\n");
	fprintf(cgiOut, "    for(var i=0; i<node.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      idlist += node[i].value + ',';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    document.getElementById('id').value = idlist;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('id').value = treeNode.value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "	 document.getElementById('level').value = treeNode.level;\n");
	fprintf(cgiOut, "  window.parent.frames.mainFrame.document.getElementById('DoSubmit').click();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function afterLoad()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('id').value = rootValue;\n");
	fprintf(cgiOut, "  document.getElementById('level').value = '0';\n");
	if(ContainsFP(user_id, "0501"))
  {
  	fprintf(cgiOut, "window.parent.frames.mainFrame.location = 'ats_info.cgi?cmd=0&id='+document.getElementById('id').value+'&level='+document.getElementById('level').value+'&user_id=%s';\n", user_id);
  }
  else
  {
  	if(ContainsFP(user_id, "0503"))
	  {
			fprintf(cgiOut, "var now = new Date().format('yyyy-MM-dd');\n");
			fprintf(cgiOut, "var Year = now.substring(0,4);\n");
			fprintf(cgiOut, "var Month = now.substring(5,7);\n");
			fprintf(cgiOut, "var BTime = now.substring(0,8) + '01';\n");
			fprintf(cgiOut, "var ETime = now.substring(0,8) + '31';\n");
	  	fprintf(cgiOut, "window.parent.frames.mainFrame.location = 'ats_ldg.cgi?cmd=0&id='+document.getElementById('id').value+'&level='+document.getElementById('level').value+'&Func_Sel_Id=1&BTime='+BTime+'&ETime='+ETime+'&Year='+Year+'&Month='+Month+'&user_id=%s';\n", user_id);
	  }
  }
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "afterLoad();\n");
  fprintf(cgiOut, "</SCRIPT>\n");
  fprintf(cgiOut, "</HTML>\n");
  fflush(stdout);
}

int sqlite3_exec_callback_tree_dept(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != col_values[0] && 0 < strlen(col_values[0]))
	{
		char* split = ",";
		char* split_result = NULL;
		int i = 0;
		split_result = strtok(col_values[0], split);
		while(split_result != NULL)
		{
			i++;
			char * save = split_result+strlen(split_result)+1;
			char pdept_id[5] = {0};
    	char pdept_name[30] = {0};
    	
    	sprintf(pdept_id, "%d", i);
			memcpy(pdept_id, StrLeftFillZero(pdept_id, 4), 5);
			memcpy(pdept_name, split_result, 30);
			
			fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'-1', isParent:true, open:false};\n", pdept_id, pdept_name, pdept_id);
			fprintf(cgiOut, "Nodes1.push(node);\n");
			
			split_result = strtok(save, split);
		}
	}
	return 0;
}

int sqlite3_exec_callback_tree_user(void *data, int n_columns, char **col_values, char **col_names)
{
	char name[60] = {0};
	if(0 == strcmp(col_values[3], "0"))
	{
		strcat(name, col_values[1]);
	}
	else
	{
		strcat(name, col_values[1]);
		strcat(name, "[��ע��]");
	}
	fprintf(cgiOut, "rootValue += '%s' + ',';\n", col_values[0]);
	fprintf(cgiOut, "var node = {id:'%s_sid', name:'%s', value:'%s', pId:'%s', open:false, icon:'../../skin/images/root.png'};\n", col_values[0], name, col_values[0], col_values[2]);
	fprintf(cgiOut, "Nodes1.push(node);\n");
	return 0;
}
