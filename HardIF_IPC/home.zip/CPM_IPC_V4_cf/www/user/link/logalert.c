#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "util.h"
#include "session.h"
#include "cgic.h"
#include <time.h>

//��������
char cmd[4] = {0};
int cnt = 0;
int cntAll = 0;
int TotalPage = 0;
int CurrPage = 0;

char sn[30] = {0};
char id[11] = {0};
char level[2] = {0};
char BTime[30] = {0};//��ʼʱ��
char ETime[30] = {0};//����ʱ��
char Func_Sel_Id[2] = {0};
char flag[2] = {0};
char timeflag[2] = {0};
char user_id[31] = {0};
FILE *csv_file = NULL; 
char idlist[4096*8] = {0};
//��������
static void getHtmlData();
bool	ContainsFP(char *pUser_Id, char *pFP_Id);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_role_list(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_PageBar(void *data, int n_columns, char **col_values, char **col_names);
//����
static void DealData();
//����
static void ExportData();
static int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain() 
{	
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	cntAll = 0;
	switch(atoi(cmd))
	{	
		case 0://��ѯ
			QueryData();
			break;
		case 1://����
			DealData();
			break;
		case 2://����
			ExportData();
			break;
	}	
	return 0;
}

void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("sn", sn, sizeof(sn));
  cgiFormString("id", id, sizeof(id));
	cgiFormString("level", level, sizeof(level));
	cgiFormString("BTime", BTime, sizeof(BTime));
	cgiFormString("ETime", ETime, sizeof(ETime));
	cgiFormString("Func_Sel_Id", Func_Sel_Id, sizeof(Func_Sel_Id));
	cgiFormString("flag", flag, sizeof(flag));
	cgiFormString("timeflag", timeflag, sizeof(timeflag));
	cgiFormString("user_id", user_id, sizeof(user_id));
	
	char cPage[10] = {0};//ȡҳ��
	cgiFormString("CurrPage", cPage, sizeof(cPage));
	CurrPage = atoi(cPage);
}

void DealData()
{
	int rc;
	char * zErrMsg = 0;
	char sql[256] = {0};
	sprintf(sql, "update alert_info set status = '1', operator = '%s', etime = datetime('now','localtime') where sn = '%s';", user_id, sn);
	sqlite3 *db;
	if(0 == strcmp(flag, "1"))
	{
		db = open_db(DB_PATH_BAK);
	}
	else
	{
		db = open_db(DB_PATH);
	}
	rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);	
	sqlite3_close(db);
	if(rc != SQLITE_OK)
	{
		printf("3006\n");
	}
	else
	{
		printf("0000\n");
	}
}

void QueryData()
{
	char BDate[11] = {0};
	char EDate[11] = {0};
	if(strlen(BTime) > 1 && strlen(ETime) > 1)
	{
		strncpy(BDate, BTime, 10);
		strncpy(EDate, ETime, 10);
	}
	else
	{
		time_t nowtime;
		struct tm *timeinfo;
		time(&nowtime);
		timeinfo = localtime(&nowtime);
		int year, month, day, hour, min, sec;
		year = timeinfo->tm_year + 1900;
		month = timeinfo->tm_mon + 1;
		day = timeinfo->tm_mday;
		hour = timeinfo->tm_hour;
		min = timeinfo->tm_min;
		sec = timeinfo->tm_sec;
		
		sprintf(BDate, "%d-%02d-%02d", year, month, day);
		sprintf(EDate, "%d-%02d-%02d", year, month, day);	
		sprintf(BTime, "%s 00:00:00", BDate);
		sprintf(ETime, "%s 23:59:59", EDate);	
	}
	if(strlen(flag) < 1)
	{
		memset(flag, 0, sizeof(flag));
		memcpy(flag, "0", 2);
	}
	if(strlen(timeflag) < 1)
	{
		memset(timeflag, 0, sizeof(timeflag));
		memcpy(timeflag, "0", 2);
	}
	fprintf(cgiOut, "<HTML>\n");
	fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "  <TITLE>�澯��־</TITLE>\n");
	fprintf(cgiOut, "  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "  <link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "  <script type=\"text/javascript\" src=\"../../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "  <script language='javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "  <SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name='alert_info' action='logalert.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "<table style='margin:auto' cellpadding='0' cellspacing='0' border='0' width='100%%'>\n");
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "    <td width='7%%' align='left'>\n");
	fprintf(cgiOut, "	     <select name='Func_Sel_Id' style='width:100px;height:20px' onChange='doSelect()'>\n");
	fprintf(cgiOut, "		     <option value='9' %s>ȫ��</option>\n",     0 == strcmp(Func_Sel_Id, "9")?"selected":"");
	fprintf(cgiOut, "			   <option value='1' %s>ϵͳ�澯</option>\n", 0 == strcmp(Func_Sel_Id, "1")?"selected":"");
	fprintf(cgiOut, "			   <option value='2' %s>���ݸ澯</option>\n", 0 == strcmp(Func_Sel_Id, "2")?"selected":"");
	fprintf(cgiOut, "			   <option value='3' %s>ϵͳ��ʾ</option>\n", 0 == strcmp(Func_Sel_Id, "3")?"selected":"");
	fprintf(cgiOut, "		   </select>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "	   <td width='40%%' align='left'>\n");
	fprintf(cgiOut, "		   <div>\n");
	fprintf(cgiOut, "		     ��ʼʱ��<input id='BDate' name='BDate' type='text' style=' width:90px;  background-color:#ffffff; border: 1 double #3491D6' value='%s' onClick='WdatePicker({readOnly:true})' class='Wdate' size='10' maxlength='10'>\n", BDate);
	fprintf(cgiOut, "			 	 ����ʱ��<input id='EDate' name='EDate' type='text' style=' width:90px;  background-color:#ffffff; border: 1 double #3491D6' value='%s' onClick='WdatePicker({readOnly:true})' class='Wdate' size='10' maxlength='10'>\n", EDate);
	fprintf(cgiOut, "			 </div>\n");
	fprintf(cgiOut, "		 </td>\n");
	fprintf(cgiOut, "		 <td width='45%%' align='right'>\n");
	fprintf(cgiOut, "			 <input name='alert_submit' style='cursor:hand;width:60px;' onClick='doSelect()' value='��ѯ' type='button'>\n");
	fprintf(cgiOut, "			 <input name='alert_export' style='cursor:hand;width:60px;' onClick='doExport()' value='����' type='button'>\n");
	fprintf(cgiOut, "		 </td>\n");
	fprintf(cgiOut, "	 </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<div id='down_bg_2'>\n");
	fprintf(cgiOut, "<table style='margin:auto' cellpadding='0' cellspacing='0' border='1' width='100%%' bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "	   <td width='3%%'  class='table_deep_blue'>SN</td>\n");
	fprintf(cgiOut, "		 <td width='8%%'  class='table_deep_blue'>�豸</td>\n");
	fprintf(cgiOut, "		 <td width='14%%' class='table_deep_blue'>�澯ʱ��</td>\n");
	fprintf(cgiOut, "		 <td width='8%%'  class='table_deep_blue'>����</td>\n");
	fprintf(cgiOut, "		 <td width='8%%'  class='table_deep_blue'>����</td>\n");
	fprintf(cgiOut, "		 <td width='24%%' class='table_deep_blue'>����</td>\n");
	fprintf(cgiOut, "		 <td width='8%%'  class='table_deep_blue'>״̬</td>\n");
	fprintf(cgiOut, "		 <td width='14%%' class='table_deep_blue'>�ָ�ʱ��</td>\n");
	fprintf(cgiOut, "		 <td width='8%%'  class='table_deep_blue'>����Ա</td>\n");
	fprintf(cgiOut, "	 </tr>\n");
	
	//��ѯ��¼����
	if(strlen(id) > 0)
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}
		char sql[4096*8] = {0};
		switch(atoi(level))
		{
			case 0:
					sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);					
					//����
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "SELECT COUNT(*) FROM ALERT_INFO A WHERE A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.ID) = 1 ", BTime, ETime, idlist);
					if(9 != atoi(Func_Sel_Id))
					{
						strcat(sql, " AND A.CTYPE = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);
				break;
			case 1:
					sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);
					//����
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "SELECT COUNT(*) FROM ALERT_INFO A WHERE A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.ID) = 1 ", BTime, ETime, idlist);
					if(9 != atoi(Func_Sel_Id))
					{
						strcat(sql, " AND A.CTYPE = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);		
				break;
			case 2:
					sprintf(sql, "SELECT COUNT(*) FROM ALERT_INFO A, ROLE B WHERE A.CTIME >= '%s' AND A.CTIME <= '%s' AND B.ID = '%s' AND contain(B.POINT, A.ID) = 1 ", BTime, ETime, id);
					if(9 != atoi(Func_Sel_Id))
					{
						strcat(sql, " AND A.CTYPE = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);
				break;
			case 3:
					sprintf(sql, "SELECT COUNT(*) FROM ALERT_INFO A WHERE A.CTIME >= '%s' AND A.CTIME <= '%s' AND A.ID = '%s' ", BTime, ETime, id);
					if(9 != atoi(Func_Sel_Id))
					{
						strcat(sql, " AND A.CTYPE = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);
				break;
		}	
		sqlite3_close(db);			
		if(cntAll%20 == 0)
		{
			TotalPage = cntAll/20;
		}
		else
		{
			TotalPage = cntAll/20 + 1;
		}		
		if(CurrPage > TotalPage)
		{
			CurrPage = TotalPage;
		}
	}
	
	//��ϸ
	if(strlen(id) > 0)
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}	
		char sql[4096*8] = {0};
		int offset = CurrPage < 1 ? 0 : (CurrPage-1)*20;
		char tail[128] = {0};
		switch(atoi(level))
		{
			case 0:
					sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);
					//��ϸ
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "SELECT B.CNAME, A.CTIME, A.CTYPE, A.LEVEL, A.VALUE, A.STATUS, A.SN, A.ETIME, A.OPERATOR FROM ALERT_INFO A, DEVICE_DETAIL B WHERE A.ID = B.ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.ID) = 1", BTime, ETime, idlist);
					if(9 != atoi(Func_Sel_Id))
					{
						strcat(sql, " AND A.CTYPE = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					sprintf(tail, " ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d", offset);
					strcat(sql, tail);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
				break;
			case 1:
					sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);
					//��ϸ
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "SELECT B.CNAME, A.CTIME, A.CTYPE, A.LEVEL, A.VALUE, A.STATUS, A.SN, A.ETIME, A.OPERATOR FROM ALERT_INFO A, DEVICE_DETAIL B WHERE A.ID = B.ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.ID) = 1", BTime, ETime, idlist);
					if(9 != atoi(Func_Sel_Id))
					{
						strcat(sql, " AND A.CTYPE = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					sprintf(tail, " ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d", offset);
					strcat(sql, tail);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
				break;
			case 2:
					sprintf(sql, "SELECT B.CNAME, A.CTIME, A.CTYPE, A.LEVEL, A.VALUE, A.STATUS, A.SN, A.ETIME, A.OPERATOR FROM ALERT_INFO A, DEVICE_DETAIL B, ROLE C WHERE A.ID = B.ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND C.ID = '%s' AND contain(C.POINT, A.ID) = 1 ", BTime, ETime, id);
					if(9 != atoi(Func_Sel_Id))
					{
						strcat(sql, " AND A.CTYPE = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}				
					sprintf(tail, " ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d", offset);	
					strcat(sql, tail);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
				break;
			case 3:
					sprintf(sql, "SELECT B.CNAME, A.CTIME, A.CTYPE, A.LEVEL, A.VALUE, A.STATUS, A.SN, A.ETIME, A.OPERATOR FROM ALERT_INFO A, DEVICE_DETAIL B WHERE A.ID = B.ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND A.ID = '%s' ", BTime, ETime, id);
					if(9 != atoi(Func_Sel_Id))
					{
						strcat(sql, " AND A.CTYPE = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					sprintf(tail, " ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d", offset);	
					strcat(sql, tail);
					
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
				break;
		}
		sqlite3_close(db);
	}
	
	for(int i=0; i<(20-cnt); i++)
	{
		fprintf(cgiOut, "<tr class='%s'>\n", 0 == i%2?"table_white_l":"table_blue");
		fprintf(cgiOut, "  <td width='3%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='8%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='14%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='8%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='8%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='24%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='8%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='14%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='8%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "</tr>\n");
	}	
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "    <td colspan='9' class='table_deep_blue' align='center'>\n");
	fprintf(cgiOut, "	     <table width='70%%' height='20'  border='0' cellpadding='0' cellspacing='0' >\n");
	fprintf(cgiOut, "		     <tr valign='bottom'>\n");
	fprintf(cgiOut, "			     <td nowrap align='center'>\n");
	fprintf(cgiOut, "            ҳ��:\n");
	fprintf(cgiOut, "            <strong>%d</strong>/<strong>%d</strong>\n", CurrPage, TotalPage);
	fprintf(cgiOut, "            <span>[��<b>%d</b>����¼]</span>\n", cntAll);
	fprintf(cgiOut, "            <a href=# onclick='GoPage(1)'>��ҳ</a>");
	fprintf(cgiOut, "            |<a href=# onclick='GoPage(%d)'>��һҳ</a>", CurrPage-1);
	fprintf(cgiOut, "            |<a href=# onclick='GoPage(%d)'>��һҳ</a>", CurrPage+1);
	fprintf(cgiOut, "            |<a href=# onclick='GoPage(%d)'>ĩ ҳ</a>", TotalPage);
	fprintf(cgiOut, "            |����<input name='ToPage' type='text' style='width:30px;height:17px' size='2'>ҳ\n");
	fprintf(cgiOut, "            <input type='button' style='width:40px;height:20px' onClick='GoPage(alert_info.ToPage.value)' value='ȷ��'/>\n");
	fprintf(cgiOut, "				   </td>\n");
	fprintf(cgiOut, "			   </tr>\n");
	fprintf(cgiOut, "		   </table>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'   value='0'>\n");
	fprintf(cgiOut, "<input type='hidden' name='id'    value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='level' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='BTime' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='ETime' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='flag'  value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='timeflag' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='CurrPage' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='user_id'  value='%s'>\n", user_id);
	fprintf(cgiOut, "<input name='DoSubmit' type='hidden' id='DoSubmit' onClick='doSelect()'/>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=\"JavaScript\">\n");
	fprintf(cgiOut, "if(null != window.parent.frames.leftFrame.CurrJsp)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 window.parent.frames.leftFrame.CurrJsp.innerText = 'alert_info.html';\n");
	fprintf(cgiOut, "}\n");	
	fprintf(cgiOut, "function StrLeftFillZero(strData, len)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var str = strData;\n");
	fprintf(cgiOut, "  var FillLen = len - str.length;\n");
	fprintf(cgiOut, "  for(var i=0; i < FillLen; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    str = '0' + str;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  return str;\n");
	fprintf(cgiOut, "}\n");
	if(0 == strcmp(timeflag, "1"))
	{
		fprintf(cgiOut, "var date = new Date();\n");
		fprintf(cgiOut, "date.setDate(date.getDate()-1);\n");
		fprintf(cgiOut, "var y = date.getFullYear();\n");
		fprintf(cgiOut, "var m = date.getMonth()+1;\n");
		fprintf(cgiOut, "var d = date.getDate();\n");	
		fprintf(cgiOut, "document.getElementById('EDate').value = y + '-' + StrLeftFillZero(m+'', 2) + '-'+ StrLeftFillZero(d+'', 2);\n");
	}
	fprintf(cgiOut, "Date.prototype.format = function(format)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var o =\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    'M+' : this.getMonth()+1,\n");
	fprintf(cgiOut, "    'd+' : this.getDate(),\n");
	fprintf(cgiOut, "    'h+' : this.getHours(),\n");
	fprintf(cgiOut, "    'm+' : this.getMinutes(),\n");
	fprintf(cgiOut, "    's+' : this.getSeconds(),\n");
	fprintf(cgiOut, "    'q+' : Math.floor((this.getMonth()+3)/3),\n");
	fprintf(cgiOut, "    'S'  : this.getMilliseconds()\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(/(y+)/.test(format))\n");
	fprintf(cgiOut, "    format=format.replace(RegExp.$1, (this.getFullYear()+\"\").substr(4 - RegExp.$1.length));\n");
	fprintf(cgiOut, "  for(var k in o)if(new RegExp(\"(\"+ k +\")\").test(format)) \n");
	fprintf(cgiOut, "    format = format.replace(RegExp.$1, RegExp.$1.length==1 ? o[k] : (\"00\"+ o[k]).substr((\"\"+ o[k]).length)); \n");
	fprintf(cgiOut, "  return format; \n");
	fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doDeal(pSN)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϵ�ǰ�澯�Ѵ���?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var flag = '0';\n");
	fprintf(cgiOut, "    var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "    if(alert_info.BDate.value == now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      flag = '0';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alert_info.BDate.value < now && alert_info.EDate.value < now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      flag = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alert_info.BDate.value < now && alert_info.EDate.value == now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      flag = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alert_info.BDate.value < now && alert_info.EDate.value > now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      flag = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alert_info.BDate.value > now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      flag = '0';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "	   if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   reqDeal = new XMLHttpRequest();\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   reqDeal = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   reqDeal.onreadystatechange = callbackDealName;\n");
	fprintf(cgiOut, "	   var url = 'logalert.cgi?cmd=1&flag='+flag+'&sn='+pSN+'&user_id=%s';\n", user_id);
	fprintf(cgiOut, "	   reqDeal.open('get', url, true);\n");
	fprintf(cgiOut, "	   reqDeal.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackDealName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqDeal.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqDeal.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('�����ɹ�');\n");
	fprintf(cgiOut, "          doSelect();\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('ʧ��,�����²���');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//��ϸ
  fprintf(cgiOut, "function doSelect()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "  if(alert_info.BDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert_info.flag.value = '0';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alert_info.BDate.value < now && alert_info.EDate.value < now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alert_info.BDate.value < now && alert_info.EDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    alert_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alert_info.BDate.value < now && alert_info.EDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    alert_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alert_info.BDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert_info.flag.value = '0';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  alert_info.BTime.value = alert_info.BDate.value + ' 00:00:00';\n");
	fprintf(cgiOut, "	 alert_info.ETime.value = alert_info.EDate.value + ' 23:59:59';\n");	
	fprintf(cgiOut, "  alert_info.id.value = window.parent.frames.leftFrame.id.value;\n");	
	fprintf(cgiOut, "  alert_info.level.value = window.parent.frames.leftFrame.level.value;\n");	
  fprintf(cgiOut, "	 alert_info.submit();\n");
  fprintf(cgiOut, "}\n");
  //��ҳ
  fprintf(cgiOut, "function GoPage(pPage)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "	 if(pPage == '0')\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "	   pPage = '1';\n");
  fprintf(cgiOut, "	 }\n"); 
  fprintf(cgiOut, "  if(pPage == '')\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "	   alert('������Ŀ��ҳ�����ֵ!');\n");
  fprintf(cgiOut, "		 return;\n");
  fprintf(cgiOut, "	 }\n");
  fprintf(cgiOut, "	 if(pPage < 1)\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "		 alert('������ҳ������1');\n");
  fprintf(cgiOut, "		 return;\n");
  fprintf(cgiOut, "	 }\n");
  fprintf(cgiOut, "  var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "  if(alert_info.BDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert_info.flag.value = '0';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alert_info.BDate.value < now && alert_info.EDate.value < now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alert_info.BDate.value < now && alert_info.EDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    alert_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alert_info.BDate.value < now && alert_info.EDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    alert_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alert_info.BDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert_info.flag.value = '0';\n");
  fprintf(cgiOut, "    alert_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n"); 
  fprintf(cgiOut, "	 alert_info.CurrPage.value = pPage;\n");
  fprintf(cgiOut, "  alert_info.BTime.value = alert_info.BDate.value + ' 00:00:00';\n");
	fprintf(cgiOut, "	 alert_info.ETime.value = alert_info.EDate.value + ' 23:59:59';\n");	
	fprintf(cgiOut, "  alert_info.id.value = window.parent.frames.leftFrame.id.value;\n");	
	fprintf(cgiOut, "  alert_info.level.value = window.parent.frames.leftFrame.level.value;\n");	
  fprintf(cgiOut, "	 alert_info.submit();\n");
  fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doExport()\n");
	fprintf(cgiOut, "{\n");
	if(!ContainsFP(user_id, "0302"))
  {
  	fprintf(cgiOut, "alert('����Ȩ��ʹ��[����]����!');return;\n");
  }
	fprintf(cgiOut, "  if(%d == 0)\n", cntAll);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�޼�¼�ɵ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  if(confirm('ȷ�ϵ���?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "    if(alert_info.BDate.value == now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alert_info.flag.value = '0';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alert_info.BDate.value < now && alert_info.EDate.value < now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alert_info.flag.value = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alert_info.BDate.value < now && alert_info.EDate.value == now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alert_info.flag.value = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alert_info.BDate.value < now && alert_info.EDate.value > now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alert_info.flag.value = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alert_info.BDate.value > now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alert_info.flag.value = '0';\n");
  fprintf(cgiOut, "    }\n"); 
	fprintf(cgiOut, "    alert_info.id.value = window.parent.frames.leftFrame.id.value;\n");	
	fprintf(cgiOut, "    alert_info.level.value = window.parent.frames.leftFrame.level.value;\n");
	fprintf(cgiOut, "	   alert_info.BTime.value = alert_info.BDate.value + ' 00:00:00';\n");
	fprintf(cgiOut, "	   alert_info.ETime.value = alert_info.EDate.value + ' 23:59:59';\n");		
	fprintf(cgiOut, "	   if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new XMLHttpRequest();\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   req.onreadystatechange = callbackForName;\n");
	fprintf(cgiOut, "	   var url = 'logalert.cgi?cmd=2&BTime='+alert_info.BTime.value+'&ETime='+alert_info.ETime.value+'&id='+alert_info.id.value+'&level='+alert_info.level.value+'&Func_Sel_Id='+alert_info.Func_Sel_Id.value+'&flag='+alert_info.flag.value+'&user_id=%s';\n", user_id);
	fprintf(cgiOut, "	   req.open('get', url, true);\n");
	fprintf(cgiOut, "	   req.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackForName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var state = req.readyState;\n");
	fprintf(cgiOut, "	 if(4 == state)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 location.href = '../other/%s_E_' + alert_info.BDate.value + '_' + alert_info.EDate.value + '.csv';\n", user_id);
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");	
}

int sqlite3_exec_callback_PageBar(void *data, int n_columns, char **col_values, char **col_names)
{
	cntAll += atoi(col_values[0]);
	return 0;
}

int sqlite3_exec_callback_role_list(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat(idlist, col_values[0]);	
	return 0;
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(CurrPage < 1)
	{
		CurrPage = 1;
	}
	int sn = (CurrPage-1)*20 + cnt;
	char statusname[128] = {0};
	char etimename[128] = {0};
	char operatorname[128] = {0};
	switch(atoi(col_values[5]))
	{
		case 0:
				strcat(statusname, "<a href='#' onClick=\"doDeal('");
				strcat(statusname, col_values[6]);
				strcat(statusname, "');\"><font color=red><U>δ����</u></font></a>");
				strcat(etimename, "");
				strcat(operatorname, "");
			break;
		case 1:
				strcat(statusname, "<font color=black>�˹��Ѵ���</font>");
				strcat(etimename, col_values[7]);
				strcat(operatorname, col_values[8]);
			break;
		case 2:
				strcat(statusname, "<font color=black>ϵͳ�Ѵ���</font>");
				strcat(etimename, col_values[7]);
				strcat(operatorname, col_values[8]);
			break;
		case 3:
				strcat(statusname, "<font color=black>��ʾ�Ѵ���</font>");
				strcat(etimename, col_values[7]);
				strcat(operatorname, col_values[8]);
			break;
	}
	char ctypename[20] = {0};
	switch(atoi(col_values[2]))
	{
		case 1:
				strcat(ctypename, "ϵͳ�澯");
			break;
		case 2:
				strcat(ctypename, "���ݸ澯");
			break;
		case 3:
				strcat(ctypename, "ϵͳ��ʾ");
			break;
	}
	char levelname[128] = "��";
	if(NULL != col_values[3] && strlen(col_values[3]) > 0)
	{
		memset(levelname, 0, sizeof(levelname));
		memcpy(levelname, col_values[3], 128);
	}
	
	fprintf(cgiOut, "<tr class='%s'>\n", 0 == cnt%2?"table_white_l":"table_blue");
	fprintf(cgiOut, "  <td width='3%%'  align=center>%d</td>\n",       sn);           //���
	fprintf(cgiOut, "	 <td width='8%%'  align=center>%s</td>\n",       col_values[0]);//�豸
	fprintf(cgiOut, "	 <td width='14%%' align=center>%s</td>\n",       col_values[1]);//�澯ʱ��
	fprintf(cgiOut, "	 <td width='8%%'  align=center>%s</td>\n",       ctypename);    //����
	fprintf(cgiOut, "	 <td width='8%%'  align=center>%s</td>\n",       levelname);    //����
	fprintf(cgiOut, "	 <td width='24%%' align=left>%s&nbsp;</td>\n",   col_values[4]);//����
	fprintf(cgiOut, "	 <td width='8%%'  align=left>%s</td>\n",         statusname);   //״̬
	fprintf(cgiOut, "	 <td width='14%%' align=left>%s&nbsp;</td>\n",   etimename);    //�ָ�ʱ��
	fprintf(cgiOut, "	 <td width='8%%'  align=left>%s&nbsp;</td>\n",   operatorname); //����Ա
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

//�첽����
void ExportData()
{
	char BDate[11] = {0};
	char EDate[11] = {0};
	if(strlen(BTime) > 1 && strlen(ETime) > 1)
	{
		strncpy(BDate, BTime, 10);
		strncpy(EDate, ETime, 10);
	}
	else
	{
		time_t nowtime;
		struct tm *timeinfo;
		time(&nowtime);
		timeinfo = localtime(&nowtime);
		int year, month, day, hour, min, sec;
		year = timeinfo->tm_year + 1900;
		month = timeinfo->tm_mon + 1;
		day = timeinfo->tm_mday;
		hour = timeinfo->tm_hour;
		min = timeinfo->tm_min;
		sec = timeinfo->tm_sec;
		
		sprintf(BDate, "%d-%02d-%02d", year, month, day);
		sprintf(EDate, "%d-%02d-%02d", year, month, day);		
		sprintf(BTime, "%s 00:00:00", BDate);
		sprintf(ETime, "%s 23:59:59", EDate);	
	}
	if(strlen(flag) < 1)
	{
		memset(flag, 0, sizeof(flag));
		memcpy(flag, "0", 2);
	}
	if(strlen(timeflag) < 1)
	{
		memset(timeflag, 0, sizeof(timeflag));
		memcpy(timeflag, "0", 2);
	}
	char file_path[100] = {0}; 
	strcpy(file_path, "../other/");
	strcat(file_path, user_id);		//�û���
	strcat(file_path, "_E_");			//����	
	strcat(file_path, BDate);		  //��ʼʱ��
	strcat(file_path, "_");			  //����	
	strcat(file_path, EDate);		  //��ֹʱ��
	strcat(file_path, ".csv");
	if(NULL != file_path)
	{
		csv_file = fopen(file_path, "w");
		chmod(file_path, 777);
		if(NULL != csv_file)
		{
			fputs("�豸,�澯ʱ��,����,����,����,״̬,�ָ�ʱ��,����Ա\n", csv_file); 	
			int rc;
			char *zErrMsg;
			sqlite3 *db;
			if(0 == strcmp(flag, "1"))
			{
				db = open_db(DB_PATH_BAK);
			}
			else
			{
				db = open_db(DB_PATH);
			}
			
			char sql[4096*8] = {0};
			switch(atoi(level))
			{
				case 0:
						sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);
						
						//��ϸ
						memset(sql, 0, sizeof(sql));
						sprintf(sql, "SELECT B.CNAME, A.CTIME, A.CTYPE, A.LEVEL, A.VALUE, A.STATUS, A.SN, A.ETIME, A.OPERATOR FROM ALERT_INFO A, DEVICE_DETAIL B WHERE A.ID = B.ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.ID) = 1 ", BTime, ETime, idlist);
						if(9 != atoi(Func_Sel_Id))
						{
							strcat(sql, " AND A.CTYPE = '");
							strcat(sql, Func_Sel_Id);
							strcat(sql, "' ");
						}									
						strcat(sql, " ORDER BY A.CTIME DESC");
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);		
					break;
				case 1:
						sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);
						//��ϸ
						memset(sql, 0, sizeof(sql));
						sprintf(sql, "SELECT B.CNAME, A.CTIME, A.CTYPE, A.LEVEL, A.VALUE, A.STATUS, A.SN, A.ETIME, A.OPERATOR FROM ALERT_INFO A, DEVICE_DETAIL B WHERE A.ID = B.ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.ID) = 1 ", BTime, ETime, idlist);
						if(9 != atoi(Func_Sel_Id))
						{
							strcat(sql, " AND A.CTYPE = '");
							strcat(sql, Func_Sel_Id);
							strcat(sql, "' ");
						}									
						strcat(sql, " ORDER BY A.CTIME DESC");
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
					break;
				case 2:
						sprintf(sql, "SELECT B.CNAME, A.CTIME, A.CTYPE, A.LEVEL, A.VALUE, A.STATUS, A.SN, A.ETIME, A.OPERATOR FROM ALERT_INFO A, DEVICE_DETAIL B, ROLE C WHERE A.ID = B.ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND C.ID = '%s' AND contain(C.POINT, A.ID) = 1 ", BTime, ETime, id);
						if(9 != atoi(Func_Sel_Id))
						{
							strcat(sql, " AND A.CTYPE = '");
							strcat(sql, Func_Sel_Id);
							strcat(sql, "' ");
						}									
						strcat(sql, " ORDER BY A.CTIME DESC");
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
					break;
				case 3:
						sprintf(sql, "SELECT B.CNAME, A.CTIME, A.CTYPE, A.LEVEL, A.VALUE, A.STATUS, A.SN, A.ETIME, A.OPERATOR FROM ALERT_INFO A, DEVICE_DETAIL B WHERE A.ID = B.ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND A.ID = '%s' ", BTime, ETime, id);
						if(9 != atoi(Func_Sel_Id))
						{
							strcat(sql, " AND A.CTYPE = '");
							strcat(sql, Func_Sel_Id);
							strcat(sql, "' ");
						}	
						strcat(sql, " ORDER BY A.CTIME DESC");				
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
					break;
			}
			sqlite3_close(db);
		}	
		fclose(csv_file);	
	}		
}

int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names)
{
	char record[2048] = {0};
	char statusname[20] = {0};
	char etimename[128] = {0};
	char operatorname[128] = {0};
	switch(atoi(col_values[5]))
	{
		case 0:
				strcat(statusname, "δ����");
				strcat(etimename, "");
				strcat(operatorname, "");
			break;
		case 1:
				strcat(statusname, "�˹��Ѵ���");
				strcat(etimename, col_values[7]);
				strcat(operatorname, col_values[8]);
			break;
		case 2:
				strcat(statusname, "ϵͳ�Ѵ���");
				strcat(etimename, col_values[7]);
				strcat(operatorname, col_values[8]);
			break;
		case 3:
				strcat(statusname, "��ʾ�Ѵ���");
				strcat(etimename, col_values[7]);
				strcat(operatorname, col_values[8]);
			break;
	}
	char ctypename[20] = {0};
	switch(atoi(col_values[2]))
	{
		case 1:
				strcat(ctypename, "ϵͳ�澯");
			break;
		case 2:
				strcat(ctypename, "���ݸ澯");
			break;
		case 3:
				strcat(ctypename, "ϵͳ��ʾ");
			break;
	}
	char levelname[128] = "��";
	if(NULL != col_values[3] && strlen(col_values[3]) > 0)
	{
		memset(levelname, 0, sizeof(levelname));
		memcpy(levelname, col_values[3], 128);
	}
	sprintf(record, "%s,%s,%s,%s,%s,%s,%s,%s\n", col_values[0], col_values[1], ctypename, levelname, col_values[4], statusname, etimename, operatorname);
	fputs(record, csv_file);
	return 0;	
}
