#include "cgic.h"
#include "sqlite3.h"
#include "session.h"
#include "util.h"

char user_id[31] = {0};
int cnt = 0;
//��������
static void Net_Tree();
static int sqlite3_exec_callback_userdata(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_tree(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	cgiFormString("user_id", user_id, sizeof(user_id));
	
	cnt = 0;
	Net_Tree();		
	return 0;
}

void Net_Tree()
{	
	fprintf(cgiOut, "<HTML>\n");
  fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>ʵʱ���</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv='x-ua-compatible' content='ie=7'/>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/zTreeStyle2.css' rel='stylesheet'/>\n");	
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery-1.4.4.min.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.core-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.excheck-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.exedit-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</HEAD>\n");
  fprintf(cgiOut, "<BODY style='background:#0B80CC;'>\n");
  fprintf(cgiOut, "  <div id='PARENT'>\n");
	fprintf(cgiOut, "    <ul id='nav'>\n");
	//fprintf(cgiOut, "      <li><a href='#' onClick='doReturn()' target='mainFrame'>�����ϲ�</a></li>\n");
	fprintf(cgiOut, "    </ul>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "  <div><ul id='areaTree' class='ztree'></ul></div>\n");
  fprintf(cgiOut, "</BODY>\n");
  fprintf(cgiOut, "<SCRIPT LANGUAGE='JavaScript'>\n");
  fprintf(cgiOut, "function doReturn()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  parent.location = 'index.cgi?user_id=%s';\n", user_id);
  fprintf(cgiOut, "}\n");
	//������
	fprintf(cgiOut, "var rootValue = '';\n");
	fprintf(cgiOut, "var nodeValue = '';\n");
	fprintf(cgiOut, "var rootLevel = false;\n");
  fprintf(cgiOut, "var Nodes1 = [];\n");
  fprintf(cgiOut, "var setting = \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  edit: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    enable: false\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  data: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    simpleData:{enable: true}\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  callback: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    onClick: zTreeOnClick\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "};\n");
	 
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = "";
	sprintf(sql, "select YKT_ROLE from USER_INFO where ID = '%s'", user_id);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_userdata, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	}
	sqlite3_close(db);
	
	/*-----------------------------������----------------------------------*/
	fprintf(cgiOut, "$('#areaTree').empty();\n");
	fprintf(cgiOut, "$.fn.zTree.init($('#areaTree'), setting, Nodes1);\n");
	
	/*-----------------------------�����----------------------------------*/
	fprintf(cgiOut, "function zTreeOnClick(event, treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if('0' == treeNode.level && !rootLevel)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  window.parent.frames.mainFrame.location = 'netToPo.cgi?cmd=5&id='+treeNode.value+'&level='+treeNode.level+'&user_id=%s';\n", user_id);
	fprintf(cgiOut, "}\n");
	
	/*-----------------------------��ʼ��----------------------------------*/
	fprintf(cgiOut, "if(rootLevel)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  window.parent.frames.mainFrame.location = 'netToPo.cgi?cmd=5&level=0&user_id=%s&id='+rootValue;\n", user_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "else\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  window.parent.frames.mainFrame.location = 'netToPo.cgi?cmd=5&level=1&user_id=%s&id='+nodeValue;\n", user_id);
	fprintf(cgiOut, "}\n");
	
	/*-----------------------------�ҽڵ�----------------------------------*/
	fprintf(cgiOut, "function FindNode(pNodeId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var zTree1 = $.fn.zTree.getZTreeObj('areaTree');\n");
	fprintf(cgiOut, "  var tempArray = zTree1.getNodesByParam('level', 1);\n");
	fprintf(cgiOut, "  for(var i in tempArray)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(pNodeId == tempArray[i].id)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      zTree1.selectNode(tempArray[i], false);\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "</SCRIPT>\n");
  fprintf(cgiOut, "</HTML>\n");
  fflush(stdout);
}

int sqlite3_exec_callback_userdata(void *data, int n_columns, char **col_values, char **col_names)
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = "";
	sprintf(sql, "select id, cname, point, icon from ROLE where ID like '%s%%'", col_values[0]);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_tree, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	}
	sqlite3_close(db);
	return 0;
}

int sqlite3_exec_callback_tree(void *data, int n_columns, char **col_values, char **col_names)
{
	if(strlen(col_values[0]) >= 4 && col_values[0][0] == '6' && col_values[0][1] == '0')
	{
		switch(strlen(col_values[0]))
		{
			case 4://����
					fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s', isParent:true, open:true, icon:'../../skin/images/root.png'};\n", col_values[0], col_values[1], col_values[0], col_values[0]);
					fprintf(cgiOut, "Nodes1.push(node);\n");
					if(NULL != col_values[3] && strlen(col_values[3]) > 6)
					{
						fprintf(cgiOut, "rootValue = '%s';\n", col_values[0]);
						fprintf(cgiOut, "rootLevel = true;\n");
					}
				break;
			case 6://����
					fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s'.substring(0,4), open:false, icon:'../../skin/images/1_close.png'};\n", col_values[0], col_values[1], col_values[0], col_values[0]);
					fprintf(cgiOut, "Nodes1.push(node);\n");
					if(0 == cnt)
					{
						fprintf(cgiOut, "nodeValue = '%s';\n", col_values[0]);
					}
					cnt++;
				break;
			case 8://����
					fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s'.substring(0,6), open:false, icon:'../../skin/images/camera.png'};\n", col_values[0], col_values[1], col_values[0], col_values[0]);
					fprintf(cgiOut, "Nodes1.push(node);\n");
				break;
		}
	}
	return 0;
}
