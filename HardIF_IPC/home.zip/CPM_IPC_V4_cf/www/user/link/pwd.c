#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

//��������
char user_id[31] = {0};
//��������
static void getHtmlData();
static void doIndex();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	doIndex();
		
	return 0;
}

void getHtmlData()
{  
	cgiFormString("user_id", user_id, sizeof(user_id));
}

void doIndex()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<title>�����޸�</title>\n");
	fprintf(cgiOut, "<meta http-equiv='x-ua-compatible' content='ie=7'/>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content='text/html; charset=gb2312'>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script language=javascript src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style='background:#CADFFF'>\n");
	fprintf(cgiOut, "  <form name='Pwd_Edit' action='user_info.cgi' method='post' target='_self'>\n");
	fprintf(cgiOut, "  <div id='down_bg_2'>\n");
	fprintf(cgiOut, "  <div id='right_table_center'><br><br>\n");
	fprintf(cgiOut, "    <table style='margin:auto;' width='50%%' border=0 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "      <tr height='30px'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='right'>\n");
	//fprintf(cgiOut, "          <img style='cursor:hand' onClick='doReturn()' src='../../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "          <img style='cursor:hand' onClick='doSubmit()' src='../../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "      <tr height='30px'>\n");
	fprintf(cgiOut, "        <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "          <table width='100%%' border=1 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "            <tr height='30px'>\n");
	fprintf(cgiOut, "              <td width='15%%' align='center'><span class='style1'>��¼�˺�</span></td>\n");
	fprintf(cgiOut, "              <td width='25%%' align='left' bgcolor='#F7F7F7'>%s</td>\n", user_id);
	fprintf(cgiOut, "            </tr>\n");	
	fprintf(cgiOut, "            <tr height='30px'>\n");
	fprintf(cgiOut, "              <td width='15%%' align='center'><span class='style1'>������</span></td>\n");
	fprintf(cgiOut, "              <td width='25%%' align='left' bgcolor='#F7F7F7'><input name='OldPwd' type='password' maxlength='6' value='' size='20'></td>\n");
	fprintf(cgiOut, "            </tr>\n");
	fprintf(cgiOut, "            <tr height='30px'>\n");
	fprintf(cgiOut, "              <td width='15%%' align='center'><span class='style1'>������</span></td>\n");
	fprintf(cgiOut, "              <td width='25%%' align='left' bgcolor='#F7F7F7'><input name='NewPwd' type='password' maxlength='6' value='' size='20'></td>\n");
	fprintf(cgiOut, "            </tr>\n");
	fprintf(cgiOut, "            <tr height='30px'>\n");
	fprintf(cgiOut, "              <td width='15%%' align='center'><span class='style1'>ȷ��������</span></td>\n");
	fprintf(cgiOut, "              <td width='25%%' align='left' bgcolor='#F7F7F7'><input name='ConfirmNewPwd' type='password' maxlength='6' value='' size='20'></td>\n");
	fprintf(cgiOut, "            </tr>\n");
	fprintf(cgiOut, "          </table>\n");
	fprintf(cgiOut, "        </td>\n");
	fprintf(cgiOut, "      </tr>\n");
	fprintf(cgiOut, "    </table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "  </form>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<script language=javascript>\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'index.cgi?user_id=%s';\n", user_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "var reqEdit = null;\n");
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  if(Pwd_Edit.OldPwd.value == null || Pwd_Edit.OldPwd.value.length < 1)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��������������!');\n");
  fprintf(cgiOut, "    return;\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  if(Pwd_Edit.NewPwd.value == null || Pwd_Edit.NewPwd.value.length < 1)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('����������������!');\n");
  fprintf(cgiOut, "    return;\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  if(Pwd_Edit.ConfirmNewPwd.value == null || Pwd_Edit.ConfirmNewPwd.value.length < 1)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('����������ȷ������!');\n");
  fprintf(cgiOut, "    return;\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  if(Pwd_Edit.NewPwd.value != Pwd_Edit.ConfirmNewPwd.value)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('���������������ȷ�����벻һ�£�����������');\n");
  fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ��Ҫ�޸���������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqEdit = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqEdit = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqEdit.onreadystatechange = callbackFuncEdit;\n");
	fprintf(cgiOut, "    var url = 'user_info.cgi?cmd=13&user_id=%s&pwd='+Pwd_Edit.OldPwd.value+'&newpwd='+Pwd_Edit.NewPwd.value+'&currtime='+new Date();\n", user_id);
	fprintf(cgiOut, "    reqEdit.open('get', url);\n");
	fprintf(cgiOut, "    reqEdit.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqEdit.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackFuncEdit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqEdit.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqEdit.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert(resp);\n");
	fprintf(cgiOut, "      Pwd_Edit.OldPwd.value = '';\n");
	fprintf(cgiOut, "      Pwd_Edit.NewPwd.value = '';\n");
	fprintf(cgiOut, "      Pwd_Edit.ConfirmNewPwd.value = '';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</html>\n");
}
