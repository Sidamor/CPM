#include <stdio.h>
#include "cgic.h"
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"

//��Ա����
int cnt = 0;
char FillStr[1024] = {0};
char user_id[31] = {0};
char cmd[4] = {0};
char id[15] = {0};
char level[2] = {0};
//��������
static void getHtmlData();
void err_msg(int pType);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback_role(void *data, int n_columns, char **col_values, char **col_names);
//��ȡ����
int getData(int flag, char *Id);
int Receiver(ClsTCPClientSocket* pTcpSocket);
static CodecType doShow(void* pMsg, int& nUsed);
//ͨѶ
char *getLocalIP();
char *StrRightFillSpace(char *strData, int len);

int cgiMain() 
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	switch(atoi(cmd))
	{
		case 0://��ѯ
			QueryData();
			break;
	}
	return 0;
}

void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("user_id", user_id, sizeof(user_id));
  cgiFormString("id", id, sizeof(id)); 
	cgiFormString("level", level, sizeof(level));
}

void QueryData()
{
	fprintf(cgiOut, "<HTML>\n");
	fprintf(cgiOut, "<TITLE>ʵʱ����</TITLE>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
  fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
  fprintf(cgiOut, "</head>\n");
  fprintf(cgiOut, "<body style=\"background:#CADFFF\">\n");
  fprintf(cgiOut, "<form name='env' action='env.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "<div id='down_bg_2'>\n");
	fprintf(cgiOut, "<table style='margin:auto' cellpadding='0' cellspacing='0' border='1' width='100%%' bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='5%%'  class='table_deep_blue'>SN</td>\n");
	fprintf(cgiOut, "    <td width='10%%' class='table_deep_blue'>�豸</td>\n");
	fprintf(cgiOut, "    <td width='10%%' class='table_deep_blue'>����</td>\n");
	fprintf(cgiOut, "    <td width='15%%' class='table_deep_blue'>ʱ��</td>\n");
	fprintf(cgiOut, "    <td width='10%%' class='table_deep_blue'>��ֵ</td>\n");
	fprintf(cgiOut, "    <td width='10%%' class='table_deep_blue'>״̬</td>\n");
	fprintf(cgiOut, "    <td width='10%%' class='table_deep_blue'>����</td>\n");
	fprintf(cgiOut, "    <td width='15%%' class='table_deep_blue'>����</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	if(strlen(id) > 0)
	{
		char sql[4096] = {0};
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db = open_db(DB_PATH);
		switch(atoi(level))
		{
			case 0:
			case 1:
			case 2:
					sprintf(sql, "select a.point from role a where length(a.id) = 8 and a.id like '%s%s' order by a.id", id, "%");
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role, 0, &zErrMsg);
					if(rc != SQLITE_OK )
					{
					  err_msg(1);
					}
				break;
			case 3:
				break;
		}
		sqlite3_close(db);
	}
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'	 value='0'>\n");
	fprintf(cgiOut, "<input type='hidden' name='id'	   value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='level' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "if(null != window.parent.frames.leftFrame.CurrJsp)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 window.parent.frames.leftFrame.CurrJsp.innerText = 'env.html';\n");
	fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "</script>\n");
  fprintf(cgiOut, "</html>\n");
}

int sqlite3_exec_callback_role(void *data, int n_columns, char **col_values, char **col_names)
{
	getData(0, col_values[0]);
	return 0;
}

CodecType doShow(void* pMsg, int& nUsed)
{
  MsgHdr *pMsgHdr = (MsgHdr *)pMsg; 
  if(nUsed < MSGHDRLEN )
  {
    nUsed = 0;
    return CODEC_NEED_DATA;
  }	
  unsigned char tempMsg[MSGHDRLEN] = {0};
  memcpy(tempMsg, (unsigned char*)pMsg, MSGHDRLEN);
  MsgHdr *pTempMsgHdr = (MsgHdr *)tempMsg; 
  TKU32 unMsgLen  = pTempMsgHdr->unMsgLen;
  TKU32 unMsgCode = pTempMsgHdr->unMsgCode;
  TKU32 unStatus  = pTempMsgHdr->unStatus;  
  
  //AddMsg((BYTE *)pMsgHdr, nUsed);	
  if(unMsgLen < MSGHDRLEN || unMsgLen > COMM_RECV_MAXBUF)
  {
    nUsed = 0;
    return CODEC_ERR;
  }
  if(nUsed < (int)unMsgLen)
  {
	  nUsed = 0;
	  return CODEC_NEED_DATA;
  }
  nUsed = unMsgLen;
  if(unMsgCode & COMM_RSP)
  {
	  if(unStatus == 0x00)
	  {
	  	return CODEC_RESP;
	  }
	  else
	  {
	  	return CODEC_ERR;
	  }
  }
  
  char realdata[4096] = {0};
  char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
  //AddMsg((BYTE *)pMsgHdr, unMsgLen);	
  
  if(0 == memcmp(pmsg+20, "0001", 4) || 0 == memcmp(pmsg+20, "0000", 4))
  {
		strncpy(realdata, pmsg+28, unMsgLen - MSGHDRLEN - 28);
		if(NULL != realdata && 0 < strlen(realdata))
		{
			char* split_result = NULL;
		  char* savePtr = NULL;
		  split_result = strtok_r(realdata, "}", &savePtr);
		  while(NULL != split_result)
			{
				cnt++;
				char* temp_savePtr = NULL;
				char *temp_p;
				char *temp_buffer = strdup(split_result);
				temp_p = strtok_r(temp_buffer, ",", &temp_savePtr);
				int i = 0;
				char v_id[11] = {0};
				char v_cname[30] = {0};
				char v_attr_name[30] = {0};
				char v_ctime[21] = {0};
				char v_data[128] = {0};
				char v_unit[10]  = {0};
				char v_status[2] = {0};
				char v_level[5] = {0};
				char v_desc[128] = {0};
				while(NULL != temp_p)
				{
					switch(i)
					{
						case 0:
							sprintf(v_id, "%s", temp_p+1);
							break;
						case 1:
							sprintf(v_cname, "%s", temp_p);
							break;
						case 2:
							sprintf(v_attr_name, "%s", temp_p);
							break;
						case 3:
							sprintf(v_ctime, "%s", temp_p);
							break;
						case 4:
							sprintf(v_data, "%s", temp_p);
							break;
						case 5:
							sprintf(v_unit, "%s", temp_p);
							break;
						case 6:
							sprintf(v_status, "%s", temp_p);
							break;
						case 7:
							sprintf(v_level, "%s", temp_p);
							break;
						case 8:
							sprintf(v_desc, "%s", temp_p);
							break;
					}
					temp_p = strtok_r(NULL, ",", &temp_savePtr);
					i++;
				}
				
				char statusname[60] = {0};
				char levelname[10] = {0};
				char descname[128] = {0};
				switch(atoi(v_status))
				{
					case 0://����
							strcat(statusname, "<font color=green>����</font>");
						break;
					case 1://�쳣
							strcat(statusname, "<font color=red>�쳣</font>");
						break;
					default://�쳣
							strcat(statusname, "<font color=red>�쳣</font>");
						break;
				}
				if(NULL == v_level || strlen(v_level) < 2)
				{
					strcat(levelname, "��");
				}
				else
				{
					strcat(levelname, v_level);
				}
				if(NULL == v_desc || strlen(v_desc) < 2)
				{
					strcat(descname, "��");
				}
				else
				{
					strcat(descname, v_desc);
				}
				fprintf(cgiOut, "<tr height='40'>\n");
				fprintf(cgiOut, "  <td width='5%%'  align='center'>%d</td>\n", cnt);
				fprintf(cgiOut, "  <td width='10%%' align='center'>%s</td>\n", v_cname);
				fprintf(cgiOut, "  <td width='10%%' align='center'>%s</td>\n", v_attr_name);
				fprintf(cgiOut, "  <td width='15%%' align='center'>%s</td>\n", v_ctime);
				fprintf(cgiOut, "  <td width='10%%' align='center'>%s%s&nbsp</td>\n", v_data, v_unit);
				fprintf(cgiOut, "  <td width='10%%' align='center'>%s</td>\n", statusname);
				fprintf(cgiOut, "  <td width='10%%' align='center'>%s</td>\n", levelname);
				fprintf(cgiOut, "  <td width='15%%' align='center'>%s</td>\n", descname);
				fprintf(cgiOut, "</tr>\n");
				
				split_result = strtok_r(NULL, "}", &savePtr);
			}		
		}		
		if(0 == memcmp(pmsg+20, "0001", 4))
		{		
  		return CODEC_CMD;
  	}
  	else
  	{
  		return CODEC_ERR;
  	}
  }
  else
  {
  	return CODEC_ERR;
  }
}

int getData(int flag, char *Id)
{
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return 0;
	}
	//������װ
	BYTE outbuf[4096] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	int len = 0;
	switch(flag)
	{
		case 0://�豸���ݲ�ѯ(2021)
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002021");
				strcat(pdata, Id);
				len = MSGHDRLEN + 20 + 8 + strlen(Id);
			break;			
	}
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	//����
	char *ip = getLocalIP();
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return 0;
	}
	pSock->SetCompletion();
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return 0;
	}
	//����
	int ret = (Receiver(pSock));
	return ret;
}

int Receiver(ClsTCPClientSocket* pTcpSocket)
{
  int nRcvLen = 0;
  char cBuff[4096] = {0};
  char MsgBuf[2048]= {0};
  char RespBuf[2048] = {0};
  int RespLen = 0;
  unsigned int nRcvPos = 0;
  int nCursor = 0;
  bool bContParse = true;
  CodecType ctRslt;
	bool loop = true;
  while(loop)
  {
    if (pTcpSocket->IsPending(30000))
    {
      nRcvLen = pTcpSocket->Recv(&cBuff[nRcvPos], 4096 - nRcvPos - 1);
      if(nRcvLen <= 0)
      {
	      return 0;
      }
      else
      {
	      nRcvPos += nRcvLen;
	      nRcvLen = 0;
	      nCursor = 0;
	      RespLen = 0;
	      int nLen = 0;
	      bContParse = true;
        while (bContParse)
        {
          nLen = nRcvPos - nCursor;
          if(0 >= nLen) 
          	break;
          memset(MsgBuf, 0, sizeof(MsgBuf));
          memset(RespBuf, 0, sizeof(RespBuf));         
          ctRslt = doShow(&cBuff[nCursor], nLen);
          switch(ctRslt)
          {
            case CODEC_CMD:
                nCursor += nLen;
                break;
            case CODEC_RESP:                
                nCursor += nLen;
                break;
            case CODEC_NEED_DATA:
                bContParse = false;
                break;
            case CODEC_ERR:
                nRcvPos = 0;
                bContParse = false;
                loop = false;
                break;
            default:
                break;
          }
        }
        if(0 != nRcvPos)
        {
          memcpy(cBuff, &cBuff[nCursor], nRcvPos - nCursor);
          nRcvPos -= nCursor;
        }
      }
    }
  }
  return 2;
}

char *StrRightFillSpace(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	int FillLen = len - strlen(strData);
	strcat(FillStr, strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(FillStr, " ");
	}
	return FillStr;
}
