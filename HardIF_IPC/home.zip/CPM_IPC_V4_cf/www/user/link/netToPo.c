#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"

/*��������*/
int staudp = 180000;
int cnt = 0;
int btn_00_cnt = 0;
int btn_01_cnt = 0;
int btn_02_cnt = 0;
int btn_03_cnt = 0;
int btn_04_cnt = 0;
int btn_05_cnt = 0;
int btn_06_cnt = 0;
int btn_07_cnt = 0;
int btn_08_cnt = 0;
int btn_09_cnt = 0;
int btn_10_cnt = 0;
int btn_11_cnt = 0;
int btn_12_cnt = 0;
char cmd[4] = {0};
char user_id[31] = {0};
char FillStr[1024] = {0};
char point[4096] = {0};
char realalert[4096] = {0};
char id_index[11] = {0};
char cmd_type[2] = {0};
char realstat[4096] = {0};
char realsing[4096] = {0};
char realmode[4096] = {0};
/*Զ�̿���*/
char id[4096] = {0};
char level[2] = {0};
char cname[30] = {0};
char icon[30] = {0};
char roleid[11] = {0};
char memo[129] = {0};
char sn[9] = {0};
char object [257] = {0};
char cmdname[30] = {0};
char isflag[2] = {0};
char isflag2[2] = {0};
char isobject[2] = {0};
char obj_insert[9] = {0};
char checkindex[10] = {0};
char cmdarea[3] = {0};
char dev_type[2] = {0};
char status[2] = {0};
//��������
char* trim(char* s, int len);
void err_msg(int pType);
static void getHtmlData();
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//��ȡ���¶���
char *getB_NCmd(int pCType, char *pId, char *pModeId, char *pSN);
static int sqlite3_exec_callback_getB_NCmd(void *data, int n_columns, char **col_values, char **col_names);
//��Ԫ��
static void NetToPoTree();
static int sqlite3_exec_callback_icon(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_nettree(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_device(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_point(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_marke(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_marke_area(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_point_all(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_marke_point(void *data, int n_columns, char **col_values, char **col_names);
//Զ�̿���
static void CtrlHtml();
static int sqlite3_exec_callback_sel(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cmd(void *data, int n_columns, char **col_values, char **col_names);
static void ObjHtml();
static int sqlite3_exec_callback_call(void *data, int n_columns, char **col_values, char **col_names);
//Զ�̿���
static void CtrlSubmit();
//���¸澯
static void Alert();
static int sqlite3_exec_callback_alert_area(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_alert_info(void *data, int n_columns, char **col_values, char **col_names);
//״̬����
static void RealStatus();
//ģʽ����
static void RealModeSel();
//���ݸ���
static void RealDataSel();
//ͨѶ
static int MsgSend(int flag);
char *getLocalIP();
char *StrRightFillSpace(char *strData, int len);
char *StrLeftFillZero(char *strData, int len);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	btn_00_cnt = 0;
	btn_01_cnt = 0;
	btn_02_cnt = 0;
	btn_03_cnt = 0;
	btn_04_cnt = 0;
	btn_05_cnt = 0;
	btn_06_cnt = 0;
	btn_07_cnt = 0;
	btn_08_cnt = 0;
	btn_09_cnt = 0;
	btn_10_cnt = 0;
	btn_11_cnt = 0;
	btn_12_cnt = 0;
	switch(atoi(cmd))
	{
		case 5:
			  NetToPoTree();
			break;
		case 4:
				Alert();
			break;			
		case 6:
				RealStatus();
			break;
		case 7:
				RealModeSel();
			break;
		case 8:
				RealDataSel();
			break;
		case 1:
				CtrlHtml();
			break;
		case 2:
				CtrlSubmit();
			break;
		case 3:
				ObjHtml();
			break;		
	}
	return 0;
}

void getHtmlData()
{  
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("user_id", user_id, sizeof(user_id));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("level", level, sizeof(level));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("icon", icon, sizeof(icon));
	cgiFormString("roleid", roleid, sizeof(roleid));
	cgiFormString("memo", memo, sizeof(memo));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("object", object, sizeof(object));
	cgiFormString("cmdname", cmdname, sizeof(cmdname));
	cgiFormString("isflag", isflag, sizeof(isflag));
	cgiFormString("isflag2", isflag2, sizeof(isflag2));
	cgiFormString("isobject", isobject, sizeof(isobject));
	cgiFormString("obj_insert", obj_insert, sizeof(obj_insert));
	cgiFormString("checkindex", checkindex, sizeof(checkindex));
	cgiFormString("cmdarea", cmdarea, sizeof(cmdarea));
	cgiFormString("cmd_type", cmd_type, sizeof(cmd_type));
	cgiFormString("id_index", id_index, sizeof(id_index));
	cgiFormString("dev_type", dev_type, sizeof(dev_type));
	cgiFormString("status", status, sizeof(status));
}

int sqlite3_exec_callback_icon(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat((char *)data, col_values[0]);
	return 0;
}

//��ԪԪ��
void NetToPoTree()
{
	if(NULL != id && strlen(id) > 0)
	{
		int showtype = 0;
		char showicon[61] = {0};
		if(strlen(id) <= 6)
		{
			int rc;
			char * zErrMsg = 0;
			sqlite3 *db = open_db(DB_PATH);
			char sql[512] = "";
			sprintf(sql, "select a.icon from role a where a.id = '%s'", id);
			rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_icon, showicon, &zErrMsg);
			if(rc != SQLITE_OK)
			{
				err_msg(3);
			}
			sqlite3_close(db);
			
			if(NULL != showicon && strlen(showicon) > 6)
			{
				showtype = 1;
			}
		}
		
		switch(atoi(level))
		{
			case 0://����(ƽ��ͼ)
					{
						if(0 == showtype)
						{
							fprintf(cgiOut, "<html>\n");
							fprintf(cgiOut, "<head>\n");
							fprintf(cgiOut, "<title>��������ƽ̨-Ӧ�ù���</title>\n");
							fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'>\n");
							fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css'    rel='stylesheet'/>\n");
							fprintf(cgiOut, "<link type='text/css' href='../../skin/css/subModal.css' rel='stylesheet'/>\n");
							fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
							fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/common.js'></script>\n");
							fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/subModal.js'></script>\n");
							fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
							fprintf(cgiOut, "<style>\n");
							fprintf(cgiOut, "  html{height:100%%}\n");
							fprintf(cgiOut, "  body{height:100%%; margin:0px; padding:0px}\n");
							fprintf(cgiOut, "</style>\n");
							fprintf(cgiOut, "</head>\n");
							fprintf(cgiOut, "<body style='background:#CADFFF'>\n");
							//fprintf(cgiOut, "<div id='down_bg_2'>\n");
							fprintf(cgiOut, "  <div id='mapdiv' style='text-align:center;width:700px;height:500px;position:relative;left:0;top:0;border:0px solid #19b31d;'>\n");
							fprintf(cgiOut, "    <img id='mapimg' src='../../admin/%s' style='width:700px;height:500px;'>\n", showicon);
							fprintf(cgiOut, "  </div>\n");
							//fprintf(cgiOut, "</div>\n");
							fprintf(cgiOut, "</body>\n");
							fprintf(cgiOut, "<SCRIPT language='javascript'>\n");
							fprintf(cgiOut, "var clientWidth = document.body.clientWidth;\n");
							fprintf(cgiOut, "var clientHeight = document.body.clientHeight;\n");
							fprintf(cgiOut, "if(clientWidth > 700){document.getElementById('mapdiv').style.left = (clientWidth-700)/2;}\n");
							fprintf(cgiOut, "if(clientHeight > 500){document.getElementById('mapdiv').style.top = (clientHeight-500)/2;}\n");
							fprintf(cgiOut, "var IdAll = '';\n");
							fprintf(cgiOut, "var CTAll = 0;\n");
						}
						else
						{
							fprintf(cgiOut, "<html>\n");
							fprintf(cgiOut, "<head>\n");
							fprintf(cgiOut, "<title>��������ƽ̨-Ӧ�ù���</title>\n");
							fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'>\n");
							fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css'    rel='stylesheet'/>\n");
							fprintf(cgiOut, "<link type='text/css' href='../../skin/css/subModal.css' rel='stylesheet'/>\n");
							fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
							fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/common.js'></script>\n");
							fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/subModal.js'></script>\n");
							fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
							fprintf(cgiOut, "<style>\n");
							fprintf(cgiOut, "  html{height:100%%}\n");
							fprintf(cgiOut, "  body{height:100%%; margin:0px; padding:0px}\n");
							fprintf(cgiOut, "</style>\n");
							fprintf(cgiOut, "</head>\n");
							fprintf(cgiOut, "<body style='background:#CADFFF'>\n");
							//fprintf(cgiOut, "<div id='down_bg_2'>\n");
							fprintf(cgiOut, "  <div id='mapdiv' style='text-align:center;width:700px;height:500px;position:relative;left:0;top:0;border:0px solid #19b31d;'>\n");
							fprintf(cgiOut, "    <img id='mapimg' src='../../admin/%s' style='width:700px;height:500px;'>\n", showicon);
							fprintf(cgiOut, "  </div>\n");
							//fprintf(cgiOut, "</div>\n");
							fprintf(cgiOut, "</body>\n");
							fprintf(cgiOut, "<SCRIPT language='javascript'>\n");
							fprintf(cgiOut, "var clientWidth = document.body.clientWidth;\n");
							fprintf(cgiOut, "var clientHeight = document.body.clientHeight;\n");
							fprintf(cgiOut, "if(clientWidth > 700){document.getElementById('mapdiv').style.left = (clientWidth-700)/2;}\n");
							fprintf(cgiOut, "if(clientHeight > 500){document.getElementById('mapdiv').style.top = (clientHeight-500)/2;}\n");
							fprintf(cgiOut, "var IdAll = '';\n");
							fprintf(cgiOut, "var CTAll = 0;\n");
							//��ϣ����
							fprintf(cgiOut, "var hashTable = new Object();\n");
							fprintf(cgiOut, "function add(key, value)\n");
							fprintf(cgiOut, "{\n");
							fprintf(cgiOut, "  if(key in hashTable)\n");
							fprintf(cgiOut, "  {\n");
							fprintf(cgiOut, "    \n");
							fprintf(cgiOut, "  }\n");
							fprintf(cgiOut, "  else\n");
							fprintf(cgiOut, "  {\n");
							fprintf(cgiOut, "    hashTable[key] = value;\n");
							fprintf(cgiOut, "  }\n");
							fprintf(cgiOut, "}\n");
							fprintf(cgiOut, "function exit(pKey)\n");
							fprintf(cgiOut, "{\n");
							fprintf(cgiOut, "  var resp = false;\n");
							fprintf(cgiOut, "  for(var k in hashTable)\n");
							fprintf(cgiOut, "  {\n");
							fprintf(cgiOut, "    if(k == pKey)\n");
							fprintf(cgiOut, "    {\n");
							fprintf(cgiOut, "      resp = true;\n");
							fprintf(cgiOut, "      break;\n");
							fprintf(cgiOut, "    }\n");
							fprintf(cgiOut, "  }\n");
							fprintf(cgiOut, "  return resp;\n");
							fprintf(cgiOut, "}\n");
							
							char sql[4096*8] = {0};
							int rc;
							char * zErrMsg = 0;
							sqlite3 *db = open_db(DB_PATH);
							
							//ȫ���ڵ�
							memset(sql, 0, sizeof(sql));
							strcat(sql, "select a.id, a.brief, b.icon, a.status, a.memo, a._pos_x, a._pos_y, b.dev_type from device_detail a, device_info b where substr(a.id, 1, 6) = b.id and a._sign = '1' order by a.id");
							rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_point_all, 0, &zErrMsg);
							if(rc != SQLITE_OK)
							{
								err_msg(3);
							}
							
							//��ʾ�ڵ�
							memset(sql, 0, sizeof(sql));
							sprintf(sql, "select a.id, a.cname, a.point from role a where length(a.id) = 8 and a.id like '%s%s' order by a.id", id, "%");
							rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_marke_point, 0, &zErrMsg);
							if(rc != SQLITE_OK)
							{
								err_msg(3);
							}
							
							//��ʾ����
							memset(sql, 0, sizeof(sql));
							sprintf(sql, "select a.id, a.cname, a.pos_x, a.pos_y from role a where length(a.id) = 6 and a.id like '%s%s' and a.sign = '1' order by a.id", id, "%");				
							rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_marke_area, 0, &zErrMsg);
							if(rc != SQLITE_OK)
							{
								err_msg(3);
							}
							
							sqlite3_close(db);
						}
					}
				break;
			case 1://����
			case 2://����
					{
						switch(showtype)
						{
							case 0://����
								{
									fprintf(cgiOut, "<html xmlns:v='urn:schemas-microsoft-com:vml'>\n");
									fprintf(cgiOut, "<head>\n");
									fprintf(cgiOut, "<title>��������ƽ̨-Ӧ�ù���</title>\n");
									fprintf(cgiOut, "<META http-equiv=Content-Type content='text/html; charset=gb2312'>\n");
									fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css'    rel='stylesheet'/>\n");
									fprintf(cgiOut, "<link type='text/css' href='../../skin/css/subModal.css' rel='stylesheet'/>\n");
									fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
									fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/common.js'></script>\n");
									fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/subModal.js'></script>\n");
									fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/wz_jsgraphics.js' charset='gb2312'></script>\n");
									fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
									fprintf(cgiOut, "</head>\n");
									fprintf(cgiOut, "<body style='background:#CADFFF'>\n");
									fprintf(cgiOut, "<div id='down_bg_2'>\n");
									fprintf(cgiOut, "  <div id='board' style='text-align:center;width:100%%;height:100%%;'></div>\n");
									fprintf(cgiOut, "</div>\n");
									fprintf(cgiOut, "</body>\n");
									fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
									//���ɻ���
									fprintf(cgiOut, "var IdAll = '';\n");
									fprintf(cgiOut, "var mainBoard = document.getElementById('board');\n");
									fprintf(cgiOut, "var mbWidth = mainBoard.style.width.replace('px','')*1;\n");
									fprintf(cgiOut, "var mbHeight = mainBoard.style.height.replace('px','')*1;\n");
									fprintf(cgiOut, "var mbLeft = mainBoard.style.left.replace('px','')*1;\n");
									fprintf(cgiOut, "var mbTop = mainBoard.style.top.replace('px','')*1;\n");
									fprintf(cgiOut, "var index = 0;\n");
									fprintf(cgiOut, "function createNode(nodeId, nodeName, imgUrl, stateFlag, level, statusname, titlevalue, rolename, pMemo, Objleft, Objtop, pDev_Type)\n");
									fprintf(cgiOut, "{\n");
									fprintf(cgiOut, "  try\n");
									fprintf(cgiOut, "  {\n");	
									fprintf(cgiOut, "    switch(parseInt(level, 10))\n");
									fprintf(cgiOut, "    {\n");
									fprintf(cgiOut, "      case 0:\n");
									fprintf(cgiOut, "          var objHtml = \"<div id='\"+nodeId+\"' level='\"+level+\"' style='position:absolute;left:\"+Objleft+\"px;top:\"+Objtop+\"px;width:100px;height:60px;'>\"+ \"<img style='width:32px;height:32px;' src='\"+imgUrl+\"'/><br>\"+nodeName+\"<br>\"+statusname +\"</div>\";\n");
									fprintf(cgiOut, "  				 mainBoard.innerHTML = mainBoard.innerHTML + objHtml;\n");
									fprintf(cgiOut, "          drawLine(nodeId, '0', cntAll, 100, 60, Objleft, Objtop);\n");
									fprintf(cgiOut, "        break;\n");
									fprintf(cgiOut, "      case 1:\n");
									fprintf(cgiOut, "          var objHtml = \"<div id='\"+nodeId+\"' level='\"+level+\"' style='position:absolute;left:\"+Objleft+\"px;top:\"+Objtop+\"px;width:100px;height:60px;'>\"+ \"<img style='width:32px;height:32px;' src='\"+imgUrl+\"'/><br>\"+nodeName+\"<br>\"+statusname +\"</div>\";\n");
									fprintf(cgiOut, "  				 mainBoard.innerHTML = mainBoard.innerHTML + objHtml;\n");
									fprintf(cgiOut, "          drawLine(nodeId, '1', cntAll, 100, 60, Objleft, Objtop);\n");
									fprintf(cgiOut, "        break;\n");
									fprintf(cgiOut, "      case 2:\n");
									fprintf(cgiOut, "  				 var objHtml = \"<div id='\"+nodeId+\"' level='\"+level+\"' style='position:absolute;left:\"+Objleft+\"px;top:\"+Objtop+\"px;width:100px;height:60px;'>\"+ \"<img id='img_sta\"+index+\"' style='width:32px;height:32px;cursor:hand;' src='\"+imgUrl+\"' onmousedown=doDefence('\"+nodeId+\"',\"+stateFlag+\",'\"+nodeName+\"','\"+imgUrl+\"','\"+rolename+\"',\"+index+\",'\"+pMemo+\"','\"+pDev_Type+\"') title='\"+titlevalue+\"' /><br>[\"+nodeName+\"]<br><div id='status\"+index+\"'>\"+statusname+\"</div></div>\";\n");
									fprintf(cgiOut, "  				 mainBoard.innerHTML = mainBoard.innerHTML + objHtml;\n");
									fprintf(cgiOut, "          drawLine(nodeId, '2', cntAll, 100, 60, Objleft, Objtop);\n");
									fprintf(cgiOut, "          IdAll += nodeId + ',';\n");
									fprintf(cgiOut, "          index++;\n");
									fprintf(cgiOut, "        break;\n");
									fprintf(cgiOut, "    }\n");
									fprintf(cgiOut, "  }\n");
									fprintf(cgiOut, "  catch(e)\n");
									fprintf(cgiOut, "  {\n");
									fprintf(cgiOut, "    \n");
									fprintf(cgiOut, "  }\n");
									fprintf(cgiOut, "}\n");
									fprintf(cgiOut, "function drawLine(node, level, subCnt, obj1Width, obj1Height, obj1Left, obj1Top)\n");
									fprintf(cgiOut, "{\n");
									fprintf(cgiOut, "  try\n");
									fprintf(cgiOut, "  {\n");
									fprintf(cgiOut, "    switch(parseInt(level, 10))\n");
									fprintf(cgiOut, "    {\n");
									fprintf(cgiOut, "      case 0:\n");
									fprintf(cgiOut, "          drawNow(obj1Left+obj1Width/2, obj1Top+obj1Height/2, obj1Left+obj1Width/2+40, obj1Top+obj1Height/2);\n");
									fprintf(cgiOut, "        break;\n");
									fprintf(cgiOut, "      case 1:\n");
									switch(atoi(level))
									{
										case 1:
												fprintf(cgiOut, "    drawNow(obj1Left+obj1Width/2-40, obj1Top+obj1Height/2, obj1Left+obj1Width/2+40, obj1Top+obj1Height/2);\n");
											break;
										case 2:
												fprintf(cgiOut, "    drawNow(obj1Left+obj1Width/2, obj1Top+obj1Height/2, obj1Left+obj1Width/2+40, obj1Top+obj1Height/2);\n");
											break;
									}
									fprintf(cgiOut, "          if(cnt > 1)\n");
									fprintf(cgiOut, "          {\n");
									fprintf(cgiOut, "      		   //����1\n");
									fprintf(cgiOut, "        		 drawNow(obj1Left+10, obj1Top+obj1Height/2, obj1Left+10, obj1Top+obj1Height/2 - (45+(cnt-1+parseInt((cntAll-1)/8))*90));\n");
									fprintf(cgiOut, "          }\n");
									fprintf(cgiOut, "          else\n");
									fprintf(cgiOut, "          {\n");
									fprintf(cgiOut, "            //����2\n");
									//fprintf(cgiOut, "        		 drawNow(obj1Left+10, obj1Top+obj1Height/2, obj1Left+10, obj1Top+obj1Height/2 - 40);\n");
									fprintf(cgiOut, "          }\n");
									fprintf(cgiOut, "        break;\n");
									fprintf(cgiOut, "      case 2:\n");
									fprintf(cgiOut, "      		 if(subCnt%%8 != 1)\n");
									fprintf(cgiOut, "      		 {\n");
									fprintf(cgiOut, "      		   //����1\n");
									fprintf(cgiOut, "        		 drawNow(obj1Left+obj1Width/2-90, obj1Top-15, obj1Left+obj1Width/2, obj1Top-15);\n");
									fprintf(cgiOut, "      		 }\n");
									fprintf(cgiOut, "      		 else\n");
									fprintf(cgiOut, "      		 {\n");
									fprintf(cgiOut, "      		   //����2\n");
									fprintf(cgiOut, "        		 drawNow(obj1Left+obj1Width/2-80, obj1Top-15, obj1Left+obj1Width/2, obj1Top-15);\n");
									fprintf(cgiOut, "      		 }\n");
									fprintf(cgiOut, "      		 //����1\n");
									fprintf(cgiOut, "      		 drawNow(obj1Left+obj1Width/2, obj1Top-15, obj1Left+obj1Width/2, obj1Top);\n");
									fprintf(cgiOut, "      		 if(subCnt%%8 == 1 && subCnt > 8)\n");
									fprintf(cgiOut, "      		 {\n");
									fprintf(cgiOut, "      		   //����2\n");
									fprintf(cgiOut, "      		   drawNow(obj1Left+obj1Width/2-80, obj1Top-105, obj1Left+obj1Width/2-80, obj1Top-15);\n");
									fprintf(cgiOut, "      		 }\n");
									fprintf(cgiOut, "        break;\n");
									fprintf(cgiOut, "    }\n");
									fprintf(cgiOut, "  }\n");
									fprintf(cgiOut, "  catch(e)\n");
									fprintf(cgiOut, "  {\n");
									fprintf(cgiOut, "  }\n");
									fprintf(cgiOut, "}\n");
									fprintf(cgiOut, "function drawNow(fromX, fromY, toX, toY)\n");
									fprintf(cgiOut, "{\n");	
									fprintf(cgiOut, "  var jgboard = new jsGraphics('board');\n");
									fprintf(cgiOut, "  jgboard.setColor('#000000');\n");
									fprintf(cgiOut, "  jgboard.setStroke(1);\n");
									fprintf(cgiOut, "  jgboard.drawLine(fromX, fromY, toX, toY);\n");
									fprintf(cgiOut, "  jgboard.paint();\n");
									fprintf(cgiOut, "}\n");
									//���ɽڵ�
									fprintf(cgiOut, "var c = 0;\n");
									fprintf(cgiOut, "var cn = 0;\n");
									fprintf(cgiOut, "var cnt = 0;\n");
									fprintf(cgiOut, "var cntAll = 0;\n");
									int rc;
									char * zErrMsg = 0;
									sqlite3 *db = open_db(DB_PATH);
									char sql[512] = "";
									sprintf(sql, "select a.id, a.cname, a.point from role a where length(a.id) >= 6 and a.id like '%s%%' order by a.id", id);
									rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_nettree, 0, &zErrMsg);
									if(rc != SQLITE_OK)
									{
										err_msg(3);
									}
									sqlite3_close(db);
									break;
								}
							case 1://����
								{
									fprintf(cgiOut, "<html>\n");
									fprintf(cgiOut, "<head>\n");
									fprintf(cgiOut, "<title>��������ƽ̨-Ӧ�ù���</title>\n");
									fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'>\n");
									fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css'    rel='stylesheet'/>\n");
									fprintf(cgiOut, "<link type='text/css' href='../../skin/css/subModal.css' rel='stylesheet'/>\n");
									fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
									fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/common.js'></script>\n");
									fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/subModal.js'></script>\n");
									fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
									fprintf(cgiOut, "<style>\n");
									fprintf(cgiOut, "  html{height:100%%}\n");
									fprintf(cgiOut, "  body{height:100%%; margin:0px; padding:0px}\n");
									fprintf(cgiOut, "</style>\n");
									fprintf(cgiOut, "</head>\n");
									fprintf(cgiOut, "<body style='background:#CADFFF'>\n");
									//fprintf(cgiOut, "<div id='down_bg_2'>\n");
									fprintf(cgiOut, "  <div id='mapdiv' style='text-align:center;width:700px;height:500px;position:relative;left:0;top:0;border:0px solid #19b31d;'>\n");
									fprintf(cgiOut, "    <img id='mapimg' src='../../admin/%s' style='width:700px;height:500px;'>\n", showicon);
									fprintf(cgiOut, "  </div>\n");
									//fprintf(cgiOut, "</div>\n");
									fprintf(cgiOut, "</body>\n");
									fprintf(cgiOut, "<SCRIPT language='javascript'>\n");
									fprintf(cgiOut, "var clientWidth = document.body.clientWidth;\n");
									fprintf(cgiOut, "var clientHeight = document.body.clientHeight;\n");
									fprintf(cgiOut, "if(clientWidth > 700){document.getElementById('mapdiv').style.left = (clientWidth-700)/2;}\n");
									fprintf(cgiOut, "if(clientHeight > 500){document.getElementById('mapdiv').style.top = (clientHeight-500)/2;}\n");
									fprintf(cgiOut, "var IdAll = '';\n");
									
									//��ʾ�ڵ�
									char sql[256] = {0};
									sprintf(sql, "select a.id, a.cname, a.point from role a where length(a.id) = 8 and a.id like '%s%s' order by a.id", id, "%");
									int rc;
									char * zErrMsg = 0;
									sqlite3 *db = open_db(DB_PATH);
									rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_point, 0, &zErrMsg);
									if(rc != SQLITE_OK)
									{
										err_msg(3);
									}
									sqlite3_close(db);
									break;
								}
						}
					}
				break;
		}
		
		//��������
		fprintf(cgiOut, "function doArea(pId)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  window.parent.frames.leftFrame.FindNode(pId);\n");
		fprintf(cgiOut, "  window.parent.frames.mainFrame.location = 'netToPo.cgi?cmd=5&id='+pId+'&level=1&user_id=%s';\n", user_id);
		fprintf(cgiOut, "}\n");
		
		//�򿪵�����
		fprintf(cgiOut, "function doDefence(pId, pStatus, pCName, pImgUrl, pRoleId, pIndex, pMemo, pDev_Type)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  var url = 'netToPo.cgi?cmd=1&id='+pId+'&cname='+pCName+'&icon='+pImgUrl+'&roleid='+pRoleId+'&id_index='+pIndex+'&memo='+pMemo+'&dev_type='+pDev_Type+'&status='+pStatus+'&user_id=%s';\n", user_id);
		fprintf(cgiOut, "  showPopWin(pCName, url, 360, 500, null, true, true);\n");
		fprintf(cgiOut, "}\n");
		
		//״̬��ʱ����	
		fprintf(cgiOut, "var reqSta = null;\n");
		fprintf(cgiOut, "function RealStatus(pId, pIndex, pType)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    reqSta = new XMLHttpRequest();\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    reqSta = new ActiveXObject('Microsoft.XMLHTTP');\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  reqSta.onreadystatechange = function()\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    var state = reqSta.readyState;\n");
		fprintf(cgiOut, "    if(state == 4)\n");
		fprintf(cgiOut, "    {\n");
		fprintf(cgiOut, "      var resp = reqSta.responseText;\n");
		switch(showtype)
		{
			case 0://����
				{
					fprintf(cgiOut, "if(null != resp && resp.Trim().length >= 4)\n");
					fprintf(cgiOut, "{\n");
					fprintf(cgiOut, "  switch(parseInt(pType, 10))\n");
					fprintf(cgiOut, "  {\n");
					fprintf(cgiOut, "    case 2:\n");
					fprintf(cgiOut, "        switch(parseInt(resp.substring(0,4)))\n");
					fprintf(cgiOut, "        {\n");
					fprintf(cgiOut, "          case 0:\n");
					fprintf(cgiOut, "              var list = resp.substring(4).split(';');\n");
					fprintf(cgiOut, "              for(var i=0; i<list.length && list[i].Trim().length>0; i++)\n");
					fprintf(cgiOut, "              {\n");
					fprintf(cgiOut, "                var show = '';\n");
					fprintf(cgiOut, "                var sublist = list[i].split(',');\n");
					fprintf(cgiOut, "                switch(parseInt(sublist[1]))\n");
					fprintf(cgiOut, "                {\n");
					fprintf(cgiOut, "                  case 0://��\n");
					fprintf(cgiOut, "                      show = '<font color=black>[' + sublist[2] + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+i).src = '../../system/b_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 1://��\n");
					fprintf(cgiOut, "                      show = '<font color=gray >[' + sublist[2] + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+i).src = '../../system/g_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 2://��\n");
					fprintf(cgiOut, "                      show = '<font color=red  >[' + sublist[2] + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+i).src = '../../system/r_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 3://��\n");
					fprintf(cgiOut, "                      show = '<font color=green>[' + sublist[2] + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+i).src = '../../system/icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 4://��\n");
					fprintf(cgiOut, "                      show = '<font color=green>[' + sublist[2] + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+i).src = '../../system/c_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 5://��\n");
					fprintf(cgiOut, "                      show = '<font color=green>[' + sublist[2] + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+i).src = '../../system/o_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                }\n");
					//fprintf(cgiOut, "                document.getElementById('status'+i).innerHTML = show;\n");
					fprintf(cgiOut, "              }\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "          case 3006:\n");
					fprintf(cgiOut, "              var list = pId.split(',');\n");
					fprintf(cgiOut, "              for(var i=0; i<list.length && list[i].length>0; i++)\n");
					fprintf(cgiOut, "              {\n");
					//fprintf(cgiOut, "                document.getElementById('status'+i).innerHTML = '<font color=red>[δ֪]</font>';\n");
					fprintf(cgiOut, "              }\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "          default:\n");
					fprintf(cgiOut, "              var list = pId.split(',');\n");
					fprintf(cgiOut, "              for(var i=0; i<list.length && list[i].length>0; i++)\n");
					fprintf(cgiOut, "              {\n");
					//fprintf(cgiOut, "                document.getElementById('status'+i).innerHTML = '<font color=red>[δ֪]</font>';\n");
					fprintf(cgiOut, "              }\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "        }\n");
					fprintf(cgiOut, "      break;\n");
					fprintf(cgiOut, "    case 3:\n");
					fprintf(cgiOut, "        switch(parseInt(resp.substring(0,4)))\n");
					fprintf(cgiOut, "        {\n");
					fprintf(cgiOut, "          case 0:\n");
					fprintf(cgiOut, "              if(resp.len() >= 71)\n");
					fprintf(cgiOut, "              {\n");
					fprintf(cgiOut, "              	 var Show = '';\n");
					fprintf(cgiOut, "                var DId  = resp.substring(4, 10);\n");
					fprintf(cgiOut, "                var statcolo = resp.substring(14, 15);\n");
					fprintf(cgiOut, "                var statshow = subString(resp, 71).substring(15);\n");
					fprintf(cgiOut, "                switch(parseInt(statcolo))\n");
					fprintf(cgiOut, "                {\n");
					fprintf(cgiOut, "                  case 0://��\n");
					fprintf(cgiOut, "                      Show = '<font color=black>[' + statshow.Trim() + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+pIndex).src = '../../system/b_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 1://��\n");
					fprintf(cgiOut, "                      Show = '<font color=gray >[' + statshow.Trim() + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+pIndex).src = '../../system/g_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 2://��\n");
					fprintf(cgiOut, "                      Show = '<font color=red  >[' + statshow.Trim() + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+pIndex).src = '../../system/r_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 3://��\n");
					fprintf(cgiOut, "                      Show = '<font color=green>[' + statshow.Trim() + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+pIndex).src = '../../system/icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 4://��\n");
					fprintf(cgiOut, "                      Show = '<font color=green>[' + statshow.Trim() + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+pIndex).src = '../../system/c_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 5://��\n");
					fprintf(cgiOut, "                      Show = '<font color=green>[' + statshow.Trim() + ']</font>';\n");
					fprintf(cgiOut, "                      document.getElementById('img_sta'+pIndex).src = '../../system/o_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                }\n");
					//fprintf(cgiOut, "                document.getElementById('status'+pIndex).innerHTML = Show;\n");
					fprintf(cgiOut, "              }\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "          case 3006:\n");
					//fprintf(cgiOut, "              document.getElementById('status'+pIndex).innerHTML = '<font color=red>[δ֪]</font>';\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "          default:\n");
					//fprintf(cgiOut, "              document.getElementById('status'+pIndex).innerHTML = '<font color=red>[δ֪]</font>';\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "        }\n");
					fprintf(cgiOut, "      break;\n");
					fprintf(cgiOut, "  }\n");
					fprintf(cgiOut, "}\n");
					fprintf(cgiOut, "else\n");
					fprintf(cgiOut, "{\n");
					fprintf(cgiOut, "  switch(parseInt(pType))\n");
					fprintf(cgiOut, "  {\n");
					fprintf(cgiOut, "    case 2:\n");
					fprintf(cgiOut, "        var list = pId.split(',');\n");
					fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
					fprintf(cgiOut, "        {\n");
					//fprintf(cgiOut, "          document.getElementById('status'+i).innerHTML = '<font color=red>[δ֪]</font>';\n");
					fprintf(cgiOut, "        }\n");
					fprintf(cgiOut, "      break;\n");
					fprintf(cgiOut, "    case 3:\n");
					//fprintf(cgiOut, "        document.getElementById('status'+pIndex).innerHTML = '<font color=red>[δ֪]</font>';\n");
					fprintf(cgiOut, "      break;\n");
					fprintf(cgiOut, "  }\n");
					fprintf(cgiOut, "}\n");
					break;
				}
			case 1://����
				{
					fprintf(cgiOut, "if(null != resp && resp.Trim().length >= 4)\n");
					fprintf(cgiOut, "{\n");
					fprintf(cgiOut, "  switch(parseInt(pType))\n");
					fprintf(cgiOut, "  {\n");
					fprintf(cgiOut, "    case 2:\n");
					fprintf(cgiOut, "        switch(parseInt(resp.substring(0,4)))\n");
					fprintf(cgiOut, "        {\n");
					fprintf(cgiOut, "          case 0:\n");
					fprintf(cgiOut, "              var list = resp.substring(4).split(';');\n");
					fprintf(cgiOut, "              for(var i=0; i<list.length && list[i].Trim().length>0; i++)\n");
					fprintf(cgiOut, "              {\n");
					fprintf(cgiOut, "                var show = '';\n");
					fprintf(cgiOut, "                var sublist = list[i].split(',');\n");
					fprintf(cgiOut, "                switch(parseInt(sublist[1]))\n");
					fprintf(cgiOut, "                {\n");
					fprintf(cgiOut, "                  case 0://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+i).style.border = '0px solid black';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).color = 'black';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).innerText = '[' + sublist[2] + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+i).src = '../../system/b_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 1://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+i).style.border = '0px solid gray';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).color = 'gray';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).innerText = '[' + sublist[2] + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+i).src = '../../system/g_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 2://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+i).style.border = '0px solid red';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).color = 'red';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).innerText = '[' + sublist[2] + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+i).src = '../../system/r_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 3://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+i).style.border = '0px solid #19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).color = '#19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).innerText = '[' + sublist[2] + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+i).src = '../../system/icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 4://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+i).style.border = '0px solid #19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).color = '#19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).innerText = '[' + sublist[2] + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+i).src = '../../system/c_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 5://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+i).style.border = '0px solid #19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).color = '#19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+i).innerText = '[' + sublist[2] + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+i).src = '../../system/o_icon/' + sublist[0].substring(0,6) + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                }\n");
					fprintf(cgiOut, "              }\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "          case 3006:\n");
					fprintf(cgiOut, "              var list = pId.split(',');\n");
					fprintf(cgiOut, "              for(var i=0; i<list.length && list[i].length>0; i++)\n");
					fprintf(cgiOut, "              {\n");
					fprintf(cgiOut, "                document.getElementById('dev_'+i).style.border = '0px solid red';\n");
					//fprintf(cgiOut, "                document.getElementById('font_'+i).color = 'red';\n");
					//fprintf(cgiOut, "                document.getElementById('font_'+i).innerText = '[δ֪]';\n");
					fprintf(cgiOut, "              }\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "          default:\n");
					fprintf(cgiOut, "              var list = pId.split(',');\n");
					fprintf(cgiOut, "              for(var i=0; i<list.length && list[i].length>0; i++)\n");
					fprintf(cgiOut, "              {\n");
					fprintf(cgiOut, "                document.getElementById('dev_'+i).style.border = '0px solid red';\n");
					//fprintf(cgiOut, "                document.getElementById('font_'+i).color = 'red';\n");
					//fprintf(cgiOut, "                document.getElementById('font_'+i).innerText = '[δ֪]';\n");
					fprintf(cgiOut, "              }\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "        }\n");
					fprintf(cgiOut, "      break;\n");
					fprintf(cgiOut, "    case 3:\n");
					fprintf(cgiOut, "        switch(parseInt(resp.substring(0,4)))\n");
					fprintf(cgiOut, "        {\n");
					fprintf(cgiOut, "          case 0:\n");
					fprintf(cgiOut, "              if(resp.len() >= 71)\n");
					fprintf(cgiOut, "              {\n");
					fprintf(cgiOut, "              	 var Show = '';\n");
					fprintf(cgiOut, "                var DId  = resp.substring(4, 10);\n");
					fprintf(cgiOut, "                var statcolo = resp.substring(14, 15);\n");
					fprintf(cgiOut, "                var statshow = subString(resp, 71).substring(15);\n");
					fprintf(cgiOut, "                switch(parseInt(statcolo))\n");
					fprintf(cgiOut, "                {\n");
					fprintf(cgiOut, "                  case 0://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+pIndex).style.border = '0px solid black';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).color = 'black';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).innerText = '[' + statshow.Trim() + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+pIndex).src = '../../system/b_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 1://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+pIndex).style.border = '0px solid gray';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).color = 'gray';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).innerText = '[' + statshow.Trim() + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+pIndex).src = '../../system/g_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 2://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+pIndex).style.border = '0px solid red';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).color = 'red';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).innerText = '[' + statshow.Trim() + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+pIndex).src = '../../system/r_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 3://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+pIndex).style.border = '0px solid #19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).color = '#19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).innerText = '[' + statshow.Trim() + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+pIndex).src = '../../system/icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 4://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+pIndex).style.border = '0px solid #19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).color = '#19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).innerText = '[' + statshow.Trim() + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+pIndex).src = '../../system/c_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                  case 5://��\n");
					fprintf(cgiOut, "                      document.getElementById('dev_'+pIndex).style.border = '0px solid #19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).color = '#19b31d';\n");
					//fprintf(cgiOut, "                      document.getElementById('font_'+pIndex).innerText = '[' + statshow.Trim() + ']';\n");
					fprintf(cgiOut, "                      document.getElementById('img_'+pIndex).src = '../../system/o_icon/' + DId + '.gif';\n");
					fprintf(cgiOut, "                    break;\n");
					fprintf(cgiOut, "                }\n");
					fprintf(cgiOut, "              }\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "          case 3006:\n");
					fprintf(cgiOut, "              document.getElementById('dev_'+pIndex).style.border = '0px solid red';\n");
					//fprintf(cgiOut, "              document.getElementById('font_'+pIndex).color = 'red';\n");
					//fprintf(cgiOut, "              document.getElementById('font_'+pIndex).innerText = '[δ֪]';\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "          default:\n");
					fprintf(cgiOut, "              document.getElementById('dev_'+pIndex).style.border = '0px solid red';\n");
					//fprintf(cgiOut, "              document.getElementById('font_'+pIndex).color = 'red';\n");
					//fprintf(cgiOut, "              document.getElementById('font_'+pIndex).innerText = '[δ֪]';\n");
					fprintf(cgiOut, "            break;\n");
					fprintf(cgiOut, "        }\n");
					fprintf(cgiOut, "      break;\n");
					fprintf(cgiOut, "  }\n");
					fprintf(cgiOut, "}\n");
					fprintf(cgiOut, "else\n");
					fprintf(cgiOut, "{\n");
					fprintf(cgiOut, "  switch(parseInt(pType))\n");
					fprintf(cgiOut, "  {\n");
					fprintf(cgiOut, "    case 2:\n");
					fprintf(cgiOut, "        var list = pId.split(',');\n");
					fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
					fprintf(cgiOut, "        {\n");
					fprintf(cgiOut, "          document.getElementById('dev_'+i).style.border = '0px solid red';\n");
					//fprintf(cgiOut, "          document.getElementById('font_'+i).color = 'red';\n");
					//fprintf(cgiOut, "          document.getElementById('font_'+i).innerText = '[δ֪]';\n");
					fprintf(cgiOut, "        }\n");
					fprintf(cgiOut, "      break;\n");
					fprintf(cgiOut, "    case 3:\n");
					fprintf(cgiOut, "        document.getElementById('dev_'+pIndex).style.border = '0px solid red';\n");
					//fprintf(cgiOut, "        document.getElementById('font_'+pIndex).color = 'red';\n");
					//fprintf(cgiOut, "        document.getElementById('font_'+pIndex).innerText = '[δ֪]';\n");
					fprintf(cgiOut, "      break;\n");
					fprintf(cgiOut, "  }\n");
					fprintf(cgiOut, "}\n");
					break;
				}
		}
		fprintf(cgiOut, "    }\n");
		fprintf(cgiOut, "  };\n");
		fprintf(cgiOut, "  var url = 'netToPo.cgi?cmd=6&id='+pId+'&cmd_type='+pType+'&user_id=%s&currtime='+new Date();\n", user_id);
		fprintf(cgiOut, "  reqSta.open('GET',url,false);\n");
		fprintf(cgiOut, "  reqSta.send(null);\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "if(IdAll.length > 0)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  setTimeout(\"RealStatus('\"+IdAll+\"', '', '2');\",  500);\n");
		fprintf(cgiOut, "  setInterval(\"RealStatus('\"+IdAll+\"', '', '2');\", %d);\n", staudp);
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "</SCRIPT>\n");
		fprintf(cgiOut, "</html>\n");
	}
	else
	{
		fprintf(cgiOut, "���Ȱ���Ԫ������ɫ!\n");
	}
}

int sqlite3_exec_callback_point_all(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "add('%s', '%s$%s$%s$%s$%s$%s$%s$%s');\n", col_values[0], col_values[0], col_values[1], col_values[2], col_values[3], col_values[4], col_values[5], col_values[6], col_values[7]);
	return 0;
}

int sqlite3_exec_callback_marke_point(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != col_values[2] && strlen(col_values[2]) > 10)
	{
		char *p;
		char *buffer = strdup(col_values[2]);
		p = strtok(buffer, ",");
		while(NULL != p)
		{
			if(strlen(p) == 10)
			{
				fprintf(cgiOut, "if(exit('%s'))\n", p);
				fprintf(cgiOut, "{\n");
				fprintf(cgiOut, "  var Strhash = hashTable['%s'];\n", p);
				fprintf(cgiOut, "  var list = Strhash.split('$');\n");
				fprintf(cgiOut, "  IdAll += list[0] + ',';\n");
				fprintf(cgiOut, "  var objHtml = '';\n");
				fprintf(cgiOut, "  objHtml += \"<div id='div_\"+CTAll+\"' style='position:absolute;left:\"+list[5]+\"px;top:\"+list[6]+\"px;width:60px;height:50px;text-align:right;'>\";\n");
				fprintf(cgiOut, "  objHtml += \"  <div id='dev_\"+CTAll+\"' style='border:0px solid #19b31d;text-align:center;margin-top:21px;' onmousedown=doDefence('\"+list[0]+\"','\"+list[3]+\"','\"+list[1]+\"','../../system/\"+list[2]+\"','%s','\"+CTAll+\"','\"+list[4]+\"','\"+list[7]+\"')><img id='img_\"+CTAll+\"' style='width:32px;height:32px;cursor:hand;' src='../../system/\"+list[2]+\"'><br><font id='font_\"+CTAll+\"' size=2 color='black'>[\"+list[1]+\"]</font></div>\";\n", col_values[0]);
				fprintf(cgiOut, "  objHtml += \"</div>\";\n");
				fprintf(cgiOut, "  document.getElementById('mapdiv').innerHTML += objHtml;\n");
				fprintf(cgiOut, "  CTAll++;\n");
				fprintf(cgiOut, "}\n");
			}
			p = strtok(NULL, ",");
		}
	}
	return 0;
}

int sqlite3_exec_callback_marke_area(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "var objHtml = '';\n");
	fprintf(cgiOut, "objHtml += \"<div id='div_\"+CTAll+\"' style='position:absolute;left:%spx;top:%spx;width:60px;height:50px;text-align:right;'>\";\n", col_values[2], col_values[3]);
	fprintf(cgiOut, "objHtml += \"  <div id='dev_\"+CTAll+\"' style='border:0px solid #19b31d;text-align:center;margin-top:21px;' onmousedown=doArea('%s')><img id='img_\"+CTAll+\"' style='width:32px;height:32px;cursor:hand;' src='../../skin/images/scene.png'><br><font id='font_\"+CTAll+\"' size=2 color='black'>[%s]</font></div>\";\n", col_values[0], col_values[1]);
	fprintf(cgiOut, "objHtml += \"</div>\";\n");
	fprintf(cgiOut, "document.getElementById('mapdiv').innerHTML += objHtml;\n");
	fprintf(cgiOut, "CTAll++;\n");
	return 0;
}

int sqlite3_exec_callback_point(void *data, int n_columns, char **col_values, char **col_names)
{
	//��ѯ�豸
	char sql[4096*8] = {0};
	sprintf(sql, "select a.id, a.brief, b.icon, a.status, a.memo, a.pos_x, a.pos_y, b.dev_type from device_detail a, device_info b where substr(a.id, 1, 6) = b.id and a.sign = '1' and contain('%s', a.id) = 1 order by a.id", col_values[2]);
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_marke, col_values[0], &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(3);
	}
	sqlite3_close(db);
	return 0;
}

int sqlite3_exec_callback_marke(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "IdAll += '%s' + ',';\n", col_values[0]);
	fprintf(cgiOut, "var objHtml = '';\n");
	fprintf(cgiOut, "objHtml += \"<div id='div_%d' style='position:absolute;left:%spx;top:%spx;width:60px;height:50px;text-align:right;'>\";\n", cnt, col_values[5], col_values[6]);
	fprintf(cgiOut, "objHtml += \"  <div id='dev_%d' style='border:0px solid #19b31d;text-align:center;margin-top:21px;' onmousedown=doDefence('%s','%s','%s','../../system/%s','%s','%d','%s','%s')><img id='img_%d' style='width:32px;height:32px;cursor:hand;' src='../../system/%s'><br><font id='font_%d' size=2 color='black'>[%s]</font></div>\";\n", cnt, col_values[0], col_values[3], col_values[1], col_values[2], (char *)data, cnt, col_values[4], col_values[7], cnt, col_values[2], cnt, col_values[1]);
	fprintf(cgiOut, "objHtml += \"</div>\";\n");
	fprintf(cgiOut, "document.getElementById('mapdiv').innerHTML += objHtml;\n");
	cnt++;
	return 0;
}

int sqlite3_exec_callback_nettree(void *data, int n_columns, char **col_values, char **col_names)
{
	switch(atoi(level))
	{
		case 0:
			break;
		case 1:
				switch(strlen(col_values[0]))
				{
					case 6:
							fprintf(cgiOut, "createNode('%s', '%s', '../../skin/images/area.png', '', '0', '', '', '', '', 0, 10, '');\n", col_values[0], col_values[1]);
						break;
					case 8:
						  fprintf(cgiOut, "cn++;\n");
							fprintf(cgiOut, "cnt += parseInt((cntAll-1)/8) + 1;\n");
							fprintf(cgiOut, "cntAll = 0;\n");
							fprintf(cgiOut, "if(cnt == 1)\n");
							fprintf(cgiOut, "{\n");
							fprintf(cgiOut, "  createNode('%s', '%s', '../../skin/images/subarea.png', '', '1', '', '', '', '', 80, 10, '');\n", col_values[0], col_values[1]);
							fprintf(cgiOut, "}\n");
							fprintf(cgiOut, "else\n");
							fprintf(cgiOut, "{\n");
							fprintf(cgiOut, "  createNode('%s', '%s', '../../skin/images/subarea.png', '', '1', '', '', '', '', 80, 10+(cn-1)*45+(cnt-1+parseInt((cntAll-1)/8))*90, '');\n", col_values[0], col_values[1]);
							fprintf(cgiOut, "}\n");							
							if(NULL != col_values[2] && strlen(col_values[2]) > 0)
							{
								int rc;
								char * zErrMsg = 0;
								sqlite3 *db = open_db(DB_PATH);
								
								char* split_result = NULL;
						    char* savePtr = NULL;
						    split_result = strtok_r(col_values[2], ",", &savePtr);
						    while(NULL != split_result)
								{
									char sql[512] = {0};
									sprintf(sql, "select a.id, a.cname, a.upper, a.upper_channel, a.be_on, a.status, a.ctype, b.icon, b.s_icon, a.brief, a.memo, b.dev_type from device_detail a, device_info b where substr(a.id,1,6) = b.id and a.id = '%s' order by a.id", split_result);						
									rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_device, col_values[0], &zErrMsg);
									
									split_result = strtok_r(NULL, ",", &savePtr);
								}
								sqlite3_close(db);
							}
						break;
				}
			break;
		case 2:
				fprintf(cgiOut, "createNode('%s', '%s', '../../skin/images/subarea.png', '', '1', '', '', '', '', 20, 10, '');\n", col_values[0], col_values[1]);
				if(NULL != col_values[2] && strlen(col_values[2]) > 0)
				{
					int rc;
					char * zErrMsg = 0;
					sqlite3 *db = open_db(DB_PATH);
					
					char* split_result = NULL;
			    char* savePtr = NULL;
			    split_result = strtok_r(col_values[2], ",", &savePtr);
			    while(NULL != split_result)
					{
						char sql[512] = {0};
						sprintf(sql, "select a.id, a.cname, a.upper, a.upper_channel, a.be_on, a.status, a.ctype, b.icon, b.s_icon, a.brief, a.memo, b.dev_type from device_detail a, device_info b where substr(a.id,1,6) = b.id and a.id = '%s' order by a.id", split_result);						
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_device, col_values[0], &zErrMsg);
						
						split_result = strtok_r(NULL, ",", &savePtr);
					}
					sqlite3_close(db);
				}
			break;
	}
	return 0;
}

int sqlite3_exec_callback_device(void *data, int n_columns, char **col_values, char **col_names)
{
	char statusname[60] = {0};
	fprintf(cgiOut, "cntAll++;\n");
	fprintf(cgiOut, "var Objleft = 140 + ((cntAll-1)%%8)*90;\n");
	fprintf(cgiOut, "var Objtop = 55 + parseInt((cntAll-1)/8)*90;\n");
	fprintf(cgiOut, "if(cnt == 1)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  Objleft = 200 + ((cntAll-1)%%8)*90;\n");
	fprintf(cgiOut, "  Objtop = 55+(cnt-1+parseInt((cntAll-1)/8))*90;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "if(cnt > 1)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  Objleft = 200 + ((cntAll-1)%%8)*90;\n");
	fprintf(cgiOut, "  Objtop = 55+(cnt-1+parseInt((cntAll-1)/8))*90+(cn-1)*45;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "createNode('%s', '%s', '../../system/%s', '%s', '2', '%s', '�������Զ�̿���', '%s', '%s', Objleft, Objtop, '%s');\n", col_values[0], col_values[9], col_values[7], col_values[5], statusname, (char *)data, col_values[10], col_values[11]);
	return 0;
}

//ϵͳ�澯
void Alert()
{
	memset(point, 0, sizeof(point));
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
	
	char sql[4096*8] = {0};
	sprintf(sql, "select a.point from role a, user_info b where length(a.id) = 8 and substr(a.id,1,4) = b.ykt_role and b.id = '%s'", user_id);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_alert_area, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(2);
	}
	
	if(NULL != point && strlen(point) > 0)
	{
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "select b.cname, a.ctime, a.value from alert_now a, device_detail b where a.id = b.id and a.ctime in (select max(c.ctime) from alert_now c where a.id = c.id and a.ctype = c.ctype and a.level = c.level group by c.id, c.ctype, c.level order by c.ctime desc) and contain('%s', a.id) = 1 and a.status = '0' group by a.id, a.ctype, a.level order by a.ctime desc", point);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_alert_info, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
		  err_msg(2);
		}
	}
	
	sqlite3_close(db);
	printf("%s\n", realalert);
}
	
int sqlite3_exec_callback_alert_area(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != col_values[0] && strlen(col_values[0]) > 0)
	{
	  strcat(point, col_values[0]);
	}
	return 0;
}

int sqlite3_exec_callback_alert_info(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat(realalert, "<font color=red>{");
	strcat(realalert, col_values[0]);
	strcat(realalert, "  ");
	strcat(realalert, col_values[1]);
	strcat(realalert, "  ");
	strcat(realalert, col_values[2]);
	strcat(realalert, "}</font>  ");
	return 0;
}

//Ԫ��״̬
void RealStatus()
{
	char resp[4096] = {0};
	int ret = MsgSend(atoi(cmd_type));
	switch(atoi(cmd_type))
	{
		case 2://�豸״̬��ѯ(2020)
				switch(ret)
				{
					case 0:
							strcat(resp, "3006");
						break;
					case 1:
							strcat(resp, "3006");
						break;
					case 2:
							strcat(resp, "0000");
							strcat(resp, realstat);
						break;
				}
			break;
		case 3://����ִ�����״̬��ѯ(2001)
				switch(ret)
				{
					case 0:
							strcat(resp, "3006");
						break;
					case 1:
							strcat(resp, "3006");
						break;
					case 2:
							strcat(resp, "0000");
							strcat(resp, realsing);						
						break;
				}
			break;
	}
	//��ѯ����	
	printf("%s\n", resp);
}

//����ģʽ
void RealModeSel()
{
	char resp[4096] = {0};
	int ret = MsgSend(4);
	switch(ret)
	{
		case 0:
				strcat(resp, "3006");
			break;
		case 1:
				strcat(resp, "3006");
			break;
		case 2:
				strcat(resp, "0000");
				strcat(resp, realmode);
			break;
	}
	//��ѯ����	
	printf("%s\n", resp);
}

//���ݸ���
void RealDataSel()
{
	char resp[4096] = {0};
	int ret = MsgSend(3);
	switch(ret)
	{
		case 0:
				strcat(resp, "3006");
			break;
		case 1:
				strcat(resp, "3006");
			break;
		case 2:
				strcat(resp, "0000");
				strcat(resp, realsing);
			break;
	}
	//��ѯ����	
	printf("%s\n", resp);
}

void CtrlHtml()
{
	//�ز�memo��dev_type��status
	int rc;
	char * zErrMsg;	
	char sql[1024] = {0};
	sprintf(sql, "select a.memo, a.status, b.dev_type from device_detail a, device_info b where substr(a.id,1,6) = b.id and a.id = '%s'", id);
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_sel, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
	fprintf(cgiOut, "<html xmlns='http://www.w3.org/1999/xhtml'>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<TITLE>Զ�̿���</TITLE>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content='text/html; charset=gb2312'>\n");
	switch(atoi(dev_type))
	{
		default://Ĭ��
		case 0://�����
		case 4://������
				fprintf(cgiOut, "<link type='text/css' href='../../skin/css/div04.css' rel='stylesheet'/>\n");
				break;
		case 1://��ֵ��
				fprintf(cgiOut, "<link type='text/css' href='../../skin/css/div01.css' rel='stylesheet'/>\n");
				break;
		case 2://��ֵ��
				fprintf(cgiOut, "<link type='text/css' href='../../skin/css/div02.css' rel='stylesheet'/>\n");		
				break;
		case 3://��ֵ��
				fprintf(cgiOut, "<link type='text/css' href='../../skin/css/div03.css' rel='stylesheet'/>\n");			
				break;
		case 5://������
				fprintf(cgiOut, "<link type='text/css' href='../../skin/css/div05.css' rel='stylesheet'/>\n");
				break;
	}
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<style>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #3491D6;\n");
	fprintf(cgiOut, "  border: 1px solid blue;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 200px;\n");
	fprintf(cgiOut, "  height:100px;\n");
	fprintf(cgiOut, "  left:25%%;\n");
	fprintf(cgiOut, "  top: 20%%;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n");
	
	//�������
	fprintf(cgiOut, "<script>\n");
	fprintf(cgiOut, "var arrayObj_00 = new Array();\n");
	fprintf(cgiOut, "var arrayObj_07 = new Array();\n");
	fprintf(cgiOut, "var arrayObj_08 = new Array();\n");
	fprintf(cgiOut, "var arrayObj_09 = new Array();\n");
	fprintf(cgiOut, "var arrayObj_10 = new Array();\n");
	fprintf(cgiOut, "var arrayObj_11 = new Array();\n");
	fprintf(cgiOut, "var showDes_00  = '';\n");
	fprintf(cgiOut, "var showDes_07  = '';\n");
	fprintf(cgiOut, "var showDes_08  = '';\n");
	fprintf(cgiOut, "var showDes_09  = '';\n");
	fprintf(cgiOut, "var showDes_10  = '';\n");
	fprintf(cgiOut, "var showDes_11  = '';\n");
	fprintf(cgiOut, "</script>\n");
	
	//����ṹ
	switch(atoi(dev_type))
	{
		default://Ĭ��
		case 0://�����
		case 4://������
			{
				fprintf(cgiOut, "<body>\n");
				fprintf(cgiOut, "  <div class='max auto'>\n");
				fprintf(cgiOut, "    <div class='top auto'>\n");
				fprintf(cgiOut, "      <p class='buchef'><a href='#'><img src='../../skin/images/div04/nobcf.png' id='bcf'/></a></p>\n");
				fprintf(cgiOut, "      <p class='logobz'><a href='#'><img src='../../skin/images/div04/biaozhi.png'/></a></p>\n");
				fprintf(cgiOut, "      <p class='switch'><a href='#'><img src='../../skin/images/div04/swtich.png' onClick='doClose()'/></a></p>\n");
				fprintf(cgiOut, "      <div class='showArea auto'>\n");
				fprintf(cgiOut, "        <div class='time'>\n");
				fprintf(cgiOut, "          <B>%s</B>\n", cname);
				fprintf(cgiOut, "        </div>\n");
				fprintf(cgiOut, "        <div class='showTxt' id='RealMode'></div>\n");
				fprintf(cgiOut, "      </div>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='showBg auto'></div>\n");
				fprintf(cgiOut, "    <div class='foot'>\n");
				fprintf(cgiOut, "      <p id='actret'><B>%s</B></p>\n", memo);
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "  </div>\n");
				fprintf(cgiOut, "  <div id='objDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
				fprintf(cgiOut, "</body>\n");
				
				int rc;
				char * zErrMsg;	
				char sql[1024] = {0};
				sprintf(sql, "select a.sn, a.id, c.cmdname, a.object, c.status, a.flag, a.flag1, b.area, a.icon, b.showdes from device_cmd a, act_limit b, device_act c where a.id = substr(c.id,1,6) and a.sn = c.sn and b.dev_id = c.id and b.dev_cmd = c.sn and b.role_id = '%s' and b.dev_id = '%s' and substr(b.dev_id,1,6) = a.id and b.dev_cmd = a.sn and a.cmd_type = '0' order by a.sn", roleid, id);
				sqlite3 *db = open_db(DB_PATH);
				rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cmd, 0, &zErrMsg);
				if(rc != SQLITE_OK)
				{
				  err_msg(1);
				}
				sqlite3_close(db);
				
				break;
			}
		case 1://��ֵ��
			{
				fprintf(cgiOut, "<body>\n");
				fprintf(cgiOut, "  <div class='max auto'>\n");
				fprintf(cgiOut, "    <div class='top auto'>\n");
				fprintf(cgiOut, "      <p class='buchef'><a href='#'><img src='../../skin/images/div01/nobcf.png' id='bcf'/></a></p>\n");
				fprintf(cgiOut, "      <p class='logobz'><a href='#'><img src='../../skin/images/div01/biaozhi.png'/></a></p>\n");
				fprintf(cgiOut, "      <p class='switch'><a href='#'><img src='../../skin/images/div01/swtich.png' onClick='doClose()'/></a></p>\n");
				fprintf(cgiOut, "      <div class='showArea auto'>\n");
				fprintf(cgiOut, "        <div class='time'>\n");
				fprintf(cgiOut, "          <B>%s</B>\n", cname);
				fprintf(cgiOut, "        </div>\n");
				fprintf(cgiOut, "        <div class='showTxt' id='RealMode'></div>\n");
				fprintf(cgiOut, "      </div>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='btnArea auto'>\n");
				fprintf(cgiOut, "      <input id='btn_m' type='image' src='../../skin/images/div01/btn.png' class='btn1'/>\n");
				fprintf(cgiOut, "      <p id='p_btn_m' class='p1'></p>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='showBg auto'></div>\n");
				fprintf(cgiOut, "    <div class='foot'>\n");
				fprintf(cgiOut, "      <p id='actret'><B>%s</B></p>\n", memo);
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "  </div>\n");
				fprintf(cgiOut, "  <div id='objDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
				fprintf(cgiOut, "</body>\n");
				
				int rc;
				char * zErrMsg;	
				char sql[1024] = {0};
				sprintf(sql, "select a.sn, a.id, c.cmdname, a.object, c.status, a.flag, a.flag1, b.area, a.icon, b.showdes from device_cmd a, act_limit b, device_act c where a.id = substr(c.id,1,6) and a.sn = c.sn and b.dev_id = c.id and b.dev_cmd = c.sn and b.role_id = '%s' and b.dev_id = '%s' and substr(b.dev_id,1,6) = a.id and b.dev_cmd = a.sn and a.cmd_type = '0' order by a.sn", roleid, id);
				sqlite3 *db = open_db(DB_PATH);
				rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cmd, 0, &zErrMsg);
				if(rc != SQLITE_OK)
				{
				  err_msg(1);
				}
				sqlite3_close(db);
				
				break;
			}
		case 2://��ֵ��
			{
				fprintf(cgiOut, "<body>\n");
				fprintf(cgiOut, "  <div class='max auto'>\n");
				fprintf(cgiOut, "    <div class='top auto'>\n");
				fprintf(cgiOut, "      <p class='buchef'><a href='#'><img src='../../skin/images/div02/nobcf.png' id='bcf'/></a></p>\n");
				fprintf(cgiOut, "      <p class='logobz'><a href='#'><img src='../../skin/images/div02/biaozhi.png'/></a></p>\n");
				fprintf(cgiOut, "      <p class='switch'><a href='#'><img src='../../skin/images/div02/swtich.png' onClick='doClose()'/></a></p>\n");
				fprintf(cgiOut, "      <div class='showArea auto'>\n");
				fprintf(cgiOut, "        <div class='time'>\n");
				fprintf(cgiOut, "          <B>%s</B>\n", cname);
				fprintf(cgiOut, "        </div>\n");
				fprintf(cgiOut, "        <div class='showTxt' id='RealMode'></div>\n");
				fprintf(cgiOut, "      </div>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='btnArea auto'>\n");
				fprintf(cgiOut, "      <input id='btn_u' type='image' src='../../skin/images/div02/btn.png' class='btn1'/>\n");
				fprintf(cgiOut, "      <input id='btn_d' type='image' src='../../skin/images/div02/btn.png' class='btn2'/>\n");
				fprintf(cgiOut, "      <p id='p_btn_u' class='p1'></p>\n");
				fprintf(cgiOut, "      <p id='p_btn_d' class='p2'></p>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='showBg auto'></div>\n");
				fprintf(cgiOut, "    <div class='foot'>\n");
				fprintf(cgiOut, "      <p id='actret'><B>%s</B></p>\n", memo);
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "  </div>\n");
				fprintf(cgiOut, "  <div id='objDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
				fprintf(cgiOut, "</body>\n");
				
				int rc;
				char * zErrMsg;	
				char sql[1024] = {0};
				sprintf(sql, "select a.sn, a.id, c.cmdname, a.object, c.status, a.flag, a.flag1, b.area, a.icon, b.showdes from device_cmd a, act_limit b, device_act c where a.id = substr(c.id,1,6) and a.sn = c.sn and b.dev_id = c.id and b.dev_cmd = c.sn and b.role_id = '%s' and b.dev_id = '%s' and substr(b.dev_id,1,6) = a.id and b.dev_cmd = a.sn and a.cmd_type = '0' order by a.sn", roleid, id);
				sqlite3 *db = open_db(DB_PATH);
				rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cmd, 0, &zErrMsg);
				if(rc != SQLITE_OK)
				{
				  err_msg(1);
				}
				sqlite3_close(db);
				
				break;
			}
		case 3://��ֵ��
			{
				fprintf(cgiOut, "<body>\n");
				fprintf(cgiOut, "  <div class='max auto'>\n");
				fprintf(cgiOut, "    <div class='top auto'>\n");
				fprintf(cgiOut, "      <p class='buchef'><a href='#'><img src='../../skin/images/div03/nobcf.png' id='bcf'/></a></p>\n");
				fprintf(cgiOut, "      <p class='logobz'><a href='#'><img src='../../skin/images/div03/biaozhi.png'/></a></p>\n");
				fprintf(cgiOut, "      <p class='switch'><a href='#'><img src='../../skin/images/div03/swtich.png' onClick='doClose()'/></a></p>\n");
				fprintf(cgiOut, "      <div class='showArea auto'>\n");
				fprintf(cgiOut, "        <div class='time'>\n");
				fprintf(cgiOut, "          <B>%s</B>\n", cname);
				fprintf(cgiOut, "        </div>\n");
				fprintf(cgiOut, "        <div class='showTxt' id='RealMode'></div>\n");
				fprintf(cgiOut, "      </div>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='btnArea auto'>\n");
				fprintf(cgiOut, "      <input id='btn_u' type='image' src='../../skin/images/div03/btn.png' class='btn1'/>\n");
				fprintf(cgiOut, "      <input id='btn_l' type='image' src='../../skin/images/div03/btn.png' class='btn2'/>\n");
				fprintf(cgiOut, "      <input id='btn_r' type='image' src='../../skin/images/div03/btn.png' class='btn3'/>\n");
				fprintf(cgiOut, "      <p id='p_btn_u' class='p1'></p>\n");
				fprintf(cgiOut, "      <p id='p_btn_l' class='p2'></p>\n");
				fprintf(cgiOut, "      <p id='p_btn_r' class='p3'></p>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='showBg auto'></div>\n");
				fprintf(cgiOut, "    <div class='foot'>\n");
				fprintf(cgiOut, "      <p id='actret'><B>%s</B></p>\n", memo);
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "  </div>\n");
				fprintf(cgiOut, "  <div id='objDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
				fprintf(cgiOut, "</body>\n");
				
				int rc;
				char * zErrMsg;	
				char sql[1024] = {0};
				sprintf(sql, "select a.sn, a.id, c.cmdname, a.object, c.status, a.flag, a.flag1, b.area, a.icon, b.showdes from device_cmd a, act_limit b, device_act c where a.id = substr(c.id,1,6) and a.sn = c.sn and b.dev_id = c.id and b.dev_cmd = c.sn and b.role_id = '%s' and b.dev_id = '%s' and substr(b.dev_id,1,6) = a.id and b.dev_cmd = a.sn and a.cmd_type = '0' order by a.sn", roleid, id);
				sqlite3 *db = open_db(DB_PATH);
				rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cmd, 0, &zErrMsg);
				if(rc != SQLITE_OK)
				{
				  err_msg(1);
				}
				sqlite3_close(db);
				
				break;
			}
		case 5://������
			{
				fprintf(cgiOut, "<body>\n");
				fprintf(cgiOut, "  <div class='max auto'>\n");
				fprintf(cgiOut, "    <div class='top auto'>\n");
				fprintf(cgiOut, "      <p class='buchef'><a href='#'><img src='../../skin/images/div05/nobcf.png' id='bcf'/></a></p>\n");
				fprintf(cgiOut, "      <p class='logobz'><a href='#'><img src='../../skin/images/div05/biaozhi.png'/></a></p>\n");
				fprintf(cgiOut, "      <p class='switch'><a href='#'><img src='../../skin/images/div05/swtich.png' onClick='doClose()'/></a></p>\n");
				fprintf(cgiOut, "      <div class='showArea auto'>\n");
				fprintf(cgiOut, "        <div class='time'>\n");
				fprintf(cgiOut, "          <B>%s</B>\n", cname);
				fprintf(cgiOut, "        </div>\n");
				fprintf(cgiOut, "        <div class='showTxt' id='RealMode'></div>\n");
				fprintf(cgiOut, "      </div>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='btnArea auto'>\n");
				fprintf(cgiOut, "      <input id='btn_u' type='image' src='../../skin/images/div05/btn1.png' class='btn1'/>\n");
				fprintf(cgiOut, "      <input id='btn_d' type='image' src='../../skin/images/div05/btn2.png' class='btn2'/>\n");
				fprintf(cgiOut, "      <input id='btn_l' type='image' src='../../skin/images/div05/btn3.png' class='btn3'/>\n");
				fprintf(cgiOut, "      <input id='btn_r' type='image' src='../../skin/images/div05/btn4.png' class='btn4'/>\n");
				fprintf(cgiOut, "      <input id='btn_m' type='image' src='../../skin/images/div05/btn5.png' class='btn5'/>\n");
				fprintf(cgiOut, "      <p id='p_btn_u' class='p1'></p>\n");
				fprintf(cgiOut, "      <p id='p_btn_d' class='p2'></p>\n");
				fprintf(cgiOut, "      <p id='p_btn_l' class='p3'></p>\n");
				fprintf(cgiOut, "      <p id='p_btn_r' class='p4'></p>\n");
				fprintf(cgiOut, "      <p id='p_btn_m' class='p5'></p>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='numBtnArea auto'>\n");
				fprintf(cgiOut, "      <table width='100%%'>\n");
				fprintf(cgiOut, "        <tr height='30px'>\n");
				
				int rc;
				char * zErrMsg;
				char sql[1024] = {0};
				sprintf(sql, "select a.sn, a.id, c.cmdname, a.object, c.status, a.flag, a.flag1, b.area, a.icon, b.showdes from device_cmd a, act_limit b, device_act c where a.id = substr(c.id,1,6) and a.sn = c.sn and b.dev_id = c.id and b.dev_cmd = c.sn and b.role_id = '%s' and b.dev_id = '%s' and substr(b.dev_id,1,6) = a.id and b.dev_cmd = a.sn and a.cmd_type = '0' order by a.sn", roleid, id);
				sqlite3 *db = open_db(DB_PATH);
				rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cmd, 0, &zErrMsg);
				if(rc != SQLITE_OK)
				{
				  err_msg(1);
				}
				sqlite3_close(db);
				
				int index = btn_12_cnt%3;
				switch(index)
				{
					case 0:
						break;
					case 1:
						fprintf(cgiOut, "      <td width='33%%' align=center>&nbsp;</td>\n");
						fprintf(cgiOut, "		   <td width='33%%' align=center>&nbsp;</td>\n");
						break;
					case 2:
						fprintf(cgiOut, "      <td width='33%%' align=center>&nbsp;</td>\n");
						break;
				}
				fprintf(cgiOut, "        </tr>\n");
				fprintf(cgiOut, "      </table>\n");
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "    <div class='foot'>\n");
				fprintf(cgiOut, "      <p id='actret'><B>%s</B></p>\n", memo);
				fprintf(cgiOut, "    </div>\n");
				fprintf(cgiOut, "  </div>\n");
				fprintf(cgiOut, "  <div id='objDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
				fprintf(cgiOut, "</body>\n");
				break;
			}
	}
	
	fprintf(cgiOut, "<script language='javascript'>\n");
	//����
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.hidePopWin(false);\n");
	fprintf(cgiOut, "}\n");
	
	//������ʾ��
	fprintf(cgiOut, "var TimeOutShow;\n");
	fprintf(cgiOut, "function doShowMemo()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('actret').innerHTML = '<B>%s</B>';\n", memo);
	fprintf(cgiOut, "}\n");
	
	//������ʾ
	fprintf(cgiOut, "var isShow = true;\n");
	fprintf(cgiOut, "function doShowDes(pData)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(!isShow)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(showDes_07.length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var list = showDes_07.split('~');\n");
	fprintf(cgiOut, "    for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var sublist = list[i].split('^');\n");
	fprintf(cgiOut, "      var subdata = pData.split('}');\n");
	fprintf(cgiOut, "      for(var j=0; j<subdata.length && subdata[j].length>0; j++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var subattr = subdata[j].split(',');\n");
	fprintf(cgiOut, "        if(sublist[1].substring(0,14) == subattr[0].substring(1))\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Comp_FH = sublist[1].substring(14,15);\n");
	fprintf(cgiOut, "          var Comp_DT = sublist[1].substring(15);\n");
	fprintf(cgiOut, "          if(Comp_FH == '>')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] > Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_07.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_07.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_m').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_m').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_m').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '=')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] == Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_07.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_07.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_m').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_m').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_m').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '<')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] < Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_07.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_07.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_m').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_m').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_m').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(showDes_08.length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var list = showDes_08.split('~');\n");
	fprintf(cgiOut, "    for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var sublist = list[i].split('^');\n");
	fprintf(cgiOut, "      var subdata = pData.split('}');\n");
	fprintf(cgiOut, "      for(var j=0; j<subdata.length && subdata[j].length>0; j++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var subattr = subdata[j].split(',');\n");
	fprintf(cgiOut, "        if(sublist[1].substring(0,14) == subattr[0].substring(1))\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Comp_FH = sublist[1].substring(14,15);\n");
	fprintf(cgiOut, "          var Comp_DT = sublist[1].substring(15);\n");
	fprintf(cgiOut, "          if(Comp_FH == '>')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] > Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_08.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_08.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_u').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_u').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_u').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '=')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] == Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_08.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_08.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_u').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_u').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_u').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '<')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] < Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_08.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_08.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_u').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_u').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_u').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(showDes_09.length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var list = showDes_09.split('~');\n");
	fprintf(cgiOut, "    for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var sublist = list[i].split('^');\n");
	fprintf(cgiOut, "      var subdata = pData.split('}');\n");
	fprintf(cgiOut, "      for(var j=0; j<subdata.length && subdata[j].length>0; j++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var subattr = subdata[j].split(',');\n");
	fprintf(cgiOut, "        if(sublist[1].substring(0,14) == subattr[0].substring(1))\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Comp_FH = sublist[1].substring(14,15);\n");
	fprintf(cgiOut, "          var Comp_DT = sublist[1].substring(15);\n");
	fprintf(cgiOut, "          if(Comp_FH == '>')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] > Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_09.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_09.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_d').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_d').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_d').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '=')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] == Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_09.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_09.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_d').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_d').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_d').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '<')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] < Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_09.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_09.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_d').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_d').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_d').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(showDes_10.length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var list = showDes_10.split('~');\n");
	fprintf(cgiOut, "    for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var sublist = list[i].split('^');\n");
	fprintf(cgiOut, "      var subdata = pData.split('}');\n");
	fprintf(cgiOut, "      for(var j=0; j<subdata.length && subdata[j].length>0; j++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var subattr = subdata[j].split(',');\n");
	fprintf(cgiOut, "        if(sublist[1].substring(0,14) == subattr[0].substring(1))\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Comp_FH = sublist[1].substring(14,15);\n");
	fprintf(cgiOut, "          var Comp_DT = sublist[1].substring(15);\n");
	fprintf(cgiOut, "          if(Comp_FH == '>')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] > Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_10.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_10.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_l').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_l').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_l').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '=')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] == Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_10.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_10.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_l').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_l').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_l').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '<')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] < Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_10.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_10.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_l').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_l').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_l').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(showDes_11.length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var list = showDes_11.split('~');\n");
	fprintf(cgiOut, "    for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var sublist = list[i].split('^');\n");
	fprintf(cgiOut, "      var subdata = pData.split('}');\n");
	fprintf(cgiOut, "      for(var j=0; j<subdata.length && subdata[j].length>0; j++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var subattr = subdata[j].split(',');\n");
	fprintf(cgiOut, "        if(sublist[1].substring(0,14) == subattr[0].substring(1))\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var Comp_FH = sublist[1].substring(14,15);\n");
	fprintf(cgiOut, "          var Comp_DT = sublist[1].substring(15);\n");
	fprintf(cgiOut, "          if(Comp_FH == '>')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] > Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_11.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_11.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_r').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_r').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_r').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '=')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] == Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_11.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_11.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_r').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_r').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_r').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          if(Comp_FH == '<')\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if('NULL' != subattr[3] && subattr[3] < Comp_DT)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var index_0 = arrayObj_11.splice(parseInt(sublist[0], 10), 1);\n");
	fprintf(cgiOut, "              arrayObj_11.unshift(index_0[0]);\n");
	fprintf(cgiOut, "              var btnlist = index_0[0].split('$');\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_r').innerHTML = btnlist[3];\n");
	fprintf(cgiOut, "              document.getElementById('p_btn_r').onclick = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "              document.getElementById('btn_r').onclick   = Function(\"doSend('\"+btnlist[0]+\"','\"+btnlist[1]+\"','\"+btnlist[2]+\"','\"+btnlist[3]+\"','\"+btnlist[4]+\"','\"+btnlist[5]+\"','\"+btnlist[6]+\"','\"+btnlist[7]+\"')\");\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  isShow = false;\n");
	fprintf(cgiOut, "}\n");
	
	//ʵʱ����
	fprintf(cgiOut, "var reqData = null;\n");
	fprintf(cgiOut, "function RealDataSel(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqData = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqData = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqData.onreadystatechange = function()\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var state = reqData.readyState;\n");
	fprintf(cgiOut, "    if(state == 4)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var resp = reqData.responseText;\n");
	fprintf(cgiOut, "      if(null != resp && resp.Trim().length >=4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        switch(parseInt(resp.substring(0,4)))\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          case 0:\n");
	fprintf(cgiOut, "            var resp = resp.substring(4);\n");
	fprintf(cgiOut, "            var Real = '';\n");
	fprintf(cgiOut, "            var statshow = subString(resp, 67).substring(11);\n");
	fprintf(cgiOut, "            var datareal = resp.substring(resp.indexOf(statshow)+statshow.length);\n");
	fprintf(cgiOut, "            if(datareal.indexOf('}') >= 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "	             var list = datareal.split('}');\n");
	fprintf(cgiOut, "              doShowDes(datareal);\n");
	fprintf(cgiOut, "              Real += \"<table width='100%%' border=0>\";\n");
	fprintf(cgiOut, "              Real += \"  <tr height='16px'>\";\n");
	fprintf(cgiOut, "              for(var i=0; i<list.length && list[i].Trim().length>0; i++)\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if(0 == i%%2 && i > 0)\n");
	fprintf(cgiOut, "                {\n");
	fprintf(cgiOut, "                  Real += \"</tr>\";\n");
	fprintf(cgiOut, "                  Real += \"<tr height='16px'>\";\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "                switch(parseInt(sublist[4]))\n");
	fprintf(cgiOut, "                {\n");
	fprintf(cgiOut, "                  case 0://����\n");
	fprintf(cgiOut, "                    Real += \"<td width='25%%' align=right>\"+ sublist[1] +\"��</td>\";\n");
	fprintf(cgiOut, "                    Real += \"<td width='25%%' align=left >\"+ sublist[2] +\"</td>\";\n");
	fprintf(cgiOut, "                    break;\n");
	fprintf(cgiOut, "                  case 1://�쳣\n");
	fprintf(cgiOut, "                    Real += \"<td width='25%%' align=right><font color=red>\"+ sublist[1] +\"��</font></td>\";\n");
	fprintf(cgiOut, "                    Real += \"<td width='25%%' align=left ><font color=red>\"+ sublist[2] +\"</font></td>\";\n");
	fprintf(cgiOut, "                    break;\n");
	fprintf(cgiOut, "                  default://��\n");
	fprintf(cgiOut, "                    Real += \"<td width='25%%' align=right><font color=red>\"+ sublist[1] +\"��</font></td>\";\n");
	fprintf(cgiOut, "                    Real += \"<td width='25%%' align=left ><font color=red>\"+ sublist[2] +\"</font></td>\";\n");
	fprintf(cgiOut, "                    break;\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              var index = (list.length-1)%%2;\n");
	fprintf(cgiOut, "              switch(index)\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                case 0:\n");
	fprintf(cgiOut, "                  break;\n");
	fprintf(cgiOut, "                case 1:\n");
	fprintf(cgiOut, "                    Real += \"<td width='25%%' align=right>&nbsp;</td>\";\n");
	fprintf(cgiOut, "                    Real += \"<td width='25%%' align=left >&nbsp;</td>\";\n");
	fprintf(cgiOut, "                  break;\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              Real += \"  </tr>\";\n");
	fprintf(cgiOut, "              Real += \"</table>\";\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            document.getElementById('RealMode').innerHTML = Real;\n");
	fprintf(cgiOut, "          	 RealModeSel(pId);\n");
	fprintf(cgiOut, "          	 break;\n");
	fprintf(cgiOut, "          case 3006:\n");
	fprintf(cgiOut, "            document.getElementById('RealMode').innerHTML = '<font color=red>[��ѯʧ��!]</font>';\n");
	fprintf(cgiOut, "            break;\n");
	fprintf(cgiOut, "          default:\n");
	fprintf(cgiOut, "            document.getElementById('RealMode').innerHTML = '<font color=red>[��ѯʧ��!]</font>';\n");
	fprintf(cgiOut, "            break;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  };\n");
	fprintf(cgiOut, "  var url = 'netToPo.cgi?cmd=8&id='+pId+'&user_id=%s'+'&currtime='+new Date();\n", user_id);
	fprintf(cgiOut, "  reqData.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqData.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqData.send(null);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "RealDataSel('%s');\n", id);
	
	//ʵʱģʽ
	fprintf(cgiOut, "var reqMode = null;\n");
	fprintf(cgiOut, "function RealModeSel(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqMode = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqMode = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqMode.onreadystatechange = function()\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var state = reqMode.readyState;\n");
	fprintf(cgiOut, "    if(state == 4)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var resp = reqMode.responseText;\n");
	fprintf(cgiOut, "      if(null != resp && resp.Trim().length >=4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        switch(parseInt(resp.substring(0,4)))\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          case 0:\n");
	fprintf(cgiOut, "            var Mode = '';\n");
	fprintf(cgiOut, "            var modereal = resp.substring(4);\n");
	fprintf(cgiOut, "            if(modereal.indexOf('}') >= 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "	             var list = modereal.split('}');\n");
	fprintf(cgiOut, "              for(var i=0; i<list.length && list[i].Trim().length>0; i++)\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if(0 == i)\n");
	fprintf(cgiOut, "                {\n");
	fprintf(cgiOut, "                  var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "                  Mode += \"<table width='100%%' border=0>\";\n");
	fprintf(cgiOut, "                  Mode += \"  <tr height='16px'>\";\n");
	fprintf(cgiOut, "                  Mode += \"    <td width='25%%' align=right>ģʽ��</td>\";\n");
	fprintf(cgiOut, "                  Mode += \"    <td width='25%%' align=left >\"+ sublist[1] +\"</td>\";\n");
	fprintf(cgiOut, "                  Mode += \"    <td width='25%%' align=right>ģֵ��</td>\";\n");
	fprintf(cgiOut, "                  Mode += \"    <td width='25%%' align=left >\"+ sublist[2] +\"</td>\";\n");
	fprintf(cgiOut, "                  Mode += \"  </tr>\";\n");
	fprintf(cgiOut, "                  Mode += \"</table>\";\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            document.getElementById('RealMode').innerHTML = Mode + document.getElementById('RealMode').innerHTML;\n");
	fprintf(cgiOut, "          	 break;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  };\n");
	fprintf(cgiOut, "  var url = 'netToPo.cgi?cmd=7&id='+pId+'&user_id=%s'+'&currtime='+new Date();\n", user_id);
	fprintf(cgiOut, "  reqMode.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqMode.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqMode.send(null);\n");
	fprintf(cgiOut, "}\n");
	
	//doSend����
  fprintf(cgiOut, "var reqSend = null;\n");
  fprintf(cgiOut, "function doSend(pSN, pObject, pId, pCmdName, pStatus, pFlag, pFlag1, pCmdArea)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  closeDiv();\n");
  fprintf(cgiOut, "  if('0' == pStatus)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ǰ����δ��Ч������ִ��!');\n");
  fprintf(cgiOut, "    return;\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  if('0' == pObject && '0' == pFlag1)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    var object = ' ';\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      reqSend = new XMLHttpRequest();\n");
  fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      reqSend = new ActiveXObject('Microsoft.XMLHTTP');\n");
  fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqSend.onreadystatechange = function(){callbackSendName(pSN, pCmdName, pCmdArea)};\n");
	fprintf(cgiOut, "    var url = 'netToPo.cgi?cmd=2&id=%s&sn='+pSN+'&object='+object+'&isflag='+pFlag+'&user_id=%s';\n", id, user_id);
	fprintf(cgiOut, "    reqSend.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqSend.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqSend.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else\n");
  fprintf(cgiOut, "  {\n"); 
  fprintf(cgiOut, "    document.getElementById('objDiv').style.display = 'block';\n");
	fprintf(cgiOut, "    var url = 'netToPo.cgi?cmd=3&id=%s&sn='+pSN+'&cname=%s&icon=%s&roleid=%s&cmdname='+pCmdName+'&isobject='+pObject+'&checkindex=%s&isflag2='+pFlag1+'&cmdarea='+pCmdArea+'&user_id=%s';\n", id, cname, icon, roleid, id_index, user_id);
	fprintf(cgiOut, "    document.getElementById('objDiv').innerHTML = \"<iframe id='objFrame' name='objFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='no'></iframe>\";\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "function callbackSendName(pSN, pCmdName, pCmdArea)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqSend.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqSend.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('actret').innerHTML = '<font color=green><B>����:['+pCmdName+'], ���:[�ɹ�]</B></font>';\n");
	fprintf(cgiOut, "          clearTimeout(TimeOutShow);\n");
	fprintf(cgiOut, "          TimeOutShow = setTimeout(\"doShowMemo()\", 5000);\n");
	fprintf(cgiOut, "  				 setTimeout(\"parent.RealStatus('%s', '%s', '3');\", 200);\n", id, id_index);
	fprintf(cgiOut, "  				 setTimeout(\"RealDataSel('%s');\", 200);\n", id);
	fprintf(cgiOut, "          doTopCmd(pCmdArea);\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else if(resp.indexOf('3000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('actret').innerHTML = '<font color=green><B>����:['+pCmdName+'], ���:[�ύ�ɹ�]</B></font>';\n");
  fprintf(cgiOut, "          clearTimeout(TimeOutShow);\n");
	fprintf(cgiOut, "          TimeOutShow = setTimeout(\"doShowMemo()\", 5000);\n");
  fprintf(cgiOut, "  				 setTimeout(\"parent.RealStatus('%s', '%s', '3');\", 200);\n", id, id_index);
	fprintf(cgiOut, "  				 setTimeout(\"RealDataSel('%s');\", 200);\n", id);
	fprintf(cgiOut, "          doTopCmd(pCmdArea);\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('actret').innerHTML = '<font color=red><B>����:['+pCmdName+'], ���:[ʧ��,�����²���]</B></font>';\n");
	fprintf(cgiOut, "          clearTimeout(TimeOutShow);\n");
	fprintf(cgiOut, "          TimeOutShow = setTimeout(\"doShowMemo()\", 5000);\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	//doTopCmd����
	fprintf(cgiOut, "function doTopCmd(pCmdArea)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  switch(parseInt(pCmdArea, 10))\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    case 0:\n");
  fprintf(cgiOut, "        var index_0 = arrayObj_00.shift();\n");
  fprintf(cgiOut, "        arrayObj_00.push(index_0);\n");
  fprintf(cgiOut, "        index_0 = arrayObj_00[0];\n");
  fprintf(cgiOut, "        var list = index_0.split('$');\n");
  fprintf(cgiOut, "        if(list[0] == '00010001')\n");
  fprintf(cgiOut, "        {\n");
  fprintf(cgiOut, "          document.getElementById('bcf').src     = '../../skin/images/div01/bf.png';\n");
  fprintf(cgiOut, "          document.getElementById('bcf').title   = list[3];\n");
  fprintf(cgiOut, "          document.getElementById('bcf').onclick = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
  fprintf(cgiOut, "        }\n");
  fprintf(cgiOut, "        else if(list[0] == '00010002')\n");
  fprintf(cgiOut, "        {\n");
  fprintf(cgiOut, "          document.getElementById('bcf').src     = '../../skin/images/div01/cf.png';\n");
  fprintf(cgiOut, "          document.getElementById('bcf').title   = list[3];\n");
  fprintf(cgiOut, "          document.getElementById('bcf').onclick = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
  fprintf(cgiOut, "        }\n");
  fprintf(cgiOut, "      break;\n");
  fprintf(cgiOut, "    case 7:\n");
  fprintf(cgiOut, "        var index_0 = arrayObj_07.shift();\n");
  fprintf(cgiOut, "        arrayObj_07.push(index_0);\n");
  fprintf(cgiOut, "        index_0 = arrayObj_07[0];\n");
  fprintf(cgiOut, "        var list = index_0.split('$');\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_m').innerHTML = list[3];\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_m').onclick = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
	fprintf(cgiOut, "        document.getElementById('btn_m').onclick   = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");			
  fprintf(cgiOut, "      break;\n");
  fprintf(cgiOut, "    case 8:\n");
  fprintf(cgiOut, "        var index_0 = arrayObj_08.shift();\n");
  fprintf(cgiOut, "        arrayObj_08.push(index_0);\n");
  fprintf(cgiOut, "        index_0 = arrayObj_08[0];\n");
  fprintf(cgiOut, "        var list = index_0.split('$');\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_u').innerHTML = list[3];\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_u').onclick = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
	fprintf(cgiOut, "        document.getElementById('btn_u').onclick   = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
  fprintf(cgiOut, "      break;\n");
  fprintf(cgiOut, "    case 9:\n");
  fprintf(cgiOut, "        var index_0 = arrayObj_09.shift();\n");
  fprintf(cgiOut, "        arrayObj_09.push(index_0);\n");
  fprintf(cgiOut, "        index_0 = arrayObj_09[0];\n");
  fprintf(cgiOut, "        var list = index_0.split('$');\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_d').innerHTML = list[3];\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_d').onclick = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
	fprintf(cgiOut, "        document.getElementById('btn_d').onclick   = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
  fprintf(cgiOut, "      break;\n");
  fprintf(cgiOut, "    case 10:\n");
  fprintf(cgiOut, "        var index_0 = arrayObj_10.shift();\n");
  fprintf(cgiOut, "        arrayObj_10.push(index_0);\n");
  fprintf(cgiOut, "        index_0 = arrayObj_10[0];\n");
  fprintf(cgiOut, "        var list = index_0.split('$');\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_l').innerHTML = list[3];\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_l').onclick = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
	fprintf(cgiOut, "        document.getElementById('btn_l').onclick   = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
  fprintf(cgiOut, "      break;\n");
  fprintf(cgiOut, "    case 11:\n");
  fprintf(cgiOut, "        var index_0 = arrayObj_11.shift();\n");
  fprintf(cgiOut, "        arrayObj_11.push(index_0);\n");
  fprintf(cgiOut, "        index_0 = arrayObj_11[0];\n");
  fprintf(cgiOut, "        var list = index_0.split('$');\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_r').innerHTML = list[3];\n");
  fprintf(cgiOut, "        document.getElementById('p_btn_r').onclick = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
	fprintf(cgiOut, "        document.getElementById('btn_r').onclick   = Function(\"doSend('\"+list[0]+\"','\"+list[1]+\"','\"+list[2]+\"','\"+list[3]+\"','\"+list[4]+\"','\"+list[5]+\"','\"+list[6]+\"','\"+list[7]+\"')\");\n");
  fprintf(cgiOut, "      break;\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "}\n");
  
  //�ǳ����л�
  if(0 != strcmp(status, "0") && btn_00_cnt > 0)
  {
  	fprintf(cgiOut, "doTopCmd('00');\n");
  }
  
	//�رյ�����
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('objDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_sel(void *data, int n_columns, char **col_values, char **col_names)
{
	memset(memo,     0, sizeof(memo));
	memset(status,   0, sizeof(status));
	memset(dev_type, 0, sizeof(dev_type));
	
	strcat(memo,     col_values[0]);
	strcat(status,   col_values[1]);
	strcat(dev_type, col_values[2]);
	return 0;
}

int sqlite3_exec_callback_cmd(void *data, int n_columns, char **col_values, char **col_names)
{
	switch(atoi(col_values[7]))
	{
		case 0://������
			{
				if(0 == btn_00_cnt)
				{
					if(0 == strcmp(col_values[0], "00010001"))
					{//����
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('bcf').src     = '../../skin/images/div01/bf.png';\n");
						fprintf(cgiOut, "  document.getElementById('bcf').title   = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('bcf').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					else if(0 == strcmp(col_values[0], "00010002"))
					{//����
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('bcf').src     = '../../skin/images/div01/cf.png';\n");
						fprintf(cgiOut, "  document.getElementById('bcf').title   = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('bcf').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
				}
				fprintf(cgiOut, "<script>\n");
				fprintf(cgiOut, "  arrayObj_00.push('%s$%s$%s$%s$%s$%s$%s$%s');\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
				fprintf(cgiOut, "</script>\n");
				
				btn_00_cnt++;
				break;
			}
		case 1://��ֵ��
			{
				if(0 == strcmp(dev_type, "1"))
				{
					if(0 == btn_01_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_m').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_m').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_m').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					btn_01_cnt++;
				}
				break;
			}
		case 2://��ֵ��-��
			{
				if(0 == strcmp(dev_type, "2"))
				{
					if(0 == btn_02_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_u').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_u').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_u').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					btn_02_cnt++;
				}
				break;
			}
		case 3://��ֵ��-��
			{
				if(0 == strcmp(dev_type, "2"))
				{
					if(0 == btn_03_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_d').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_d').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_d').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					btn_03_cnt++;
				}
				break;
			}
		case 4://��ֵ��-��
			{
				if(0 == strcmp(dev_type, "3"))
				{
					if(0 == btn_04_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_l').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_l').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_l').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					btn_04_cnt++;
				}
				break;
			}
		case 5://��ֵ��-��
			{
				if(0 == strcmp(dev_type, "3"))
				{
					if(0 == btn_05_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_u').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_u').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_u').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					btn_05_cnt++;
				}
				break;
			}
		case 6://��ֵ��-��
			{
				if(0 == strcmp(dev_type, "3"))
				{
					if(0 == btn_06_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_r').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_r').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_r').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					btn_06_cnt++;
				}
				break;
			}
		case 7://������-��
			{
				if(0 == strcmp(dev_type, "5"))
				{
					if(0 == btn_07_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_m').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_m').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_m').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					fprintf(cgiOut, "<script>\n");
					fprintf(cgiOut, "  arrayObj_07.push('%s$%s$%s$%s$%s$%s$%s$%s');\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
					fprintf(cgiOut, "</script>\n");
					
					//������ʾ
					if(NULL != col_values[9] && strlen(col_values[9]) > 0)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  showDes_07 += '%d' + '^' + '%s' + '~';\n", btn_07_cnt, col_values[9]);
						fprintf(cgiOut, "</script>\n");				
					}
					
					btn_07_cnt++;
				}
				break;
			}
		case 8://������-��
			{
				if(0 == strcmp(dev_type, "5"))
				{
					if(0 == btn_08_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_u').innerHTML = '%s';\n", col_values[2]);					
						fprintf(cgiOut, "  document.getElementById('p_btn_u').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_u').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);					
						fprintf(cgiOut, "</script>\n");
					}
					fprintf(cgiOut, "<script>\n");
					fprintf(cgiOut, "  arrayObj_08.push('%s$%s$%s$%s$%s$%s$%s$%s');\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
					fprintf(cgiOut, "</script>\n");
					
					//������ʾ
					if(NULL != col_values[9] && strlen(col_values[9]) > 0)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  showDes_08 += '%d' + '^' + '%s' + '~';\n", btn_08_cnt, col_values[9]);
						fprintf(cgiOut, "</script>\n");				
					}
					
					btn_08_cnt++;
				}
				break;
			}
		case 9://������-��
			{
				if(0 == strcmp(dev_type, "5"))
				{
					if(0 == btn_09_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_d').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_d').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_d').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					fprintf(cgiOut, "<script>\n");
					fprintf(cgiOut, "  arrayObj_09.push('%s$%s$%s$%s$%s$%s$%s$%s');\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
					fprintf(cgiOut, "</script>\n");
					
					//������ʾ
					if(NULL != col_values[9] && strlen(col_values[9]) > 0)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  showDes_09 += '%d' + '^' + '%s' + '~';\n", btn_09_cnt, col_values[9]);
						fprintf(cgiOut, "</script>\n");				
					}
					
					btn_09_cnt++;
				}
				break;
			}
		case 10://������-��
			{
				if(0 == strcmp(dev_type, "5"))
				{
					if(0 == btn_10_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_l').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_l').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_l').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					fprintf(cgiOut, "<script>\n");
					fprintf(cgiOut, "  arrayObj_10.push('%s$%s$%s$%s$%s$%s$%s$%s');\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
					fprintf(cgiOut, "</script>\n");
					
					//������ʾ
					if(NULL != col_values[9] && strlen(col_values[9]) > 0)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  showDes_10 += '%d' + '^' + '%s' + '~';\n", btn_10_cnt, col_values[9]);
						fprintf(cgiOut, "</script>\n");				
					}
					
					btn_10_cnt++;
				}
				break;
			}
		case 11://������-��
			{
				if(0 == strcmp(dev_type, "5"))
				{
					if(0 == btn_11_cnt)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  document.getElementById('p_btn_r').innerHTML = '%s';\n", col_values[2]);
						fprintf(cgiOut, "  document.getElementById('p_btn_r').onclick = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "  document.getElementById('btn_r').onclick   = Function(\"doSend('%s','%s','%s','%s','%s','%s','%s','%s')\");\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
						fprintf(cgiOut, "</script>\n");
					}
					fprintf(cgiOut, "<script>\n");
					fprintf(cgiOut, "  arrayObj_11.push('%s$%s$%s$%s$%s$%s$%s$%s');\n", col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
					fprintf(cgiOut, "</script>\n");
					
					//������ʾ
					if(NULL != col_values[9] && strlen(col_values[9]) > 0)
					{
						fprintf(cgiOut, "<script>\n");
						fprintf(cgiOut, "  showDes_11 += '%d' + '^' + '%s' + '~';\n", btn_11_cnt, col_values[9]);
						fprintf(cgiOut, "</script>\n");				
					}
					
					btn_11_cnt++;
				}
				break;
			}
		case 12://������-��
			{
				if(0 == strcmp(dev_type, "5"))
				{
					if(0 == btn_12_cnt%3 && btn_12_cnt > 0)
					{
						fprintf(cgiOut, "</tr>\n");
						fprintf(cgiOut, "<tr height='30px'>\n");
					}
					fprintf(cgiOut, "  <td width='33%%' align=center>\n");
					fprintf(cgiOut, "    <input type='button' value='%s' onclick=\"doSend('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s');\">\n", col_values[2], col_values[0], col_values[3], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7]);
					fprintf(cgiOut, "  </td>\n");
					btn_12_cnt++;
				}
				break;
			}
	}
	return 0;
}

void ObjHtml()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>Զ�̿���</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#d2d2e9\">\n");
	fprintf(cgiOut, "<form name=\"ObjHtml\" action=\"netToPo.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<table width=\"98%%\" align='center' style='margin:auto;margin-top:10px' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	
	//������ģʽ
	if(0 == strcmp(isflag2, "0"))
	{
		if(0 == strncmp(id, "001103", 6))
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='tel' style='width:90%%;height:20px' value='' maxlength=200>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='obj' style='width:90%%;height:20px' value='' maxlength=100>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
		else if(0 == strncmp(id, "001104", 6))
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='tel' style='width:90%%;height:20px' value='' maxlength=200>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <select name='obj' style='width:90%%;height:20px'>\n");
			
			int rc;
			char * zErrMsg = 0;
			sqlite3 *db = open_db(DB_PATH);
			char sql[128] = {0};
			sprintf(sql, "select a.sn, a.cname from call a");
			rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_call, 0, &zErrMsg);
			if(rc != SQLITE_OK)
			{
			  err_msg(1);
			}
			sqlite3_close(db);
			
			fprintf(cgiOut, "    </select>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
		else
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='obj' style='width:90%%;height:20px' value='' maxlength=256>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}	
	}
	//����ģʽ
	else if(0 == strcmp(isflag2, "1"))
	{
		fprintf(cgiOut, "<tr height='30'>\n");
		fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
		fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
		fprintf(cgiOut, "    <input type='text' name='obj_insert' style='width:90%%;height:20px' value='' maxlength=4>\n");
		fprintf(cgiOut, "  </td>\n");
		fprintf(cgiOut, "</tr>\n");	
		if(0 == strcmp(isobject, "1"))
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='obj' style='width:90%%;height:20px' value='' maxlength=256>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
	}
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>\n");	
	fprintf(cgiOut, "      <input type='button' value='�ر�' style='width:40px;height:22px' onClick=\"doCancel();\">\n");
	fprintf(cgiOut, "      <input type='button' value='�ύ' style='width:40px;height:22px' onClick=\"doSendObj('%s');\">\n", id);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	//doSend����
  fprintf(cgiOut, "var reqSend = null;\n");
  fprintf(cgiOut, "function doSendObj(pId)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  var object = '';\n");
  fprintf(cgiOut, "  var obj_insert = '';\n");
  fprintf(cgiOut, "  var isflag = '';\n");
  //������ģʽ
	if(0 == strcmp(isflag2, "0"))
	{
		fprintf(cgiOut, "var isflag = '0';\n");
	  fprintf(cgiOut, "if('001103' == pId.substring(0,6) || '001104' == pId.substring(0,6))\n");//���š�����
	  fprintf(cgiOut, "{\n");
	  fprintf(cgiOut, "  if(ObjHtml.tel.value.Trim().length < 1)\n");
	  fprintf(cgiOut, "  {\n");
	  fprintf(cgiOut, "    alert('���������');\n");
	  fprintf(cgiOut, "    return;\n");
	  fprintf(cgiOut, "  }\n");
	  fprintf(cgiOut, "  if(ObjHtml.obj.value.Trim().length < 1)\n");
	  fprintf(cgiOut, "  {\n");
	  fprintf(cgiOut, "    alert('����������');\n");
	  fprintf(cgiOut, "    return;\n");
	  fprintf(cgiOut, "  }\n");
	  fprintf(cgiOut, "  object = ObjHtml.tel.value + '//' + ObjHtml.obj.value;\n");
	  fprintf(cgiOut, "}\n");
	  fprintf(cgiOut, "else\n");
	  fprintf(cgiOut, "{\n");
	  fprintf(cgiOut, "  if(ObjHtml.obj.value.Trim().length < 1)\n");
	  fprintf(cgiOut, "  {\n");
	  fprintf(cgiOut, "    alert('����������');\n");
	  fprintf(cgiOut, "    return;\n");
	  fprintf(cgiOut, "  }\n");
	  fprintf(cgiOut, "  object = ObjHtml.obj.value;\n");
	  fprintf(cgiOut, "}\n");
	}
	//����ģʽ
	else if(0 == strcmp(isflag2, "1"))
	{
		fprintf(cgiOut, "var isflag = '3';\n");
		fprintf(cgiOut, "if(ObjHtml.obj_insert.value.Trim().length < 1)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('����д����ֵ');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "for(var i=0; i<ObjHtml.obj_insert.value.length; i++)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(isNaN(ObjHtml.obj_insert.value.charAt(i)))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('����ֵ���Ƿ��ַ�!');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "obj_insert = StrLeftFillZero(ObjHtml.obj_insert.value.Trim(), 4);\n");
		if(0 == strcmp(isobject, "1"))
		{
			fprintf(cgiOut, "if(ObjHtml.obj.value.Trim().length < 1)\n");
	  	fprintf(cgiOut, "{\n");
	  	fprintf(cgiOut, "  alert('����������');\n");
	  	fprintf(cgiOut, "  return;\n");
	  	fprintf(cgiOut, "}\n");
	  	fprintf(cgiOut, "object = ObjHtml.obj.value;\n");
		}
	}
  fprintf(cgiOut, "  if(object.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    object = ' ';\n");
	fprintf(cgiOut, "  }\n");  
	fprintf(cgiOut, "  var len = object.len();\n");	
	fprintf(cgiOut, "  if(len > 256)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ݳ��ȹ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    reqSend = new XMLHttpRequest();\n");
  fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    reqSend = new ActiveXObject('Microsoft.XMLHTTP');\n");
  fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqSend.onreadystatechange = callbackSendName;\n");
	fprintf(cgiOut, "  var url = 'netToPo.cgi?cmd=2&id=%s&sn=%s&object='+object+'&obj_insert='+obj_insert+'&isflag='+isflag+'&user_id=%s';\n", id, sn, user_id);
	fprintf(cgiOut, "  reqSend.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqSend.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqSend.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackSendName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqSend.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqSend.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "  				 parent.closeDiv();\n");
	fprintf(cgiOut, "          parent.document.getElementById('actret').innerHTML = '<font color=green><B>����:[%s], ���:[�ɹ�]</B></font>';\n", cmdname);
	fprintf(cgiOut, "          clearTimeout(parent.TimeOutShow);\n");
	fprintf(cgiOut, "          parent.TimeOutShow = setTimeout(\"parent.doShowMemo()\", 5000);\n");
	fprintf(cgiOut, "  				 setTimeout(\"parent.parent.RealStatus('%s', '%s', '3');\", 200);\n", id, checkindex);
	fprintf(cgiOut, "  				 setTimeout(\"parent.RealDataSel('%s');\", 200);\n", id);
	fprintf(cgiOut, "          parent.doTopCmd('%s');\n", cmdarea);
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else if(resp.indexOf('3000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "  				 parent.closeDiv();\n");
	fprintf(cgiOut, "          parent.document.getElementById('actret').innerHTML = '<font color=green><B>����:[%s], ���:[�ύ�ɹ�]</B></font>';\n", cmdname);
	fprintf(cgiOut, "          clearTimeout(parent.TimeOutShow);\n");
	fprintf(cgiOut, "          parent.TimeOutShow = setTimeout(\"parent.doShowMemo()\", 5000);\n");
	fprintf(cgiOut, "  				 setTimeout(\"parent.parent.RealStatus('%s', '%s', '3');\", 200);\n", id, checkindex);
	fprintf(cgiOut, "  				 setTimeout(\"parent.RealDataSel('%s');\", 200);\n", id);
	fprintf(cgiOut, "          parent.doTopCmd('%s');\n", cmdarea);
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "  				 parent.closeDiv();\n");
  fprintf(cgiOut, "          parent.document.getElementById('actret').innerHTML = '<font color=red><B>����:[%s], ���:[ʧ��,�����²���]</B></font>';\n", cmdname);
	fprintf(cgiOut, "          clearTimeout(parent.TimeOutShow);\n");
	fprintf(cgiOut, "          parent.TimeOutShow = setTimeout(\"parent.doShowMemo()\", 5000);\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_call(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	return 0;	
}

void CtrlSubmit()
{
	if(NULL != isflag && (0 == strcmp(isflag, "1") || 0 == strcmp(isflag, "2")))
	{
		int ret = MsgSend(4);
		switch(ret)
		{
			case 0:
					printf("9999\n");
				break;
			case 1:
			case 2:
					//����
					if(NULL != realmode && strstr(realmode, "}"))
					{
						char curr_Mode[5] = {0};
						char curr_SN[5] = {0};
						int i = 0;
						char* split_result = NULL;
				    char* savePtr = NULL;
				    split_result = strtok_r(realmode, "}", &savePtr);
				    while(NULL != split_result)
						{
							if(0 == i)
							{
								strncpy(curr_Mode, split_result+11, 4);
								strncpy(curr_SN, split_result+15, 4);
								break;
							}						
							i++;
							split_result = strtok_r(NULL, "}", &savePtr);
						}
						
						memset(sn, 0, sizeof(sn));
						memcpy(sn, getB_NCmd(atoi(isflag), id, curr_Mode, curr_SN), 9);
						if(NULL != sn && strlen(sn) == 8)
						{
							int ret2 = MsgSend(1);
							switch(ret2)
							{
								case 0:
										printf("9999\n");
									break;
								case 1:
										printf("3000\n");
									break;
								case 2:
										printf("0000\n");
									break;
							}
						}
						else
						{
							printf("9999\n");
						}						
					}
					else
					{
						printf("9999\n");
					}			
				break;
		}
	}
	else if(NULL != isflag && 0 == strcmp(isflag, "3"))
	{//����ģʽ
		int ret = MsgSend(4);
		switch(ret)
		{
			case 0:
					printf("9999\n");
				break;
			case 1:
			case 2:
					//����
					if(NULL != realmode && strstr(realmode, "}"))
					{
						char curr_Mode[5] = {0};
						char curr_SN[5] = {0};
						int i = 0;
						char* split_result = NULL;
				    char* savePtr = NULL;
				    split_result = strtok_r(realmode, "}", &savePtr);
				    while(NULL != split_result)
						{
							if(0 == i)
							{
								strncpy(curr_Mode, split_result+11, 4);
								strncpy(curr_SN, split_result+15, 4);
								break;
							}						
							i++;
							split_result = strtok_r(NULL, "}", &savePtr);
						}
						
						memset(sn, 0, sizeof(sn));
						strcat(sn, curr_Mode);
						strcat(sn, obj_insert);
						if(NULL != sn && strlen(sn) == 8)
						{
							int ret2 = MsgSend(1);
							switch(ret2)
							{
								case 0:
										printf("9999\n");
									break;
								case 1:
										printf("3000\n");
									break;
								case 2:
										printf("0000\n");
									break;
							}
						}
						else
						{
							printf("9999\n");
						}						
					}
					else
					{
						printf("9999\n");
					}			
				break;
		}
	}
	else
	{
		int ret = MsgSend(1);
		switch(ret)
		{
			case 0:
					printf("9999\n");
				break;
			case 1:
					printf("3000\n");
				break;
			case 2:
					printf("0000\n");
				break;
		}
	}
}

char *getB_NCmd(int pCType, char *pId, char *pModeId, char *pSN)
{
	memset(FillStr, 0, sizeof(FillStr));
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	char sql[512] = {0};
	switch(pCType)
	{
		case 1://��һ����
				strcat(sql, "select a.b_sn from device_cmd a where a.id = substr('");
				strcat(sql, pId);
				strcat(sql, "',1,6) and a.sn = '");
				strcat(sql, pModeId);
				strcat(sql, pSN);
				strcat(sql, "'");
			break;
		case 2://��һ����
				strcat(sql, "select a.n_sn from device_cmd a where a.id = substr('");
				strcat(sql, pId);
				strcat(sql, "',1,6) and a.sn = '");
				strcat(sql, pModeId);
				strcat(sql, pSN);
				strcat(sql, "'");
			break;
	}
	
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_getB_NCmd, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	return FillStr;
}

int sqlite3_exec_callback_getB_NCmd(void *data, int n_columns, char **col_values, char **col_names)
{
	memcpy(FillStr, col_values[0], 9);
	return 0;
}

//�����߳�(0:ʧ��,�����²���; 1:�ύ�ɹ�; 2:�����ɹ�)
int MsgSend(int flag)
{
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return 0;
	}
	
	//������װ
	BYTE outbuf[2048] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	int len = 0;
	switch(flag)
	{
		case 1://Զ�̿���
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00003002");
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 8));
				strcat(pdata, StrRightFillSpace(user_id, 10));
				strcat(pdata, StrRightFillSpace(object, 256));
				len = MSGHDRLEN + 20 + 8 + 10 + 8 + 10 + 256;
			break;
		case 2://�豸״̬��ѯ(2020)
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002020");
				strcat(pdata, id);
				len = MSGHDRLEN + 20 + 8 + strlen(id);
			break;
		case 3://����ִ�����״̬��ѯ(2001)
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002001");
				strcat(pdata, StrRightFillSpace(id, 10));
				len = MSGHDRLEN + 20 + 8 + 10;
			break;
		case 4://�豸ģʽ��ѯ
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002022");
				strcat(pdata, id);
				len = MSGHDRLEN + 20 + 8 + strlen(id);
			break;
	}
	
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	
	char *ip = getLocalIP();
	//����
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return 0;
	}
	pSock->SetCompletion();
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return 0;
	}
	
	char szBuf[4096] = {0};
	if(true == pSock->IsPending(30000))
	{
		if((len = pSock->Recv(szBuf, 4096)) <= 0) 
		{
			pSock->EndSocket();
			return 0;
		}
		
		//AddMsg((BYTE *)szBuf, 100);
		pMsgHdr = (PMsgHdr)szBuf;
		char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
		
		//���سɹ�
		if(0 == memcmp(pmsg+20, "0000", 4))
		{//������
			switch(flag)
			{
				case 2://�豸״̬��ѯ(2020)
						memset(realstat, 0, sizeof(realstat));
						strncpy(realstat, pmsg+28, 4096);
					break;
				case 3://����ִ�����״̬��ѯ(2001)
						memset(realsing, 0, sizeof(realsing));
						strncpy(realsing, pmsg+28, 4096);
					break;
				case 4://�豸ģʽ��ѯ
						memset(realmode, 0, sizeof(realmode));
						strncpy(realmode, pmsg+28, 4096);
					break;
			}
			pSock->EndSocket();
			return 2;
		}
		else if(0 == memcmp(pmsg+20, "0001", 4))
		{//Ҫ����		
			pSock->EndSocket();
			return 2;
		}
		else if(0 == memcmp(pmsg+20, "3000", 4))
		{
			pSock->EndSocket();
			return 1;
		}
		else
		{
			pSock->EndSocket();
			return 0;
		}
	}
	else
	{
		pSock->EndSocket();
		return 0;
	}
	
	//�ر�����
	pSock->EndSocket();
	return 0;
}

char *StrRightFillSpace(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	int FillLen = len - strlen(strData);
	strcat(FillStr, strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(FillStr, " ");
	}
	return FillStr;
}
