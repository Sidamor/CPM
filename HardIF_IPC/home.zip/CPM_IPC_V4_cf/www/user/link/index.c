#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

//��������
char cmd[4] = {0};
char user_id[31] = {0};
//��������
static void getHtmlData();
static void doIndex();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	switch(atoi(cmd))
	{
		case 0:
				doIndex();
			break;
	}		
	return 0;
}

void getHtmlData()
{  
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("user_id", user_id, sizeof(user_id));
}

void doIndex()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<title>��������ƽ̨-Ӧ�ù���</title>\n");
	fprintf(cgiOut, "<meta http-equiv='x-ua-compatible' content='ie=7'/>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content='text/html; charset=gb2312'>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style='background:#2da3d6' onload='FuncSel();'>\n");
	fprintf(cgiOut, "<form>\n");
	fprintf(cgiOut, "<div id='down_bg_3'>\n");
	fprintf(cgiOut, "  <table width='700px' align='center' style='margin:auto;margin-top:10px;' border=0 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "    <tr height='180'>\n");
	fprintf(cgiOut, "      <td width='33%%' align='center' id='li01'>\n");
	fprintf(cgiOut, "        <img src='../../skin/images/donet.png' style='width:100px;height:100px;cursor:hand;'><br>\n");
	fprintf(cgiOut, "        <a href='#'><font color=gray  size='4'><B>ʵʱ���<B></font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='33%%' align='center' id='li02'>\n");
	fprintf(cgiOut, "        <img src='../../skin/images/doenv.png' style='width:100px;height:100px;cursor:hand;'><br>\n");
	fprintf(cgiOut, "        <a href='#'><font color=gray  size='4'><B>���ݷ���<B></font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='33%%' align='center' id='li03'>\n");
	fprintf(cgiOut, "        <img src='../../skin/images/dolog.png' style='width:100px;height:100px;cursor:hand;'><br>\n");
	fprintf(cgiOut, "        <a href='#'><font color=gray  size='4'><B>��־����<B></font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='180'>\n");
	fprintf(cgiOut, "      <td width='33%%' align='center' id='li04'>\n");
	fprintf(cgiOut, "        <img src='../../skin/images/dodvr.png' style='width:100px;height:100px;cursor:hand;'><br>\n");
	fprintf(cgiOut, "        <a href='#'><font color=gray  size='4'><B>��Ƶ���<B></font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='33%%' align='center' id='li05' style='display:none;'>\n");
	fprintf(cgiOut, "        <img src='../../skin/images/others.png' style='width:100px;height:100px;cursor:hand;' onClick='doAts();'><br>\n");
	fprintf(cgiOut, "        <a href='#' onClick='doAts();'><font color=green size='4'><B>����ϵͳ<B></font></a>\n");    	
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='33%%' align='center' id='li06'>\n");
	fprintf(cgiOut, "        <img src='../../skin/images/dopwd.png' style='width:100px;height:100px;cursor:hand;' onClick='doPwd();'><br>\n");
	fprintf(cgiOut, "        <a href='#' onClick='doPwd();'><font color=green size='4'><B>�����޸�<B></font></a>\n");    	
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<script language=javascript>\n");
	fprintf(cgiOut, "function doNet()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'net.cgi?user_id=%s';\n", user_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doEnv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'env.cgi?user_id=%s';\n", user_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doLog()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'log.cgi?user_id=%s';\n", user_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doDvr()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'dvr.cgi?user_id=%s';\n", user_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doAts()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'ats.cgi?user_id=%s';\n", user_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doPwd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'pwd.cgi?user_id=%s';\n", user_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function fGetQuery(name)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var sUrl = window.location.search.substr(1);\n");
	fprintf(cgiOut, "  var r = sUrl.match(new RegExp('(^|&)' + name + '=([^&]*)(&|$)'));\n");
	fprintf(cgiOut, "  return (r == null ? null : unescape(r[2]));\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "var bForcepc = fGetQuery('dv') == 'pc';\n");
	fprintf(cgiOut, "function fBrowserRedirect()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var sUserAgent = navigator.userAgent.toLowerCase();\n");
	fprintf(cgiOut, "  var bIsIpad = sUserAgent.match(/ipad/i) == 'ipad';\n");
	fprintf(cgiOut, "  var bIsIphoneOs = sUserAgent.match(/iphone os/i) == 'iphone os';\n");
	fprintf(cgiOut, "  var bIsMidp = sUserAgent.match(/midp/i) == 'midp';\n");
	fprintf(cgiOut, "  var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == 'rv:1.2.3.4';\n");
	fprintf(cgiOut, "  var bIsUc = sUserAgent.match(/ucweb/i) == 'ucweb';\n");
	fprintf(cgiOut, "  var bIsAndroid = sUserAgent.match(/android/i) == 'android';\n");
	fprintf(cgiOut, "  var bIsCE = sUserAgent.match(/windows ce/i) == 'windows ce';\n");
	fprintf(cgiOut, "  var bIsWM = sUserAgent.match(/windows mobile/i) == 'windows mobile';\n");
	fprintf(cgiOut, "  if(bIsIpad)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var sUrl = location.href;\n");
	fprintf(cgiOut, "    if(!bForcepc)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      document.getElementById('li04').innerHTML = \"<img src='../../skin/images/dodvr.png' style='width:100px;height:100px;cursor:hand;'><br><a href='#'><font color=gray  size='4'><B>��Ƶ���<B></font></a>\";\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(bIsIphoneOs || bIsAndroid)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var sUrl = location.href;\n");
	fprintf(cgiOut, "    if(!bForcepc)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      //document.getElementById('li04').innerHTML = '';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(bIsMidp||bIsUc7||bIsUc||bIsCE||bIsWM)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var sUrl = location.href;\n");
	fprintf(cgiOut, "    if(!bForcepc)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      //document.getElementById('li04').innerHTML = '';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    //document.getElementById('li04').innerHTML = '';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "var reqEdit = null;\n");
	fprintf(cgiOut, "function FuncSel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqEdit = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqEdit = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqEdit.onreadystatechange = callbackFuncSel;\n");
	fprintf(cgiOut, "  var url = 'user_info.cgi?cmd=14&user_id=%s';\n", user_id);
	fprintf(cgiOut, "  reqEdit.open('get', url);\n");
	fprintf(cgiOut, "  reqEdit.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqEdit.send(null);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackFuncSel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqEdit.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqEdit.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var qx_list = resp.split(',');\n");
	fprintf(cgiOut, "      for(var i=0; i<qx_list.length; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(qx_list[i].indexOf('01') == 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('li01').innerHTML = \"<img src='../../skin/images/donet.png' style='width:100px;height:100px;cursor:hand;' onClick='doNet();'><br><a href='#' onClick='doNet();'><font color=green size='4'><B>ʵʱ���<B></font></a>\";\n");
	fprintf(cgiOut, "          continue;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        if(qx_list[i].indexOf('02') == 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('li02').innerHTML = \"<img src='../../skin/images/doenv.png' style='width:100px;height:100px;cursor:hand;' onClick='doEnv();'><br><a href='#' onClick='doEnv();'><font color=green size='4'><B>���ݷ���<B></font></a>\";\n");
	fprintf(cgiOut, "          continue;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        if(qx_list[i].indexOf('03') == 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('li03').innerHTML = \"<img src='../../skin/images/dolog.png' style='width:100px;height:100px;cursor:hand;' onClick='doLog();'><br><a href='#' onClick='doLog();'><font color=green size='4'><B>��־����<B></font></a>\";\n");
	fprintf(cgiOut, "          continue;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        if(qx_list[i].indexOf('04') == 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('li04').innerHTML = \"<img src='../../skin/images/dodvr.png' style='width:100px;height:100px;cursor:hand;' onClick='doDvr();'><br><a href='#' onClick='doDvr();'><font color=green size='4'><B>��Ƶ���<B></font></a>\";\n");
	fprintf(cgiOut, "          continue;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        if(qx_list[i].indexOf('05') == 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('li05').style.display = '';\n");
	fprintf(cgiOut, "          continue;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      FuncSYSSel();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "//ϵͳȨ��\n");
	fprintf(cgiOut, "var reqSel = null;\n");
	fprintf(cgiOut, "function FuncSYSSel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqSel = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqSel = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqSel.onreadystatechange = function()\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var state = reqSel.readyState;\n");
	fprintf(cgiOut, "    if(state == 4)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(reqSel.status == 200)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var Resp = reqSel.responseText;\n");
	fprintf(cgiOut, "        if(null != Resp && Resp.substring(0,4) == ('0000') && Resp.length > 4)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var list = Resp.substring(4).split(';');\n");
	fprintf(cgiOut, "          for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "            switch(parseInt(sublist[0]))\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              case 4:\n");
	fprintf(cgiOut, "                  if('0' == sublist[1])\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    document.getElementById('li04').innerHTML = \"<img src='../../skin/images/dodvr.png' style='width:100px;height:100px;cursor:hand;'><br><a href='#'><font color=gray  size='4'><B>��Ƶ���<B></font></a>\";\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                break;\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "          fBrowserRedirect();\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var url = 'out_set.cgi?currtime='+new Date();\n");
	fprintf(cgiOut, "  reqSel.open('get', url);\n");
	fprintf(cgiOut, "  reqSel.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqSel.send(null);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</html>\n");
}
