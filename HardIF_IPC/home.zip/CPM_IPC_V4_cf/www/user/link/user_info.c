#include <stdio.h>
#include "cgic.h"
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>

//��������
int cnt = 0;
char cmd[4] = {0};
char user_id[31] = {0};
char FP_QX[5] = {0};
char FP_QXAll[1024] = {0};
char pwd[20] = {0};
char newpwd[20] = {0};
//��������
void err_msg(int pType);
static void Func_Sel();
static int sqlite3_exec_callback_funcsel(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_funcselall(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_funqx(void *data, int n_columns, char **col_values, char **col_names);
static void SingleValidate();
static void UpdateData();
static int sqlite3_exec_callback_validate(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("user_id", user_id, sizeof(user_id));
	cgiFormString("pwd", pwd, sizeof(pwd));
	cgiFormString("newpwd", newpwd, sizeof(newpwd));
	
	cnt = 0;
	switch(atoi(cmd))
	{
		case 13://�޸�����
					SingleValidate();
					if(cnt == 1)
					{
						UpdateData();
						printf("�����޸ĳɹ�!");
					}
					else
					{
						printf("�û������������!");
					}
					break;
		case 14://����Ȩ��
			Func_Sel();
			break;
	}
	return 0;
}

void SingleValidate()
{
	int rc;
	char *zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	char sql[256] = {0};
	sprintf(sql, "select t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role from user_info t where t.id = '%s' and t.pwd = '%s'", user_id, pwd);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_validate, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(2);
	}
	
	sqlite3_close(db);
}

int sqlite3_exec_callback_validate(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

void UpdateData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	char sql[256] = {0};
	sprintf(sql, "update user_info set pwd = '%s' where id = '%s' ", newpwd, user_id);
	rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(2);
	}
	
	sqlite3_close(db);
}

void Func_Sel()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	char sql[256] = {0};
	sprintf(sql, "select a.qx from user_info a where a.id='%s'", user_id);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_funqx, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(3);
	}
	if(0 == strcmp(FP_QX, "000"))
	{
		memset(FP_QXAll, 0, sizeof(FP_QXAll));
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "select a.id from fp_info a");
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_funcselall, 0, &zErrMsg);
		if( rc!=SQLITE_OK )
		{
		  err_msg(3);
		}
		printf("%s\n", FP_QXAll);
	}
	else
	{
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "select b.point from user_info a, role b where a.id='%s' and a.qx=b.id", user_id);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_funcsel, 0, &zErrMsg);
		if( rc!=SQLITE_OK )
		{
		  err_msg(3);
		}
	}
	
	sqlite3_close(db);
}

int sqlite3_exec_callback_funqx(void *data, int n_columns, char **col_values, char **col_names)
{
	memset(FP_QX, 0, sizeof(FP_QX));
	memcpy(FP_QX, col_values[0], 5);
	return 0;
}

int sqlite3_exec_callback_funcselall(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat(FP_QXAll, col_values[0]);
	strcat(FP_QXAll, ",");
	return 0;
}

int sqlite3_exec_callback_funcsel(void *data, int n_columns, char **col_values, char **col_names)
{
	printf("%s\n", col_values[0]);
	return 0;
}
