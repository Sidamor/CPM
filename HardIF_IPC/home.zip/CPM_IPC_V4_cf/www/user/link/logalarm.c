#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "util.h"
#include "session.h"
#include "cgic.h"
#include <time.h>

//��������
char cmd[4] = {0};
int cnt = 0;
int cntAll = 0;
int TotalPage = 0;
int CurrPage = 0;
char dev_name[30] = {0};

char id[11] = {0};
char level[2] = {0};
char BTime[30] = {0};//��ʼʱ��
char ETime[30] = {0};//����ʱ��
char Func_Sel_Id[5] = {0};//9:ȫ��, 0:����, 1:�쳣
char flag[2] = {0};
char timeflag[2] = {0};
char user_id[31] = {0};
FILE *csv_file = NULL; 
char idlist[4096*8] = {0};
//��������
static void getHtmlData();
bool	ContainsFP(char *pUser_Id, char *pFP_Id);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_role_list(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_PageBar(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_dev_name(void *data, int n_columns, char **col_values, char **col_names);
//����
static void ExportData();
static int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain() 
{	
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	cntAll = 0;
	switch(atoi(cmd))
	{
		case 0://��ѯ
			QueryData();
			break;
		case 2://����
			ExportData();
			break;
	}	
	return 0;
}

void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("id", id, sizeof(id));
	cgiFormString("level", level, sizeof(level));
	cgiFormString("BTime", BTime, sizeof(BTime));
	cgiFormString("ETime", ETime, sizeof(ETime));
	cgiFormString("Func_Sel_Id", Func_Sel_Id, sizeof(Func_Sel_Id));
	cgiFormString("flag", flag, sizeof(flag));
	cgiFormString("timeflag", timeflag, sizeof(timeflag));
	cgiFormString("user_id", user_id, sizeof(user_id));
	
	char cPage[10] = {0};//ȡҳ��
	cgiFormString("CurrPage", cPage, sizeof(cPage));
	CurrPage = atoi(cPage);
}

void QueryData()
{
	char BDate[11] = {0};
	char EDate[11] = {0};
	if(strlen(BTime) > 1 && strlen(ETime) > 1)
	{
		strncpy(BDate, BTime, 10);
		strncpy(EDate, ETime, 10);
	}
	else
	{
		time_t nowtime;
		struct tm *timeinfo;
		time(&nowtime);
		timeinfo = localtime(&nowtime);
		int year, month, day, hour, min, sec;
		year = timeinfo->tm_year + 1900;
		month = timeinfo->tm_mon + 1;
		day = timeinfo->tm_mday;
		hour = timeinfo->tm_hour;
		min = timeinfo->tm_min;
		sec = timeinfo->tm_sec;
		
		sprintf(BDate, "%d-%02d-%02d", year, month, day);
		sprintf(EDate, "%d-%02d-%02d", year, month, day);		
		sprintf(BTime, "%s 00:00:00", BDate);
		sprintf(ETime, "%s 23:59:59", EDate);	
	}
	if(strlen(flag) < 1)
	{
		memset(flag, 0, sizeof(flag));
		memcpy(flag, "0", 2);
	}
	if(strlen(timeflag) < 1)
	{
		memset(timeflag, 0, sizeof(timeflag));
		memcpy(timeflag, "0", 2);
	}
	fprintf(cgiOut, "<HTML>\n");
	fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "  <TITLE>������־</TITLE>\n");
	fprintf(cgiOut, "  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "  <link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "  <script type=\"text/javascript\" src=\"../../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "  <script language='javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "  <SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name='alarm_info' action='logalarm.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "<table style='margin:auto' cellpadding='0' cellspacing='0' border='0' width='100%%'>\n");
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "    <td width='7%%' align='left'>\n");
	fprintf(cgiOut, "	     <select name='Func_Sel_Id' style='width:100px;height:20px' onChange='doSelect()'>\n");
	fprintf(cgiOut, "		     <option value='9' %s>ȫ��</option>\n",        0 == strcmp(Func_Sel_Id, "9")?"selected":"");
	fprintf(cgiOut, "			   <option value='0000' %s>�ɹ�</option>\n",     0 == strcmp(Func_Sel_Id, "0000")?"selected":"");
	fprintf(cgiOut, "			   <option value='3000' %s>�ύ�ɹ�</option>\n", 0 == strcmp(Func_Sel_Id, "3000")?"selected":"");
	fprintf(cgiOut, "			   <option value='3006' %s>ʧ��</option>\n",     0 == strcmp(Func_Sel_Id, "3006")?"selected":"");	
	fprintf(cgiOut, "		   </select>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "	   <td width='40%%' align='left'>\n");
	fprintf(cgiOut, "		   <div>\n");
	fprintf(cgiOut, "		     ��ʼʱ��<input id='BDate' name='BDate' type='text' style=' width:90px;  background-color:#ffffff; border: 1 double #3491D6' value='%s' onClick='WdatePicker({readOnly:true})' class='Wdate' size='10' maxlength='10'>\n", BDate);
	fprintf(cgiOut, "			 	 ����ʱ��<input id='EDate' name='EDate' type='text' style=' width:90px;  background-color:#ffffff; border: 1 double #3491D6' value='%s' onClick='WdatePicker({readOnly:true})' class='Wdate' size='10' maxlength='10'>\n", EDate);
	fprintf(cgiOut, "			 </div>\n");
	fprintf(cgiOut, "		 </td>\n");
	fprintf(cgiOut, "		 <td width='45%%' align='right'>\n");
	fprintf(cgiOut, "			 <input name='alert_submit' style='cursor:hand;width:60px;' onClick='doSelect()' value='��ѯ' type='button'>\n");
	fprintf(cgiOut, "			 <input name='alert_export' style='cursor:hand;width:60px;' onClick='doExport()' value='����' type='button'>\n");
	fprintf(cgiOut, "		 </td>\n");
	fprintf(cgiOut, "	 </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<div id='down_bg_2'>\n");
	fprintf(cgiOut, "<table style='margin:auto' cellpadding='0' cellspacing='0' border='1' width='100%%' bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "	   <td width=\"3%%\"  class=\"table_deep_blue\">SN</td>\n");	
	fprintf(cgiOut, "		 <td width=\"10%%\" class=\"table_deep_blue\">�豸</td>\n");
	fprintf(cgiOut, "		 <td width=\"8%%\"  class=\"table_deep_blue\">����</td>\n");
	fprintf(cgiOut, "		 <td width=\"24%%\" class=\"table_deep_blue\">����</td>\n");
	fprintf(cgiOut, "		 <td width=\"15%%\" class=\"table_deep_blue\">ʱ��</td>\n");
	fprintf(cgiOut, "		 <td width=\"24%%\" class=\"table_deep_blue\">ԭ��</td>\n");
	fprintf(cgiOut, "		 <td width=\"8%%\"  class=\"table_deep_blue\">����Ա</td>\n");
	fprintf(cgiOut, "		 <td width=\"8%%\"  class=\"table_deep_blue\">���</td>\n");
	fprintf(cgiOut, "	 </tr>\n");
	
	//��ѯ��¼����
	if(strlen(id) > 0)
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}
		char sql[4096*8] = {0};
		switch(atoi(level))
		{
			case 0:
					sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);					
					
					//����
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "SELECT COUNT(*) FROM ALARM_INFO A WHERE A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.D_ID) = 1 ", BTime, ETime, idlist);
					if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
					{
						strcat(sql, " AND A.STATUS = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					if(0 == strcmp(Func_Sel_Id, "3006"))
					{
						strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
					}
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);
				break;
			case 1:
					sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);					
					
					//����
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "SELECT COUNT(*) FROM ALARM_INFO A WHERE A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.D_ID) = 1 ", BTime, ETime, idlist);
					if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
					{
						strcat(sql, " AND A.STATUS = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					if(0 == strcmp(Func_Sel_Id, "3006"))
					{
						strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
					}
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);
				break;
			case 2:
					sprintf(sql, "SELECT COUNT(*) FROM ALARM_INFO A, ROLE B WHERE A.CTIME >= '%s' AND A.CTIME <= '%s' AND B.ID = '%s' AND contain(B.POINT, A.D_ID) = 1 ", BTime, ETime, id);
					if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
					{
						strcat(sql, " AND A.STATUS = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					if(0 == strcmp(Func_Sel_Id, "3006"))
					{
						strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
					}					
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);
				break;
			case 3:
					sprintf(sql, "SELECT COUNT(*) FROM ALARM_INFO A WHERE A.CTIME >= '%s' AND A.CTIME <= '%s' AND A.D_ID = '%s' ", BTime, ETime, id);
					if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
					{
						strcat(sql, " AND A.STATUS = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					if(0 == strcmp(Func_Sel_Id, "3006"))
					{
						strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
					}
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);
				break;
		}	
		sqlite3_close(db);			
		if(cntAll%20 == 0)
		{
			TotalPage = cntAll/20;
		}
		else
		{
			TotalPage = cntAll/20 + 1;
		}		
		if(CurrPage > TotalPage)
		{
			CurrPage = TotalPage;
		}
	}
	
	//��ϸ
	if(strlen(id) > 0)
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}	
		char sql[4096*8] = {0};
		int offset = CurrPage < 1 ? 0 : (CurrPage-1)*20;
		char tail[128] = {0};
		switch(atoi(level))
		{
			case 0:
					sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);
					
					//��ϸ
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "select a.s_id, a.s_attr, a.d_id, a.d_cmd, a.ctime, a.cdata, a.flag, a.operator, a.status, b.cname, c.cmdname, a.s_value from alarm_info a, device_detail b, device_act c where a.d_id = b.id and a.d_id = c.id and a.d_cmd = c.sn and a.ctime >= '%s' and a.ctime <= '%s' and contain('%s', a.d_id) = 1", BTime, ETime, idlist);
					if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
					{
						strcat(sql, " AND A.STATUS = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					if(0 == strcmp(Func_Sel_Id, "3006"))
					{
						strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
					}
					sprintf(tail, " ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d", offset);
					strcat(sql, tail);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
				break;
			case 1:
					sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);
					
					//��ϸ
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "select a.s_id, a.s_attr, a.d_id, a.d_cmd, a.ctime, a.cdata, a.flag, a.operator, a.status, b.cname, c.cmdname, a.s_value from alarm_info a, device_detail b, device_act c where a.d_id = b.id and a.d_id = c.id and a.d_cmd = c.sn and a.ctime >= '%s' and a.ctime <= '%s' and contain('%s', a.d_id) = 1", BTime, ETime, idlist);
					if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
					{
						strcat(sql, " AND A.STATUS = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					if(0 == strcmp(Func_Sel_Id, "3006"))
					{
						strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
					}
					sprintf(tail, " ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d", offset);
					strcat(sql, tail);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
				break;
			case 2:
					sprintf(sql, "select a.s_id, a.s_attr, a.d_id, a.d_cmd, a.ctime, a.cdata, a.flag, a.operator, a.status, b.cname, c.cmdname, a.s_value from alarm_info a, device_detail b, device_act c, role d where a.d_id = b.id and a.d_id = c.id and a.d_cmd = c.sn and a.ctime >= '%s' and a.ctime <= '%s' and d.id = '%s' and contain(d.point, a.d_id) = 1", BTime, ETime, id);
					if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
					{
						strcat(sql, " AND A.STATUS = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					if(0 == strcmp(Func_Sel_Id, "3006"))
					{
						strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
					}	
					sprintf(tail, " ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d", offset);	
					strcat(sql, tail);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
				break;
			case 3:
					sprintf(sql, "select a.s_id, a.s_attr, a.d_id, a.d_cmd, a.ctime, a.cdata, a.flag, a.operator, a.status, b.cname, c.cmdname, a.s_value from alarm_info a, device_detail b, device_act c where a.d_id = b.id and a.d_id = c.id and a.d_cmd = c.sn and a.ctime >= '%s' and a.ctime <= '%s' and a.d_id = '%s'", BTime, ETime, id);
					if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
					{
						strcat(sql, " AND A.STATUS = '");
						strcat(sql, Func_Sel_Id);
						strcat(sql, "'");
					}
					if(0 == strcmp(Func_Sel_Id, "3006"))
					{
						strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
					}	
					sprintf(tail, " ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d", offset);	
					strcat(sql, tail);
					
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
				break;
		}
		sqlite3_close(db);
	}
	for(int i=0; i<(20-cnt); i++)
	{
		fprintf(cgiOut, "<tr class='%s'>\n", 0 == i%2?"table_white_l":"table_blue");	
		fprintf(cgiOut, "  <td width='3%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='8%%' >&nbsp;</td>\n");	
		fprintf(cgiOut, "	 <td width='24%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='15%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='24%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='8%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='8%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "</tr>\n");		
	}
	
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "    <td colspan='8' class='table_deep_blue' align='center'>\n");
	fprintf(cgiOut, "	     <table width='70%%' height='20'  border='0' cellpadding='0' cellspacing='0' >\n");
	fprintf(cgiOut, "		     <tr valign='bottom'>\n");
	fprintf(cgiOut, "			     <td nowrap align='center'>\n");
	fprintf(cgiOut, "            ҳ��:\n");
	fprintf(cgiOut, "            <strong>%d</strong>/<strong>%d</strong>\n", CurrPage, TotalPage);
	fprintf(cgiOut, "            <span>[��<b>%d</b>����¼]</span>\n", cntAll);
	fprintf(cgiOut, "            <a href=# onclick='GoPage(1)'>��ҳ</a>");
	fprintf(cgiOut, "            |<a href=# onclick='GoPage(%d)'>��һҳ</a>", CurrPage-1);
	fprintf(cgiOut, "            |<a href=# onclick='GoPage(%d)'>��һҳ</a>", CurrPage+1);
	fprintf(cgiOut, "            |<a href=# onclick='GoPage(%d)'>ĩ ҳ</a>", TotalPage);
	fprintf(cgiOut, "            |����<input name='ToPage' type='text' style='width:30px;height:17px' size='2'>ҳ\n");
	fprintf(cgiOut, "            <input type='button' style='width:40px;height:20px' onClick='GoPage(alarm_info.ToPage.value)' value='ȷ��'/>\n");
	fprintf(cgiOut, "				   </td>\n");
	fprintf(cgiOut, "			   </tr>\n");
	fprintf(cgiOut, "		   </table>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'   value='0'>\n");
	fprintf(cgiOut, "<input type='hidden' name='id'    value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='level' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='BTime' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='ETime' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='flag'  value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='timeflag' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='CurrPage' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='user_id'  value='%s'>\n", user_id);
	fprintf(cgiOut, "<input name='DoSubmit' type='hidden' id='DoSubmit' onClick='doSelect()'/>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=\"JavaScript\">\n");
	fprintf(cgiOut, "if(null != window.parent.frames.leftFrame.CurrJsp)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 window.parent.frames.leftFrame.CurrJsp.innerText = 'alarm_info.html';\n");
	fprintf(cgiOut, "}\n");	
	fprintf(cgiOut, "function StrLeftFillZero(strData, len)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var str = strData;\n");
	fprintf(cgiOut, "  var FillLen = len - str.length;\n");
	fprintf(cgiOut, "  for(var i=0; i < FillLen; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    str = '0' + str;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  return str;\n");
	fprintf(cgiOut, "}\n");
	if(0 == strcmp(timeflag, "1"))
	{
		fprintf(cgiOut, "var date = new Date();\n");
		fprintf(cgiOut, "date.setDate(date.getDate()-1);\n");
		fprintf(cgiOut, "var y = date.getFullYear();\n");
		fprintf(cgiOut, "var m = date.getMonth()+1;\n");
		fprintf(cgiOut, "var d = date.getDate();\n");	
		fprintf(cgiOut, "document.getElementById('EDate').value = y + '-' + StrLeftFillZero(m+'', 2) + '-'+ StrLeftFillZero(d+'', 2);\n");
	}
	fprintf(cgiOut, "Date.prototype.format = function(format)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var o =\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    'M+' : this.getMonth()+1,\n");
	fprintf(cgiOut, "    'd+' : this.getDate(),\n");
	fprintf(cgiOut, "    'h+' : this.getHours(),\n");
	fprintf(cgiOut, "    'm+' : this.getMinutes(),\n");
	fprintf(cgiOut, "    's+' : this.getSeconds(),\n");
	fprintf(cgiOut, "    'q+' : Math.floor((this.getMonth()+3)/3),\n");
	fprintf(cgiOut, "    'S'  : this.getMilliseconds()\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(/(y+)/.test(format))\n");
	fprintf(cgiOut, "    format=format.replace(RegExp.$1, (this.getFullYear()+\"\").substr(4 - RegExp.$1.length));\n");
	fprintf(cgiOut, "  for(var k in o)if(new RegExp(\"(\"+ k +\")\").test(format)) \n");
	fprintf(cgiOut, "    format = format.replace(RegExp.$1, RegExp.$1.length==1 ? o[k] : (\"00\"+ o[k]).substr((\"\"+ o[k]).length)); \n");
	fprintf(cgiOut, "  return format; \n");
	fprintf(cgiOut, "}\n");
	//��ϸ
  fprintf(cgiOut, "function doSelect()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "  if(alarm_info.BDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '0';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alarm_info.BDate.value < now && alarm_info.EDate.value < now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alarm_info.BDate.value < now && alarm_info.EDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alarm_info.BDate.value < now && alarm_info.EDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alarm_info.BDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '0';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  alarm_info.BTime.value = alarm_info.BDate.value + ' 00:00:00';\n");
	fprintf(cgiOut, "	 alarm_info.ETime.value = alarm_info.EDate.value + ' 23:59:59';\n");	
	fprintf(cgiOut, "  alarm_info.id.value = window.parent.frames.leftFrame.id.value;\n");	
	fprintf(cgiOut, "  alarm_info.level.value = window.parent.frames.leftFrame.level.value;\n");	
  fprintf(cgiOut, "	 alarm_info.submit();\n");
  fprintf(cgiOut, "}\n");
  //��ҳ
  fprintf(cgiOut, "function GoPage(pPage)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "	 if(pPage == '0')\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "	   pPage = '1';\n");
  fprintf(cgiOut, "	 }\n"); 
  fprintf(cgiOut, "  if(pPage == '')\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "	   alert('������Ŀ��ҳ�����ֵ!');\n");
  fprintf(cgiOut, "		 return;\n");
  fprintf(cgiOut, "	 }\n");
  fprintf(cgiOut, "	 if(pPage < 1)\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "		 alert('������ҳ������1');\n");
  fprintf(cgiOut, "		 return;\n");
  fprintf(cgiOut, "	 }\n");
  fprintf(cgiOut, "  var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "  if(alarm_info.BDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '0';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alarm_info.BDate.value < now && alarm_info.EDate.value < now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alarm_info.BDate.value < now && alarm_info.EDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alarm_info.BDate.value < now && alarm_info.EDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '1';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(alarm_info.BDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alarm_info.flag.value = '0';\n");
  fprintf(cgiOut, "    alarm_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n"); 
  fprintf(cgiOut, "	 alarm_info.CurrPage.value = pPage;\n");
  fprintf(cgiOut, "  alarm_info.BTime.value = alarm_info.BDate.value + ' 00:00:00';\n");
	fprintf(cgiOut, "	 alarm_info.ETime.value = alarm_info.EDate.value + ' 23:59:59';\n");	
	fprintf(cgiOut, "  alarm_info.id.value = window.parent.frames.leftFrame.id.value;\n");	
	fprintf(cgiOut, "  alarm_info.level.value = window.parent.frames.leftFrame.level.value;\n");	
  fprintf(cgiOut, "	 alarm_info.submit();\n");
  fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doExport()\n");
	fprintf(cgiOut, "{\n");
	if(!ContainsFP(user_id, "0304"))
  {
  	fprintf(cgiOut, "alert('����Ȩ��ʹ��[����]����!');return;\n");
  }
	fprintf(cgiOut, "  if(%d == 0)\n", cntAll);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�޼�¼�ɵ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϵ���?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "    if(alarm_info.BDate.value == now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alarm_info.flag.value = '0';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alarm_info.BDate.value < now && alarm_info.EDate.value < now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alarm_info.flag.value = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alarm_info.BDate.value < now && alarm_info.EDate.value == now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alarm_info.flag.value = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alarm_info.BDate.value < now && alarm_info.EDate.value > now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alarm_info.flag.value = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(alarm_info.BDate.value > now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      alarm_info.flag.value = '0';\n");
  fprintf(cgiOut, "    }\n"); 
	fprintf(cgiOut, "    alarm_info.id.value = window.parent.frames.leftFrame.id.value;\n");	
	fprintf(cgiOut, "    alarm_info.level.value = window.parent.frames.leftFrame.level.value;\n");
	fprintf(cgiOut, "	   alarm_info.BTime.value = alarm_info.BDate.value + ' 00:00:00';\n");
	fprintf(cgiOut, "	   alarm_info.ETime.value = alarm_info.EDate.value + ' 23:59:59';\n");		
	fprintf(cgiOut, "	   if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new XMLHttpRequest();\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   req.onreadystatechange = callbackForName;\n");
	fprintf(cgiOut, "	   var url = 'logalarm.cgi?cmd=2&BTime='+alarm_info.BTime.value+'&ETime='+alarm_info.ETime.value+'&id='+alarm_info.id.value+'&level='+alarm_info.level.value+'&Func_Sel_Id='+alarm_info.Func_Sel_Id.value+'&flag='+alarm_info.flag.value+'&user_id=%s';\n", user_id);
	fprintf(cgiOut, "	   req.open('get', url, true);\n");
	fprintf(cgiOut, "	   req.send(null);\n");	
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackForName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var state = req.readyState;\n");
	fprintf(cgiOut, "	 if(4 == state)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 location.href = '../other/%s_E_' + alarm_info.BDate.value + '_' + alarm_info.EDate.value + '.csv';\n", user_id);
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");	
}

int sqlite3_exec_callback_PageBar(void *data, int n_columns, char **col_values, char **col_names)
{
	cntAll += atoi(col_values[0]);
	return 0;
}

int sqlite3_exec_callback_role_list(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat(idlist, col_values[0]);	
	return 0;
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(CurrPage < 1)
	{
		CurrPage = 1;	
	}	
	int sn = (CurrPage-1)*20 + cnt;
	
	char color[10] = {0};
	switch(atoi(col_values[8]))
	{
		case 0:
				strcat(color, "black");
			break;
		case 3000:
				strcat(color, "black");
			break;
		default:
				strcat(color, "black");
			break;
	}
	fprintf(cgiOut, "<tr class='%s'>\n", 0 == cnt%2?"table_white_l":"table_blue");
	fprintf(cgiOut, "  <td width='3%%'  align=center><font color='%s'>%d</font></td>\n", color, sn);
	fprintf(cgiOut, "	 <td width='10%%' align=left><font color='%s'>%s</font></td>\n", color, col_values[9]);//�豸
	fprintf(cgiOut, "	 <td width='8%%'  align=left><font color='%s'>%s</font></td>\n", color, col_values[10]);//����	
	if(NULL != col_values[5] && strlen(col_values[5]) > 25)
	{
		char value[50] = {0};
		strncpy(value, col_values[5], 25);
		strcat(value, "...");
		fprintf(cgiOut, "<td width='24%%' align=left title='%s'><font color='%s'>%s</font></td>\n", col_values[5], color, value);//����
	}
	else
	{
		fprintf(cgiOut, "<td width='24%%' align=left title='%s'><font color='%s'>%s&nbsp;</font></td>\n", col_values[5], color, col_values[5]);//����
	}		
	fprintf(cgiOut, "	 <td width='15%%' align=left><font color='%s'>%s</font></td>\n", color, col_values[4]);//ʱ��	
	
	memset(dev_name, 0, sizeof(dev_name));
	if(strlen(col_values[0]) < 1 && 0 != strcmp(col_values[7], "TIMING"))
	{
		fprintf(cgiOut, "<td width='24%%' align=left><font color='%s'>��ΪԶ���ֹ�����</font></td>\n", color);//ԭ��
	}
	else if(strlen(col_values[0]) < 1 && 0 == strcmp(col_values[7], "TIMING"))
	{
		fprintf(cgiOut, "<td width='24%%' align=left><font color='%s'>��ʱ�Զ�ִ������</font></td>\n", color);//ԭ��
	}
	else
	{
		int rc;
		char * zErrMsg = 0;
		char sql[128] = "select t.cname from device_detail t where t.id = '";
		strcat(sql, col_values[0]);
		strcat(sql, "'");
		
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}	
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_dev_name, 0, &zErrMsg);
		if(0 == strcmp(col_values[1], "0000"))
		{
			char reason[256] = {0};
			strcat(reason, "[");
			strcat(reason, dev_name);
			strcat(reason, "]���ߴ���");		
			fprintf(cgiOut, "<td width='24%%' align=left><font color='%s'>%s</font></td>\n", color, reason);//ԭ��
		}
		else
		{
			char reason[256] = {0};
			strcat(reason, "[");
			strcat(reason, dev_name);
			strcat(reason, "]��ɼ�[");		
			memset(dev_name, 0, sizeof(dev_name));
			
			char sql2[128] = {0};
			sprintf(sql2, "select a.attr_name from device_roll a where a.id = '%s' and a.sn = '%s'", col_values[0], col_values[1]);
			rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_dev_name, 0, &zErrMsg);		
			
			strcat(reason, dev_name);
			if(NULL != col_values[11] && strlen(col_values[11]) > 0)
			{
				strcat(reason, col_values[11]);
			}
			strcat(reason, "]�Զ�����");	
			fprintf(cgiOut, "<td width='24%%' align=left><font color='%s'>%s</font></td>\n", color, reason);//ԭ��
		}
		sqlite3_close(db);
	}
	
	memset(dev_name, 0, sizeof(dev_name));
	if(0 == strcmp(col_values[7], "AUTO") || 0 == strcmp(col_values[7], "TIMING"))
	{
		fprintf(cgiOut, "<td width='8%%'  align=left><font color='%s'>%s</font></td>\n", color, col_values[7]);//����Ա
	}
	else
	{
		int rc;
		char * zErrMsg = 0;
		char sql[128] = "select t.cname from user_info t where t.id = '";
		strcat(sql, col_values[7]);
		strcat(sql, "'");	
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}	
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_dev_name, 0, &zErrMsg);
		sqlite3_close(db); 	
		
		fprintf(cgiOut, "<td width='8%%'  align=left><font color='%s'>%s</font></td>\n", color, dev_name);//����Ա
	}
	char statusname[60] = {0};
	switch(atoi(col_values[8]))
	{
		case 0:
				strcat(statusname, "<font color=green>�ɹ�</font>");
			break;
		case 3000:
				strcat(statusname, "<font color=black>�ύ�ɹ�</font>");
			break;
		default:
				strcat(statusname, "<font color=red>ʧ��</font>");
			break;
	}
	fprintf(cgiOut, "  <td width='8%%'  align=left>%s</td>\n", statusname);//���
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

int sqlite3_exec_callback_dev_name(void *data, int n_columns, char **col_values, char **col_names)
{
	memcpy(dev_name, col_values[0], 30);
	return 0;
}

//�첽����
void ExportData()
{
	char BDate[11] = {0};
	char EDate[11] = {0};
	if(strlen(BTime) > 1 && strlen(ETime) > 1)
	{
		strncpy(BDate, BTime, 10);
		strncpy(EDate, ETime, 10);
	}
	else
	{
		time_t nowtime;
		struct tm *timeinfo;
		time(&nowtime);
		timeinfo = localtime(&nowtime);
		int year, month, day, hour, min, sec;
		year = timeinfo->tm_year + 1900;
		month = timeinfo->tm_mon + 1;
		day = timeinfo->tm_mday;
		hour = timeinfo->tm_hour;
		min = timeinfo->tm_min;
		sec = timeinfo->tm_sec;
		
		sprintf(BDate, "%d-%02d-%02d", year, month, day);
		sprintf(EDate, "%d-%02d-%02d", year, month, day);
		sprintf(BTime, "%s 00:00:00", BDate);
		sprintf(ETime, "%s 23:59:59", EDate);	
	}
	if(strlen(flag) < 1)
	{
		memset(flag, 0, sizeof(flag));
		memcpy(flag, "0", 2);
	}
	if(strlen(timeflag) < 1)
	{
		memset(timeflag, 0, sizeof(timeflag));
		memcpy(timeflag, "0", 2);
	}	
	char file_path[100] = {0}; 
	strcpy(file_path, "../other/");
	strcat(file_path, user_id);		//�û���
	strcat(file_path, "_E_");			//����	
	strcat(file_path, BDate);		  //��ʼʱ��
	strcat(file_path, "_");			  //����	
	strcat(file_path, EDate);		  //��ֹʱ��
	strcat(file_path, ".csv");
	if(NULL != file_path)
	{
		csv_file = fopen(file_path, "w");
		chmod(file_path, 777);
		if(NULL != csv_file)
		{
			fputs("�豸,����,����,ʱ��,ԭ��,����Ա,���\n", csv_file);
			int rc;
			char *zErrMsg;
			sqlite3 *db;
			if(0 == strcmp(flag, "1"))
			{
				db = open_db(DB_PATH_BAK);
			}
			else
			{
				db = open_db(DB_PATH);
			}	
			char sql[4096*8] = {0};
			switch(atoi(level))
			{
				case 0:
						sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);
						
						//����
						memset(sql, 0, sizeof(sql));
						sprintf(sql, "select a.s_id, a.s_attr, a.d_id, a.d_cmd, a.ctime, a.cdata, a.flag, a.operator, a.status, b.cname, c.cmdname, a.s_value from alarm_info a, device_detail b, device_act c where a.d_id = b.id and a.d_id = c.id and a.d_cmd = c.sn and a.ctime >= '%s' and a.ctime <= '%s' and contain('%s', a.d_id) = 1", BTime, ETime, idlist);
						if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
						{
							strcat(sql, " AND A.STATUS = '");
							strcat(sql, Func_Sel_Id);
							strcat(sql, "'");
						}
						if(0 == strcmp(Func_Sel_Id, "3006"))
						{
							strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
						}										
						strcat(sql, " ORDER BY A.CTIME DESC");	
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
					break;
				case 1:
						sprintf(sql, "SELECT A.Point from Role A WHERE length(A.Id) = 8 AND A.Id like '%s%s' order by A.ID", id, "%");
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role_list, 0, &zErrMsg);
						
						//����
						memset(sql, 0, sizeof(sql));
						sprintf(sql, "select a.s_id, a.s_attr, a.d_id, a.d_cmd, a.ctime, a.cdata, a.flag, a.operator, a.status, b.cname, c.cmdname, a.s_value from alarm_info a, device_detail b, device_act c where a.d_id = b.id and a.d_id = c.id and a.d_cmd = c.sn and a.ctime >= '%s' and a.ctime <= '%s' and contain('%s', a.d_id) = 1", BTime, ETime, idlist);
						if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
						{
							strcat(sql, " AND A.STATUS = '");
							strcat(sql, Func_Sel_Id);
							strcat(sql, "'");
						}
						if(0 == strcmp(Func_Sel_Id, "3006"))
						{
							strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
						}										
						strcat(sql, " ORDER BY A.CTIME DESC");	
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
					break;
				case 2:
						sprintf(sql, "select a.s_id, a.s_attr, a.d_id, a.d_cmd, a.ctime, a.cdata, a.flag, a.operator, a.status, b.cname, c.cmdname, a.s_value from alarm_info a, device_detail b, device_act c, role d where a.d_id = b.id and a.d_id = c.id and a.d_cmd = c.sn and a.ctime >= '%s' and a.ctime <= '%s' and d.id = '%s' and contain(d.point, a.d_id) = 1", BTime, ETime, id);
						if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
						{
							strcat(sql, " AND A.STATUS = '");
							strcat(sql, Func_Sel_Id);
							strcat(sql, "'");
						}
						if(0 == strcmp(Func_Sel_Id, "3006"))
						{
							strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
						}										
						strcat(sql, " ORDER BY A.CTIME DESC");
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
					break;
				case 3:
						sprintf(sql, "select a.s_id, a.s_attr, a.d_id, a.d_cmd, a.ctime, a.cdata, a.flag, a.operator, a.status, b.cname, c.cmdname, a.s_value from alarm_info a, device_detail b, device_act c where a.d_id = b.id and a.d_id = c.id and a.d_cmd = c.sn and a.ctime >= '%s' and a.ctime <= '%s' and a.d_id = '%s'", BTime, ETime, id);
						if(0 == strcmp(Func_Sel_Id, "0000") || 0 == strcmp(Func_Sel_Id, "3000"))
						{
							strcat(sql, " AND A.STATUS = '");
							strcat(sql, Func_Sel_Id);
							strcat(sql, "'");
						}
						if(0 == strcmp(Func_Sel_Id, "3006"))
						{
							strcat(sql, " AND A.STATUS <> '0000' AND A.STATUS <> '3000' ");
						}	
						strcat(sql, " ORDER BY A.CTIME DESC");				
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
					break;
			}
			sqlite3_close(db);
		}	
		fclose(csv_file);	
	}		
}

int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names)
{
	char record[2048] = {0};
	char reason[256] = {0};
	memset(dev_name, 0, sizeof(dev_name));
	if(strlen(col_values[0]) < 1 && 0 != strcmp(col_values[7], "TIMING"))
	{
		strcat(reason, "��ΪԶ���ֹ�����");
	}
	else if(strlen(col_values[0]) < 1 && 0 == strcmp(col_values[7], "TIMING"))
	{
		strcat(reason, "��ʱ�Զ�ִ������");
	}
	else
	{
		int rc;
		char * zErrMsg = 0;
		char sql[128] = "select t.cname from device_detail t where t.id = '";
		strcat(sql, col_values[0]);
		strcat(sql, "'");
		
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}	
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_dev_name, 0, &zErrMsg);		
		
		if(0 == strcmp(col_values[1], "0000"))
		{
			strcat(reason, "[");
			strcat(reason, dev_name);
			strcat(reason, "]���ߴ���");
		}
		else
		{
			strcat(reason, "[");
			strcat(reason, dev_name);
			strcat(reason, "]��ɼ�[");		
			memset(dev_name, 0, sizeof(dev_name));
			
			char sql2[128] = {0};
			sprintf(sql2, "select a.attr_name from device_roll a where a.id = '%s' and a.sn = '%s'", col_values[0], col_values[1]);
			rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_dev_name, 0, &zErrMsg);		
			 		
			strcat(reason, dev_name);
			if(NULL != col_values[11] && strlen(col_values[11]) > 0)
			{
				strcat(reason, col_values[11]);
			}
			strcat(reason, "]�Զ�����");
		}
		sqlite3_close(db);		
	}
	
	//����Ա
	char oper[60] = {0};
	memset(dev_name, 0, sizeof(dev_name));
	if(0 == strcmp(col_values[7], "AUTO") || 0 == strcmp(col_values[7], "TIMING"))
	{
		strcat(oper, col_values[7]);
	}
	else
	{
		int rc;
		char * zErrMsg = 0;
		char sql[128] = "select t.cname from user_info t where t.id = '";
		strcat(sql, col_values[7]);
		strcat(sql, "'");	
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}	
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_dev_name, 0, &zErrMsg);
		sqlite3_close(db); 	
		
		strcat(oper, dev_name);
	}
	
	//���
	char statusname[60] = {0};
	switch(atoi(col_values[8]))
	{
		case 0:
				strcat(statusname, "�ɹ�");
			break;
		case 3000:
				strcat(statusname, "�ύ�ɹ�");
			break;
		default:
				strcat(statusname, "ʧ��");
			break;
	}
		
	sprintf(record, "%s,%s,%s,%s,%s,%s,%s\n", col_values[9], col_values[10], col_values[5], col_values[4], reason, oper, statusname);
	fputs(record, csv_file);
	return 0;	
}
