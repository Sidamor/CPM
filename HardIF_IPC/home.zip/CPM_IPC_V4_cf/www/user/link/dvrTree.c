#include <stdio.h>
#include "cgic.h"
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>

//��������
char user_id[31] = {0};
char cmd[5] = {0};
sqlite3 *db = NULL;
int ip_type = 0;

//��������
static void getHtmlData();
//��ѯ
static void dvrTree();
static int sqlite3_exec_callback_userdata(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_tree(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_preset(void *data, int n_columns, char **col_values, char **col_names);
static void cgiGetenv(char **s, char *var);
static int getIP_Type();
bool ContainsFP(char *pUser_Id, char *pFP_Id);

int cgiMain()
{
	cgiHeaderContentType("text/html");
	getHtmlData();
	
	cgiGetenv(&cgiRemoteAddr, "REMOTE_ADDR");
	ip_type = getIP_Type();//IP���ж�(0:������1:������)
	dvrTree();
	
	return 0;
}

void getHtmlData()
{	
	cgiFormString("user_id", user_id, sizeof(user_id));
	cgiFormString("cmd", cmd, sizeof(cmd));
}

void cgiGetenv(char **s, char *var)
{
	*s = getenv(var);
	if (!(*s)) {
		*s = "";
	}
}

int getIP_Type()
{
	int resp = 0;
	char tempip[20] = {0};
	if(NULL == cgiRemoteAddr || strlen(cgiRemoteAddr) < 3)
	{
		return 0;
	}

	char ip1[4] = {0};
	char ip2[9] = {0};
	char ip3[5] = {0};
	
	sprintf(ip1, "%s", "10.");
	sprintf(ip2, "%s", "192.168.");
	sprintf(ip3, "%s", "172.");
	
	strncpy(tempip, cgiRemoteAddr, strlen(ip1));
	if(0 == strcmp(tempip, ip1))
	{
		resp = 1;
		return resp;
	}
	memset(tempip, 0, sizeof(tempip));
	strncpy(tempip, cgiRemoteAddr, strlen(ip2));
	if(0 == strcmp(tempip, ip2))
	{
		resp = 1;
		return resp;
	}
	memset(tempip, 0, sizeof(tempip));
	strncpy(tempip, cgiRemoteAddr, strlen(ip3));
	if(0 == strcmp(tempip, ip3) && strlen(cgiRemoteAddr) >= 7)
	{
		memset(tempip, 0, sizeof(tempip));
		tempip[0] = cgiRemoteAddr[4];
		tempip[1] = cgiRemoteAddr[5];
		if('.' == cgiRemoteAddr[6] && atoi(tempip) >= 16 && atoi(tempip) <= 32)
		{
			resp = 1;
		    return resp;
		}
	}
	return resp;
}

void dvrTree()
{
	fprintf(cgiOut, "<HTML>\n");
  fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>��Ƶ���</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv='x-ua-compatible' content='ie=7'/>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/zTreeStyle2.css' rel='stylesheet'/>\n");	
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery-1.4.4.min.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.core-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.excheck-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.exedit-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</HEAD>\n");
  fprintf(cgiOut, "<BODY style='background:#0B80CC;'>\n");
	fprintf(cgiOut, "  <div id='PARENT'>\n");
	fprintf(cgiOut, "    <ul id='nav'>\n");
	if(ContainsFP(user_id, "0401"))
  {
		fprintf(cgiOut, "    <li><a href='dvrReal.html'           target='mainFrame'>��Ƶ���</a></li>\n");
	}
	if(ContainsFP(user_id, "0402"))
  {
		fprintf(cgiOut, "    <li><a href='dvrHis.html'            target='mainFrame'>��ʷ�ط�</a></li>\n");
	}
	//fprintf(cgiOut, "      <li><a href='#' onClick='doReturn()' target='mainFrame'>�����ϲ�</a></li>\n");
	fprintf(cgiOut, "    </ul>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "  <div><ul id='areaTree' class='ztree'></ul></div>\n");
  fprintf(cgiOut, "  <div id='CurrJsp' style='display:none'></div>\n");
  fprintf(cgiOut, "</BODY>\n");
  fprintf(cgiOut, "<SCRIPT LANGUAGE=\"JavaScript\">\n");
  fprintf(cgiOut, "function doReturn()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  parent.location = 'index.cgi?user_id=%s';\n", user_id);
  fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "var Nodes1 = [];\n");
  fprintf(cgiOut, "var setting = \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  edit: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    enable: false\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  data: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    simpleData:{enable: true}\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  callback: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    onClick: zTreeOnClick\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "};\n");
	
	int rc;
	char * zErrMsg = 0;
	char sql[128] = "";
	sprintf(sql, "select SP_ROLE from USER_INFO where ID = '%s'", user_id);
	db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_userdata, 0, &zErrMsg);
	sqlite3_close(db);
	
	/*-----------------------------������----------------------------------*/
	fprintf(cgiOut, "$('#areaTree').empty();\n");
	fprintf(cgiOut, "$.fn.zTree.init($('#areaTree'), setting, Nodes1);\n");
	
	/*-----------------------------�����----------------------------------*/
	fprintf(cgiOut, "function zTreeOnClick(event, treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(null != treeNode.ctype && treeNode.ctype != '-1')\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "    window.parent.frames.mainFrame.CurrIP_Type.value = treeNode.ip_type;\n");
	fprintf(cgiOut, "    window.parent.frames.mainFrame.CurrINIP.value = treeNode.inip;\n");
	fprintf(cgiOut, "    window.parent.frames.mainFrame.CurrINPort.value = treeNode.inport;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrIP.value = treeNode.outip;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrPort.value = treeNode.outport;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrDeviceId.value = treeNode.value;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrChannel.value = treeNode.channel_id;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrStream.value = treeNode.code_type;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrLoginId.value = treeNode.login_id;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrLoginPwd.value = treeNode.login_pwd;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrPan_Tilt.value = treeNode.pan_tilt;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrButton.click();\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  else if(null != treeNode.ctype && treeNode.ctype == '-1' && document.getElementById('CurrJsp').innerText == 'dvrReal.html')\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "    if(null != treeNode.nindex)\n");
	fprintf(cgiOut, "      window.parent.frames.mainFrame.CurrNIndex.value = treeNode.nindex;\n");
	fprintf(cgiOut, "    window.parent.frames.mainFrame.CurrIP_Type.value = treeNode.getParentNode().ip_type;\n");
	fprintf(cgiOut, "    window.parent.frames.mainFrame.CurrINIP.value = treeNode.getParentNode().inip;\n");
	fprintf(cgiOut, "    window.parent.frames.mainFrame.CurrINPort.value = treeNode.getParentNode().inport;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrIP.value = treeNode.getParentNode().outip;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrPort.value = treeNode.getParentNode().outport;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrDeviceId.value = treeNode.getParentNode().value;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrChannel.value = treeNode.getParentNode().channel_id;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrStream.value = treeNode.getParentNode().code_type;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrLoginId.value = treeNode.getParentNode().login_id;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrLoginPwd.value = treeNode.getParentNode().login_pwd;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrPan_Tilt.value = treeNode.getParentNode().pan_tilt;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.CurrButton.click();\n");
	fprintf(cgiOut, "	 }\n");	
	fprintf(cgiOut, "}\n");
	
	/*-----------------------------��ʼ��----------------------------------*/
	fprintf(cgiOut, "function afterLoad()\n");
	fprintf(cgiOut, "{\n");
	if(ContainsFP(user_id, "0401"))
  {
  	fprintf(cgiOut, "window.parent.frames.mainFrame.location = 'dvrReal.html';\n");
  }
  else
  {
  	if(ContainsFP(user_id, "0402"))
	  {
	  	fprintf(cgiOut, "window.parent.frames.mainFrame.location = 'dvrHis.html';\n");
	  }
  }
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "afterLoad();\n");
  fprintf(cgiOut, "</SCRIPT>\n");
  fprintf(cgiOut, "</HTML>\n");
  fflush(stdout);
}

int sqlite3_exec_callback_userdata(void *data, int n_columns, char **col_values, char **col_names)
{
	int rc;
	char * zErrMsg = 0;
	char sql[128] = "";
	sprintf(sql, "select id, cname, point from ROLE where ID like '%s%%'", col_values[0]);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_tree, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	}
	return 0;
}

int sqlite3_exec_callback_tree(void *data, int n_columns, char **col_values, char **col_names)
{
	if(strlen(col_values[0]) >= 4 && col_values[0][0] == '9' && col_values[0][1] == '0')
	{
		switch(strlen(col_values[0]))
		{
			case 4:
				fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s', isParent:true, open:true, icon:'../../skin/images/root.png'};\n", col_values[0], col_values[1], col_values[0], col_values[0]);
				fprintf(cgiOut, "Nodes1.push(node);\n");
				break;
			case 6:
				fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s'.substring(0,4), isParent:true, open:true, icon:'../../skin/images/1_close.png'};\n", col_values[0], col_values[1], col_values[0], col_values[0]);
				fprintf(cgiOut, "Nodes1.push(node);\n");
				break;
			case 8:
				fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s'.substring(0,6), isParent:true};\n", col_values[0], col_values[1], col_values[0], col_values[0]);
				fprintf(cgiOut, "Nodes1.push(node);\n");
							
				if(NULL != col_values[2] && strlen(col_values[2]) > 6)
				{
					char *p = NULL;
					char *buffer = strdup(col_values[2]);
					p = strtok(buffer, ",");
					while(NULL != p)
					{
						char * save = p+strlen(p)+1;
						int rc;
						char * zErrMsg = 0;
						char sql[256] = "";			
						sprintf(sql, "select a.id, a.cname, a.upper, a.upper_channel, b.private_attr, a.preset, a.private_attr as self_private_attr, c.s_icon from device_detail a, device_detail b, device_info c where substr(a.id,1,6)=c.id and a.upper=b.id and a.id = '%s'", p);						
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_preset, col_values[0], &zErrMsg);
											
						p = strtok(save, ",");
					}
				}
				break;
		}
	}
	return 0;
}

int sqlite3_exec_callback_preset(void *data, int n_columns, char **col_values, char **col_names)
{
	char inip[20] = {0};
	char inport[10] = {0};
	char outip[20] = {0};
	char outport[10] = {0};
	char code_stream[5] = {0};
	char login_id[20] = {0};	
	char login_pwd[20] = {0};
	char pan_tilt[10] = {0};
	char ctype[7] = {0};

	sprintf(inip, "%s", define_sscanf(col_values[4], "inip="));
	sprintf(inport, "%s", define_sscanf(col_values[4], "inport="));
	strcpy(outip, define_sscanf(col_values[4], "outip="));
	strcpy(outport, define_sscanf(col_values[4], "outport="));
	strcpy(code_stream, define_sscanf(col_values[4], "code_stream="));
	strcpy(login_id, define_sscanf(col_values[4], "login_id="));
	strcpy(login_pwd, define_sscanf(col_values[4], "login_pwd="));
	strcpy(pan_tilt, define_sscanf(col_values[6], "pan_tilt="));
	strncpy(ctype, col_values[0], 6);
	
	fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s', icon:'../../system/%s', open:true, channel_id:'%s', outip:'%s', outport:'%s', code_type:'%s', login_id:'%s', login_pwd:'%s', ctype:'%s', pan_tilt:'%s', inip:'%s', inport:'%s', ip_type:%d};\n", col_values[0], col_values[1], col_values[0], (char *)data, col_values[7], col_values[3], outip, outport, code_stream, login_id, login_pwd, ctype, pan_tilt, inip, inport, ip_type);
	fprintf(cgiOut, "Nodes1.push(node);\n");
	
	char *p = NULL;
	char *buffer = strdup(col_values[5]);
	p = strtok(buffer, ";");
	while(NULL != p)
	{
		char tempNIndex[3] = {0};
		char tempCName[20] = {0};
		sscanf(p, "%[^','],%[^',']", tempNIndex, tempCName);
		
		fprintf(cgiOut, "var subnode = {id:'%s', name:'%s', value:'%s', pId:'%s', icon:'../../skin/images/preset.png', nindex:'%s', ctype:'-1', open:true};\n", tempNIndex, tempCName, tempNIndex, col_values[0], tempNIndex);
		fprintf(cgiOut, "Nodes1.push(subnode);\n");
		
		p = strtok(NULL, ";");
	}
	return 0;
}
