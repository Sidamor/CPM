#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

//��������
char user_id[31] = {0};
//��������
static void getHtmlData();
static void doIndex();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	doIndex();
	
	return 0;
}

void getHtmlData()
{
	cgiFormString("user_id", user_id, sizeof(user_id));
}

void doIndex()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<title>��������ƽ̨-Ӧ�ù���</title>\n");
	fprintf(cgiOut, "<meta http-equiv='x-ua-compatible' content='ie=7'/>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content='text/html; charset=gb2312'>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<frameset id='glb_frm' rows='*' cols='184,11,*' frameborder='NO' border='0' framespacing='0px'>\n");
	fprintf(cgiOut, "  <frame src='envTree.cgi?user_id=%s' name='leftFrame' scrolling='auto' noresize frameborder='NO'>\n", user_id);
	fprintf(cgiOut, "  <frame src='open.html'              name='ctr_frm'   id='ctr_frm'     noresize scrolling='no'  >\n");
	fprintf(cgiOut, "  <frame src=''                       name='mainFrame' scrolling='no'   noresize frameborder='NO'>\n");
	fprintf(cgiOut, "</frameset>\n");
	fprintf(cgiOut, "</html>\n");
}
