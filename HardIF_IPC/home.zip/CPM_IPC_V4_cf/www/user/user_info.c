#include <stdio.h>
#include "cgic.h"
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>

//��Ա��������
char Sql[1024] = {0};
int count = 0;
char cmd[4] = {0};
char FP_QX[5] = {0};
char FP_QXAll[1024] = {0};

//��user_info
char id[30] = {0};
char pwd[20] = {0};
char cname[20] = {0};
char sex[10] = {0};
char birthday[20] = {0};
char addr[50] = {0};
char tel[20] = {0};
char status[10] = {0};
char sp_role[10] = {0};
char hj_role[10] = {0};
char qx[10] = {0};
char newpwd[20] = {0};

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);

static void QueryData();
static int UpdateData();
static void Func_Sel();
static void SingleValidate();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_validate(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_funcsel(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_funcselall(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_funqx(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			count = 0;
			switch(atoi(cmd))
			{
				case 11://��Ϣ�޸�
					UpdateData();
					sprintf(cmd, "%s", "0");
				case 0:
					QueryData();
					break;
				case 13://�޸�����
					SingleValidate();
					if(count == 1)
					{
						UpdateData();
						printf("�����޸ĳɹ�!");
					}
					else
					{
						printf("�û������������!");
					}
					break;
				case 14:
					Func_Sel();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
	cgiCookieString("COOKIE_CNAME", id, sizeof(id));
	cgiFormString("pwd", pwd, sizeof(pwd));
	cgiFormString("cname", cname, sizeof(cname));	
	cgiFormString("sex", sex, sizeof(sex));
	cgiFormString("birthday", birthday, sizeof(birthday));
	cgiFormString("addr", addr, sizeof(addr));
	cgiFormString("tel", tel, sizeof(tel));
	cgiFormString("status", status, sizeof(status));
	cgiFormString("sp_role", sp_role, sizeof(sp_role));
	cgiFormString("hj_role", hj_role, sizeof(hj_role));
	cgiFormString("qx", qx, sizeof(qx));
	cgiFormString("newpwd", newpwd, sizeof(newpwd));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0:	//�û���Ϣ
      sprintf(Sql, "select t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role, t.dept_id, a.dept from user_info t, corp_info a where t.id='%s'", id);
			break;
		case 1:	//�޸������ѯ
      sprintf(Sql, "select t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role from user_info t where t.id = '%s' and t.pwd = '%s'", id, pwd);
			break;
		case 11://�޸���Ϣ
			strcat(Sql, "update user_info set cname = '");
			strcat(Sql, cname);
			strcat(Sql, "', birthday = '");
			strcat(Sql, birthday);
			strcat(Sql, "', addr = '");
			strcat(Sql, addr);
			strcat(Sql, "', tel = '");
			strcat(Sql, tel);
			strcat(Sql, "', sex = '");
			strcat(Sql, sex);
      strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
		case 13://�޸�����
			strcat(Sql, "update user_info set pwd='");
			strcat(Sql, newpwd);
			strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
	}
	return Sql;
}

static void QueryData()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>�û���Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};  </SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");

	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"user_info\" action=\"user_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<input id= 'user_info_submit' name='user_info_submit' type='submit' style='display:none;'>\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/user_info.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"50%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");

	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='100%%' colspan=4 align='right'><img style=\"cursor:hand\" src=\"../../skin/images/mini_button_submit.gif\" onclick='doEdit()'></td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='100%%' align='right' colspan=4>\n");
	fprintf(cgiOut, "<table width=\"100%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "<td width='35%%' align='left' id='id'>&nbsp</td>\n");
	
	fprintf(cgiOut, "<td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "<td width='35%%' align='left' id='dept_id'>&nbsp</td>\n");
	fprintf(cgiOut, "</tr>\n");

	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "<td width='35%%' align='left'><input type='text' id='cname' name='cname' value='' style='width:80%%;height:20px;' maxlength=5></td>\n");
	fprintf(cgiOut, "<td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "<td width='35%%' align='left'><select name='sex' id='sex' style='width:120px;height:20px'>\n");
	
	fprintf(cgiOut, "</select></td>\n");
	fprintf(cgiOut, "</tr>\n");

	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "<td width=\"35%%\"><input type='text' name='tel' id='tel' style='width:80%%;height:20px;' maxlength='15' value=''></td>\n");
	fprintf(cgiOut, "<td width='15%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "<td width=\"35%%\"><input type='text' name='birthday' id='birthday' onClick='WdatePicker({readOnly:true})' class='Wdate' size='10' style='width:120px' maxlength='10' value=''></td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ַ</td>\n");
	fprintf(cgiOut, "<td width='35%%' align='left'><input type='text' name='addr' id='addr' style='width:80%%;height:20px;' maxlength='50' value=''></td>\n");
	fprintf(cgiOut, "<td width='15%%' align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "<td width='35%%' align='left' id='status'>&nbsp</td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	/*
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='15%%' align='center'>Ȩ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "<td width='35%%' align='left' id='qx'>&nbsp</td>\n");
	fprintf(cgiOut, "<td width='15%%' align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "<td width='35%%' align='left' id='status'>&nbsp</td>\n");
	fprintf(cgiOut, "</tr>\n");
	*/
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "</tr>\n");

	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='11'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doEdit(){\n");
	fprintf(cgiOut, "if(user_info.cname.value.length < 1){alert('����д����');return;}\n");
	fprintf(cgiOut, "if(user_info.birthday.value.length < 1){alert('����д��������');return;}\n");
	fprintf(cgiOut, "if(user_info.tel.value.length < 1){alert('����д��ϵ��ʽ');return;}\n");
	fprintf(cgiOut, "if(user_info.addr.value.length < 1){alert('����д��ַ');return;}\n");
	fprintf(cgiOut, "if(confirm('ȷ�ϱ༭?')){\n");
	fprintf(cgiOut, "user_info.user_info_submit.click();\n");
	fprintf(cgiOut, "}}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

static int UpdateData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(atoi(cmd)), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(2);
	}
	sqlite3_close(db);
	return 0;
}

static void SingleValidate()
{
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(1);
	
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_validate, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{  
	count++;
	if(count == 1)
	{
		//t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role, t.dept_id, a.dept
		fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
		if(0 < strlen(col_values[12]))
		{
			char* split = ",";
			char* split_result = NULL;
			int i = 0;
			split_result = strtok(col_values[12], split);
			while(split_result != NULL)
			{
				i++;
				char * save = split_result+strlen(split_result)+1;	
				char pdept_id[5] = {0};
	    	char pdept_name[30] = {0};
	    		
	    	sprintf(pdept_id, "%d", i);	    		    	 	
				memcpy(pdept_id, StrLeftFillZero(pdept_id, 4), 5);
				memcpy(pdept_name, split_result, 30);
		
				if(0 == strcmp(pdept_id, col_values[11]))
				{
					fprintf(cgiOut, "document.getElementById('dept_id').innerText = '%s';\n", pdept_name);
					break;
				}	
				
				split_result = strtok(save, split);
			}
		}
		
		fprintf(cgiOut, "document.getElementById('id').innerText = '%s';\n", col_values[0]);	
		fprintf(cgiOut, "document.getElementById('cname').value = '%s';\n", col_values[1]);			
		fprintf(cgiOut, "document.getElementById('sex').value = '%s';\n", col_values[4]);
		//��ɾ��
		fprintf(cgiOut, "var sexlength = document.getElementById('sex').length;\n");	
	  fprintf(cgiOut, "for(var i=0; i<sexlength; i++){\n");
	  fprintf(cgiOut, "document.getElementById('sex').remove(0);\n");
		fprintf(cgiOut, "}\n");
		
		//������
		fprintf(cgiOut, "var objOption1 = document.createElement('OPTION');\n");
		fprintf(cgiOut, "objOption1.value = '0';\n");
		fprintf(cgiOut, "objOption1.text = '��';\n");
   	fprintf(cgiOut, "document.getElementById('sex').add(objOption1);\n");  
    fprintf(cgiOut, "if(%s == '0'){\n", col_values[4]);
    fprintf(cgiOut, "document.getElementById('sex').options[0].selected = 'true';\n");   	
    fprintf(cgiOut, "}\n");
		
		fprintf(cgiOut, "var objOption2 = document.createElement('OPTION');\n");
    fprintf(cgiOut, "objOption2.value = '1';\n");
		fprintf(cgiOut, "objOption2.text = 'Ů';\n");
   	fprintf(cgiOut, "document.getElementById('sex').add(objOption2);\n");  
    fprintf(cgiOut, "if(%s == '1'){\n", col_values[4]);
    fprintf(cgiOut, "document.getElementById('sex').options[1].selected = 'true';\n");   	
    fprintf(cgiOut, "}\n");
    
		fprintf(cgiOut, "document.getElementById('tel').value = '%s';\n", col_values[7]);
		fprintf(cgiOut, "document.getElementById('birthday').value = '%s';\n", col_values[5]);
		fprintf(cgiOut, "document.getElementById('addr').value = '%s';\n", col_values[6]);
		
		char statusname[10] = {0};
		switch(atoi(col_values[8]))
		{
			case 0:
					strcat(statusname, "����");
				break;
			case 1:
					strcat(statusname, "ע��");
				break;
		}
		//fprintf(cgiOut, "document.getElementById('qx').innerText = '%s';\n", col_values[13]);
		fprintf(cgiOut, "document.getElementById('status').innerText = '%s';\n", statusname);
		fprintf(cgiOut, "</SCRIPT>\n");
	}
	return 0;
}

int sqlite3_exec_callback_validate(void *data, int n_columns, char **col_values, char **col_names)
{
	count++;
	return 0;
}

static void Func_Sel()
{
	char user_id[31] = {0};
	cgiCookieString("COOKIE_CNAME", user_id, sizeof(user_id));
	
	char sql[128] = {0};
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	sprintf(sql, "select a.qx from user_info a where a.id='%s'", user_id);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_funqx, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(3);
	}
	if(0 == strcmp(FP_QX, "000"))
	{
		memset(FP_QXAll, 0, sizeof(FP_QXAll));
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "select a.id from fp_info a");
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_funcselall, 0, &zErrMsg);
		if( rc!=SQLITE_OK )
		{
		  err_msg(3);
		}
		printf("%s\n", FP_QXAll);
	}
	else
	{
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "select b.point from user_info a, role b where a.id='%s' and a.qx=b.id", user_id);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_funcsel, 0, &zErrMsg);
		if( rc!=SQLITE_OK )
		{
		  err_msg(3);
		}
	}
	
	sqlite3_close(db);
}

static int sqlite3_exec_callback_funqx(void *data, int n_columns, char **col_values, char **col_names)
{
	memset(FP_QX, 0, sizeof(FP_QX));
	memcpy(FP_QX, col_values[0], 5);
	return 0;
}

static int sqlite3_exec_callback_funcselall(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat(FP_QXAll, col_values[0]);
	strcat(FP_QXAll, ",");
	return 0;
}

static int sqlite3_exec_callback_funcsel(void *data, int n_columns, char **col_values, char **col_names)
{
	printf("%s\n", col_values[0]);
	return 0;
}
