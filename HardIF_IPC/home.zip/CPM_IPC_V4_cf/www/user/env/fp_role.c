#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

static void Func_Sel();
static int sqlite3_exec_callback_funcsel(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:		
			Func_Sel();
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('2')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void Func_Sel()
{
	char user_id[31] = {0};
	cgiCookieString("COOKIE_CNAME", user_id, sizeof(user_id));
	char sql[128] = {0};
	sprintf(sql, "select b.point from user_info a, role b where a.id='%s' and a.qx=b.id", user_id);
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_funcsel, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	}
	sqlite3_close(db);
}
static int sqlite3_exec_callback_funcsel(void *data, int n_columns, char **col_values, char **col_names)
{
	printf("%s\n", col_values[0]);
	return 0;
}



