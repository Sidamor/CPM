#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "util.h"
#include "session.h"
#include "cgic.h"
//��������
char table_name[64] = {0};
char dev_name[30] = {0};
FILE *csv_file = NULL;
char user_id[31] = {0};
char cmd[4] = {0};
int cnt = 0;
int cntAll = 0;
int TotalPage = 0;
int CurrPage = 0;
char id[15] = {0};
char ctype[5] = {0};
char BTime[30] = {0};
char ETime[30] = {0};
char Func_Sel_Id[2] = {0};
char flag[2] = {0};

//��������
static void getHtmlData();
void err_msg(int pType);
bool ContainsFP(char *pUser_Id, char *pFP_Id);
void getTableName(char *pFlag, char *pDate);
bool TableIsExit(char *pTableName);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_PageBar(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_dev_name(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_storemode(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_table_cnt(void *data, int n_columns, char **col_values, char **col_names);
//����
static void ExportData();
static int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain() 
{	
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			cntAll = 0;
			getTableName(flag, BTime);
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://����
					ExportData();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('2')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

void getHtmlData()
{
	cgiCookieString("COOKIE_CNAME", user_id, sizeof(user_id));
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("id", id, sizeof(id));
  cgiFormString("ctype", ctype, sizeof(ctype)); 
	cgiFormString("BTime", BTime, sizeof(BTime));
	cgiFormString("ETime", ETime, sizeof(ETime));
	cgiFormString("Func_Sel_Id", Func_Sel_Id, sizeof(Func_Sel_Id));
	cgiFormString("flag", flag, sizeof(flag));	
	char cPage[10] = {0};//ȡҳ��
	
	cgiFormString("CurrPage", cPage, sizeof(cPage));
	CurrPage = atoi(cPage);
}

void QueryData()
{
	fprintf(cgiOut, "<HTML>\n");
	fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>��ʷ����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script language='javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name='env_his' action='env_his.cgi' method='post' target='divFrame'>\n");
	fprintf(cgiOut, "  <table align=center style='margin:auto' cellpadding='0' cellspacing='0' border='0' width='100%%'>\n");
	fprintf(cgiOut, "    <tr>\n");
	fprintf(cgiOut, "      <td width='7%%' align='left'>\n");
	fprintf(cgiOut, "	       <select name='Func_Sel_Id' style='width:100px;height:20px' onChange='doSelect()'>\n");
	fprintf(cgiOut, "		       <option value='9' %s>ȫ��</option>\n", 0 == strcmp(Func_Sel_Id, "9")?"selected":"");
	fprintf(cgiOut, "			     <option value='0' %s>����</option>\n", 0 == strcmp(Func_Sel_Id, "0")?"selected":"");
	fprintf(cgiOut, "			     <option value='1' %s>�쳣</option>\n", 0 == strcmp(Func_Sel_Id, "1")?"selected":"");
	fprintf(cgiOut, "		     </select>\n");
	fprintf(cgiOut, "	     </td>\n");
	fprintf(cgiOut, "		   <td width='45%%' align='right'>\n");
	fprintf(cgiOut, "			   <input type='button' style='cursor:hand;width:60px;' onClick='doClose()'  value='����'>\n");
	fprintf(cgiOut, "			   <input type='button' style='cursor:hand;width:60px;' onClick='doExport()' value='����'>\n");
	fprintf(cgiOut, "		   </td>\n");
	fprintf(cgiOut, "	   </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <div id='down_bg_2'>\n");
	fprintf(cgiOut, "  <table align=center style='margin:auto;margin-top:2px;' cellpadding='0' cellspacing='0' border='1' width='100%%' bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr>\n");
	fprintf(cgiOut, "	     <td width=\"5%%\"  class='table_deep_blue'>SN</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>�豸</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>����</td>\n");
	fprintf(cgiOut, "		   <td width=\"15%%\" class='table_deep_blue'>ʱ��</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>��ֵ</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>״̬</td>\n");
	fprintf(cgiOut, "		   <td width=\"10%%\" class='table_deep_blue'>����</td>\n");
	fprintf(cgiOut, "		   <td width=\"15%%\" class='table_deep_blue'>����</td>\n");
	fprintf(cgiOut, "	   </tr>\n");
	
	//��ѯ��¼����
	if(strlen(id) > 0)
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}
		char sql[1024] = {0};	
		sprintf(sql, "SELECT COUNT(*) FROM %s A WHERE A.ID = '%s' AND A.CTYPE = '%s' AND A.CTIME >= '%s' AND A.CTIME <= '%s' ", table_name, id, ctype, BTime, ETime);
		if(9 != atoi(Func_Sel_Id))
		{
			strcat(sql, " AND A.STATUS = '");
			strcat(sql, Func_Sel_Id);
			strcat(sql, "'");
		}
		
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(1);
		}
		sqlite3_close(db);	
		if(cntAll%20 == 0)
		{
			TotalPage = cntAll/20;
		}
		else
		{
			TotalPage = cntAll/20 + 1;
		}
		if(CurrPage > TotalPage)
		{
			CurrPage = TotalPage;
		}
	}
	
	//��ϸ
	if(strlen(id) > 0)
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}		
		char sql[1024] = {0};
		int offset = CurrPage < 1 ? 0 : (CurrPage-1)*20;
		char tail[128] = {0};		
		sprintf(sql, "SELECT A.VALUE, A.CTIME, A.ID, A.FLAG, T.CNAME, E.ATTR_NAME, C.UNIT, A.CTYPE, A.STATUS, E.S_Define, A.LEVEL, A.DESC, D.CARD FROM %s A, device_detail T, DATA_TYPE C, DEVICE_ATTR D, DEVICE_ROLL E WHERE A.CTYPE = D.SN AND substr(A.ID,1,6) = D.ID AND A.CTYPE = E.SN AND A.ID = E.ID AND C.ID = D.ATTR_ID AND A.ID = T.ID AND A.ID = '%s' AND A.CTYPE = '%s' AND A.CTIME >= '%s' AND A.CTIME <= '%s' ", table_name, id, ctype, BTime, ETime);
		if(9 != atoi(Func_Sel_Id))
		{
			strcat(sql, " AND A.STATUS = '");
			strcat(sql, Func_Sel_Id);
			strcat(sql, "'");
		}
		sprintf(tail, " ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d", offset);
		strcat(sql, tail);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(1);
		}
		sqlite3_close(db);
	}
	
	for(int i=0; i<(20-cnt); i++)
	{
		fprintf(cgiOut, "<tr class='%s'>\n", 0 == i%2?"table_white_l":"table_blue");
		fprintf(cgiOut, "  <td width='5%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='15%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='15%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "</tr>\n");		
	}
		
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "    <td colspan='8' class='table_deep_blue' align='center'>\n");
	fprintf(cgiOut, "	     <table width='70%%' height='20'  border='0' cellpadding='0' cellspacing='0' >\n");
	fprintf(cgiOut, "		     <tr valign='bottom'>\n");
	fprintf(cgiOut, "			     <td nowrap align='center'>\n");
	fprintf(cgiOut, "            ҳ��:<strong>%d</strong>/<strong>%d</strong>\n", CurrPage, TotalPage);
	fprintf(cgiOut, "            <span>[��<b>%d</b>����¼]</span>\n", cntAll);
	fprintf(cgiOut, "            <a href=# onclick='GoPage(1)'>��ҳ</a>|<a href=# onclick='GoPage(%d)'>��һҳ</a>|<a href=# onclick='GoPage(%d)'>��һҳ</a>|<a href=# onclick='GoPage(%d)'>ĩ ҳ</a>|\n", CurrPage-1, CurrPage+1, TotalPage);
	fprintf(cgiOut, "            ����<input name='ToPage' type='text' style='width:30px;height:17px' size='2'>ҳ\n");
	fprintf(cgiOut, "            <input type='button' style='width:40px;height:20px' onClick='GoPage(env_his.ToPage.value)' value='ȷ��'/>\n");
	fprintf(cgiOut, "				   </td>\n");
	fprintf(cgiOut, "			   </tr>\n");
	fprintf(cgiOut, "		   </table>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'   value='0'>\n");
	fprintf(cgiOut, "<input type='hidden' name='id'    value='%s'>\n", id);
	fprintf(cgiOut, "<input type='hidden' name='ctype' value='%s'>\n", ctype);
	fprintf(cgiOut, "<input type='hidden' name='BTime' value='%s'>\n", BTime);
	fprintf(cgiOut, "<input type='hidden' name='ETime' value='%s'>\n", ETime);
	fprintf(cgiOut, "<input type='hidden' name='flag'  value='%s'>\n", flag);
	fprintf(cgiOut, "<input type='hidden' name='CurrPage' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=\"JavaScript\">\n");
	fprintf(cgiOut, "function doClose()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  parent.closeDiv();\n");
  fprintf(cgiOut, "}\n");
	//��ϸ
  fprintf(cgiOut, "function doSelect()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  env_his.submit();\n");
  fprintf(cgiOut, "}\n");
  //��ҳ
  fprintf(cgiOut, "function GoPage(pPage)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "	 if(pPage == '0')\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "	   pPage = '1';\n");
  fprintf(cgiOut, "	 }\n"); 
  fprintf(cgiOut, "  if(pPage == '')\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "	   alert('������Ŀ��ҳ�����ֵ!');\n");
  fprintf(cgiOut, "		 return;\n");
  fprintf(cgiOut, "	 }\n");
  fprintf(cgiOut, "	 if(pPage < 1)\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "		 alert('������ҳ������1');\n");
  fprintf(cgiOut, "		 return;\n");
  fprintf(cgiOut, "	 }\n");
  fprintf(cgiOut, "	 env_his.CurrPage.value = pPage;\n");
  fprintf(cgiOut, "	 env_his.submit();\n");
  fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doExport()\n");
	fprintf(cgiOut, "{\n");
	if(!ContainsFP(user_id, "020203"))
  {
  	fprintf(cgiOut, "alert('����Ȩ�޵�����ϸ!');return;\n");
  }
	fprintf(cgiOut, "  if(%d == 0)\n", cntAll);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�޼�¼�ɵ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "	 if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 req = new XMLHttpRequest();\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 req = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 req.onreadystatechange = callbackForName;\n");
  fprintf(cgiOut, "	 var url = 'env_his.cgi?cmd=1&id='+env_his.id.value+'&ctype='+env_his.ctype.value+'&BTime='+env_his.BTime.value+'&ETime='+env_his.ETime.value+'&Func_Sel_Id='+env_his.Func_Sel_Id.value+'&flag='+env_his.flag.value;\n");
	fprintf(cgiOut, "	 req.open('get', url, true);\n");
	fprintf(cgiOut, "	 req.send(null);\n");	
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackForName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var state = req.readyState;\n");
	fprintf(cgiOut, "	 if(4 != state)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 else\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 location.href = '../other/%s_E_' + env_his.BTime.value + '.csv';\n", user_id);
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");	
	
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(CurrPage < 1)
		CurrPage = 1;		
	int sn = (CurrPage-1)*20 + cnt;
	
	fprintf(cgiOut, "<tr class='%s'>\n", 0 == cnt%2?"table_white_l":"table_blue");
	fprintf(cgiOut, "  <td width='5%%' >%d</td>\n", sn);
	fprintf(cgiOut, "	 <td width='10%%'>%s</td>\n", col_values[4]);	//�豸
	fprintf(cgiOut, "	 <td width='10%%'>%s</td>\n", col_values[5]);	//����
	fprintf(cgiOut, "	 <td width='15%%'>%s</td>\n", col_values[1]);	//ʱ��
	
	char str_value[128] = {0};
	if(0 == strcmp(col_values[12], "1"))
	{
		memset(dev_name, 0, sizeof(dev_name));
		strcat(dev_name, col_values[3]);
		int rc;
		char * zErrMsg = 0;
		char sql[128] = {0};
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}
		sprintf(sql, "select a.cname from user_info a, card_manager b where a.sys_id = b.id and b.ic = '%s' ", col_values[0]);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_dev_name, 0, &zErrMsg);
		sqlite3_close(db);
		
		strcat(str_value, col_values[0]);
		strcat(str_value, col_values[6]);
		strcat(str_value, "(");
		strcat(str_value, dev_name);
		strcat(str_value, ")");
	}
	else
	{
		strcat(str_value, col_values[0]);
		strcat(str_value, col_values[6]);
	}
	fprintf(cgiOut, "	 <td width='10%%'>%s</td>\n", str_value);//��ֵ
	
	if(NULL == col_values[9] || strlen(col_values[9]) < 1)
	{
		char statusname[60] = {0};
		switch(atoi(col_values[8]))
		{
			case 0:
					strcat(statusname, "<font color=green>����</font>");
				break;
			case 1:
					strcat(statusname, "<font color=red>�쳣</font>");
				break;
		}
		fprintf(cgiOut, "  <td width='10%%' align=center>%s</td>\n", statusname);
	}
	else
	{
		char statusname[60] = "<font color=red>δ����</font>";	
		char *p;
		char *buffer = strdup(col_values[9]);			
		p = strtok(buffer, ";");
		int temp = 0;			
		while(p != NULL)
		{
			char * save = p+strlen(p)+1;
			temp++;
			char *temp_p;
			char *temp_buffer = strdup(p);
			temp_p = strtok(temp_buffer, ",");							
			//0,����;1,�쳣;
			char oldstatus[60] = {0};  //ԭʼֵ
			char newstatus[60] = {0};  //����
			int i = 0;
			while(temp_p != NULL)
			{
				switch(i)
				{
					case 0:
							sprintf(oldstatus, "%s", temp_p);
						break;
					case 1:
							if(0 == strcmp(col_values[8], "0"))
							{
								sprintf(newstatus, "<font color=green>%s</font>", temp_p);
							}							
							else
							{
								sprintf(newstatus, "<font color=red>%s</font>", temp_p);
							}
						break;
				}
				temp_p = strtok(NULL, ",");
				i++;
			}
			if(0 == strcmp(col_values[0], oldstatus))
			{
				memset(statusname, 0, sizeof(statusname));
				memcpy(statusname, newstatus, 60);
				break;
			}
			
			p = strtok(save, ";");	
		}
		
		fprintf(cgiOut, "  <td width='10%%' align=center>%s</td>\n", statusname);
	}
	if(NULL == col_values[10] || strlen(col_values[10]) < 1)
	{
		fprintf(cgiOut, "  <td width='10%%' align=center>��</td>\n");
	}
	else
	{
		fprintf(cgiOut, "  <td width='10%%' align=center>%s</td>\n", col_values[10]);
	}
	if(NULL == col_values[11] || strlen(col_values[11]) < 1)
	{
		fprintf(cgiOut, "  <td width='15%%' align=center>��</td>\n");
	}
	else
	{
		fprintf(cgiOut, "  <td width='15%%' align=center>%s</td>\n", col_values[11]);
	}
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

int sqlite3_exec_callback_PageBar(void *data, int n_columns, char **col_values, char **col_names)
{
	cntAll += atoi(col_values[0]);
	return 0;
}

int sqlite3_exec_callback_dev_name(void *data, int n_columns, char **col_values, char **col_names)
{
	memset(dev_name, 0, sizeof(dev_name));
	memcpy(dev_name, col_values[0], 30);
	return 0;
}

//�첽����
void ExportData()
{
	char file_path[100] = {0}; 
	strcpy(file_path, "../other/");
	strcat(file_path, user_id);		//�û���
	strcat(file_path, "_E_");			//����
	strcat(file_path, BTime);		  //��ʼʱ��
	strcat(file_path, ".csv");
	if(NULL != file_path)
	{
		csv_file = fopen(file_path, "w");
		chmod(file_path, 777);
		if(NULL != csv_file)
		{
			fputs("�豸,����,ʱ��,��ֵ,״̬,����,����\n", csv_file);
			int rc;
			char *zErrMsg;
			sqlite3 *db;
			if(0 == strcmp(flag, "1"))
			{
				db = open_db(DB_PATH_BAK);
			}
			else
			{
				db = open_db(DB_PATH);
			}
			char sql[1024] = {0};
			sprintf(sql, "SELECT A.VALUE, A.CTIME, A.ID, A.FLAG, T.CNAME, E.ATTR_NAME, C.UNIT, A.CTYPE, A.STATUS, E.S_Define, A.LEVEL, A.DESC, D.CARD FROM %s A, device_detail T, DATA_TYPE C, DEVICE_ATTR D, DEVICE_ROLL E WHERE A.CTYPE = D.SN AND substr(A.ID,1,6) = D.ID AND A.CTYPE = E.SN AND A.ID = E.ID AND C.ID = D.ATTR_ID AND A.ID = T.ID AND A.ID = '%s' AND A.CTYPE = '%s' AND A.CTIME >= '%s' AND A.CTIME <= '%s' ", table_name, id, ctype, BTime, ETime);
			if(9 != atoi(Func_Sel_Id))
			{
				strcat(sql, " AND A.STATUS = '");
				strcat(sql, Func_Sel_Id);
				strcat(sql, "'");
			}			
			strcat(sql, " ORDER BY A.CTIME DESC");
			rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
			if(rc != SQLITE_OK)
			{
				err_msg(2);
			}
			sqlite3_close(db);
		}	
		fclose(csv_file);	
	}
}

int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names)
{
	char record[2048] = {0};
	//��ֵ
	char str_value[128] = {0};
	if(0 == strcmp(col_values[12], "1"))
	{
		memset(dev_name, 0, sizeof(dev_name));
		strcat(dev_name, col_values[3]);
		int rc;
		char * zErrMsg = 0;
		char sql[128] = {0};
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}
		sprintf(sql, "select a.cname from user_info a, card_manager b where a.sys_id = b.id and b.ic = '%s' ", col_values[0]);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_dev_name, 0, &zErrMsg);
		sqlite3_close(db);
		
		strcat(str_value, col_values[0]);
		strcat(str_value, col_values[6]);
		strcat(str_value, "(");
		strcat(str_value, dev_name);
		strcat(str_value, ")");
	}
	else
	{
		strcat(str_value, col_values[0]);
		strcat(str_value, col_values[6]);
	}
	
	if(NULL == col_values[9] || strlen(col_values[9]) < 1)
	{
		char statusname[60] = {0};
		switch(atoi(col_values[8]))
		{
			case 0:
					strcat(statusname, "����");
				break;
			case 1:
					strcat(statusname, "�쳣");
				break;
		}
		char levelname[60] = {0};
		if(NULL == col_values[10] || strlen(col_values[10]) < 1)
		{
			strcat(levelname, "��");
		}
		else
		{
			strcat(levelname, col_values[10]);
		}
		char descname[128] = {0};
		if(NULL == col_values[11] || strlen(col_values[11]) < 1)
		{
			strcat(descname, "��");
		}
		else
		{
			strcat(descname, col_values[11]);
		}
		//"�豸,����,ʱ��,��ֵ,״̬,����,����\n"
		sprintf(record, "%s,%s,%s,%s,%s,%s,%s\n", col_values[4], col_values[5], col_values[1], str_value, statusname, levelname, descname);
	}
	else
	{
		char statusname[60] = "δ����";
		char *p;
		char *buffer = strdup(col_values[9]);			
		p = strtok(buffer, ";");
		int temp = 0;			
		while(p != NULL)
		{
			char * save = p+strlen(p)+1;
			temp++;
			char *temp_p;
			char *temp_buffer = strdup(p);
			temp_p = strtok(temp_buffer, ",");							
			//0,����;1,�쳣;
			char oldstatus[60] = {0};  //ԭʼֵ
			char newstatus[60] = {0};  //����
			int i = 0;
			while(temp_p != NULL)
			{
				switch(i)
				{
					case 0:
							sprintf(oldstatus, "%s", temp_p);
						break;
					case 1:
							sprintf(newstatus, "%s", temp_p);
						break;
				}
				temp_p = strtok(NULL, ",");
				i++;
			}
			if(0 == strcmp(col_values[0], oldstatus))
			{
				memset(statusname, 0, sizeof(statusname));
				memcpy(statusname, newstatus, 60);
				break;
			}
			
			p = strtok(save, ";");	
		}
		char levelname[60] = {0};
		if(NULL == col_values[10] || strlen(col_values[10]) < 1)
		{
			strcat(levelname, "��");
		}
		else
		{
			strcat(levelname, col_values[10]);
		}
		char descname[128] = {0};
		if(NULL == col_values[11] || strlen(col_values[11]) < 1)
		{
			strcat(descname, "��");
		}
		else
		{
			strcat(descname, col_values[11]);
		}
		//"�豸,����,ʱ��,��ֵ,״̬,����,����\n"
		sprintf(record, "%s,%s,%s,%s,%s,%s,%s\n", col_values[4], col_values[5], col_values[1], str_value, statusname, levelname, descname);
	}
	
	fputs(record, csv_file);
	return 0;
}

//��ȡ����
void getTableName(char *pFlag, char *pDate)
{
	//�洢ģʽ
	char storemode[2] = {0};
	int rc;
	char * zErrMsg = 0;
	char sql[128] = {0};
	strcat(sql, "select ColltStoreMode from config");
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_storemode, &storemode, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	if(NULL == storemode || 0 == strlen(storemode))
	{
		memset(storemode, 0, sizeof(storemode));
		memcpy(storemode, "0", 2);
	}
	
	//�������
	memset(table_name, 0, sizeof(table_name));
	switch(atoi(pFlag))
	{
		case 0:
				strcat(table_name, "DATA");
			break;
		case 1:
				switch(atoi(storemode))
				{
					case 0://������
						{
							strcat(table_name, "DATA");
							break;
						}
					case 1://������
						{
							char cpm_Year[5] = {0};
							char cpm_Mont[3] = {0};
							char cpm_Date[3] = {0};
							
							cpm_Year[0] = pDate[0];
							cpm_Year[1] = pDate[1];
							cpm_Year[2] = pDate[2];
							cpm_Year[3] = pDate[3];
							cpm_Year[4] = '\0';
							
							cpm_Mont[0] = pDate[5];
							cpm_Mont[1] = pDate[6];
							cpm_Mont[2] = '\0';
							
							cpm_Date[0] = pDate[8];
							cpm_Date[1] = pDate[9];
							cpm_Date[2] = '\0';
							
							if(atoi(cpm_Date) >= 1 && atoi(cpm_Date) <= 10)
							{
								strcat(table_name, "DATA_");
								strcat(table_name, cpm_Year);
								strcat(table_name, cpm_Mont);
								strcat(table_name, "01");
							}
							else if(atoi(cpm_Date) >= 11 && atoi(cpm_Date) <= 20)
							{
								strcat(table_name, "DATA_");
								strcat(table_name, cpm_Year);
								strcat(table_name, cpm_Mont);
								strcat(table_name, "11");
							}
							else if(atoi(cpm_Date) >= 21 && atoi(cpm_Date) <= 31)
							{
								strcat(table_name, "DATA_");
								strcat(table_name, cpm_Year);
								strcat(table_name, cpm_Mont);
								strcat(table_name, "21");
							}
							
							//��֤���Ƿ����
							if(!TableIsExit(table_name))
							{
								memset(table_name, 0, sizeof(table_name));
								strcat(table_name, "DATA");
							}
							break;
						}
					case 2://����
						{
							char cpm_Year[5] = {0};
							char cpm_Mont[3] = {0};
							char cpm_Date[3] = {0};
							
							cpm_Year[0] = pDate[0];
							cpm_Year[1] = pDate[1];
							cpm_Year[2] = pDate[2];
							cpm_Year[3] = pDate[3];
							cpm_Year[4] = '\0';
							
							cpm_Mont[0] = pDate[5];
							cpm_Mont[1] = pDate[6];
							cpm_Mont[2] = '\0';
							
							cpm_Date[0] = pDate[8];
							cpm_Date[1] = pDate[9];
							cpm_Date[2] = '\0';
							
							if(atoi(cpm_Date) >= 1 && atoi(cpm_Date) <= 15)
							{
								strcat(table_name, "DATA_");
								strcat(table_name, cpm_Year);
								strcat(table_name, cpm_Mont);
								strcat(table_name, "01");
							}
							else if(atoi(cpm_Date) >= 16 && atoi(cpm_Date) <= 31)
							{
								strcat(table_name, "DATA_");
								strcat(table_name, cpm_Year);
								strcat(table_name, cpm_Mont);
								strcat(table_name, "16");
							}
							
							//��֤���Ƿ����
							if(!TableIsExit(table_name))
							{
								memset(table_name, 0, sizeof(table_name));
								strcat(table_name, "DATA");
							}
							break;
						}
				}
			break;
	}
}

int sqlite3_exec_callback_storemode(void *data, int n_columns, char **col_values, char **col_names)
{
	char* mode = (char*)data;
	memcpy(mode, col_values[0], 2);
	return 0;
}

bool TableIsExit(char *pTableName)
{
	int table_cnt = 0;
	int rc;
	char * zErrMsg = 0;
	char sql[128] = {0};
	sprintf(sql, "select name from sqlite_master where type='table' and upper(name) = '%s'", pTableName);
	sqlite3 *db = open_db(DB_PATH_BAK);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_table_cnt, &table_cnt, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		return false;
	}
	sqlite3_close(db);
	
	if(table_cnt > 0)
		return true;
	else
		return false;
}

int sqlite3_exec_callback_table_cnt(void *data, int n_columns, char **col_values, char **col_names)
{
	int* userdata = (int*)data;
	*userdata += 1;
	
	return 0;
}
