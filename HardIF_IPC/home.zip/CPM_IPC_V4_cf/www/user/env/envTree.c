#include "cgic.h"
#include "sqlite3.h"
#include "session.h"
#include "util.h"

//��������
char user_id[31] = {0};
int cnt = 0;
//��������
static void Env_Tree();
static int sqlite3_exec_callback_attr_all(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_userdata(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_tree(void *data, int n_columns, char **col_values, char **col_names);
bool ContainsFP(char *pUser_Id, char *pFP_Id);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	cgiCookieString("COOKIE_CNAME", user_id, sizeof(user_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			Env_Tree();
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('2')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

void Env_Tree()
{
	fprintf(cgiOut, "<HTML>\n");
  fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>���ݷ���</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/zTreeStyle2.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery-1.4.4.min.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.core-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.excheck-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/jquery.ztree.exedit-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</HEAD>\n");
  fprintf(cgiOut, "<BODY style='background:#0B80CC;'>\n");
  fprintf(cgiOut, "  <div><ul id='areaTree' class='ztree'></ul></div>\n");
	fprintf(cgiOut, "  <div id='CurrJsp' style='display:none'></div>\n");
	fprintf(cgiOut, "  <input type='hidden' id='id' name='id' value=''>\n");
	fprintf(cgiOut, "  <input type='hidden' id='level' name='level' value=''>\n");
  fprintf(cgiOut, "</BODY>\n");
  fprintf(cgiOut, "<SCRIPT LANGUAGE='JavaScript'>\n");
  //��ϣ����
	fprintf(cgiOut, "var attrTable = new Object();\n");
	fprintf(cgiOut, "function addattr(key, value)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(key in attrTable)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    \n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    attrTable[key] = value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function exitattr(key)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(key in attrTable)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return false;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//������
	fprintf(cgiOut, "var rootValue3 = '';\n");
  fprintf(cgiOut, "var Nodes1 = [];\n");
  fprintf(cgiOut, "var setting = \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  edit: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    enable: false\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  data: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    simpleData:{enable: true}\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  callback: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    onClick: zTreeOnClick\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "};\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = "";
	
	//��������
	memset(sql, 0, sizeof(sql));
	strcat(sql, "select t.id, t.sn, t.attr_name from device_roll t order by t.id, t.sn");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_attr_all, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		
	}
	
	//������
	memset(sql, 0, sizeof(sql));
	sprintf(sql, "select HJ_ROLE from USER_INFO where ID = '%s'", user_id);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_userdata, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	}
	sqlite3_close(db);
	
	/*-----------------------------������----------------------------------*/
	fprintf(cgiOut, "$('#areaTree').empty();\n");
	fprintf(cgiOut, "$.fn.zTree.init($('#areaTree'), setting, Nodes1);\n");
	
	/*-----------------------------�����----------------------------------*/
	fprintf(cgiOut, "function zTreeOnClick(event, treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 if(document.getElementById('CurrJsp').innerText == 'env.html')\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "    document.getElementById('id').value = treeNode.value;\n");	
	fprintf(cgiOut, "	   document.getElementById('level').value = treeNode.level;\n");	
	fprintf(cgiOut, "    window.parent.frames.mainFrame.location = 'env.cgi?cmd=0&id='+document.getElementById('id').value+'&level='+document.getElementById('level').value;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 else if(document.getElementById('CurrJsp').innerText == 'env_graph.html')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('0' == treeNode.level || '1' == treeNode.level || '2' == treeNode.level)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    document.getElementById('id').value = treeNode.value;\n");	
	fprintf(cgiOut, "	   document.getElementById('level').value = treeNode.level;\n");
	fprintf(cgiOut, "		 window.parent.frames.mainFrame.env_graph.DoSubmit.click();\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");	
	fprintf(cgiOut, "function afterLoad()\n");
	fprintf(cgiOut, "{\n");
	if(ContainsFP(user_id, "0202"))
  {
  	fprintf(cgiOut, "document.getElementById('id').value = rootValue3;\n");
		fprintf(cgiOut, "document.getElementById('level').value = '3';\n");
  	fprintf(cgiOut, "var BTime = (new Date()).format('yyyy-MM-dd');\n");
  	fprintf(cgiOut, "window.parent.frames.mainFrame.location = 'env_graph.cgi?cmd=0&Func_Sel_Id=1&BTime='+BTime+'&id='+document.getElementById('id').value+'&level='+document.getElementById('level').value;\n");
  }
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "afterLoad();\n");
  fprintf(cgiOut, "</SCRIPT>\n");
  fprintf(cgiOut, "</HTML>\n");
  fflush(stdout);
}

int sqlite3_exec_callback_attr_all(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "addattr('%s%s', '%s');\n", col_values[0], col_values[1], col_values[2]);
	return 0;
}

int sqlite3_exec_callback_userdata(void *data, int n_columns, char **col_values, char **col_names)
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = "";
	sprintf(sql, "select id, cname, point from ROLE where ID like '%s%%'", col_values[0]);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_tree, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	}
	sqlite3_close(db);
	return 0;
}

int sqlite3_exec_callback_tree(void *data, int n_columns, char **col_values, char **col_names)
{
	if(strlen(col_values[0]) >= 4 && col_values[0][0] == '7' && col_values[0][1] == '0')
	{
		switch(strlen(col_values[0]))
		{
			case 4://����
					fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s', isParent:true, open:true, icon:'../../skin/images/root.png'};\n", col_values[0], col_values[1], col_values[0], col_values[0]);
					fprintf(cgiOut, "Nodes1.push(node);\n");
				break;
			case 6://����
					fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s'.substring(0,4), isParent:true, open:true, icon:'../../skin/images/1_close.png'};\n", col_values[0], col_values[1], col_values[0], col_values[0]);
					fprintf(cgiOut, "Nodes1.push(node);\n");
				break;
			case 8://����
					fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s'.substring(0,6), isParent:true, open:false};\n", col_values[0], col_values[1], col_values[0], col_values[0]);
					fprintf(cgiOut, "Nodes1.push(node);\n");
					
					if(NULL != col_values[2] && strlen(col_values[2]) > 6)
					{				
						char *p = NULL;
						char *buffer = strdup(col_values[2]);
						p = strtok(buffer, ",");
						while(NULL != p)
						{
							if(NULL != p && strlen(p) >= 6)
							{
								cnt++;
								if(1 == cnt)
								{
									fprintf(cgiOut, "rootValue3 = '%s';\n", p);
								}
								
								fprintf(cgiOut, "if(exitattr('%s'))\n", p);
								fprintf(cgiOut, "{\n");
								fprintf(cgiOut, "  var Strhash = attrTable['%s'];\n", p);
								fprintf(cgiOut, "  var subnode = {id:'%s', name:Strhash, value:'%s', pId:'%s', icon:'../../skin/images/camera.png', open:false};\n", p, p, col_values[0]);
								fprintf(cgiOut, "  Nodes1.push(subnode);\n");
								//fprintf(cgiOut, "delete(attrTable['%s']);\n", p);
								fprintf(cgiOut, "}\n");
							}
							
							p = strtok(NULL, ",");
						}
					}
				break;
		}
	}
	return 0;
}
