#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "util.h"
#include "session.h"
#include "cgic.h"
#include <time.h>

//��������
char cmd[4] = {0};
int cnt = 0;
int cntAll = 0;
int TotalPage = 0;
int CurrPage = 0;

char id[4096*8] = {0};
char level[2] = {0};
char BTime[30] = {0};//��ʼʱ��
char ETime[30] = {0};//����ʱ��
char flag[2] = {0};
char timeflag[2] = {0};
char user_id[31] = {0};
FILE *csv_file = NULL;
//��������
static void getHtmlData();
bool	ContainsFP(char *pUser_Id, char *pFP_Id);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_PageBar(void *data, int n_columns, char **col_values, char **col_names);
//����
static void ExportData();
static int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain() 
{	
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			cntAll = 0;
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 2://����
					ExportData();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('2')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("id", id, sizeof(id));
	cgiFormString("level", level, sizeof(level));
	cgiFormString("BTime", BTime, sizeof(BTime));
	cgiFormString("ETime", ETime, sizeof(ETime));
	cgiFormString("flag", flag, sizeof(flag));
	cgiFormString("timeflag", timeflag, sizeof(timeflag));
	cgiCookieString("COOKIE_CNAME", user_id, sizeof(user_id));
	
	char cPage[10] = {0};//ȡҳ��
	cgiFormString("CurrPage", cPage, sizeof(cPage));
	CurrPage = atoi(cPage);
}

void QueryData()
{
	char BDate[11] = {0};
	char EDate[11] = {0};
	if(strlen(BTime) > 1 && strlen(ETime) > 1)
	{
		strncpy(BDate, BTime, 10);
		strncpy(EDate, ETime, 10);
	}
	else
	{
		time_t nowtime;
		struct tm *timeinfo;
		time(&nowtime);
		timeinfo = localtime(&nowtime);
		int year, month, day, hour, min, sec;
		year = timeinfo->tm_year + 1900;
		month = timeinfo->tm_mon + 1;
		day = timeinfo->tm_mday;
		hour = timeinfo->tm_hour;
		min = timeinfo->tm_min;
		sec = timeinfo->tm_sec;
		
		sprintf(BDate, "%d-%02d-%02d", year, month, day);
		sprintf(EDate, "%d-%02d-%02d", year, month, day);		
		sprintf(BTime, "%s 00:00:00", BDate);
		sprintf(ETime, "%s 23:59:59", EDate);	
	}
	if(strlen(flag) < 1)
	{
		memset(flag, 0, sizeof(flag));
		memcpy(flag, "0", 2);
	}
	if(strlen(timeflag) < 1)
	{
		memset(timeflag, 0, sizeof(timeflag));
		memcpy(timeflag, "0", 2);
	}
	fprintf(cgiOut, "<HTML>\n");
	fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "  <TITLE>������ϸ</TITLE>\n");
	fprintf(cgiOut, "  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "  <link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "  <script type=\"text/javascript\" src=\"../../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "  <script language='javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "  <SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name='ats_info' action='ats_info.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "<table style='margin:auto' cellpadding='0' cellspacing='0' border='0' width='100%%'>\n");
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "	   <td width='50%%' align='left'>\n");
	fprintf(cgiOut, "		   <div>\n");
	fprintf(cgiOut, "		     ��ʼʱ��<input id='BDate' name='BDate' type='text' style=' width:90px;  background-color:#ffffff; border: 1 double #3491D6' value='%s' onClick='WdatePicker({readOnly:true})' class='Wdate' size='10' maxlength='10'>\n", BDate);
	fprintf(cgiOut, "			 	 ����ʱ��<input id='EDate' name='EDate' type='text' style=' width:90px;  background-color:#ffffff; border: 1 double #3491D6' value='%s' onClick='WdatePicker({readOnly:true})' class='Wdate' size='10' maxlength='10'>\n", EDate);
	fprintf(cgiOut, "			 </div>\n");
	fprintf(cgiOut, "		 </td>\n");
	fprintf(cgiOut, "		 <td width='50%%' align='right'>\n");
	fprintf(cgiOut, "			 <input style='cursor:hand;width:60px;' onClick='doSelect()' value='��ѯ' type='button'>\n");
	fprintf(cgiOut, "			 <input style='cursor:hand;width:60px;' onClick='doExport()' value='����' type='button'>\n");
	fprintf(cgiOut, "		 </td>\n");
	fprintf(cgiOut, "	 </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<div id='down_bg_2'>\n");
	fprintf(cgiOut, "<table style='margin:auto' cellpadding='0' cellspacing='0' border='1' width='100%%' bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "	   <td width=\"3%%\"  class=\"table_deep_blue\">SN</td>\n");
	fprintf(cgiOut, "		 <td width=\"10%%\" class=\"table_deep_blue\">�豸</td>\n");
	fprintf(cgiOut, "		 <td width=\"10%%\" class=\"table_deep_blue\">����</td>\n");
	fprintf(cgiOut, "		 <td width=\"10%%\" class=\"table_deep_blue\">ʱ��</td>\n");
	fprintf(cgiOut, "		 <td width=\"10%%\" class=\"table_deep_blue\">����</td>\n");
	fprintf(cgiOut, "		 <td width=\"10%%\" class=\"table_deep_blue\">��Ա</td>\n");
	fprintf(cgiOut, "	 </tr>\n");
	
	//��ѯ��¼����
	if(strlen(id) > 0)
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}
		char sql[4096*8] = {0};
		switch(atoi(level))
		{
			case 0:
			case 1:
			case 2:
					sprintf(sql, "SELECT COUNT(*) FROM ATS A WHERE A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.U_Id) = 1 ", BTime, ETime, id);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_PageBar, 0, &zErrMsg);
				break;
		}
		sqlite3_close(db);
		if(cntAll%20 == 0)
		{
			TotalPage = cntAll/20;
		}
		else
		{
			TotalPage = cntAll/20 + 1;
		}
		if(CurrPage > TotalPage)
		{
			CurrPage = TotalPage;
		}
	}
	
	//��ϸ
	if(strlen(id) > 0)
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db;
		if(0 == strcmp(flag, "1"))
		{
			db = open_db(DB_PATH_BAK);
		}
		else
		{
			db = open_db(DB_PATH);
		}
		char sql[4096*8] = {0};
		int offset = CurrPage < 1 ? 0 : (CurrPage-1)*20;
		switch(atoi(level))
		{
			case 0:
			case 1:
			case 2:
					sprintf(sql, "SELECT A.ID, A.CTYPE, A.CTIME, A.VALUE, B.CNAME, C.ATTR_NAME, D.CNAME FROM ATS A, DEVICE_DETAIL B, DEVICE_ROLL C, USER_INFO D WHERE A.ID = B.ID AND A.ID = C.ID AND A.CTYPE = C.SN AND A.U_ID = D.SYS_ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.U_ID) = 1 ORDER BY A.CTIME DESC LIMIT 20 OFFSET %d ", BTime, ETime, id, offset);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
				break;
		}
		sqlite3_close(db);
	}
	for(int i=0; i<(20-cnt); i++)
	{
		fprintf(cgiOut, "<tr class='%s'>\n", 0 == i%2?"table_white_l":"table_blue");
		fprintf(cgiOut, "  <td width='3%%' >&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "	 <td width='10%%'>&nbsp;</td>\n");
		fprintf(cgiOut, "</tr>\n");
	}
	
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "    <td colspan='6' class='table_deep_blue' align='center'>\n");
	fprintf(cgiOut, "	     <table width='70%%' height='20'  border='0' cellpadding='0' cellspacing='0' >\n");
	fprintf(cgiOut, "		     <tr valign='bottom'>\n");
	fprintf(cgiOut, "			     <td nowrap align='center'>\n");
	fprintf(cgiOut, "            ҳ��:\n");
	fprintf(cgiOut, "            <strong>%d</strong>/<strong>%d</strong>\n", CurrPage, TotalPage);
	fprintf(cgiOut, "            <span>[��<b>%d</b>����¼]</span>\n", cntAll);
	fprintf(cgiOut, "            <a href=# onclick='GoPage(1)'>��ҳ</a>");
	fprintf(cgiOut, "            |<a href=# onclick='GoPage(%d)'>��һҳ</a>", CurrPage-1);
	fprintf(cgiOut, "            |<a href=# onclick='GoPage(%d)'>��һҳ</a>", CurrPage+1);
	fprintf(cgiOut, "            |<a href=# onclick='GoPage(%d)'>ĩ ҳ</a>", TotalPage);
	fprintf(cgiOut, "            |����<input name='ToPage' type='text' style='width:30px;height:17px' size='2'>ҳ\n");
	fprintf(cgiOut, "            <input type='button' style='width:40px;height:20px' onClick='GoPage(ats_info.ToPage.value)' value='ȷ��'/>\n");
	fprintf(cgiOut, "				   </td>\n");
	fprintf(cgiOut, "			   </tr>\n");
	fprintf(cgiOut, "		   </table>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'   value='0'>\n");
	fprintf(cgiOut, "<input type='hidden' name='id'    value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='level' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='BTime' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='ETime' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='flag'  value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='timeflag' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='CurrPage' value=''>\n");
	fprintf(cgiOut, "<input name='DoSubmit' type='hidden' id='DoSubmit' onClick='doSelect()'/>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=\"JavaScript\">\n");
	if(0 == strcmp(timeflag, "1"))
	{
		fprintf(cgiOut, "var date = new Date();\n");
		fprintf(cgiOut, "date.setDate(date.getDate()-1);\n");
		fprintf(cgiOut, "var y = date.getFullYear();\n");
		fprintf(cgiOut, "var m = date.getMonth()+1;\n");
		fprintf(cgiOut, "var d = date.getDate();\n");	
		fprintf(cgiOut, "document.getElementById('EDate').value = y + '-' + StrLeftFillZero(m+'', 2) + '-'+ StrLeftFillZero(d+'', 2);\n");
	}
	//��ϸ
  fprintf(cgiOut, "function doSelect()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "  if(ats_info.BDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    ats_info.flag.value = '0';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(ats_info.BDate.value < now && ats_info.EDate.value < now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    ats_info.flag.value = '1';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(ats_info.BDate.value < now && ats_info.EDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    ats_info.flag.value = '1';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(ats_info.BDate.value < now && ats_info.EDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    ats_info.flag.value = '1';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(ats_info.BDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    ats_info.flag.value = '0';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  ats_info.BTime.value = ats_info.BDate.value + ' 00:00:00';\n");
	fprintf(cgiOut, "	 ats_info.ETime.value = ats_info.EDate.value + ' 23:59:59';\n");	
	fprintf(cgiOut, "  ats_info.id.value = window.parent.frames.leftFrame.id.value;\n");	
	fprintf(cgiOut, "  ats_info.level.value = window.parent.frames.leftFrame.level.value;\n");	
  fprintf(cgiOut, "	 ats_info.submit();\n");
  fprintf(cgiOut, "}\n");
  //��ҳ
  fprintf(cgiOut, "function GoPage(pPage)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "	 if(pPage == '0')\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "	   pPage = '1';\n");
  fprintf(cgiOut, "	 }\n"); 
  fprintf(cgiOut, "  if(pPage == '')\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "	   alert('������Ŀ��ҳ�����ֵ!');\n");
  fprintf(cgiOut, "		 return;\n");
  fprintf(cgiOut, "	 }\n");
  fprintf(cgiOut, "	 if(pPage < 1)\n");
  fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "		 alert('������ҳ������1');\n");
  fprintf(cgiOut, "		 return;\n");
  fprintf(cgiOut, "	 }\n");
  fprintf(cgiOut, "  var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "  if(ats_info.BDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    ats_info.flag.value = '0';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(ats_info.BDate.value < now && ats_info.EDate.value < now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    ats_info.flag.value = '1';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(ats_info.BDate.value < now && ats_info.EDate.value == now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    ats_info.flag.value = '1';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(ats_info.BDate.value < now && ats_info.EDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('��ʷ��ѯ�����������¼');\n");
  fprintf(cgiOut, "    ats_info.flag.value = '1';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '1';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else if(ats_info.BDate.value > now)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    ats_info.flag.value = '0';\n");
  fprintf(cgiOut, "    ats_info.timeflag.value = '0';\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "	 ats_info.CurrPage.value = pPage;\n");
  fprintf(cgiOut, "  ats_info.BTime.value = ats_info.BDate.value + ' 00:00:00';\n");
	fprintf(cgiOut, "	 ats_info.ETime.value = ats_info.EDate.value + ' 23:59:59';\n");
	fprintf(cgiOut, "  ats_info.id.value = window.parent.frames.leftFrame.id.value;\n");
	fprintf(cgiOut, "  ats_info.level.value = window.parent.frames.leftFrame.level.value;\n");
  fprintf(cgiOut, "	 ats_info.submit();\n");
  fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doExport()\n");
	fprintf(cgiOut, "{\n");
	if(!ContainsFP(user_id, "0502"))
  {
  	fprintf(cgiOut, "alert('����Ȩ�޵�����ϸ!');return;\n");
  }
	fprintf(cgiOut, "  if(%d == 0)\n", cntAll);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�޼�¼�ɵ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϵ���?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var now = new Date().format('yyyy-MM-dd');\n");
  fprintf(cgiOut, "    if(ats_info.BDate.value == now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      ats_info.flag.value = '0';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(ats_info.BDate.value < now && ats_info.EDate.value < now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      ats_info.flag.value = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(ats_info.BDate.value < now && ats_info.EDate.value == now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      ats_info.flag.value = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(ats_info.BDate.value < now && ats_info.EDate.value > now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      ats_info.flag.value = '1';\n");
  fprintf(cgiOut, "    }\n");
  fprintf(cgiOut, "    else if(ats_info.BDate.value > now)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      ats_info.flag.value = '0';\n");
  fprintf(cgiOut, "    }\n"); 
	fprintf(cgiOut, "    ats_info.id.value = window.parent.frames.leftFrame.id.value;\n");	
	fprintf(cgiOut, "    ats_info.level.value = window.parent.frames.leftFrame.level.value;\n");
	fprintf(cgiOut, "	   ats_info.BTime.value = ats_info.BDate.value + ' 00:00:00';\n");
	fprintf(cgiOut, "	   ats_info.ETime.value = ats_info.EDate.value + ' 23:59:59';\n");		
	fprintf(cgiOut, "	   if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new XMLHttpRequest();\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "		   req = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   req.onreadystatechange = callbackForName;\n");
	fprintf(cgiOut, "	   var url = 'ats_info.cgi?cmd=2&BTime='+ats_info.BTime.value+'&ETime='+ats_info.ETime.value+'&id='+ats_info.id.value+'&level='+ats_info.level.value+'&flag='+ats_info.flag.value;\n");
	fprintf(cgiOut, "	   req.open('get', url, true);\n");
	fprintf(cgiOut, "	   req.send(null);\n");	
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackForName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var state = req.readyState;\n");
	fprintf(cgiOut, "	 if(4 == state)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 location.href = '../other/%s_E_' + ats_info.BDate.value + '_' + ats_info.EDate.value + '.csv';\n", user_id);
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
  fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");	
}

int sqlite3_exec_callback_PageBar(void *data, int n_columns, char **col_values, char **col_names)
{
	cntAll += atoi(col_values[0]);
	return 0;
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(CurrPage < 1)
	{
		CurrPage = 1;	
	}	
	int sn = (CurrPage-1)*20 + cnt;
	
	fprintf(cgiOut, "<tr class='%s'>\n", 0 == cnt%2?"table_white_l":"table_blue");
	fprintf(cgiOut, "  <td width='3%%'  align=center>%d</td>\n", sn);
	fprintf(cgiOut, "	 <td width='10%%' align=center>%s</td>\n", col_values[4]);//�豸
	fprintf(cgiOut, "	 <td width='10%%' align=center>%s</td>\n", col_values[5]);//����
	fprintf(cgiOut, "	 <td width='10%%' align=center>%s</td>\n", col_values[2]);//ʱ��
	fprintf(cgiOut, "	 <td width='10%%' align=center>%s</td>\n", col_values[3]);//����
	fprintf(cgiOut, "  <td width='10%%' align=center>%s</td>\n", col_values[6]);//��Ա
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

//�첽����
void ExportData()
{
	char BDate[11] = {0};
	char EDate[11] = {0};
	if(strlen(BTime) > 1 && strlen(ETime) > 1)
	{
		strncpy(BDate, BTime, 10);
		strncpy(EDate, ETime, 10);
	}
	else
	{
		time_t nowtime;
		struct tm *timeinfo;
		time(&nowtime);
		timeinfo = localtime(&nowtime);
		int year, month, day, hour, min, sec;
		year = timeinfo->tm_year + 1900;
		month = timeinfo->tm_mon + 1;
		day = timeinfo->tm_mday;
		hour = timeinfo->tm_hour;
		min = timeinfo->tm_min;
		sec = timeinfo->tm_sec;
		
		sprintf(BDate, "%d-%02d-%02d", year, month, day);
		sprintf(EDate, "%d-%02d-%02d", year, month, day);
		sprintf(BTime, "%s 00:00:00", BDate);
		sprintf(ETime, "%s 23:59:59", EDate);	
	}
	if(strlen(flag) < 1)
	{
		memset(flag, 0, sizeof(flag));
		memcpy(flag, "0", 2);
	}
	if(strlen(timeflag) < 1)
	{
		memset(timeflag, 0, sizeof(timeflag));
		memcpy(timeflag, "0", 2);
	}	
	char file_path[100] = {0}; 
	strcpy(file_path, "../other/");
	strcat(file_path, user_id);		//�û���
	strcat(file_path, "_E_");			//����
	strcat(file_path, BDate);		  //��ʼʱ��
	strcat(file_path, "_");			  //����
	strcat(file_path, EDate);		  //��ֹʱ��
	strcat(file_path, ".csv");
	if(NULL != file_path)
	{
		csv_file = fopen(file_path, "w");
		chmod(file_path, 777);
		if(NULL != csv_file)
		{
			fputs("�豸,����,ʱ��,����,��Ա\n", csv_file);
			int rc;
			char *zErrMsg;
			sqlite3 *db;
			if(0 == strcmp(flag, "1"))
			{
				db = open_db(DB_PATH_BAK);
			}
			else
			{
				db = open_db(DB_PATH);
			}	
			char sql[4096*8] = {0};
			switch(atoi(level))
			{
				case 0:
				case 1:
				case 2:
						sprintf(sql, "SELECT A.ID, A.CTYPE, A.CTIME, A.VALUE, B.CNAME, C.ATTR_NAME, D.CNAME FROM ATS A, DEVICE_DETAIL B, DEVICE_ROLL C, USER_INFO D WHERE A.ID = B.ID AND A.ID = C.ID AND A.CTYPE = C.SN AND A.U_ID = D.SYS_ID AND A.CTIME >= '%s' AND A.CTIME <= '%s' AND contain('%s', A.U_ID) = 1 ORDER BY A.CTIME DESC ", BTime, ETime, id);
						sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
						rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Export, 0, &zErrMsg);
					break;
			}
			sqlite3_close(db);
		}	
		fclose(csv_file);	
	}		
}

int sqlite3_exec_callback_Export(void *data, int n_columns, char **col_values, char **col_names)
{
	char record[2048] = {0};
	sprintf(record, "%s,%s,%s,%s,%s\n", col_values[4], col_values[5], col_values[2], col_values[3], col_values[6]);
	fputs(record, csv_file);
	return 0;	
}
