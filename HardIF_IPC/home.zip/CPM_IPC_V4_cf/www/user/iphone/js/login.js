function loadcss(fileName)
{
	var fileref = document.createElement("link");
	fileref.setAttribute("rel", "stylesheet");
	fileref.setAttribute("type", "text/css");
	fileref.setAttribute("href", fileName);
	fileref.setAttribute("media", "screen");
	if(typeof fileref != "undefined")
	{
	
		document.getElementsByTagName("head")[0].appendChild(fileref);
	}
}
function replacecssfile(oldfilename, newfilename){
	var flag = 0;
	var targetelement =  "link" //determine element type to create nodelist using	

	var targetattr =  "href" //determine corresponding attribute to test for	

	var allsuspects=document.getElementsByTagName(targetelement)	

	for (var i=allsuspects.length; i>=0; i--){ //search backwards within nodelist for matching elements to remove	
		if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(oldfilename)!=-1){
			//alert("flag=1");	
		   	var newelement=loadcss(newfilename)	
		   	allsuspects[i].parentNode.replaceChild(newelement, allsuspects[i])	
			flag = 1;
		}
	}
	if(0 == flag)
	{
		//alert("flag=0");
		loadcss(newfilename);
	}
}
function orientationChange() {
    switch(window.orientation) {
    ����case 0:
			//alert("0");	
			replacecssfile("css/login90.css", "css/login.css");
            break;
    ����case -90:
			//alert("-90");	
			replacecssfile("css/login.css", "css/login90.css");
            break;
    ����case 90:  
			//alert("90");	
			replacecssfile("css/login.css", "css/login90.css");
            break;
    ����case 180:  
        ����break;
    };
};


var myScroll;
var a = 0;

function loaded() {
	setHeight();	// Set the wrapper height. Not strictly needed, see setHeight() function below.
	// Please note that the following is the only line needed by iScroll to work. Everything else here is to make this demo fancier.
	myScroll = new iScroll('scroller', {desktopCompatibility:true});
}
// Change wrapper height based on device orientation. Not strictly needed by iScroll, you may also use pure CSS techniques.
function setHeight() {
	//var headerH = document.getElementById('header').offsetHeight
	//	footerH = document.getElementById('footer').offsetHeight,,
	wrapperH = window.innerHeight;// - headerH;// - footerH;
	document.getElementById('wrapper').style.height = wrapperH  + 'px';
}
// Check screen size on orientation change
window.addEventListener('onorientationchange' in window ? 'orientationchange' : 'resize', setHeight, false);

addEventListener('load', function(){
    orientationChange();
    window.onorientationchange = orientationChange;
});
// Prevent the whole screen to scroll when dragging elements outside of the scroller (ie:header/footer).
// If you want to use iScroll in a portion of the screen and still be able to use the native scrolling, do *not* preventDefault on touchmove.
document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);

// Load iScroll when DOM content is ready.
document.addEventListener('DOMContentLoaded', loaded, false);