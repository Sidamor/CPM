#include <stdio.h>
#include "cgic.h"
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>

char user_id[31] = {0};
int cnt = 0;
//��������
static void getHtmlData();
void err_msg(int pType);
bool	ContainsFP(char *pUser_Id, char *pFP_Id);
//��ҳ
static void QueryData();
static int sqlite3_exec_callback_role(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_area(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, IPH_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			QueryData();
			break;
		case 1:
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "var expiration = new Date();\n");
			fprintf(cgiOut, "expiration.setTime(expiration.getTime() + 30*24*60*60*1000);\n");
			fprintf(cgiOut, "document.cookie = 'Auto_Login=0;path=/;expires=' + expiration.toGMTString();\n");
			fprintf(cgiOut, "location = 'iphindex.html';\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	
	return 0;
}

void getHtmlData()
{
	cgiCookieString("COOKIE_CNAME", user_id, sizeof(user_id));	
}

void QueryData()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>��������ƽ̨-Ӧ�ù���</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<meta name='viewport' content='width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;'/>\n");
	fprintf(cgiOut, "<script language='javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<meta name='apple-mobile-web-app-capable' content='yes' />\n");
	fprintf(cgiOut, "<meta name='apple-mobile-web-app-status-bar-style' content='black' />\n");
	fprintf(cgiOut, "<link rel='apple-touch-startup-image' href='images/myCustomStartupGraphic.png' />\n");
	fprintf(cgiOut, "<link rel= 'stylesheet' type='text/css' href='css/list.css '  media='screen'/> \n");
	fprintf(cgiOut, "<script type='text/javascript' src='js/iscroll.js?v3.7.1'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript'>\n");
	fprintf(cgiOut, "function getCookieName(name)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var bikky = document.cookie;\n");
	fprintf(cgiOut, "  name += '=';\n");
	fprintf(cgiOut, "  var i = 0;\n");
	fprintf(cgiOut, "  while(i < bikky.length)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var offset = i + name.length;\n");
	fprintf(cgiOut, "    if(bikky.substring(i, offset) == name)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var endstr = bikky.indexOf(';', offset);\n");
	fprintf(cgiOut, "      if(endstr == -1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        endstr = bikky.length;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      return unescape(bikky.substring(offset, endstr));\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    i = bikky.indexOf(' ', i) + 1;\n");
	fprintf(cgiOut, "    if(i == 0)\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  return null;\n");
	fprintf(cgiOut, "}\n");
	//��ȡCookie(RoleId��RoleName)��ת
	fprintf(cgiOut, "var RoleId = getCookieName('RId');\n");
	fprintf(cgiOut, "var RoleName = getCookieName('RName');\n");
	fprintf(cgiOut, "var AreaId = getCookieName('AreaId');\n");
	fprintf(cgiOut, "if(null == AreaId || 'null' == AreaId || AreaId.length != 8)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  AreaId = '';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "if(null != RoleId && null != RoleName && 'null' != RoleId && 'null' != RoleName && RoleId.Trim().length > 0 && RoleName.Trim().length > 0)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location.href = 'net_index.cgi?cmd=0&roleid='+RoleId+'&rolename='+RoleName+'&AreaId='+AreaId;\n");
	fprintf(cgiOut, "}\n");
	//��ҳ
	fprintf(cgiOut, "var myScroll;\n");
	fprintf(cgiOut, "var a = 0;\n");
	fprintf(cgiOut, "function setHeight() {\n");
	fprintf(cgiOut, "	var headerH = document.getElementById('header').offsetHeight,\n");
	fprintf(cgiOut, "		wrapperH = window.innerHeight - headerH;\n");
	fprintf(cgiOut, "	document.getElementById('wrapper').style.height = wrapperH + 'px';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function loaded() {\n");
	fprintf(cgiOut, "	setHeight();\n");
	fprintf(cgiOut, "	myScroll = new iScroll('scroller', {desktopCompatibility:true});\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "window.addEventListener('onorientationchange' in window ? 'orientationchange' : 'resize', setHeight, false);\n");
	fprintf(cgiOut, "document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);\n");
	fprintf(cgiOut, "document.addEventListener('DOMContentLoaded', loaded, false);\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");	
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY>\n");
	fprintf(cgiOut, "<form id='searchForm' action='' method='post'>\n");
	fprintf(cgiOut, "<div id='header'>\n");
	fprintf(cgiOut, "<h1>��������</h1>\n");
	fprintf(cgiOut, "<a class='leftButton' onclick='doReturnOut()'>ע��</a>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='wrapper'>\n");
	fprintf(cgiOut, "	<div id='scroller'>\n");
	fprintf(cgiOut, "		<ul id='thelist'>\n");
	
	/*Ȩ�޿���--��Ԫ����*/
	if(ContainsFP(user_id, "01"))
	{
		int rc;
		char * zErrMsg = 0;
		char sql[256] = "";
		sprintf(sql, "select a.ykt_role from user_info a where a.id = '%s'", user_id);
		sqlite3 *db = open_db(DB_PATH);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_role, 0, &zErrMsg);
		if( rc!=SQLITE_OK )
		{
		  err_msg(1);
		}
		sqlite3_close(db);
	}
	fprintf(cgiOut, "        </ul>\n");
	fprintf(cgiOut, "	</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function goNet(pRoleId, pRoleName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location.href = 'net_index.cgi?cmd=0&roleid='+pRoleId+'&rolename='+pRoleName;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doReturnOut()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ��ע��,�˳�ϵͳ?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var expiration = new Date();\n");
	fprintf(cgiOut, "    expiration.setTime(expiration.getTime() + 30*24*60*60*1000);\n");
	fprintf(cgiOut, "    document.cookie = 'Auto_Login=0;path=/;expires=' + expiration.toGMTString();\n");
	fprintf(cgiOut, "    location = 'iphindex.html';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_role(void *data, int n_columns, char **col_values, char **col_names)
{
	int rc;
	char * zErrMsg = 0;
	char sql1[1024] = {0};
	sqlite3 *db = open_db(DB_PATH);
	
	if(strlen(col_values[0]) > 0)
	{		
		sprintf(sql1, "select a.id, a.cname, a.point from role a where length(a.id) = 6 and a.id like '%s%s'", col_values[0], "%");
		rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_area, 0, &zErrMsg);
	}
	
	sqlite3_close(db);
	return 0;	
}

int sqlite3_exec_callback_area(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	fprintf(cgiOut, "<li class='arrow'><a onClick=\"goNet('%s', '%s');\" onTouchstart=\"this.style.background='rgba(0, 0, 0, 0.35)';\" onTouchend=\"this.style.background='rgba(255, 255, 255, 0.15)';\"><span>  <img class='icon' src='images/%d.gif' width='32px' height='30px' /></span>     %s</a></li>\n", col_values[0], col_values[1], cnt, col_values[1]);
	return 0;
}
