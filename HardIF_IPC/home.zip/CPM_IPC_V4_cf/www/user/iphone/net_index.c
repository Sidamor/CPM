#include <stdio.h>
#include "cgic.h"
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"

//��������
char AreaId[11] = {0};
char checkrolename[30] = {0};
int checka_cnt = 0;
int staudp = 30000;
char FillStr[1024] = {0};
int a_cnt = 0;
char cmd[4] = {0};
char user_id[31] = {0};
char id[4096] = {0};
char cmd_type[2] = {0};
char sn[9] = {0};
char object[257] = {0};
char cmdname[30] = {0};
char isobject[2] = {0};
char obj_insert[9] = {0};
char isflag[2] = {0};
char isflag2[2] = {0};
char checkindex[10] = {0};
char roleid[11] = {0};
char rolename[30] = {0};
char realdata[4096] = {0};
char realstat[4096] = {0};
char realsing[4096] = {0};
char realmode[4096] = {0};
//��������
static void getHtmlData();
void err_msg(int pType);
bool	ContainsFP(char *pUser_Id, char *pFP_Id);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//��ȡ���¶���
char *getB_NCmd(int pCType, char *pId, char *pModeId, char *pSN);
static int sqlite3_exec_callback_getB_NCmd(void *data, int n_columns, char **col_values, char **col_names);
//��Ԫ����-��ҳ
static void QueryData();
static int sqlite3_exec_callback_area(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_staudp(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_device_all(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cmd_all(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_call(void *data, int n_columns, char **col_values, char **col_names);
//ʵʱģʽ
static void RealModeSel();
//״̬����
static void RealStatus();
//Զ�̿���
static void ObjHtml();
static void Defence();
//ͨѶ
static int MsgSend(int flag);
char *getLocalIP();
char *StrRightFillSpace(char *strData, int len);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, IPH_WEB);
	switch(ret)
	{
		case 0:
			a_cnt = 0;
			switch(atoi(cmd))
			{
				case 0://��Ԫ����-��ҳ
						QueryData();
					break;
				case 3://��Ԫ����-Զ�̿���
						Defence();
					break;
				case 4://��Ԫ����-Զ�̿���
						ObjHtml();
					break;
				case 5://��Ԫ����-ʵʱģʽ
						RealModeSel();
					break;
				case 6://��Ԫ����-״̬����
						RealStatus();
					break;
			}
			break;
		case 1:
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "var expiration = new Date();\n");
			fprintf(cgiOut, "expiration.setTime(expiration.getTime() + 30*24*60*60*1000);\n");
			fprintf(cgiOut, "document.cookie = 'Auto_Login=0;path=/;expires=' + expiration.toGMTString();\n");
			fprintf(cgiOut, "location = 'iphindex.html';\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	
	return 0;
}

void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cmd_type", cmd_type, sizeof(cmd_type));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("object", object, sizeof(object));
	cgiFormString("cmdname", cmdname, sizeof(cmdname));
	cgiFormString("isobject", isobject, sizeof(isobject));
	cgiFormString("obj_insert", obj_insert, sizeof(obj_insert));
	cgiFormString("isflag", isflag, sizeof(isflag));
	cgiFormString("isflag2", isflag2, sizeof(isflag2));
	cgiFormString("checkindex", checkindex, sizeof(checkindex));
	cgiFormString("roleid", roleid, sizeof(roleid));
	cgiFormString("rolename", rolename, sizeof(rolename));
	cgiFormString("AreaId", AreaId, sizeof(AreaId));
	cgiCookieString("COOKIE_CNAME", user_id, sizeof(user_id));
}

void QueryData()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>��������ƽ̨-Ӧ�ù���</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<meta name='viewport' content='width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;'/>\n");
	fprintf(cgiOut, "<meta name='apple-mobile-web-app-capable' content='yes' />\n");
	fprintf(cgiOut, "<meta name='apple-mobile-web-app-status-bar-style' content='black' />\n");
	fprintf(cgiOut, "<link rel='apple-touch-startup-image' href='images/myCustomStartupGraphic.png' />\n");
	fprintf(cgiOut, "<link rel= 'stylesheet' type='text/css' href='css/main.css ' media='screen'/>\n");
	fprintf(cgiOut, "<script language='javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='js/main.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='js/iscroll.js?v3.7.1'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript'>\n");
	//����Cookie
	fprintf(cgiOut, "var RId = '%s';\n", roleid);
	fprintf(cgiOut, "var RName = escape('%s');\n", rolename);
	fprintf(cgiOut, "var expiration = new Date();\n");
	fprintf(cgiOut, "expiration.setTime(expiration.getTime() + 30*24*60*60*1000);\n");
	fprintf(cgiOut, "document.cookie = 'RId='+RId+';path=/;expires=' + expiration.toGMTString();\n");
	fprintf(cgiOut, "document.cookie = 'RName='+RName+';path=/;expires=' + expiration.toGMTString();\n");
	//ҳ��
	fprintf(cgiOut, "var myScroll;\n");
	fprintf(cgiOut, "var devScroll;\n");
	fprintf(cgiOut, "function loaded()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  setHeight();\n");
	fprintf(cgiOut, "  bgScroll = new iScroll('bgscroller', {desktopCompatibility:true, bounceLock:true });\n");
	fprintf(cgiOut, "  myScroll = new iScroll('scroller', {desktopCompatibility:true, bounceLock:true });\n");
	fprintf(cgiOut, "  devScroll = new iScroll('devscroller', {desktopCompatibility:true, bounceLock:true });\n");
	fprintf(cgiOut, "  detailScroll = new iScroll('detailscroller', {desktopCompatibility:true, bounceLock:true });\n");
	fprintf(cgiOut, "  ctlScroll = new iScroll('ctlscroller', {desktopCompatibility:true, bounceLock:true });\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function setHeight()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var headerH = document.getElementById('header').offsetHeight,\n");
	fprintf(cgiOut, "  bgH = window.innerHeight - headerH;\n");
	fprintf(cgiOut, "  document.getElementById('bg').style.height = bgH + 'px';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "window.addEventListener('onorientationchange' in window ? 'orientationchange' : 'resize', setHeight, false);\n");
	fprintf(cgiOut, "document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);\n");
	fprintf(cgiOut, "document.addEventListener('DOMContentLoaded', loaded, false);\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "<style>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background: rgba(10, 66, 104, 0.99);\n");
	fprintf(cgiOut, "  border:2px solid rgba(255, 255, 255, 0.6);\n");
	fprintf(cgiOut, "  -webkit-border-top-left-radius: 8px;\n");
	fprintf(cgiOut, "  -webkit-border-top-right-radius: 8px;\n");
	fprintf(cgiOut, "  -webkit-border-bottom-left-radius: 8px;\n");
	fprintf(cgiOut, "  -webkit-border-bottom-right-radius: 8px;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 70%%;\n");
	fprintf(cgiOut, "  height:120px;\n");
	fprintf(cgiOut, "  top:40%%;\n");
	fprintf(cgiOut, "  left:15%%;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<body >\n");
	fprintf(cgiOut, "<form id='searchForm' name='searchForm' action='' method='post'>\n");
	fprintf(cgiOut, "  <div id='header'>\n");
	fprintf(cgiOut, "	   <h1>%s</h1>\n", rolename);
	fprintf(cgiOut, "	   <a class='leftButton' onClick='doCancel()'>����</a>\n");
	fprintf(cgiOut, "	 </div>\n");
	fprintf(cgiOut, "	 <div id='bg'>\n");
	fprintf(cgiOut, "	 <div id='bgscroller'>\n");
	
	/*****************1.����*******************/
	fprintf(cgiOut, "	   <div id='wrapper'>\n");
	fprintf(cgiOut, "		   <div id='scroller'>\n");
	fprintf(cgiOut, "			   <ul id='thelist'>\n");
	
	//������Ŀ
	int rc;
	char * zErrMsg = 0;
	char sql[512] = "";
	sprintf(sql, "select a.id, a.cname, a.point from role a where length(a.id) = 8 and a.id like '%s%%'", roleid);
	sqlite3 *db = open_db(DB_PATH);
	sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_area, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
		err_msg(1);
	}
	
	fprintf(cgiOut, "	       </ul>\n");
	fprintf(cgiOut, "      </div>\n");
	fprintf(cgiOut, "    </div>\n");
	fprintf(cgiOut, "    <script>\n");
	//����JS��Ч
	fprintf(cgiOut, "    var topscr  = document.getElementById('scroller');\n");
	fprintf(cgiOut, "    var toplist = document.getElementById('thelist');\n");
	fprintf(cgiOut, "    var topli   = toplist.getElementsByTagName('li');\n");
	fprintf(cgiOut, "    var topw    = 0;\n");
	fprintf(cgiOut, "    for(var i=0,end=topli.length; i<end; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      topw += getWidth(topli[i]);\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    topscr.style.width = topw  + 'px';\n");
	
	//�豸��ϣ����
	fprintf(cgiOut, "    var hashDevTable = new Object();\n");
	fprintf(cgiOut, "    function addDev(key, value)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(key in hashDevTable)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        \n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        hashDevTable[key] = value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	
	//������ϣ����
	fprintf(cgiOut, "    var hashCmdTable = new Object();\n");
	fprintf(cgiOut, "    function addCmd(key, value)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(key in hashCmdTable)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        \n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        hashCmdTable[key] = value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	
	//��������
	memset(sql, 0, sizeof(sql));
	sprintf(sql, "select a.staudp from corp_info a");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_staudp, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	
	//ȫ���豸
	memset(sql, 0, sizeof(sql));
	sprintf(sql, "select a.id, a.brief, a.upper, a.upper_channel, a.be_on, a.status, a.ctype, b.icon, b.s_icon, a.cname from device_detail a, device_info b where substr(a.id,1,6) = b.id");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_device_all, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	
	//ȫ������
	memset(sql, 0, sizeof(sql));
	sprintf(sql, "select a.sn, a.id, c.cmdname, a.object, b.dev_id, a.flag, a.flag1, b.role_id from device_cmd a, act_limit b, device_act c where a.id = substr(c.id,1,6) and a.sn = c.sn and b.dev_id = c.id and b.dev_cmd = c.sn and b.dev_cmd = a.sn and substr(b.dev_id,1,6) = a.id and substr(b.role_id,1,6) = substr('%s',1,6) order by a.sn", roleid);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cmd_all, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	fprintf(cgiOut, "    </script>\n");
	
	/*****************2.�豸*******************/
	fprintf(cgiOut, "	   <div id='device'>\n");
	fprintf(cgiOut, "	     <span id='area_name' style=\"color:#7cbbde; font-size:18px; padding-left:8px;\">%s</span>&nbsp<img src='images/data.gif' width='12px', height='12px'>\n", checkrolename);
	fprintf(cgiOut, "		   <h id='device_name' text-align='left' style=\"font-size:14px; color:#0f0;\"></h>\n");
	fprintf(cgiOut, "		   <hr size=1 align=left noshade style='color: #fff;border-style:dotted;width:180px;'>\n");
	fprintf(cgiOut, "	     <div id='devscroller'>\n");
	fprintf(cgiOut, "		     <ul id='devlist'>\n");
	fprintf(cgiOut, "        </ul>\n");
	fprintf(cgiOut, "      </div>\n");
	fprintf(cgiOut, "    </div>\n");
	fprintf(cgiOut, "    <script>\n");
	//�豸JS��Ч
	fprintf(cgiOut, "    var devscr  = document.getElementById('devscroller');\n");
	fprintf(cgiOut, "    var devlist = document.getElementById('devlist');\n");
	fprintf(cgiOut, "    var devli   = devlist.getElementsByTagName('li');\n");
	fprintf(cgiOut, "    var devw    = 0;\n");
	fprintf(cgiOut, "    for(var j=0,end2=devli.length; j<end2; j++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      devw += getWidth(devli[j]);\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    devscr.style.width = devw + 20 +'px';\n");
	fprintf(cgiOut, "    </script>\n");
	
	/*****************3.����*******************/
  fprintf(cgiOut, "    <div id='detail'><div id='detailscroller'><div id='detailcontent'></div></div></div>\n");
  
	/*****************4.����*******************/
	fprintf(cgiOut, "    <div id='ctl'>\n");
	fprintf(cgiOut, "      <div id='ctlscroller'>\n");
	fprintf(cgiOut, "	       <ul id='ctllist'>\n");
	fprintf(cgiOut, "		     </ul>\n");
	fprintf(cgiOut, "	     </div>\n");
	fprintf(cgiOut, "    </div>	\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' id='Real' name='Real' value = ''>\n");
	fprintf(cgiOut, "<input type='hidden' id='checkdevindex' name='checkdevindex' value = '0'>\n");
	fprintf(cgiOut, "<div id='objDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	//fprintf(cgiOut, "  history.go(-1);\n");
	fprintf(cgiOut, "  var expiration = new Date();\n");
	fprintf(cgiOut, "  expiration.setTime(expiration.getTime() + 30*24*60*60*1000);\n");
	fprintf(cgiOut, "  document.cookie = 'RId=;path=/;expires=' + expiration.toGMTString();\n");
	fprintf(cgiOut, "  document.cookie = 'RName=;path=/;expires=' + expiration.toGMTString();\n");
	fprintf(cgiOut, "  document.cookie = 'AreaId=;path=/;expires=' + expiration.toGMTString();\n");
	fprintf(cgiOut, "  location = 'index.cgi';\n");
	fprintf(cgiOut, "}\n");
	
	//��ʾ����
	fprintf(cgiOut, "var showflag = '0';\n");
	fprintf(cgiOut, "function doShow()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if('0' == showflag)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('detailcontent').innerHTML = document.getElementById('Real').value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  setTimeout(\"doShow();\", 3000);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doShow();\n");
	
	//��Ŀ�л�
	fprintf(cgiOut, "var InterStatus;\n");
	fprintf(cgiOut, "function doAreaChange(pIndex, pId, pRoleId, pRoleName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  //��¼��ǰ����\n");
	fprintf(cgiOut, "  var expiration = new Date();\n");
	fprintf(cgiOut, "  expiration.setTime(expiration.getTime() + 30*24*60*60*1000);\n");
	fprintf(cgiOut, "  document.cookie = 'AreaId='+pRoleId+';path=/;expires=' + expiration.toGMTString();\n");
	fprintf(cgiOut, "  //���setInterval\n");
	fprintf(cgiOut, "  clearInterval(InterStatus);\n");
	fprintf(cgiOut, "  //���dev���li\n");
	fprintf(cgiOut, "  var ul = document.getElementById('devlist');\n");
	fprintf(cgiOut, "  var liList = ul.getElementsByTagName('li');\n");
	fprintf(cgiOut, "  var lilength = liList.length;\n");
	fprintf(cgiOut, "  for(var i=0; i<lilength; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    ul.removeChild(liList[0]);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  //���ำ��\n");
	fprintf(cgiOut, "  document.getElementById('area_name').innerHTML = pRoleName;\n");
	fprintf(cgiOut, "  document.getElementById('device_name').innerHTML = '';\n");
	fprintf(cgiOut, "  document.getElementById('detailcontent').innerHTML = '';\n");
	fprintf(cgiOut, "  document.getElementById('Real').value = '';\n");
	fprintf(cgiOut, "  document.getElementById('checkdevindex').value = '0';\n");
	fprintf(cgiOut, "  setTimeout(\"doAreaChangeGo('\"+ pIndex +\"','\"+ pId +\"','\"+ pRoleId +\"');\", 200);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doAreaChangeGo(pIndex, pId, pRoleId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  //////�豸//////\n");
	fprintf(cgiOut, "  var list = pId.split(',');\n");
	fprintf(cgiOut, "  var IdAll = '';\n");
	fprintf(cgiOut, "  var index_cnt = 0;\n");
	fprintf(cgiOut, "  var index_id = '';\n");
	fprintf(cgiOut, "  var index_name = '';\n");
	fprintf(cgiOut, "  var objHTML = '';\n");
	fprintf(cgiOut, "  for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var strDev = hashDevTable[list[i]];\n");
	fprintf(cgiOut, "    if(null != strDev && strDev.Trim().length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "		   index_cnt++;\n");
	fprintf(cgiOut, "			 var sublist = strDev.split('$');\n");
	fprintf(cgiOut, "      objHTML += \"<li>\";\n");
	fprintf(cgiOut, "      objHTML += \"  <a onclick=doDevChange(\"+i+\",'\"+sublist[0]+\"','\"+pRoleId+\"','0','\"+sublist[1]+\"') >\";\n");
	fprintf(cgiOut, "      objHTML += \"    <img id='img_sta\"+i+\"' src='../../system/\"+ sublist[2] +\"' width='32px' height='32px'/><br>\";\n");
	fprintf(cgiOut, "      objHTML +=       sublist[1] + \"<br>\";\n");
	fprintf(cgiOut, "      objHTML += \"    <h style='text-align:top;font-size:14px;color:#00ff00;' id='status\"+i+\"'></h>\";\n");
	fprintf(cgiOut, "      objHTML += \"  </a>\";\n");
	fprintf(cgiOut, "      objHTML += \"</li>\";\n");
	fprintf(cgiOut, "      if(1 == index_cnt)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        index_id = sublist[0];\n");
	fprintf(cgiOut, "        index_name = sublist[1];\n");
	fprintf(cgiOut, "        document.getElementById('device_name').innerHTML = sublist[1];\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      IdAll += sublist[0] + ',';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('devlist').innerHTML = objHTML;\n");
	fprintf(cgiOut, "  var devscr  = document.getElementById('devscroller');\n");
	fprintf(cgiOut, "  var devlist = document.getElementById('devlist');\n");
	fprintf(cgiOut, "  var devli   = devlist.getElementsByTagName('li');\n");
	fprintf(cgiOut, "  var devw    = 0;\n");
	fprintf(cgiOut, "  for(var j=0, end2=devli.length; j<end2; j++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    devw += getWidth(devli[j]);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  devscr.style.width = devw + 20 +'px';\n");
	fprintf(cgiOut, "  //////��ʱ//////\n");
	fprintf(cgiOut, "  if(IdAll.length >= 10)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    setTimeout(\"RealStatus('\"+IdAll+\"', '2', '');\",  500);\n");
	fprintf(cgiOut, "	 	 InterStatus = setInterval(\"RealStatus('\"+IdAll+\"', '2', '');\", %d);\n", staudp);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  //////����//////\n");
	fprintf(cgiOut, "  doDevChange(0, index_id, pRoleId, '0', index_name);\n");
	fprintf(cgiOut, "}\n");
	//�豸ѡ��
	fprintf(cgiOut, "var InterData;\n");
	fprintf(cgiOut, "function doDevChange(pIndex, pId, pRoleId, pType, pCName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  //���setInterval\n");
	fprintf(cgiOut, "  clearInterval(InterData);\n");
	fprintf(cgiOut, "  //���cmd���li\n");
	fprintf(cgiOut, "  var ctlul = document.getElementById('ctllist');\n");
	fprintf(cgiOut, "  var ctlliList = ctlul.getElementsByTagName('li');\n");
	fprintf(cgiOut, "  var ctllilength = ctlliList.length;\n");
	fprintf(cgiOut, "  for(var i=0; i<ctllilength; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    ctlul.removeChild(ctlliList[0]);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  //�豸��ֵ\n");
	fprintf(cgiOut, "  document.getElementById('device_name').innerHTML = pCName;\n");
	fprintf(cgiOut, "  document.getElementById('detailcontent').innerHTML = '';\n");
	fprintf(cgiOut, "  document.getElementById('Real').value = '';\n");
	fprintf(cgiOut, "  document.getElementById('checkdevindex').value = pIndex;\n");
	fprintf(cgiOut, "  setTimeout(\"doDevChangeGo('\"+ pIndex +\"','\"+ pId +\"','\"+ pRoleId +\"','\"+ pType +\"');\", 200);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doDevChangeGo(pIndex, pId, pRoleId, pType)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  //////����//////\n");
	fprintf(cgiOut, "  var cmdHTML = '<li>';\n");
	fprintf(cgiOut, "  var index_cnt = 0;\n");
	fprintf(cgiOut, "  for(var k in hashCmdTable)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if((pRoleId + pId) == k.substring(0,18))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var strCmd = hashCmdTable[k];\n");
	fprintf(cgiOut, "      if(null != strCmd && strCmd.Trim().length > 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(0 == index_cnt%%2 && index_cnt != 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          cmdHTML += '</li>';\n");
	fprintf(cgiOut, "          cmdHTML += '<li>';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        index_cnt++;\n");
	fprintf(cgiOut, "        var sublist = strCmd.split('$');\n");
	fprintf(cgiOut, "        cmdHTML += \"<input type='button' class='btn_blue' value='\"+sublist[2]+\"' onclick=doSend('\"+sublist[0]+\"','\"+sublist[3]+\"',\"+i+\",'\"+sublist[1]+\"','\"+sublist[4]+\"','\"+sublist[2]+\"','\"+sublist[5]+\"','\"+sublist[6]+\"') />\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  cmdHTML += '</li>';\n");
	fprintf(cgiOut, "  document.getElementById('ctllist').innerHTML = cmdHTML;\n");
	fprintf(cgiOut, "  //////��ʱ//////\n");
	fprintf(cgiOut, "  setTimeout(\"RealStatus('\"+pId+\"', '4', '\"+pIndex+\"');\", 500);\n");
	fprintf(cgiOut, "  InterData = setInterval(\"RealStatus('\"+pId+\"', '4', '\"+pIndex+\"');\", %d);\n", staudp);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doAreaChange('%d', '%s', '%s', '%s')\n", checka_cnt, id, roleid, checkrolename);
	
	//ʵʱģʽ
	fprintf(cgiOut, "var reqMode = null;\n");
	fprintf(cgiOut, "function RealModeSel(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqMode = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqMode = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqMode.onreadystatechange = function()\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var state = reqMode.readyState;\n");
	fprintf(cgiOut, "    if(state == 4)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var resp = reqMode.responseText;\n");
	fprintf(cgiOut, "      if(null != resp && resp.Trim().length > 4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var Mode = '';\n");
	fprintf(cgiOut, "        var modereal = resp.substring(4);\n");
	fprintf(cgiOut, "        if(modereal.indexOf('}') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "	         var list = modereal.split('}');\n");
	fprintf(cgiOut, "          for(var i=0; i<list.length && list[i].Trim().length>0; i++)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if(0 == i)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "              Mode += '<font color=#0f0>{ģʽ: '+ sublist[1] +'}</font>';\n");
	fprintf(cgiOut, "              Mode += '<font color=#0f0>{ֵ: '+ sublist[2] +'}</font>';\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        document.getElementById('Real').value = Mode + document.getElementById('Real').value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var url = 'net_index.cgi?cmd=5&id='+pId+'&currtime='+new Date();\n");
	fprintf(cgiOut, "  reqMode.open('GET',url,false);\n");
	fprintf(cgiOut, "  reqMode.send(null);\n");
	fprintf(cgiOut, "}\n");
	//״̬��ʱ����
	fprintf(cgiOut, "var reqSta = null;\n");
	fprintf(cgiOut, "function RealStatus(pId, pType, pIndex)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqSta = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqSta = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqSta.onreadystatechange = function()\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var state = reqSta.readyState;\n");
	fprintf(cgiOut, "    if(state == 4)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var resp = reqSta.responseText;\n");
	fprintf(cgiOut, "      if(null != resp && resp.Trim().length >= 4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        switch(parseInt(pType))\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          case 2:\n");
	fprintf(cgiOut, "              switch(parseInt(resp.substring(0,4)))\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                case 0:\n");
	fprintf(cgiOut, "                    var list = resp.substring(4).split(';');\n");
	fprintf(cgiOut, "                    for(var i=0; i<list.length && list[i].Trim().length>0; i++)\n");
	fprintf(cgiOut, "                    {\n");
	fprintf(cgiOut, "                      var show = '';\n");
	fprintf(cgiOut, "                      var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "                      switch(parseInt(sublist[1]))\n");
	fprintf(cgiOut, "                      {\n");
	fprintf(cgiOut, "                        case 0://��\n");
	fprintf(cgiOut, "                            show = '<font color=black>[' + sublist[2] + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+i).src = '../../system/b_icon/' + sublist[0].substring(0,6) + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 1://��\n");
	fprintf(cgiOut, "                            show = '<font color=gray >[' + sublist[2] + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+i).src = '../../system/g_icon/' + sublist[0].substring(0,6) + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 2://��\n");
	fprintf(cgiOut, "                            show = '<font color=red  >[' + sublist[2] + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+i).src = '../../system/r_icon/' + sublist[0].substring(0,6) + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 3://��\n");
	fprintf(cgiOut, "                            show = '<font color=#0f0 >[' + sublist[2] + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+i).src = '../../system/icon/' + sublist[0].substring(0,6) + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 4://��\n");
	fprintf(cgiOut, "                            show = '<font color=#0f0 >[' + sublist[2] + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+i).src = '../../system/c_icon/' + sublist[0].substring(0,6) + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 5://��\n");
	fprintf(cgiOut, "                            show = '<font color=#0f0 >[' + sublist[2] + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+i).src = '../../system/o_icon/' + sublist[0].substring(0,6) + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                      }\n");
	//fprintf(cgiOut, "                      document.getElementById('status'+i).innerHTML = show;\n");
	fprintf(cgiOut, "                    }\n");
	fprintf(cgiOut, "                  break;\n");
	fprintf(cgiOut, "                case 3006:\n");
	fprintf(cgiOut, "                    var list = pId.split(',');\n");
	fprintf(cgiOut, "                    for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "                    {\n");
	//fprintf(cgiOut, "                      document.getElementById('status'+i).innerHTML = '<font color=red>[δ֪]</font>';\n");
	fprintf(cgiOut, "                    }\n");
	fprintf(cgiOut, "                  break;\n");
	fprintf(cgiOut, "                default :\n");
	fprintf(cgiOut, "                    var list = pId.split(',');\n");
	fprintf(cgiOut, "                    for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "                    {\n");
	//fprintf(cgiOut, "                      document.getElementById('status'+i).innerHTML = '<font color=red>[δ֪]</font>';\n");
	fprintf(cgiOut, "                    }\n");
	fprintf(cgiOut, "                  break;\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "          	 break;\n");
	fprintf(cgiOut, "          case 4:\n");
	fprintf(cgiOut, "              switch(parseInt(resp.substring(0,4)))\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                case 0:\n");
	fprintf(cgiOut, "                    if(resp.len() >= 71)\n");
	fprintf(cgiOut, "                    {\n");
	fprintf(cgiOut, "              	       var Show = '';\n");
	fprintf(cgiOut, "              	       var Real = '';\n");
	fprintf(cgiOut, "                      var DId  = resp.substring(4, 10);\n");
	fprintf(cgiOut, "                      var statcolo = resp.substring(14, 15);\n");
	fprintf(cgiOut, "                      var statshow = subString(resp, 71).substring(15);\n");
	fprintf(cgiOut, "                      var datareal = resp.substring(resp.indexOf(statshow)+statshow.length);\n");
	fprintf(cgiOut, "                      switch(parseInt(statcolo))\n");
	fprintf(cgiOut, "                      {\n");
	fprintf(cgiOut, "                        case 0://��\n");
	fprintf(cgiOut, "                            Show = '<font color=black>[' + statshow.Trim() + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+pIndex).src = '../../system/b_icon/' + DId + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 1://��\n");
	fprintf(cgiOut, "                            Show = '<font color=gray >[' + statshow.Trim() + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+pIndex).src = '../../system/g_icon/' + DId + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 2://��\n");
	fprintf(cgiOut, "                            Show = '<font color=red  >[' + statshow.Trim() + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+pIndex).src = '../../system/r_icon/' + DId + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 3://��\n");
	fprintf(cgiOut, "                            Show = '<font color=#0f0 >[' + statshow.Trim() + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+pIndex).src = '../../system/icon/' + DId + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 4://��\n");
	fprintf(cgiOut, "                            Show = '<font color=#0f0 >[' + statshow.Trim() + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+pIndex).src = '../../system/c_icon/' + DId + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                        case 5://��\n");
	fprintf(cgiOut, "                            Show = '<font color=#0f0 >[' + statshow.Trim() + ']</font>';\n");
	fprintf(cgiOut, "                            document.getElementById('img_sta'+pIndex).src = '../../system/o_icon/' + DId + '.gif';\n");
	fprintf(cgiOut, "                          break;\n");
	fprintf(cgiOut, "                      }\n");
	fprintf(cgiOut, "                      if(datareal.indexOf('}') >= 0)\n");
	fprintf(cgiOut, "                      {\n");
	fprintf(cgiOut, "                        var list = datareal.split('}');\n");
	fprintf(cgiOut, "                        for(var i=0; i<list.length && list[i].Trim().length>0; i++)\n");
	fprintf(cgiOut, "                        {\n");
	fprintf(cgiOut, "                          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "                          switch(parseInt(sublist[4]))\n");
	fprintf(cgiOut, "                          {\n");
	fprintf(cgiOut, "                        	   case 0://����\n");
	fprintf(cgiOut, "                                Real += '<font color=#0f0>{' + sublist[1] + ' ' + sublist[2] + '}</font>';\n");
	fprintf(cgiOut, "                              break;\n");
	fprintf(cgiOut, "                            case 1://�쳣\n");
	fprintf(cgiOut, "                                Real += '<font color=red >{' + sublist[1] + ' ' + sublist[2] + '}</font>';\n");
	fprintf(cgiOut, "                              break;\n");
	fprintf(cgiOut, "                            default://��\n");
	fprintf(cgiOut, "                                Real += '<font color=red >{' + sublist[1] + ' ' + sublist[2] + '}</font>';\n");
	fprintf(cgiOut, "                              break;\n");
	fprintf(cgiOut, "                          }\n");
	fprintf(cgiOut, "                        }\n");
	fprintf(cgiOut, "                      }\n");
	//fprintf(cgiOut, "                      document.getElementById('status'+pIndex).innerHTML = Show;\n");
	fprintf(cgiOut, "                      document.getElementById('Real').value = Real;\n");
	fprintf(cgiOut, "                      RealModeSel(pId);\n");
	fprintf(cgiOut, "                    }\n");
	fprintf(cgiOut, "                  break;\n");
	fprintf(cgiOut, "                case 3006:\n");
	//fprintf(cgiOut, "                    document.getElementById('status'+pIndex).innerHTML = '<font color=red>[δ֪]</font>';\n");
	fprintf(cgiOut, "                    document.getElementById('Real').value = '<font color=red>��ѯʧ��!</font>';\n");
	fprintf(cgiOut, "                  break;\n");
	fprintf(cgiOut, "                default :\n");
	//fprintf(cgiOut, "                    document.getElementById('status'+pIndex).innerHTML = '<font color=red>[δ֪]</font>';\n");
	fprintf(cgiOut, "                    document.getElementById('Real').value = '<font color=red>��ѯʧ��!</font>';\n");
	fprintf(cgiOut, "                  break;\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            break;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        switch(parseInt(pType))\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          case 2:\n");
	fprintf(cgiOut, "              var list = pId.split(',');\n");
	fprintf(cgiOut, "              for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "              {\n");
	//fprintf(cgiOut, "                document.getElementById('status'+i).innerHTML = '<font color=red>[δ֪]</font>';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "          	 break;\n");
	fprintf(cgiOut, "          case 4:\n");
	//fprintf(cgiOut, "              document.getElementById('status'+pIndex).innerHTML = '<font color=red>[δ֪]</font>';\n");
	fprintf(cgiOut, "              document.getElementById('Real').value = '<font color=red>��ѯʧ��!</font>';\n");
	fprintf(cgiOut, "            break;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  };\n");
	fprintf(cgiOut, "  var url = 'net_index.cgi?cmd=6&id='+pId+'&cmd_type='+pType+'&currtime='+new Date();\n");
	fprintf(cgiOut, "  reqSta.open('GET',url,false);\n");
	fprintf(cgiOut, "  reqSta.send(null);\n");
	fprintf(cgiOut, "}\n");
	//����ִ��
  fprintf(cgiOut, "var reqSend = null;\n");
  fprintf(cgiOut, "function doSend(pSN, pObject, pCount, pId, pDId, pCmdName, pFlag, pFlag1)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  closeDiv();\n");
  fprintf(cgiOut, "  if('0' == pObject && '0' == pFlag1)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    var object = ' ';\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      reqSend = new XMLHttpRequest();\n");
  fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      reqSend = new ActiveXObject('Microsoft.XMLHTTP');\n");
  fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqSend.onreadystatechange = function(){callbackSendName(pSN, pCmdName, pDId)};\n");
	fprintf(cgiOut, "    var url = 'net_index.cgi?cmd=3&id='+pDId+'&sn='+pSN+'&object='+object+'&isflag='+pFlag;\n");
	fprintf(cgiOut, "    reqSend.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqSend.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqSend.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  else\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    document.getElementById('objDiv').style.display = 'block';\n");
	fprintf(cgiOut, "    var url = 'net_index.cgi?cmd=4&id='+pDId+'&sn='+pSN+'&cmdname='+pCmdName+'&isobject='+pObject+'&checkindex='+document.getElementById('checkdevindex').value+'&isflag2='+pFlag1;\n");
	fprintf(cgiOut, "    document.getElementById('objDiv').innerHTML = \"<iframe id='objFrame' name='objFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='no'></iframe>\";\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "}\n");  
  fprintf(cgiOut, "function callbackSendName(pSN, pCmdName, pDId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqSend.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqSend.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        showflag = '1';\n");
	fprintf(cgiOut, "        if(resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('detailcontent').innerHTML = '<font color=#0f0>����:['+pCmdName+'], ���:[�ɹ�]</font>';\n");
	fprintf(cgiOut, "          RealStatus(pDId, '4', document.getElementById('checkdevindex').value);\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else if(resp.indexOf('3000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('detailcontent').innerHTML = '<font color=#0f0>����:['+pCmdName+'], ���:[�ύ�ɹ�]</font>';\n");
	fprintf(cgiOut, "          RealStatus(pDId, '4', document.getElementById('checkdevindex').value);\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          document.getElementById('detailcontent').innerHTML = '<font color=red>����:['+pCmdName+'], ���:[ʧ��]</font>';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        setTimeout(\"showflag = '0';\", 4000);\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//�رյ�����
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('objDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_area(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != AreaId && strlen(AreaId) == 8)
	{
		if(0 == strcmp(AreaId, col_values[0]))
		{
			memset(id, 0 , sizeof(id));
			memset(roleid, 0 , sizeof(roleid));
			memset(checkrolename, 0, sizeof(checkrolename));
			strcat(id, col_values[2]);
			strcat(roleid, col_values[0]);
			strcat(checkrolename, col_values[1]);
			checka_cnt = a_cnt;
		}
	}
	else
	{
		if(a_cnt == 0)
		{
			memset(id, 0 , sizeof(id));
			memset(roleid, 0 , sizeof(roleid));
			memset(checkrolename, 0, sizeof(checkrolename));
			strcat(id, col_values[2]);
			strcat(roleid, col_values[0]);
			strcat(checkrolename, col_values[1]);
			checka_cnt = a_cnt;
		}
	}
	fprintf(cgiOut, "<li><a onTouchstart=\"this.style.background='rgba(0, 0, 0, 0.8)';\" onTouchend=\"this.style.background='rgba(0, 0, 0, 0)';\" onclick=\"doAreaChange('%d', '%s', '%s', '%s')\">%s</a></li>\n", a_cnt, col_values[2], col_values[0], col_values[1], col_values[1]);
	a_cnt++;					
	return 0;
}

int sqlite3_exec_callback_staudp(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != col_values[0] && atoi(col_values[0]) >= 10)
	{
		staudp = atoi(col_values[0])*1000;
	}
	else
	{
		staudp = 30000;
	}
	return 0;	
}

int sqlite3_exec_callback_device_all(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "addDev('%s', '%s$%s$%s');\n", col_values[0], col_values[0], col_values[1], col_values[7]);
	return 0;
}

int sqlite3_exec_callback_cmd_all(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "addCmd('%s%s%s', '%s$%s$%s$%s$%s$%s$%s');\n", col_values[7], col_values[4], col_values[0], col_values[0], col_values[1], col_values[2], col_values[3], col_values[4], col_values[5], col_values[6]);
	return 0;
}

void ObjHtml()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>Զ�̿���</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style='color:#fff;'>\n");
	fprintf(cgiOut, "<form name=\"ObjHtml\" action=\"net_index.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<table width=\"98%%\" align='center' style='margin:auto;margin-top:10px' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	
	//������ģʽ
	if(0 == strcmp(isflag2, "0"))
	{
		if(0 == strncmp(id, "001103", 6))
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='tel' style='width:90%%;height:20px' value='' maxlength=200>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='obj' style='width:90%%;height:20px' value='' maxlength=100>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
		else if(0 == strncmp(id, "001104", 6))
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='tel' style='width:90%%;height:20px' value='' maxlength=200>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <select name='obj' style='width:90%%;height:20px'>\n");
			
			int rc;
			char * zErrMsg = 0;
			sqlite3 *db = open_db(DB_PATH);
			char sql[128] = {0};
			sprintf(sql, "select a.sn, a.cname from call a");
			rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_call, 0, &zErrMsg);
			if(rc != SQLITE_OK)
			{
			  err_msg(1);
			}
			sqlite3_close(db);
			
			fprintf(cgiOut, "    </select>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
		else
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='obj' style='width:90%%;height:20px' value='' maxlength=256>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
	}
	//����ģʽ
	else if(0 == strcmp(isflag2, "1"))
	{
		fprintf(cgiOut, "<tr height='30'>\n");
		fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
		fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
		fprintf(cgiOut, "    <input type='text' name='obj_insert' style='width:90%%;height:20px' value='' maxlength=4>\n");
		fprintf(cgiOut, "  </td>\n");
		fprintf(cgiOut, "</tr>\n");	
		if(0 == strcmp(isobject, "1"))
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='obj' style='width:90%%;height:20px' value='' maxlength=256>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
	}
		
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>\n");	
	fprintf(cgiOut, "      <input type='button' value='�ر�' style='width:50px;height:22px' onClick=\"doCancel();\">\n");
	fprintf(cgiOut, "      <input type='button' value='�ύ' style='width:50px;height:22px' onClick=\"doSendObj('%s');\">\n", id);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	//doSend����
  fprintf(cgiOut, "var reqSend = null;\n");
  fprintf(cgiOut, "function doSendObj(pId)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  var object = '';\n");
  fprintf(cgiOut, "  var obj_insert = '';\n");
  fprintf(cgiOut, "  var isflag = '';\n");
  //������ģʽ
	if(0 == strcmp(isflag2, "0"))
	{
		fprintf(cgiOut, "var isflag = '0';\n");
	  fprintf(cgiOut, "if('001103' == pId.substring(0,6) || '001104' == pId.substring(0,6))\n");//���š�����
	  fprintf(cgiOut, "{\n");
	  fprintf(cgiOut, "  if(ObjHtml.tel.value.Trim().length < 1)\n");
	  fprintf(cgiOut, "  {\n");
	  fprintf(cgiOut, "    alert('���������');\n");
	  fprintf(cgiOut, "    return;\n");
	  fprintf(cgiOut, "  }\n");
	  fprintf(cgiOut, "  if(ObjHtml.obj.value.Trim().length < 1)\n");
	  fprintf(cgiOut, "  {\n");
	  fprintf(cgiOut, "    alert('����������');\n");
	  fprintf(cgiOut, "    return;\n");
	  fprintf(cgiOut, "  }\n");
	  fprintf(cgiOut, "  object = ObjHtml.tel.value + '//' + ObjHtml.obj.value;\n");
	  fprintf(cgiOut, "}\n");
	  fprintf(cgiOut, "else\n");
	  fprintf(cgiOut, "{\n");
	  fprintf(cgiOut, "  if(ObjHtml.obj.value.Trim().length < 1)\n");
	  fprintf(cgiOut, "  {\n");
	  fprintf(cgiOut, "    alert('����������');\n");
	  fprintf(cgiOut, "    return;\n");
	  fprintf(cgiOut, "  }\n");
	  fprintf(cgiOut, "  object = ObjHtml.obj.value;\n");
	  fprintf(cgiOut, "}\n");
	}
	//����ģʽ
	else if(0 == strcmp(isflag2, "1"))
	{
		fprintf(cgiOut, "var isflag = '3';\n");
		fprintf(cgiOut, "if(ObjHtml.obj_insert.value.Trim().length < 1)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('����д����ֵ');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "for(var i=0; i<ObjHtml.obj_insert.value.length; i++)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(isNaN(ObjHtml.obj_insert.value.charAt(i)))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('����ֵ���Ƿ��ַ�!');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "obj_insert = StrLeftFillZero(ObjHtml.obj_insert.value.Trim(), 4);\n");
		if(0 == strcmp(isobject, "1"))
		{
			fprintf(cgiOut, "if(ObjHtml.obj.value.Trim().length < 1)\n");
	  	fprintf(cgiOut, "{\n");
	  	fprintf(cgiOut, "  alert('����������');\n");
	  	fprintf(cgiOut, "  return;\n");
	  	fprintf(cgiOut, "}\n");
	  	fprintf(cgiOut, "object = ObjHtml.obj.value;\n");
		}
	}
	fprintf(cgiOut, "  if(object.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    object = ' ';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var len = object.len();\n");	
	fprintf(cgiOut, "  if(len > 256)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ݳ��ȹ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    reqSend = new XMLHttpRequest();\n");
  fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    reqSend = new ActiveXObject('Microsoft.XMLHTTP');\n");
  fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqSend.onreadystatechange = callbackSendName;\n");
	fprintf(cgiOut, "  var url = 'net_index.cgi?cmd=3&id=%s&sn=%s&object='+object+'&obj_insert='+obj_insert+'&isflag='+isflag;\n", id, sn);
	fprintf(cgiOut, "  reqSend.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqSend.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqSend.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackSendName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqSend.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqSend.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        parent.showflag = '1';\n");
	fprintf(cgiOut, "        if(resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "        {\n");	
	fprintf(cgiOut, "  				 parent.closeDiv();\n");
	fprintf(cgiOut, "          parent.document.getElementById('detailcontent').innerHTML = '<font color=#0f0>����:[%s], ���:[�ɹ�]</font>';\n", cmdname);
	fprintf(cgiOut, "          parent.RealStatus('%s', '4', '%s');\n", id, checkindex);
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else if(resp.indexOf('3000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "  				 parent.closeDiv();\n");
	fprintf(cgiOut, "          parent.document.getElementById('detailcontent').innerHTML = '<font color=#0f0>����:[%s], ���:[�ύ�ɹ�]</font>';\n", cmdname);
	fprintf(cgiOut, "          parent.RealStatus('%s', '4', '%s');\n", id, checkindex);
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "  				 parent.closeDiv();\n");
  fprintf(cgiOut, "          parent.document.getElementById('detailcontent').innerHTML = '<font color=red>����:[%s], ���:[ʧ��]</font>';\n", cmdname);
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        setTimeout(\"parent.showflag = '0';\", 4000);\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_call(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	return 0;	
}

void RealStatus()
{
	char resp[4096] = {0};
	int ret = MsgSend(atoi(cmd_type));
	switch(atoi(cmd_type))
	{
		case 2://�豸״̬��ѯ(2020)
				switch(ret)
				{
					case 0:
							strcat(resp, "3006");
						break;
					case 1:
							strcat(resp, "3006");
						break;
					case 2:
							strcat(resp, "0000");
							strcat(resp, realstat);
						break;
				}
			break;
		case 3://�豸���ݲ�ѯ(2021)
				switch(ret)
				{
					case 0:
							strcat(resp, "3006");
						break;
					case 1:
							strcat(resp, "3006");
						break;
					case 2:
							strcat(resp, "0000");
							strcat(resp, realdata);
						break;
				}
			break;
		case 4://����ִ�����״̬��ѯ(2001)
				switch(ret)
				{
					case 0:
							strcat(resp, "3006");
						break;
					case 1:
							strcat(resp, "3006");
						break;
					case 2:
							strcat(resp, "0000");
							strcat(resp, realsing);						
						break;
				}
			break;
	}
	//��ѯ����	
	printf("%s\n", resp);
}

//ʵʱģʽ
void RealModeSel()
{
	char resp[4096] = {0};
	int ret = MsgSend(5);
	switch(ret)
	{
		case 0:
				strcat(resp, "3006");
			break;
		case 1:
				strcat(resp, "3006");
			break;
		case 2:
				strcat(resp, "0000");
				strcat(resp, realmode);
			break;
	}
	//��ѯ����
	printf("%s\n", resp);
}

//Զ�̿���
void Defence()
{
	if(NULL != isflag && (0 == strcmp(isflag, "1") || 0 == strcmp(isflag, "2")))
	{
		int ret = MsgSend(5);
		switch(ret)
		{
			case 0:
					printf("9999\n");
				break;
			case 1:
			case 2:
					//����
					if(NULL != realmode && strstr(realmode, "}"))
					{
						char curr_Mode[5] = {0};
						char curr_SN[5] = {0};
						int i = 0;
						char* split_result = NULL;
				    char* savePtr = NULL;
				    split_result = strtok_r(realmode, "}", &savePtr);
				    while(NULL != split_result)
						{
							if(0 == i)
							{
								strncpy(curr_Mode, split_result+11, 4);
								strncpy(curr_SN, split_result+15, 4);
								break;
							}						
							i++;
							split_result = strtok_r(NULL, "}", &savePtr);
						}
						
						memset(sn, 0, sizeof(sn));
						memcpy(sn, getB_NCmd(atoi(isflag), id, curr_Mode, curr_SN), 9);
						if(NULL != sn && strlen(sn) == 8)
						{
							int ret2 = MsgSend(1);
							switch(ret2)
							{
								case 0:
										printf("9999\n");
									break;
								case 1:
										printf("3000\n");
									break;
								case 2:
										printf("0000\n");
									break;
							}
						}
						else
						{
							printf("9999\n");
						}						
					}
					else
					{
						printf("9999\n");
					}			
				break;
		}
	}
	else if(NULL != isflag && 0 == strcmp(isflag, "3"))
	{//����ģʽ
		int ret = MsgSend(5);
		switch(ret)
		{
			case 0:
					printf("9999\n");
				break;
			case 1:
			case 2:
					//����
					if(NULL != realmode && strstr(realmode, "}"))
					{
						char curr_Mode[5] = {0};
						char curr_SN[5] = {0};
						int i = 0;
						char* split_result = NULL;
				    char* savePtr = NULL;
				    split_result = strtok_r(realmode, "}", &savePtr);
				    while(NULL != split_result)
						{
							if(0 == i)
							{
								strncpy(curr_Mode, split_result+11, 4);
								strncpy(curr_SN, split_result+15, 4);
								break;
							}						
							i++;
							split_result = strtok_r(NULL, "}", &savePtr);
						}
						
						memset(sn, 0, sizeof(sn));
						strcat(sn, curr_Mode);
						strcat(sn, obj_insert);
						if(NULL != sn && strlen(sn) == 8)
						{
							int ret2 = MsgSend(1);
							switch(ret2)
							{
								case 0:
										printf("9999\n");
									break;
								case 1:
										printf("3000\n");
									break;
								case 2:
										printf("0000\n");
									break;
							}
						}
						else
						{
							printf("9999\n");
						}						
					}
					else
					{
						printf("9999\n");
					}			
				break;
		}	
	}
	else
	{
		int ret = MsgSend(1);
		switch(ret)
		{
			case 0:
					printf("9999\n");
				break;
			case 1:
					printf("3000\n");
				break;
			case 2:
					printf("0000\n");
				break;
		}
	}
}

char *getB_NCmd(int pCType, char *pId, char *pModeId, char *pSN)
{
	memset(FillStr, 0, sizeof(FillStr));
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	char sql[512] = {0};
	switch(pCType)
	{
		case 1://��һ����
				strcat(sql, "select a.b_sn from device_cmd a where a.id = substr('");
				strcat(sql, pId);
				strcat(sql, "',1,6) and a.sn = '");
				strcat(sql, pModeId);
				strcat(sql, pSN);
				strcat(sql, "'");
			break;
		case 2://��һ����
				strcat(sql, "select a.n_sn from device_cmd a where a.id = substr('");
				strcat(sql, pId);
				strcat(sql, "',1,6) and a.sn = '");
				strcat(sql, pModeId);
				strcat(sql, pSN);
				strcat(sql, "'");
			break;
	}
	
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_getB_NCmd, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	return FillStr;
}

int sqlite3_exec_callback_getB_NCmd(void *data, int n_columns, char **col_values, char **col_names)
{
	memcpy(FillStr, col_values[0], 9);
	return 0;
}

//�����߳�(0:ʧ��; 1:�ύ�ɹ�; 2:�����ɹ�)
int MsgSend(int flag)
{
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return 0;
	}
	
	//������װ
	BYTE outbuf[4096] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	int len = 0;
	switch(flag)
	{
		case 1://Զ�̿���
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00003002");
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 8));
				strcat(pdata, StrRightFillSpace(user_id, 10));
				strcat(pdata, StrRightFillSpace(object, 256));
				len = MSGHDRLEN + 20 + 8 + 10 + 8 + 10 + 256;
			break;
		case 2://�豸״̬��ѯ(2020)
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002020");
				strcat(pdata, id);
				len = MSGHDRLEN + 20 + 8 + strlen(id);
			break;
		case 3://�豸���ݲ�ѯ(2021)
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002021");
				strcat(pdata, StrRightFillSpace(id, 10));
				len = MSGHDRLEN + 20 + 8 + 10;
			break;
		case 4://����ִ�����״̬��ѯ(2001)
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002001");
				strcat(pdata, StrRightFillSpace(id, 10));
				len = MSGHDRLEN + 20 + 8 + 10;
			break;
		case 5://�豸ģʽ��ѯ
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002022");
				strcat(pdata, id);
				len = MSGHDRLEN + 20 + 8 + strlen(id);
			break;
	}
	
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	
	char *ip = getLocalIP();
	//����
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return 0;
	}
	pSock->SetCompletion();
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return 0;
	}
	
	char szBuf[4096] = {0};
	if(true == pSock->IsPending(30000))
	{
	 	if((len = pSock->Recv(szBuf, 4096)) <= 0) 
		{
			pSock->EndSocket();
			return 0;
		}		
		
		//AddMsg((BYTE *)szBuf, 100);
		pMsgHdr = (PMsgHdr)szBuf;
		char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
		
		if(0 == memcmp(pmsg+20, "0000", 4))
		{//������
			switch(flag)
			{
				case 2://�豸״̬��ѯ(2020)
						memset(realstat, 0, sizeof(realstat));
						strncpy(realstat, pmsg+28, 4096);
					break;
				case 3://�豸���ݲ�ѯ(2021)
						memset(realdata, 0, sizeof(realdata));
						strncpy(realdata, pmsg+28, 4096);
					break;
				case 4://����ִ�����״̬��ѯ(2001)
						memset(realsing, 0, sizeof(realsing));
						strncpy(realsing, pmsg+28, 4096);
					break;
				case 5://�豸ģʽ��ѯ
						memset(realmode, 0, sizeof(realmode));
						strncpy(realmode, pmsg+28, 4096);
					break;
			}
			pSock->EndSocket();
			return 2;
		}
		else if(0 == memcmp(pmsg+20, "0001", 4))
		{//Ҫ����
			
			pSock->EndSocket();
			return 2;
		}
		else if(0 == memcmp(pmsg+20, "3000", 4))
		{
			pSock->EndSocket();
			return 1;
		}
		else
		{
			pSock->EndSocket();
			return 0;
		}
	}
	else
	{
		pSock->EndSocket();
		return 0;
	}
	
	//�ر�����
	pSock->EndSocket();
	return 0;
}

char *StrRightFillSpace(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	int FillLen = len - strlen(strData);
	strcat(FillStr, strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(FillStr, " ");
	}
	return FillStr;
}
