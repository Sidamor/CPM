#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"
#include "IniFile.h"
#include <time.h>

//��������
int cnt = 0;
char FillStr[1024] = {0};

//��������
void HandleSubmit(char *username, char *password, char *link, char *iphweb);
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_permit(void *data, int n_columns, char **col_values, char **col_names);
bool isPermit();
int MsgSend(char *pro_SIM);
char *getLocalIP();
char *StrRightFillSpace(char *strData, int len);

int cgiMain()
{
	char link[3]   = {0};
	char iphweb[2] = {0};
  char username[20] = {0};
  char password[20] = {0};
  cgiFormString("link",   link,   sizeof(link));
  cgiFormString("iphweb", iphweb, sizeof(iphweb));
	cgiFormString("username", username, sizeof(username));
	cgiFormString("password", password, sizeof(password));
	
	HandleSubmit(username, password, link, iphweb);
  return 0;
}

void HandleSubmit(char *username, char *password, char *link, char *iphweb)
{
	cnt = 0;
	char url[50]  = {0};
	char *zErrMsg = 0;
	sqlite3 *db   = 0;
	char sql[256] = {0};
	sprintf(sql, "select * from user_info where id = '%s' and pwd = '%s' and status = '0'", username, password);
	
	//�����ݿ�
	if(SQLITE_OK != sqlite3_open(DB_PATH, &db))
	{
		fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
	}
	
	//�ȴ�����
	sqlite3_busy_timeout(db, 2000);
	
	//����
	if(SQLITE_OK != sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg))
	{
		fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
	}
	
	//�ر����ݿ�
	sqlite3_close(db);
	
	if(0 == cnt)
	{
		fprintf(cgiOut, "Content-Type:text/html\n\n");
		fprintf(cgiOut, "<script language='javascript'>\n");
		fprintf(cgiOut, "var date = new Date();\n");
		fprintf(cgiOut, "date.setTime(date.getTime()-10000);\n");
		fprintf(cgiOut, "document.cookie = 'password=;path=/;expire='+date.toGMTString();\n");
		fprintf(cgiOut, "</script>\n");
		strcpy(url, "/index.html");
	}
	else
	{
		//���뻺��
		char *session_id;
		session_id = set_session(username, password, iphweb);
		if(NULL == session_id || 1 > strlen(session_id))
		{
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
		}
		else
		{
			printf("Set-Cookie:COOKIE_CNAME=%s;path=/;\n", username);
			printf("Set-Cookie:session_id=%s;path=/;\n", session_id);
		}
		
		//������ת
		if(0 == strcmp("system", username))
		{
			strcpy(url, "/system/index.html");
		}
		else if(0 == strcmp("admin", username))
		{
			strcpy(url, "/admin/main.html");
			//ƽ̨����-����
			if(0 == strcmp("00", link))
			{
				memset(url, 0, sizeof(url));
				strcpy(url, "/admin/link/main.html");
			}
		}
		else
		{
			if(!isPermit())
			{
				fprintf(cgiOut, "Content-Type:text/html;charset=gb2312\n\n");
				fprintf(cgiOut, "<script language='javascript'>\n");
				fprintf(cgiOut, "var date = new Date();\n");
				fprintf(cgiOut, "date.setTime(date.getTime()-10000);\n");
				fprintf(cgiOut, "document.cookie = 'password=;path=/;expire='+date.toGMTString();\n");
				fprintf(cgiOut, "alert('����CPM������δͨ����Ȩ���޷�����Ӧ��ϵͳ�������������ϵ��ѯ����!');\n");
				fprintf(cgiOut, "parent.location = '../index.html';\n");
				fprintf(cgiOut, "</script>\n");
			}
			else
			{
				strcpy(url, "/user/index.html");
				//ƽ̨����-��ҳ
				if(0 == strcmp("00", link))
				{
					memset(url, 0, sizeof(url));
					strcat(url, "/user/link/index.cgi?cmd=0&user_id=");
					strcat(url, username);
				}
				//ƽ̨����-ʵʱ���
				else if(0 == strcmp("01", link))
				{
					memset(url, 0, sizeof(url));
					strcat(url, "/user/link/net.cgi?user_id=");
					strcat(url, username);
				}
				//ƽ̨����-���ݼ��
				else if(0 == strcmp("02", link))
				{
					memset(url, 0, sizeof(url));
					strcat(url, "/user/link/env.cgi?user_id=");
					strcat(url, username);
				}
				//ƽ̨����-��־����
				else if(0 == strcmp("03", link))
				{
					memset(url, 0, sizeof(url));
					strcat(url, "/user/link/log.cgi?user_id=");
					strcat(url, username);
				}
				//ƽ̨����-��Ƶ���
				else if(0 == strcmp("04", link))
				{
					memset(url, 0, sizeof(url));
					strcat(url, "/user/link/dvr.cgi?user_id=");
					strcat(url, username);
				}
				//ƽ̨����-����ϵͳ
				else if(0 == strcmp("05", link))
				{
					memset(url, 0, sizeof(url));
					strcat(url, "/user/link/ats.cgi?user_id=");
					strcat(url, username);
				}
			}
		}
	}
	
	toURL(url);
}

static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

//��Ȩ��֤
bool isPermit()
{
	bool retVal = true;
	
	int rc;
	char * zErrMsg = 0;
	char persql[256] = {0};
	strcat(persql, "select t.pro_date, t.pro_sim, t.pro_tel, t.is_ctrl from pro_ctrl t");
	sqlite3 *db = open_db(DB_PATH);	
	rc = sqlite3_exec(db, persql, &sqlite3_exec_callback_permit, &retVal, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  retVal = false;
	}
	sqlite3_close(db);
	
	return retVal;
}

int sqlite3_exec_callback_permit(void *data, int n_columns, char **col_values, char **col_names)
{
	//t.pro_date, t.pro_sim, t.pro_tel, t.is_ctrl
	bool* retVal = (bool*)data;
	if(0 == strcmp(col_values[3], "0"))
	{
		*retVal = true;
	}
	else
	{
		if(NULL == col_values[0] || strlen(col_values[0]) < 1 
		|| NULL == col_values[1] || strlen(col_values[1]) < 1 
		|| NULL == col_values[2] || strlen(col_values[2]) < 1)
		{
			*retVal = false;
		}
		else
		{
			//��֤����
			time_t nowtime;
			struct tm *timeinfo;
			time(&nowtime);
			timeinfo = localtime(&nowtime);
			int year, month, day, hour, min, sec;
			year = timeinfo->tm_year + 1900;
			month = timeinfo->tm_mon + 1;
			day = timeinfo->tm_mday;
			hour = timeinfo->tm_hour;
			min = timeinfo->tm_min;
			sec = timeinfo->tm_sec;
			char s_date[11] = {0};
			sprintf(s_date, "%d-%02d-%02d", year, month, day);
			
			if(strcmp(col_values[0], s_date) < 0)
			{
				*retVal = false;
			}
			else
			{
				//��֤����
				if(0 != MsgSend(col_values[1]))
					*retVal = false;
				else
					*retVal = true;
			}
		}
	}
	
	return 0;
}

//�Ҳ��ո�
char *StrRightFillSpace(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	int FillLen = len - strlen(strData);
	strcat(FillStr, strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(FillStr, " ");
	}
	return FillStr;
}

//�����߳�
int MsgSend(char *pro_SIM)
{
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	//������װ
	BYTE outbuf[2048] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	strcat(pdata, StrRightFillSpace(" ", 20));
	strcat(pdata, "00003007");
	int len = MSGHDRLEN + 20 + 8;
	
	//AddMsg((BYTE *)outbuf, 1024);
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	
	char *ip = getLocalIP();
	
	//����
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	pSock->SetCompletion();
		
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return SYS_STATUS_FORMAT_ERROR;
	}
	
	char szBuf[2048] = {0};
	if(true == pSock->IsPending(3000))
	{
		//���շ���
	 	if((len = pSock->Recv(szBuf, 2048)) <= 0)
		{
			pSock->EndSocket();
			return SYS_STATUS_SYS_BUSY;
		}
		pSock->EndSocket();
		
		//���ݲ��
		pMsgHdr = (PMsgHdr)szBuf;
		char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
		char result[5] = {0};
		char ressim[17]= {0};
		strncpy(result, pmsg+20, 4);
		strncpy(ressim, pmsg+28, 16);
		
		if(0 == atoi(result) && strstr(ressim, pro_SIM))
			return SYS_STATUS_SUCCESS;
		else
			return SYS_STATUS_FAILED;
	}
	else
	{
		pSock->EndSocket();
		return SYS_STATUS_TIMEOUT;
	}
	
	//�ر�����
	pSock->EndSocket();
	return SYS_STATUS_FAILED;
}

