/*****************************************************************************
*   ��������: shared.cpp                                                     *
*   �� �� ��: ������                                                         *
*   ��Ƶ�λ: ���ݰ��´�Ӧ�������о���                                       *
*   ��������: 2003-06-22                                                     *
*   ������: �ṩϵͳ�Ĺ�������                                             *
*   �� �� ��:                                                                *
*   ��������: 
g++ -shared -I./include -I./lib -L./lib  -lpthread -o ./lib/shared.so ./src/shared.cpp 
*   �� �� ��: ������                                                         *   
******************************************************************************/
#include <locale.h>
#include "Shared.h"

//lhy
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <poll.h> 
#include <errno.h>
#include <linux/if.h>
#include <sys/ioctl.h>

#include <dirent.h>  
#include <stdlib.h> 
#include "IniFile.h"

using namespace std;
#include <time.h>
#include <sys/timeb.h>

int gDataLogFlag;
bool gDataLogSockFlag;
char gDataLogFile[100];
/*************************************************************************
*       ��������:       HexToInt()
*       ��������:       ��4���ֽڵ��ַ������32λ����������:����00a0���160
*       �������:       str��4���ֽڵ��ַ�����
*       �������:   result(str�ȼ۵����֣�
*************************************************************************/
int HexToInt(string str)
{
	int result = 0; 
	sscanf( str.c_str(), "%x", &result );
	return result;
}

string IntToHex(int datalen)
{
	char result[5];
	int dd1,dd2,dd3;
	dd3=4096;
	for (int i=0;i<4;i++)
	{
		dd1=datalen/dd3;
		dd2=datalen%dd3;
		if (dd1>9)
			dd1=64+dd1-9;
		else
			dd1=48+dd1;
		result[i]=dd1;
		datalen=dd2;
		dd3=dd3/16;
	}
	result[4]='\0';    
	string bb(result);
	return bb;
}
DWORD TurnDWord(const DWORD value)
{
	DWORD ret = 0;
	ret |= (value << 24) & 0xFF000000;
	ret |= (value <<  8) & 0x00FF0000;
	ret |= (value >>  8) & 0x0000FF00;
	ret |= (value >> 24) & 0x000000FF;
	return ret;
}

void AddMsg(unsigned char *str,int num)
{
	int i;
	DBG(("\n"));
	for (i = 0; i < num; i++)
	{
		DBG(("%02X ", str[i]));
		if (i % 4 == 3) DBG(("  "));
		if (i % 20 == 19) DBG(("\n"));
	}
	DBG(("\n"));
}

void AddMsg_NoSep(unsigned char *str,int num)
{
	int i;
	DBG(("\n"));
	for (i = 0; i < num; i++)
		DBG(("%02X", str[i]));
	DBG(("\n"));
}


#include <stdio.h>
extern int errno;
int writelog(char *path,string log)
{
	/*
	ofstream os(path,ios::app);
	time_t log_time;
	string str_log_time;

	time(&log_time);
	str_log_time = ctime(&log_time);
	
	os << str_log_time << log << endl;*/
	
	//printf("path:%s, data:%s\n", path, log.c_str());
	FILE *fs = fopen(path, "a");
	if (!fs)
	{ 
		//fprintf(stderr, "fopen failed, errno = %d (%s)\n", errno, strerror( errno)); 
		return -1;
	}
	fprintf(fs, "%s", log.c_str());
	fclose(fs);
	
	return 0;
}
char* ltrim(char* s, int len)
{
	const char* space = " "; 
	char ret[2] = {0};
	int i = 0;
	ret[0] = s[0];
	while(NULL != strstr(space, ret) && i<len)
	{
		ret[0] = s[i];
		i++;
	}
	return (s + i);
}
char* rtrim(char* s, int len)
{
	const char* space = " "; 
	char ret[2] = {0};
	int i=len-1;
	ret[0] = s[i];
	while(NULL != strstr(space, ret) && i > 0)
	{		
		s[i] = '\0';
		i--;
		ret[0] = s[i];
	}	
	return s;
}
char* trim(char* s, int len)
{
	char* tmp = ltrim(s,len);
	tmp = rtrim(tmp, strlen(tmp));
	return tmp;
}

char* strrightfillspace(char* s, int slen, int dlen)
{
	int i=0;
	while(dlen - slen > i)
	{
		s[slen + i] = ' ';
		i++;
	}
	return s;
}

bool GetLocalAddress(char*   szIPAddr)   
{   
	int sock;     
	struct sockaddr_in sin;
	struct ifreq ifr; 

	sock = socket(AF_INET, SOCK_DGRAM, 0);     

	if(sock == -1)     
	{     
		perror("Error: get local IP socket fail!");     
		return false;                               
	}     

	strncpy(ifr.ifr_name, "eth0", IFNAMSIZ);     
	ifr.ifr_name[IFNAMSIZ - 1] = 0;     

	if(ioctl(sock, SIOCGIFADDR, &ifr) < 0)     
	{     
		perror("Error:   get   local   IP   ioctl   fail!");     
		return   false;     
	}     

	memcpy(&sin, &ifr.ifr_addr, sizeof(sin));     
	sprintf(szIPAddr, "%s", inet_ntoa(sin.sin_addr));     
	close(sock);
	return true;
  }


void deletedir(char* directory)
{   
	DIR* dir;   
	struct dirent *ent;
	if((dir = opendir(directory)) == NULL)   
	{   
		perror("Unable to open directory");
		return;   
	}   
	while((ent = readdir(dir)) != NULL)   
	{          
		char filepath[256] = {0};
		if(0 == strcmp(ent->d_name,".")
				|| 0 == strcmp(ent->d_name,".."))
				continue;
		sprintf(filepath, "%s/%s", directory, ent->d_name);
		if(0 != remove(filepath))
		{
		  perror("unable to remove:");  
		} 
				  
	}   
	if(closedir(dir) != 0)   
		perror("Unable to close directory");   
} 
