#include "ClsTcp.h"
#include "Shared.h"

/*********************************************************************************
TCP Socket Base definition
*********************************************************************************/

ClsTCPSocket::ClsTCPSocket(int nSocket) :ClsSocket(AF_INET,SOCK_STREAM, 0, nSocket)
{
	TRACE(ClsTCPSocket::ClsTCPSocket);

	m_nTimeout = DEF_TIMEOUT;
	memset(&m_local, 0, sizeof(m_local));
	m_local.sin_family = AF_INET;
}

char * ClsTCPSocket::GetLocal(char *buf, int sz)
{
	TRACE(ClsTCPSocket::GetLocal);
	snprintf(buf, sz, "addr %d.%d.%d.%d, port %d\n",
		(TKU32)(m_local.sin_addr.s_addr &0xff),
		(TKU32)(m_local.sin_addr.s_addr >> 8)&0xff,
		(TKU32)(m_local.sin_addr.s_addr >> 16)&0xff,
		(TKU32)(m_local.sin_addr.s_addr >> 24)&0xff,
		ntohs(m_local.sin_port));
	buf[sz - 1] = 0;

	return buf;
}

/*********************************************************************************
TCP Client Socket definition
*********************************************************************************/

ClsTCPClientSocket::ClsTCPClientSocket()
{
	TRACE(ClsTCPClientSocket::ClsTCPClientSocket);
}

ClsTCPClientSocket::ClsTCPClientSocket(int nClientId):ClsTCPSocket(nClientId)
{
	TRACE(ClsTCPClientSocket::ClsTCPClientSocket);

	int nLen = sizeof(m_local);
	if ((0 == getsockname(m_socket, (sockaddr*)&m_local, (socklen_t*)&nLen)) &&
		(0 == getpeername(m_socket, (sockaddr*)&m_peer, (socklen_t*)&nLen)))
	{
		m_state = SOCKET_CONNECTED;
	} else
	{
		m_state = SOCKET_INITIAL;
	}
}

int ClsTCPClientSocket::Connect(const ClsInetAddress &ia, tpport_t port, bool bReconnect)
{
	TRACE(ClsTCPClientSocket::Connect);
	if (SOCKET_CONNECTED == m_state)
	{
		if (false == bReconnect)
		{
			return -1;
		} else
		{
			EndSocket();
			SetPeer(ia, port);
			m_socket = socket(m_peer.sin_family, SOCK_STREAM, 0);
			if (m_socket < 0)
			{
				return -1;
			}
		}
	}
	if (SetCompletion(true) == -1)
	{
		return -1;
	}

	SetPeer(ia, port);
	int nRet = connect(m_socket,(const sockaddr *)&m_peer, sizeof(m_peer));
	if (-1 != nRet)
	{
		m_state = SOCKET_CONNECTED;
	} 
	else
	{
		m_state = SOCKET_INITIAL;
	}

	return nRet;
}

int ClsTCPClientSocket::Send(void *buf, size_t len)
{
	TRACE(ClsTCPClientSocket::Send);
	int nRet = 0;
	int nLen = len;
	if (SOCKET_CONNECTED == m_state)
	{
		while (1)
		{
			nRet = send(m_socket, buf, nLen, 0);
			if (nRet < 0)
			{
				if (EINTR != errno)
				{
					EndSocket();
					return -1;
				} 
			} 
			else
			{
				return nRet;
			}
		}
	} 
	else
	{
		return -1;
	}
}


int ClsTCPClientSocket::Recv(char *buf, int len)
{
	TRACE(ClsTCPClientSocket::Recv);
	int nRet = 0;
	int nLen = len;
	if (SOCKET_CONNECTED == m_state)
	{
		while (1)
		{
			nRet = recv(m_socket, buf, nLen, 0); 
			if (nRet <= 0)
			{
				if (nRet == 0)
				{
					EndSocket();
					return -1;
				}
			} 
			else
			{
				return nRet;
			}
		}
	}
	return -1;
}

void ClsTCPClientSocket::SetPeer(TKU32 ipAddr, tpport_t port)
{
	TRACE(ClsTCPClientSocket::SetPeer);

	m_peer.sin_family = AF_INET;
	m_peer.sin_addr.s_addr = htonl(ipAddr);
	m_peer.sin_port = htons(port);
}

void ClsTCPClientSocket::SetPeer(const ClsInetAddress &ia, tpport_t port)
{
	TRACE(ClsTCPClientSocket::SetPeer);

	memset(&m_peer, 0, sizeof(m_peer));
	m_peer.sin_family = AF_INET;
	m_peer.sin_addr = ia.GetAddress();
	m_peer.sin_port = htons(port);
}


char * ClsTCPClientSocket::GetPeer(char *buf, int sz)
{
	TRACE(ClsTCPClientSocket::GetPeer);

	snprintf(buf, sz, "addr %d.%d.%d.%d, port %d\n",
			(TKU32)(m_peer.sin_addr.s_addr &0xff),
			(TKU32)(m_peer.sin_addr.s_addr >> 8)&0xff,
			(TKU32)(m_peer.sin_addr.s_addr >> 16)&0xff,
			(TKU32)(m_peer.sin_addr.s_addr >> 24)&0xff,			 
			 ntohs(m_peer.sin_port));
	buf[sz - 1] = 0;

	return buf;
}
