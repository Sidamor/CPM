//��ʱ��Ϊ30����
#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> 
#include <string.h>
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/stat.h>
#include <fcntl.h> 
#include <dirent.h> 
#include <assert.h>
#include "IniFile.h"
#include "sqlite3.h"
#include "util.h"

#define REMOTE_ADDR getenv("REMOTE_ADDR")
#define HTTP_COOKIE getenv("HTTP_COOKIE")
char timeout[5] = {0};

//��ʱ���ò�ѯ
sqlite3 *open_db_session(const char *filename)
{
	sqlite3 *db = 0;
	int rc;
	rc = sqlite3_open(filename, &db);
	if(rc!=SQLITE_OK)
	{
		printf( "Can't open database: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
	}
	return db;
}

int sqlite3_exec_callback_fortimeout(void *data, int n_columns, char **col_values, char **col_names)
{
	memset(timeout, 0, sizeof(timeout));
	memcpy(timeout, col_values[0] , 5);
	return 0;
}

void pro_timeout()
{
	int rc;
	char * zErrMsg = 0;
	char sql[128] = "select a.timeout from corp_info a";
	
	sqlite3 *db = open_db_session(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_fortimeout, 0, &zErrMsg);
	sqlite3_close(db);
	
	//get_ini_string("/www/session/Config.ini", "SESSION", "timeout", "=", timeout, sizeof(timeout));
	if(NULL == timeout || 0 == strlen(timeout))
	{
		//��ȡ����ֵĬ��30����
		memcpy(timeout, "30", 5);
	}
}

//����ɾ�����ڵ�session�ļ�
void clean_session_file(char *name, char *pwd, char *ip, char *iphweb)
{
  DIR *pdir;
  struct dirent *ent;
  char *path;
  char *filename;
  char filepath[64];
  int fd;
  char str_time[11];
  time_t now;
  FILE *logininfo;
  char buffer[256] = {0};
  char str_name[31];
  char iphwebname[6] = {0};
  
  if(NULL != iphweb && 0 == strcmp(iphweb, "1"))
  	strcat(iphwebname, "ipho_");
  else
  	strcat(iphwebname, "sess_");
  	
  path = "/home/www/session";
  pdir = opendir(path);
  if(NULL != pdir)
  {
  	while((ent = readdir(pdir)))
    {
    	filename = ent->d_name;
      if(strncmp(filename, iphwebname, 5) == 0)
      {
	    	strcpy(filepath, path);
	      strcat(filepath, "/");
	      strcat(filepath, filename);
	      
	      //��ʱɾ���ļ�
	      fd = open(filepath, O_RDONLY);
	      read(fd, str_time, 10);
	      time(&now);
		  	pro_timeout();
	      if(now - atoi(str_time) > atoi(timeout)*60)
	      {
			 		remove(filepath);
			 		close(fd);
			 		continue;
	      }
	      close(fd);
	      
	      //ͬ���˺�ɾ���ļ�
	      logininfo = fopen(filepath, "rb+");
	      if(NULL != logininfo)
				{
					int i = 0;
					while(fgets(buffer, 1024, logininfo) != NULL)
				 	{
			 			buffer[strlen(buffer)-1] = '\0';//ȥ���з�
						switch(i)
						{
							case 3:
									memcpy(str_name, buffer, 31);
								break;
						}
						i++;
				 	}
				 	if(0 == strcmp(name, str_name))
		      {
		        remove(filepath);
		      }
				}
	      fclose(logininfo);
      }
    }
	}
	closedir(pdir);
}

//����ɾ����ǰ��export�ļ�
void clean_export_file(char *name)
{
  DIR *pdir;
  struct dirent *ent;
  char *path;
  char *filename;
  char filepath[64];
  int fd;
  
  path = "/home/www/user/other";
  pdir = opendir(path);
  if(pdir != NULL)
  {
  	char CName[32] = {0};
    while((ent = readdir(pdir)))
    {
       filename = ent->d_name;
       sscanf(filename, "%[^'_'],%*s", CName);
       if(strcmp(name, CName) == 0)
       {
          strcpy(filepath, path);
          strcat(filepath, "/");
          strcat(filepath, filename);
          fd = open(filepath, O_RDONLY);
          remove(filepath);
          close(fd);
       }
    }
  }
  closedir(pdir);
}

//��½����
char *set_session(char *name, char *pwd, char *iphweb)
{
	//�����ʱsession
	clean_session_file(name, pwd, REMOTE_ADDR, iphweb);
	
	//���ɵ���session
	char session_file_path[60] = {0};
	char str_now[11] = {0};
	char hash_key[17]= {0};
	char *session_id;
	
	//��ȡ����ʱ��
	time_t now = {0};
	time(&now);
	sprintf(str_now, "%10ld", now);
	
	//��ȡ���hash_key
	int i,temp,r;
	srand(now);
	r = rand();
	for(i=0; i<16; i++)
	{
		srand(r);
		r = rand();
		hash_key[i] = r%26 + 'a';
	}
	hash_key[16] = '\0';
	  
	//��ȡ���session_id
	temp = rand();
	srand(temp);
	r = rand();
	session_id = (char*) malloc(17*sizeof(char));
	for(i=0; i<16; i++)
	{
		srand(r);
		r = rand();
		session_id[i] = r%26 + 'A';
	}
	session_id[16] = '\0';
	
	//�����ļ��洢·��
	if(NULL != iphweb && 0 == strcmp(iphweb, "1"))
		strcpy(session_file_path,"/home/www/session/ipho_");
	else
		strcpy(session_file_path,"/home/www/session/sess_");
	strcat(session_file_path, session_id);
	
	//�����ļ�
	FILE *session_file = NULL;
	session_file = fopen(session_file_path, "w");
	chmod(session_file_path, 777);
	if(NULL == session_file)
	{
		memcpy(session_id, "", 17);
	}
	else
	{
		//ֵд��session�ļ�
		fputs(str_now, session_file); 		  //����ʱ��
		fputs("\n", session_file);
		fputs(hash_key, session_file);    	//����
		fputs("\n", session_file);
		fputs(REMOTE_ADDR, session_file);   //IP
		fputs("\n", session_file);
		fputs(name, session_file);          //�����ʺ�
		fputs("\n", session_file);
		fputs(pwd,  session_file);          //��������
		fputs("\n", session_file);
	}
	fclose(session_file);

	//��������ļ�
	clean_export_file(name);

	return session_id;
} 

//ÿ��ҳ��������ǰ����
int start_session(char* session_id, char *iphweb)
{
	int ret = 0;//����ֵ
	
	int i = 0;
	int j = 0;
	int k = 0;
	
	char *sess_user_name   = NULL;
	char *sess_user_pwd    = NULL;
	char str_time[16]      = {0};
	char str_hash_key[20]  = {0};
	char str_client_ip[20] = {0};
	sess_user_name         = (char*)malloc(20*sizeof(char));
	sess_user_pwd          = (char*)malloc(20*sizeof(char));
	char *str_array[6]     = {NULL, NULL, NULL, NULL, NULL, NULL};
	
	str_array[0]   = str_time;
	str_array[1]   = str_hash_key;
	str_array[2]   = str_client_ip;
	str_array[3]   = sess_user_name;
	str_array[4]   = sess_user_pwd;
	
	FILE *session_file; 
	char session_file_path[60] = {0};
	time_t now; 
	char buffer[256] = {0}; 
	char temp[64] = {0}; 
	
	//��ȡsession_id
	if(16 != strlen(session_id))
	{
		ret = 1;//��ҳֱ����������
	}
	else
	{
		//��session�ļ�
		if(NULL != iphweb && 0 == strcmp(iphweb, "1"))
			strcpy(session_file_path, "/home/www/session/ipho_");
		else
			strcpy(session_file_path, "/home/www/session/sess_");
		
		strcat(session_file_path, session_id);
		session_file = fopen(session_file_path, "rb+");
		if(NULL == session_file)
		{
			ret = 2;//��ʱ�˳�
		}
		else
		{
			memset(buffer, 0, 256); 
			fread(buffer, 1, 256, session_file);			
			for(i=0, j=0, k=0; k<5 && i<(int)strlen(buffer); i++)
			{ 
				if('\n' == buffer[i])
				{ 
					temp[j] = '\0'; 
					strcpy(str_array[k], temp);
					j = 0;
					k++; 
				} 
				else 
				{
					temp[j++] = buffer[i];
				} 
			} 
	
			//��ʱ���
			time(&now);
			pro_timeout();
			if(now - atoi(str_time) > atoi(timeout)*60)
			{ 
				ret = 2;//��ʱ�˳�
			}
			else
			{
				//ˢ��ʱ��
				time(&now);
				sprintf(str_time, "%10ld", now);
				fseek(session_file, 0, SEEK_SET);
				fputs(str_time, session_file);
			}
			fclose(session_file);
		}
	}
	return ret;
}
