#include <memory.h>
#include "des.h"
#include "assert.h"
#include "SSSC_DES.h"

void vHardwareDES(BYTE  *pbKey, BYTE *pbIn, BYTE *pbOut, BYTE bOp)
{
	DoDES(pbIn, pbKey, 0, bOp, pbOut, 8);		// ECB(op=0����,op=1����)
}

void vHardware3DES(BYTE  *pbKey1, BYTE  *pbKey2, BYTE *pbIn, BYTE *pbOut, BYTE bOp)
{
	BYTE key[16];

	memcpy(key, pbKey1, 8);
	memcpy(key+8, pbKey2, 8);

	Do2DES(pbIn, key, 0, bOp, pbOut, 8);
}

void DES_CBC(BYTE temp[8], BYTE src[8], BYTE key[8], BYTE dest[8], BYTE op)
{
	BYTE i;

	if (op)		// ����
	{
		vHardwareDES((BYTE  *)key, src, dest, 1);
		for (i = 0; i < 8; i++)
		{
			dest[i] ^= temp[i];
			temp[i] = src[i];
		}
	}
	else		// ����
	{
		for (i = 0; i < 8; i++)
			temp[i] ^= src[i];
		vHardwareDES((BYTE  *)key, temp, dest, 0);
		memcpy(temp, dest, 8);
	}
}

void TripleDES_CBC(BYTE temp[8], BYTE src[8], BYTE key[16], BYTE dest[8], BYTE op)
{
	BYTE i;

	if (op)		// ����
	{
		vHardware3DES((BYTE  *)key, (BYTE  *)(key+8), src, dest, 1);
		for (i = 0; i < 8; i++)
		{
			dest[i] ^= temp[i];
			temp[i] = src[i];
		}
	}
	else		// ����
	{
		for (i = 0; i < 8; i++)
			temp[i] ^= src[i];
		vHardware3DES((BYTE  *)key, (BYTE  *)(key+8), temp, dest, 0);
		memcpy(temp, dest, 8);
	}
}

static void _TripleDES_CBC(BYTE temp[8], BYTE src[8], BYTE key[16], BYTE dest[8], BYTE op)
{
	BYTE i;
	
	if (op)		// ����
	{
		Do2DES(src, (BYTE  *)key, ECB, op, dest, 8);
		for (i = 0; i < 8; i++)
		{
			dest[i] ^= temp[i];
			temp[i] = src[i];
		}
	}
	else		// ����
	{
		for (i = 0; i < 8; i++)
			temp[i] ^= src[i];
		Do2DES(temp, (BYTE  *)key, ECB, op, dest, 8);
		memcpy(temp, dest, 8);
	}
}

void TripleDES_ECB(BYTE src[8], BYTE key[16], BYTE dest[8], BYTE op)
{
	vHardware3DES((BYTE  *)key, (BYTE  *)(key+8), src, dest, op);
}


CBC_ST *gMac;

typedef struct CBCPtrChain CBCPtrChain;

struct CBCPtrChain
{
	BYTE *ptr;
	BYTE len;
	CBCPtrChain *next;
};

CBCPtrChain *gChainFirst, *gChainLast;	

void _AddToChain(BYTE *ptr, BYTE len)
{
	CBCPtrChain *node;
	
	node = new CBCPtrChain;
	node->next = NULL;
	node->ptr = ptr;
	node->len = len;

	if (gChainLast == NULL)
	{
		assert (gChainFirst == NULL);
		gChainLast = node;
		gChainFirst = node;
	}
	else
	{
		gChainLast->next = node;
	}
}

CBCPtrChain *_RemoveFromChain()
{
	CBCPtrChain *next, *result;

	if (gChainFirst == NULL) 
		return NULL;
	if (gChainFirst == gChainLast)
		gChainLast = NULL;
	result = gChainFirst;
	next = gChainFirst->next;
	gChainFirst = next;

	return result;
}

BYTE gOp;

void TDESCBC_Begin(CBC_ST *mac, BYTE op)
{
	gMac = mac;
	mac->macCount = 0;
	gChainFirst = NULL;
	gChainLast = NULL;
	gOp = op;
}

void TDESCBC_Data(BYTE *data, BYTE len)
{
	CBCPtrChain *node;
	BYTE temp, l;

	while (len > 0)
	{
		temp = gMac->macCount;
		if (temp + len >= 8)
		{
			l = 8 - temp;
			memcpy(gMac->macBuf + temp, data, l);
			_AddToChain(data, l);
			
			data += l;
			len -= l;

			TripleDES_CBC(gMac->macTemp, gMac->macBuf, gMac->macKey, gMac->macDest, gOp);
			node = _RemoveFromChain();
			temp = 0;
			while (node != NULL)
			{
				memcpy(node->ptr, gMac->macDest + temp, node->len);
				temp += node->len;
				delete node;
				node = _RemoveFromChain();
			}
			gMac->macCount = 0;
		}
		else
		{
			memcpy(gMac->macBuf + temp, data, len);
			_AddToChain(data, len);

			gMac->macCount += len;
			len = 0;
		}
	}
}

BYTE TDESCBC_End(BYTE fix, BYTE *padTo)
{
	CBCPtrChain *node;
	BYTE temp, len;

	if (gOp == 1)
		assert (gMac->macCount == 0);

	temp = gMac->macCount;
	if (temp > 0)
	{
		len = (BYTE)(8 - temp);
		memset(gMac->macBuf + temp, fix, len);
		_AddToChain(padTo, len);

		TripleDES_CBC(gMac->macTemp, gMac->macBuf, gMac->macKey, gMac->macDest, gOp);
		node = _RemoveFromChain();
		temp = 0;
		while (node != NULL)
		{
			memcpy(node->ptr, gMac->macDest + temp, node->len);
			temp += node->len;
			delete node;
			node = _RemoveFromChain();
		}
		return len;
	}
	else
		return 0;
}

void MAC_Begin(CBC_ST *mac)
{
	gMac = mac;
	mac->macCount = 0;
}

void MAC_Data(BYTE  *data, WORD len)
{
	BYTE temp;

	while (len > 0)
	{
		temp = gMac->macCount;
		if (temp + len >= 8)
		{
			memcpy(gMac->macBuf + temp, data, (BYTE)(8 - temp));
			DES_CBC(gMac->macTemp, gMac->macBuf, gMac->macKey, gMac->macDest, 0);
			gMac->macCount = 0;
			
			temp = 8 - temp;
			data += temp;
			len -= temp;
		}
		else
		{
			memcpy(gMac->macBuf + temp, data, (BYTE)(len));
			gMac->macCount += len;

			len = 0;
		}
	}
}

void MAC_End(BYTE result[4], BYTE fix)
{
	BYTE temp;

	temp = gMac->macCount;
	if (temp > 0)
	{
		memset(gMac->macBuf + temp, fix, (BYTE)(8 - temp));
		DES_CBC(gMac->macTemp, gMac->macBuf, gMac->macKey, gMac->macDest, 0);
	}
	memcpy(result, gMac->macDest, 4);
}


int RunDesCBC(void *Data, int DataLen, BYTE key[8], BYTE bOp)
{
	int OutLen = ((DataLen + 7) / 8) * 8;
	if (OutLen > DataLen)
		memset(((BYTE *)Data)+DataLen, 0, OutLen-DataLen);
	
	BYTE ucTemp[8];
	BYTE *cpEnter = (BYTE *)Data;
	BYTE *cpResult = (BYTE *)Data;
	
	int i;
	memset(ucTemp, 0, 8);

	for (i = 0; i < OutLen/8; i++)
	{
		DES_CBC(ucTemp, cpEnter, key, cpResult, bOp);
		cpEnter += 8;
		cpResult += 8;
	}
	return OutLen;
}
 

int Run3DesCBC(void *Data, int DataLen, BYTE key[16], BYTE bOp)
{
	int Len = DataLen;
	int OutLen = ((DataLen + 7) / 8) * 8;
	
//	if (OutLen > DataLen)
//		memset(((BYTE *)Data)+DataLen, 0, OutLen-DataLen);
	
	BYTE ucTemp[8];
	BYTE ucSrcTemp[8];
	BYTE *cpEnter = (BYTE *)Data;
	BYTE *cpResult = (BYTE *)Data;
	
	int i;
	memset(ucTemp, 0, 8);

	for (i = 0; i < OutLen/8; i++)
	{
		memset(ucSrcTemp, 0, 8);
		memcpy(ucSrcTemp, cpEnter, 8<Len?8:Len);

		_TripleDES_CBC(ucTemp, ucSrcTemp, key, cpResult, bOp);
		cpEnter += 8;
		cpResult += 8;
		Len -= 8;
	}

	return OutLen;
}

int RunDesECB(void *Data, int DataLen, BYTE key[8], BYTE bOp)
{
	int OutLen = ((DataLen + 7) / 8) * 8;
	if (OutLen > DataLen)
		memset(((BYTE *)Data)+DataLen, 0, OutLen-DataLen);
	DoDES((BYTE *)Data, key, ECB, bOp, (BYTE *)Data, OutLen);
	return OutLen;
}

int Run3DesECB(void *Data, int DataLen, BYTE key[16], BYTE bOp)
{
	int OutLen = ((DataLen + 7) / 8) * 8;
	if (OutLen > DataLen)
		memset(((BYTE *)Data)+DataLen, 0, OutLen-DataLen);
	Do2DES((BYTE *)Data, key, ECB, bOp, (BYTE *)Data, OutLen);
	return OutLen;
}


