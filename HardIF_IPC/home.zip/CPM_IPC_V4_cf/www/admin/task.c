#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"
#include "IniFile.h"

//��������
char Sql[1024] = {0};
char FillStr[1024] = {0};
int cnt = 0;
char cmd[4] = {0};
char changevalue[11] = {0};

//��task_info
char seq[10] = {0};         //���
char id[11] = {0};					//���
char sn[9] = {0};			      //����
char acttime[13] = {0};     //ʱ��
char cdata[257] = {0};      //����
char memo[129] = {0};       //��ע

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
char *getStatusName(int pStatus);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
//����
static void AddForData();
static int sqlite3_exec_callback_device(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_device_cmd(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_device_call(void *data, int n_columns, char **col_values, char **col_names);
static void AddData();
static int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names);
//��ѯ��������
static void QueryCmd();
static int sqlite3_exec_callback_querycmd(void *data, int n_columns, char **col_values, char **col_names);
//�༭
static void UdpForData();
static int sqlite3_exec_callback_forudp(void *data, int n_columns, char **col_values, char **col_names);
static void UdpData();
//ɾ��
static void DelData();
//ͨѶ
static int MsgSend(int flag);
char *getLocalIP();
char *StrRightFillSpace(char *strData, int len);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://�޸�ҳ��
					UdpForData();
					break;
				case 2://����ҳ��
					AddForData();
					break;
				case 4://��ѯ��������
					QueryCmd();
					break;
				case 10://����
					AddData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 11://�༭
					UdpData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 12://ɾ��
					DelData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}	
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

void getHtmlData()
{  
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("seq", seq, sizeof(seq));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("acttime", acttime, sizeof(acttime));
	cgiFormString("cdata", cdata, sizeof(cdata));
	cgiFormString("memo", memo, sizeof(memo));
}

char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      	strcat(Sql, "select t.seq, t.id, t.sn, t.ctime, t.cdata, t.memo, a.cname, b.cmdname from task_info t, device_detail a, device_act b where t.id = a.id and t.id = b.id and t.sn = b.sn order by t.seq asc");
			break;
		case 1://������ѯ	
      	strcat(Sql, "select t.seq, t.id, t.sn, t.ctime, t.cdata, t.memo, a.cname, b.cmdname from task_info t, device_detail a, device_act b where t.id = a.id and t.id = b.id and t.sn = b.sn ");    	
      	strcat(Sql, "and t.seq = '");
      	strcat(Sql, seq);
      	strcat(Sql, "'");
			break;
	}
	return Sql;
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-��ʱ����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"task\" action=\"task.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/task.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"80%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "	 <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right' colspan=2><img style=\"cursor:hand\" src=\"../skin/images/mini_button_add.gif\" onclick='doAdd()'></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "	 <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>\n");
	fprintf(cgiOut, "      <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "        <tr height='30'>\n");
	fprintf(cgiOut, "          <td width=\"5%%\"  class=\"table_deep_blue\">SN</td>\n");
  fprintf(cgiOut, "          <td width=\"10%%\" class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "          <td width=\"10%%\" class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "          <td width=\"25%%\" class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "          <td width=\"20%%\" class=\"table_deep_blue\">ʱ ��</td>\n");
	fprintf(cgiOut, "          <td width=\"15%%\" class=\"table_deep_blue\">�� ע</td>\n");
	fprintf(cgiOut, "          <td width=\"10%%\" class=\"table_deep_blue\">ɾ ��</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	if(0 == cnt)
	{
		fprintf(cgiOut, "      <tr height='30'>\n");
		fprintf(cgiOut, "        <td width='100%%' align=center colspan=7>��</td>\n");
		fprintf(cgiOut, "      </tr>\n");
	}
	
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");	
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'task.cgi?cmd=2';\n");
	fprintf(cgiOut, "}\n");
	//�༭
	fprintf(cgiOut, "function doEdit(pSeq)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'task.cgi?cmd=1&seq='+pSeq;\n");
	fprintf(cgiOut, "}\n");
	//ɾ��
	fprintf(cgiOut, "function doDelete(pSeq)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ��ɾ��?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'task.cgi?cmd=12&seq='+pSeq;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}


int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{  
	cnt++;
	fprintf(cgiOut, "<tr height=30 class='%s'>\n", cnt%2 == 0?"table_blue":"table_white_l");
	fprintf(cgiOut, "  <td width='5%%'  align='center' style='cursor:hand;color:red;' title='����༭' onClick=\"doEdit('%s')\">%d</td>\n", col_values[0], cnt);
  fprintf(cgiOut, "  <td width='10%%' align=left>%s</td>\n", col_values[6]);
	fprintf(cgiOut, "  <td width='10%%' align=left>%s</td>\n", col_values[7]);
	fprintf(cgiOut, "  <td width='25%%' align=left>%s&nbsp;</td>\n", col_values[4]);
	
	//000000100800
	char Year[5] = {0};
	char Mont[3] = {0};
	char Date[3] = {0};
	char Hour[3] = {0};
	char Mine[3] = {0};
	char Year_Name[10] = {0};
	char Mont_Name[10] = {0};
	char Date_Name[10] = {0};
	if(strlen(col_values[3]) > 0)
	{
		Year[0] = col_values[3][0];
		Year[1] = col_values[3][1];
		Year[2] = col_values[3][2];
		Year[3] = col_values[3][3];
		Year[4] = '\0';
		
		Mont[0] = col_values[3][4];
		Mont[1] = col_values[3][5];
		Mont[2] = '\0';
		
		Date[0] = col_values[3][6];
		Date[1] = col_values[3][7];
		Date[2] = '\0';
		
		Hour[0] = col_values[3][8];
		Hour[1] = col_values[3][9];
		Hour[2] = '\0';
		
		Mine[0] = col_values[3][10];
		Mine[1] = col_values[3][11];
		Mine[2] = '\0';
	}
	
	switch(atoi(Year))
	{
		case 0:
				strcat(Year_Name, "ÿ��");
			break;
		default:
				strcat(Year_Name, Year);
				strcat(Year_Name, "��");
			break;
	}
	
	switch(atoi(Mont))
	{
		case 0:
				strcat(Mont_Name, "ÿ��");
				if(0 == strcmp(Date, "00"))
				{
					strcat(Date_Name, "ÿ��");
				}
				else
				{
					strcat(Date_Name, Date);
					strcat(Date_Name, "��");
				}
			break;
		case 90:
				strcat(Mont_Name, "ÿ��");
				switch(atoi(Date))
				{
					case 91:
							strcat(Date_Name, "����");
						break;
					case 92:
							strcat(Date_Name, "��һ");
						break;
					case 93:
							strcat(Date_Name, "�ܶ�");
						break;
					case 94:
							strcat(Date_Name, "����");
						break;
					case 95:
							strcat(Date_Name, "����");
						break;
					case 96:
							strcat(Date_Name, "����");
						break;
					case 97:
							strcat(Date_Name, "����");
						break;
				}
			break;
		default:
				strcat(Mont_Name, Mont);
				strcat(Mont_Name, "��");
				if(0 == strcmp(Date, "00"))
				{
					strcat(Date_Name, "ÿ��");
				}
				else
				{
					strcat(Date_Name, Date);
					strcat(Date_Name, "��");
				}
			break;
	}
	
	fprintf(cgiOut, "  <td width='20%%' align=center>%s%s%s%s��%s��</td>\n", Year_Name, Mont_Name, Date_Name, Hour, Mine);
	fprintf(cgiOut, "  <td width='15%%' align=left>%s&nbsp;</td>\n", col_values[5]);
	fprintf(cgiOut, "  <td width='10%%' align='center' style='cursor:hand;color:red;' title='���ɾ��' onClick=\"doDelete('%s')\">ɾ ��</td>\n", col_values[0]);
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

void UdpForData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_forudp, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_forudp(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-ʵʱ����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"task\" action=\"task.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/task.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"70%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right'>\n");
	fprintf(cgiOut, "      <img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doEdit()'>\n");
	fprintf(cgiOut, "      <img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "      <table width=\"100%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "			   <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <select name='Id' id='Id' style='width:315px;height:25px;' onchange=\"doChange(this.value, '')\">\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = "select a.id, a.cname from device_detail a, device_act b where a.id = b.id group by a.id order by a.id";
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_device, col_values[1], &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <select name='Cmd' id='Cmd' style='width:315px;height:25px;' onchange='doChange2(this.value)'>\n");
		
	char sql2[512] = "select a.id, a.sn, a.cmdname, a.status, b.object from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and b.flag = '0' and b.flag1 = '0' and a.id = '";
	strcat(sql2, changevalue);
	strcat(sql2, "'");
	rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_device_cmd, col_values[2], &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	fprintf(cgiOut, "  			 <tr height='30px' id='Tel' style='display:none'>\n");
	fprintf(cgiOut, "    			 <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "    			 <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <input type='text' name='Tel' value='%s' style='width:315px;height:20px;' maxlength=256><font color=red>�������/����</font>\n", col_values[4]);	
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px' id='Object' style='display:none'>\n");
	fprintf(cgiOut, "    		   <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <input type='text' name='Object' value='%s' style='width:315px;height:20px;' maxlength=256>\n", col_values[4]);
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");	
	fprintf(cgiOut, "        <tr height='30px' id='Call' style='display:none'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <select id='CallSN' name='Call' style='width:315px;height:20px;'>\n");
	char sql3[512] = "select a.sn, a.cname from call a";
	rc = sqlite3_exec(db, sql3, &sqlite3_exec_callback_device_call, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);	
	
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	char Year[5] = {0};
	char Mont[3] = {0};
	char Date[3] = {0};
	char Hour[3] = {0};
	char Mine[3] = {0};
	if(strlen(col_values[3]) > 0)
	{
		Year[0] = col_values[3][0];
		Year[1] = col_values[3][1];
		Year[2] = col_values[3][2];
		Year[3] = col_values[3][3];
		Year[4] = '\0';
		
		Mont[0] = col_values[3][4];
		Mont[1] = col_values[3][5];
		Mont[2] = '\0';
		
		Date[0] = col_values[3][6];
		Date[1] = col_values[3][7];
		Date[2] = '\0';
		
		Hour[0] = col_values[3][8];
		Hour[1] = col_values[3][9];
		Hour[2] = '\0';
		
		Mine[0] = col_values[3][10];
		Mine[1] = col_values[3][11];
		Mine[2] = '\0';
	}
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>ʱ ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <select id='Year' name='Year' style='width:60px;height:25px;'>\n");
	fprintf(cgiOut, "              <option value='0000' %s>ÿ��</option>\n", 0 == strcmp(Year, "0000")?"selected":"");
	for(int i=2013; i<=2049; i++)
	{
		fprintf(cgiOut, "            <option value='%d'   %s>%d��</option>\n", i, (atoi(Year) == i)?"selected":"", i);
	}
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "            <select id='Mont' name='Mont' style='width:60px;height:25px;' onchange=\"doDateChange(this.value, '')\">\n");
	fprintf(cgiOut, "              <option value='90' %s>ÿ��</option>\n", 0 == strcmp(Mont, "90")?"selected":"");
	fprintf(cgiOut, "              <option value='00' %s>ÿ��</option>\n", 0 == strcmp(Mont, "00")?"selected":"");
	fprintf(cgiOut, "              <option value='01' %s>1��</option>\n",  0 == strcmp(Mont, "01")?"selected":"");
	fprintf(cgiOut, "              <option value='02' %s>2��</option>\n",  0 == strcmp(Mont, "02")?"selected":"");
	fprintf(cgiOut, "              <option value='03' %s>3��</option>\n",  0 == strcmp(Mont, "03")?"selected":"");
	fprintf(cgiOut, "              <option value='04' %s>4��</option>\n",  0 == strcmp(Mont, "04")?"selected":"");
	fprintf(cgiOut, "              <option value='05' %s>5��</option>\n",  0 == strcmp(Mont, "05")?"selected":"");
	fprintf(cgiOut, "              <option value='06' %s>6��</option>\n",  0 == strcmp(Mont, "06")?"selected":"");
	fprintf(cgiOut, "              <option value='07' %s>7��</option>\n",  0 == strcmp(Mont, "07")?"selected":"");
	fprintf(cgiOut, "              <option value='08' %s>8��</option>\n",  0 == strcmp(Mont, "08")?"selected":"");
	fprintf(cgiOut, "              <option value='09' %s>9��</option>\n",  0 == strcmp(Mont, "09")?"selected":"");
	fprintf(cgiOut, "              <option value='10' %s>10��</option>\n", 0 == strcmp(Mont, "10")?"selected":"");
	fprintf(cgiOut, "              <option value='11' %s>11��</option>\n", 0 == strcmp(Mont, "11")?"selected":"");
	fprintf(cgiOut, "              <option value='12' %s>12��</option>\n", 0 == strcmp(Mont, "12")?"selected":"");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "            <select id='Date' name='Date' style='width:60px;height:25px;'>\n");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "            <select id='Hour' name='Hour' style='width:60px;height:25px;'>\n");
	fprintf(cgiOut, "              <option value='00' %s>00��</option>\n", 0 == strcmp(Hour, "00")?"selected":"");
	fprintf(cgiOut, "              <option value='01' %s>01��</option>\n", 0 == strcmp(Hour, "01")?"selected":"");
	fprintf(cgiOut, "              <option value='02' %s>02��</option>\n", 0 == strcmp(Hour, "02")?"selected":"");
	fprintf(cgiOut, "              <option value='03' %s>03��</option>\n", 0 == strcmp(Hour, "03")?"selected":"");
	fprintf(cgiOut, "              <option value='04' %s>04��</option>\n", 0 == strcmp(Hour, "04")?"selected":"");
	fprintf(cgiOut, "              <option value='05' %s>05��</option>\n", 0 == strcmp(Hour, "05")?"selected":"");
	fprintf(cgiOut, "              <option value='06' %s>06��</option>\n", 0 == strcmp(Hour, "06")?"selected":"");
	fprintf(cgiOut, "              <option value='07' %s>07��</option>\n", 0 == strcmp(Hour, "07")?"selected":"");
	fprintf(cgiOut, "              <option value='08' %s>08��</option>\n", 0 == strcmp(Hour, "08")?"selected":"");
	fprintf(cgiOut, "              <option value='09' %s>09��</option>\n", 0 == strcmp(Hour, "09")?"selected":"");
	fprintf(cgiOut, "              <option value='10' %s>10��</option>\n", 0 == strcmp(Hour, "10")?"selected":"");
	fprintf(cgiOut, "              <option value='11' %s>11��</option>\n", 0 == strcmp(Hour, "11")?"selected":"");
	fprintf(cgiOut, "              <option value='12' %s>12��</option>\n", 0 == strcmp(Hour, "12")?"selected":"");
	fprintf(cgiOut, "              <option value='13' %s>13��</option>\n", 0 == strcmp(Hour, "13")?"selected":"");
	fprintf(cgiOut, "              <option value='14' %s>14��</option>\n", 0 == strcmp(Hour, "14")?"selected":"");
	fprintf(cgiOut, "              <option value='15' %s>15��</option>\n", 0 == strcmp(Hour, "15")?"selected":"");
	fprintf(cgiOut, "              <option value='16' %s>16��</option>\n", 0 == strcmp(Hour, "16")?"selected":"");
	fprintf(cgiOut, "              <option value='17' %s>17��</option>\n", 0 == strcmp(Hour, "17")?"selected":"");
	fprintf(cgiOut, "              <option value='18' %s>18��</option>\n", 0 == strcmp(Hour, "18")?"selected":"");
	fprintf(cgiOut, "              <option value='19' %s>19��</option>\n", 0 == strcmp(Hour, "19")?"selected":"");
	fprintf(cgiOut, "              <option value='20' %s>20��</option>\n", 0 == strcmp(Hour, "20")?"selected":"");
	fprintf(cgiOut, "              <option value='21' %s>21��</option>\n", 0 == strcmp(Hour, "21")?"selected":"");
	fprintf(cgiOut, "              <option value='22' %s>22��</option>\n", 0 == strcmp(Hour, "22")?"selected":"");
	fprintf(cgiOut, "              <option value='23' %s>23��</option>\n", 0 == strcmp(Hour, "23")?"selected":"");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "            <select id='Mine' name='Mine' style='width:56px;height:25px;'>\n");
	fprintf(cgiOut, "              <option value='00' %s>00��</option>\n", 0 == strcmp(Mine, "00")?"selected":"");
	fprintf(cgiOut, "              <option value='05' %s>05��</option>\n", 0 == strcmp(Mine, "05")?"selected":"");
	fprintf(cgiOut, "              <option value='10' %s>10��</option>\n", 0 == strcmp(Mine, "10")?"selected":"");
	fprintf(cgiOut, "              <option value='15' %s>15��</option>\n", 0 == strcmp(Mine, "15")?"selected":"");
	fprintf(cgiOut, "              <option value='20' %s>20��</option>\n", 0 == strcmp(Mine, "20")?"selected":"");
	fprintf(cgiOut, "              <option value='25' %s>25��</option>\n", 0 == strcmp(Mine, "25")?"selected":"");
	fprintf(cgiOut, "              <option value='30' %s>30��</option>\n", 0 == strcmp(Mine, "30")?"selected":"");
	fprintf(cgiOut, "              <option value='35' %s>35��</option>\n", 0 == strcmp(Mine, "35")?"selected":"");
	fprintf(cgiOut, "              <option value='40' %s>40��</option>\n", 0 == strcmp(Mine, "40")?"selected":"");
	fprintf(cgiOut, "              <option value='45' %s>45��</option>\n", 0 == strcmp(Mine, "45")?"selected":"");
	fprintf(cgiOut, "              <option value='50' %s>50��</option>\n", 0 == strcmp(Mine, "50")?"selected":"");
	fprintf(cgiOut, "              <option value='55' %s>55��</option>\n", 0 == strcmp(Mine, "55")?"selected":"");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>�� ע</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <input name='memo' type='text' style='width:315px;height:20px' maxlength='30' value='%s'>\n", col_values[5]);
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='11'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//�����л�
	fprintf(cgiOut, "function doDateChange(pValue, pDate)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var length = document.getElementById('Date').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('Date').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  switch(parseInt(pValue, 10))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 0:\n");
	fprintf(cgiOut, "      var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption.value = '00';\n");
	fprintf(cgiOut, "      objOption.text = 'ÿ��';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption);\n");
	fprintf(cgiOut, "      if('00' == pDate)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objOption.selected = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      for(var i=1; i<32; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var objOption1 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "        objOption1.value = StrLeftFillZero(i+'', 2);\n");
	fprintf(cgiOut, "        objOption1.text = i + '��';\n");
	fprintf(cgiOut, "        document.getElementById('Date').add(objOption1);\n");
	fprintf(cgiOut, "        if(StrLeftFillZero(i+'', 2) == pDate)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          objOption1.selected = true;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 90:\n");
	fprintf(cgiOut, "      var objOption1 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption1.value = '91';\n");
	fprintf(cgiOut, "      objOption1.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption1);\n");
	fprintf(cgiOut, "      if('91' == pDate)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objOption1.selected = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var objOption2 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption2.value = '92';\n");
	fprintf(cgiOut, "      objOption2.text = '��һ';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption2);\n");
	fprintf(cgiOut, "      if('92' == pDate)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objOption2.selected = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var objOption3 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption3.value = '93';\n");
	fprintf(cgiOut, "      objOption3.text = '�ܶ�';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption3);\n");
	fprintf(cgiOut, "      if('93' == pDate)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objOption3.selected = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var objOption4 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption4.value = '94';\n");
	fprintf(cgiOut, "      objOption4.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption4);\n");
	fprintf(cgiOut, "      if('94' == pDate)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objOption4.selected = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var objOption5 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption5.value = '95';\n");
	fprintf(cgiOut, "      objOption5.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption5);\n");
	fprintf(cgiOut, "      if('95' == pDate)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objOption5.selected = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var objOption6 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption6.value = '96';\n");
	fprintf(cgiOut, "      objOption6.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption6);\n");
	fprintf(cgiOut, "      if('96' == pDate)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objOption6.selected = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var objOption7 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption7.value = '97';\n");
	fprintf(cgiOut, "      objOption7.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption7);\n");
	fprintf(cgiOut, "      if('97' == pDate)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objOption7.selected = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    default:\n");
	fprintf(cgiOut, "      var darry = [31,28,31,30,31,30,31,31,30,31,30,31];\n");
	fprintf(cgiOut, "      var dacnt = darry[parseInt(pValue, 10)-1];\n");
	fprintf(cgiOut, "      var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption.value = '00';\n");
	fprintf(cgiOut, "      objOption.text = 'ÿ��';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption);\n");
	fprintf(cgiOut, "      if('00' == pDate)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objOption.selected = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      for(var i=1; i<=dacnt; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var objOption1 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "        objOption1.value = StrLeftFillZero(i+'', 2);\n");
	fprintf(cgiOut, "        objOption1.text = i + '��';\n");
	fprintf(cgiOut, "        document.getElementById('Date').add(objOption1);\n");
	fprintf(cgiOut, "        if(StrLeftFillZero(i+'', 2) == pDate)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          objOption1.selected = true;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doDateChange(task.Mont.value, '%s');\n", Date);
	//�����л�
	fprintf(cgiOut, "var reqChg = null;\n");
	fprintf(cgiOut, "function doChange(pValue, pSelCmd)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var length = document.getElementById('Cmd').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('Cmd').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var CmdType = '0';\n");
	fprintf(cgiOut, "  if(pValue.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(pValue.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqChg.onreadystatechange = function(){callbackChangeName(pValue, pSelCmd, CmdType)};\n");
	fprintf(cgiOut, "  var url = 'task.cgi?cmd=4&id='+pValue+'&currtime='+new Date();\n");
	fprintf(cgiOut, "	 reqChg.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqChg.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackChangeName(pValue, pSelCmd, CmdType)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqChg.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqChg.responseText;\n");	
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var list = resp.split('#');\n");
	fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "      		 var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      		 objOption.value = list[i];\n");
	fprintf(cgiOut, "      		 objOption.text = sublist[2];\n");
	fprintf(cgiOut, "      		 document.getElementById('Cmd').add(objOption);\n");
	fprintf(cgiOut, "  			   if(pSelCmd.length > 0)\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "  			     if(pSelCmd == sublist[1])\n");
	fprintf(cgiOut, "  			     {\n");
	fprintf(cgiOut, "  			       objOption.selected = true;\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(task.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = task.Object.value.substring(0, task.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = task.Object.value.substring(task.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    task.Tel.value = tel;\n");
	fprintf(cgiOut, "                    task.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(task.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = task.Tel.value.substring(0, task.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = task.Tel.value.substring(task.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   task.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "  			     }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "  			   else\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "            if(i == 0)\n");
	fprintf(cgiOut, "        	   {\n");
	fprintf(cgiOut, "						   objOption.selected = 'true';\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(task.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = task.Object.value.substring(0, task.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = task.Object.value.substring(task.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    task.Tel.value = tel;\n");
	fprintf(cgiOut, "                    task.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(task.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = task.Tel.value.substring(0, task.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = task.Tel.value.substring(task.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   task.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doChange2(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 if(pValue.length > 0)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   var list = pValue.split(',');\n");
	fprintf(cgiOut, "	   var Id = list[0];\n");
	fprintf(cgiOut, "	   var SN = list[1];\n");
	fprintf(cgiOut, "	   var CmdName = list[2];\n");
	fprintf(cgiOut, "	   var Object = list[3];\n");
	fprintf(cgiOut, "	   var CmdType = '0';\n");
	fprintf(cgiOut, "	   if(Id.indexOf('001103') >= 0 && Object == '1')\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '1';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(Id.indexOf('001104') >= 0 && Object == '1')\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '2';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   if('0' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     if('1' == Object)\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	     else\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('1' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('2' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doChange(task.Id.value, '%s');\n", col_values[2]);	
	
	//�༭
	fprintf(cgiOut, "function doEdit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(task.Id.value.length < 1){alert('��ѡ���豸!'); return;}\n");
	fprintf(cgiOut, "  if(task.Cmd.value.length < 1){alert('��ѡ����!');return;}\n");
	
	fprintf(cgiOut, "  var Id = task.Id.value;\n");
	fprintf(cgiOut, "  var Style = '0';\n");
	fprintf(cgiOut, "  if(Id.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(Id.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var CmdList = task.Cmd.value.split(',');\n");
	fprintf(cgiOut, "  var Cmd = CmdList[1];\n");	
	fprintf(cgiOut, "  var ObjectFlag = CmdList[3];\n");
	fprintf(cgiOut, "  var StatusFlag = CmdList[4];\n");
	fprintf(cgiOut, "  var Object = '';\n");
	fprintf(cgiOut, "  if('0' == Style)\n");//��ͨ
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      Object = task.Object.value;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('1' == Style)\n");//����
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(task.Object.value.length < 1 && task.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = task.Tel.value + '//' + task.Object.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('2' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(task.Call.value.length < 1 && task.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = task.Tel.value + '//' + task.Call.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(Object.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Object = ' ';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var len = Object.len();\n");	
	fprintf(cgiOut, "  if(len > 256)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ݳ��ȹ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var acttime = task.Year.value + task.Mont.value + task.Date.value + task.Hour.value + task.Mine.value;\n");
	fprintf(cgiOut, "  if(task.memo.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    task.memo.value = ' ';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  if('0' == StatusFlag)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ����δ����Ϊ���ã��ݲ��ɱ༭!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'task.cgi?cmd=11&seq=%s&id='+Id+'&sn='+Cmd+'&cdata='+Object+'&memo='+task.memo.value+'&acttime='+acttime;\n", col_values[0]);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'task.cgi?cmd=0';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
	return 0;	
}

void UdpData()
{
	int ret = MsgSend(2);
	fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", getStatusName(ret));
}

void AddForData()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-ʵʱ����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"task\" action=\"task.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/task.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"70%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right'>\n");
	fprintf(cgiOut, "      <img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doAdd()'>\n");
	fprintf(cgiOut, "      <img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "      <table width=\"100%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "			   <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <select name='Id' id='Id' style='width:315px;height:25px;' onchange=\"doChange(this.value, '')\">\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = "select a.id, a.cname from device_detail a, device_act b where a.id = b.id group by a.id order by a.id";
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_device, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <select name='Cmd' id='Cmd' style='width:315px;height:25px;' onchange='doChange2(this.value)'>\n");
	
	char sql2[512] = "select a.id, a.sn, a.cmdname, a.status, b.object from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and b.flag = '0' and b.flag1 = '0' and a.id = '";
	strcat(sql2, changevalue);
	strcat(sql2, "'");
	rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_device_cmd, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	
	fprintf(cgiOut, "  			 <tr height='30px' id='Tel' style='display:none'>\n");
	fprintf(cgiOut, "    			 <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "    			 <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <input type='text' name='Tel' value='' style='width:315px;height:20px;' maxlength=256><font color=red>�������/����</font>\n");	
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30px' id='Object' style='display:none'>\n");
	fprintf(cgiOut, "    		   <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <input type='text' name='Object' value='' style='width:315px;height:20px;' maxlength=256>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");	
	fprintf(cgiOut, "        <tr height='30px' id='Call' style='display:none'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <select id='CallSN' name='Call' style='width:315px;height:20px;'>\n");
	char sql3[512] = "select a.sn, a.cname from call a";
	rc = sqlite3_exec(db, sql3, &sqlite3_exec_callback_device_call, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);	
	
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	
	
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>ʱ ��</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <select id='Year' name='Year' style='width:60px;height:25px;'>\n");
	fprintf(cgiOut, "              <option value='0000' selected>ÿ��</option>\n");
	for(int i=2013; i<=2049; i++)
	{
		fprintf(cgiOut, "            <option value='%d'>%d��</option>\n", i, i);
	}
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "            <select id='Mont' name='Mont' style='width:60px;height:25px;' onchange='doDateChange(this.value)'>\n");
	fprintf(cgiOut, "              <option value='90'>ÿ��</option>\n");
	fprintf(cgiOut, "              <option value='00' selected>ÿ��</option>\n");
	fprintf(cgiOut, "              <option value='01'>1��</option>\n");
	fprintf(cgiOut, "              <option value='02'>2��</option>\n");
	fprintf(cgiOut, "              <option value='03'>3��</option>\n");
	fprintf(cgiOut, "              <option value='04'>4��</option>\n");
	fprintf(cgiOut, "              <option value='05'>5��</option>\n");
	fprintf(cgiOut, "              <option value='06'>6��</option>\n");
	fprintf(cgiOut, "              <option value='07'>7��</option>\n");
	fprintf(cgiOut, "              <option value='08'>8��</option>\n");
	fprintf(cgiOut, "              <option value='09'>9��</option>\n");
	fprintf(cgiOut, "              <option value='10'>10��</option>\n");
	fprintf(cgiOut, "              <option value='11'>11��</option>\n");
	fprintf(cgiOut, "              <option value='12'>12��</option>\n");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "            <select id='Date' name='Date' style='width:60px;height:25px;'>\n");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "            <select id='Hour' name='Hour' style='width:60px;height:25px;'>\n");
	fprintf(cgiOut, "              <option value='00'>00��</option>\n");
	fprintf(cgiOut, "              <option value='01'>01��</option>\n");
	fprintf(cgiOut, "              <option value='02'>02��</option>\n");
	fprintf(cgiOut, "              <option value='03'>03��</option>\n");
	fprintf(cgiOut, "              <option value='04'>04��</option>\n");
	fprintf(cgiOut, "              <option value='05'>05��</option>\n");
	fprintf(cgiOut, "              <option value='06'>06��</option>\n");
	fprintf(cgiOut, "              <option value='07'>07��</option>\n");
	fprintf(cgiOut, "              <option value='08'>08��</option>\n");
	fprintf(cgiOut, "              <option value='09'>09��</option>\n");
	fprintf(cgiOut, "              <option value='10'>10��</option>\n");
	fprintf(cgiOut, "              <option value='11'>11��</option>\n");
	fprintf(cgiOut, "              <option value='12'>12��</option>\n");
	fprintf(cgiOut, "              <option value='13'>13��</option>\n");
	fprintf(cgiOut, "              <option value='14'>14��</option>\n");
	fprintf(cgiOut, "              <option value='15'>15��</option>\n");
	fprintf(cgiOut, "              <option value='16'>16��</option>\n");
	fprintf(cgiOut, "              <option value='17'>17��</option>\n");
	fprintf(cgiOut, "              <option value='18'>18��</option>\n");
	fprintf(cgiOut, "              <option value='19'>19��</option>\n");
	fprintf(cgiOut, "              <option value='20'>20��</option>\n");
	fprintf(cgiOut, "              <option value='21'>21��</option>\n");
	fprintf(cgiOut, "              <option value='22'>22��</option>\n");
	fprintf(cgiOut, "              <option value='23'>23��</option>\n");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "            <select id='Mine' name='Mine' style='width:56px;height:25px;'>\n");
	fprintf(cgiOut, "              <option value='00'>00��</option>\n");
	fprintf(cgiOut, "              <option value='05'>05��</option>\n");
	fprintf(cgiOut, "              <option value='10'>10��</option>\n");
	fprintf(cgiOut, "              <option value='15'>15��</option>\n");
	fprintf(cgiOut, "              <option value='20'>20��</option>\n");
	fprintf(cgiOut, "              <option value='25'>25��</option>\n");
	fprintf(cgiOut, "              <option value='30'>30��</option>\n");
	fprintf(cgiOut, "              <option value='35'>35��</option>\n");
	fprintf(cgiOut, "              <option value='40'>40��</option>\n");
	fprintf(cgiOut, "              <option value='45'>45��</option>\n");
	fprintf(cgiOut, "              <option value='50'>50��</option>\n");
	fprintf(cgiOut, "              <option value='55'>55��</option>\n");
	fprintf(cgiOut, "            </select>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='30%%' align='center'>�� ע</td>\n");
	fprintf(cgiOut, "          <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "            <input name='memo' type='text' style='width:315px;height:20px' maxlength='30' value=''>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='10'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//�����л�
	fprintf(cgiOut, "function doDateChange(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var length = document.getElementById('Date').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('Date').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  switch(parseInt(pValue, 10))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 0:\n");
	fprintf(cgiOut, "      var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption.value = '00';\n");
	fprintf(cgiOut, "      objOption.text = 'ÿ��';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption);\n");
	fprintf(cgiOut, "      for(var i=1; i<32; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var objOption1 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "        objOption1.value = StrLeftFillZero(i+'', 2);\n");
	fprintf(cgiOut, "        objOption1.text = i + '��';\n");
	fprintf(cgiOut, "        document.getElementById('Date').add(objOption1);\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 90:\n");
	fprintf(cgiOut, "      var objOption1 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption1.value = '91';\n");
	fprintf(cgiOut, "      objOption1.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption1);\n");
	fprintf(cgiOut, "      var objOption2 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption2.value = '92';\n");
	fprintf(cgiOut, "      objOption2.text = '��һ';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption2);\n");
	fprintf(cgiOut, "      var objOption3 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption3.value = '93';\n");
	fprintf(cgiOut, "      objOption3.text = '�ܶ�';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption3);\n");
	fprintf(cgiOut, "      var objOption4 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption4.value = '94';\n");
	fprintf(cgiOut, "      objOption4.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption4);\n");
	fprintf(cgiOut, "      var objOption5 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption5.value = '95';\n");
	fprintf(cgiOut, "      objOption5.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption5);\n");
	fprintf(cgiOut, "      var objOption6 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption6.value = '96';\n");
	fprintf(cgiOut, "      objOption6.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption6);\n");
	fprintf(cgiOut, "      var objOption7 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption7.value = '97';\n");
	fprintf(cgiOut, "      objOption7.text = '����';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption7);\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    default:\n");
	fprintf(cgiOut, "      var darry = [31,28,31,30,31,30,31,31,30,31,30,31];\n");
	fprintf(cgiOut, "      var dacnt = darry[parseInt(pValue, 10)-1];\n");
	fprintf(cgiOut, "      var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      objOption.value = '00';\n");
	fprintf(cgiOut, "      objOption.text = 'ÿ��';\n");
	fprintf(cgiOut, "      document.getElementById('Date').add(objOption);\n");
	fprintf(cgiOut, "      for(var i=1; i<=dacnt; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var objOption1 = document.createElement('OPTION');\n");
	fprintf(cgiOut, "        objOption1.value = StrLeftFillZero(i+'', 2);\n");
	fprintf(cgiOut, "        objOption1.text = i + '��';\n");
	fprintf(cgiOut, "        document.getElementById('Date').add(objOption1);\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doDateChange(task.Mont.value);\n");
	//�����л�
	fprintf(cgiOut, "var reqChg = null;\n");
	fprintf(cgiOut, "function doChange(pValue, pSelCmd)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var length = document.getElementById('Cmd').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('Cmd').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var CmdType = '0';\n");
	fprintf(cgiOut, "  if(pValue.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(pValue.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqChg.onreadystatechange = function(){callbackChangeName(pValue, pSelCmd, CmdType)};\n");
	fprintf(cgiOut, "  var url = 'task.cgi?cmd=4&id='+pValue+'&currtime='+new Date();\n");
	fprintf(cgiOut, "	 reqChg.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqChg.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackChangeName(pValue, pSelCmd, CmdType)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqChg.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqChg.responseText;\n");	
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var list = resp.split('#');\n");
	fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "      		 var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      		 objOption.value = list[i];\n");
	fprintf(cgiOut, "      		 objOption.text = sublist[2];\n");
	fprintf(cgiOut, "      		 document.getElementById('Cmd').add(objOption);\n");
	fprintf(cgiOut, "  			   if(pSelCmd.length > 0)\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "  			     if(pSelCmd == sublist[1])\n");
	fprintf(cgiOut, "  			     {\n");
	fprintf(cgiOut, "  			       objOption.selected = true;\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(task.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = task.Object.value.substring(0, task.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = task.Object.value.substring(task.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    task.Tel.value = tel;\n");
	fprintf(cgiOut, "                    task.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(task.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = task.Tel.value.substring(0, task.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = task.Tel.value.substring(task.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   task.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "  			     }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "  			   else\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "            if(i == 0)\n");
	fprintf(cgiOut, "        	   {\n");
	fprintf(cgiOut, "						   objOption.selected = 'true';\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(task.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = task.Object.value.substring(0, task.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = task.Object.value.substring(task.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    task.Tel.value = tel;\n");
	fprintf(cgiOut, "                    task.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(task.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = task.Tel.value.substring(0, task.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = task.Tel.value.substring(task.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   task.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doChange2(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 if(pValue.length > 0)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   var list = pValue.split(',');\n");
	fprintf(cgiOut, "	   var Id = list[0];\n");
	fprintf(cgiOut, "	   var SN = list[1];\n");
	fprintf(cgiOut, "	   var CmdName = list[2];\n");
	fprintf(cgiOut, "	   var Object = list[3];\n");
	fprintf(cgiOut, "	   var CmdType = '0';\n");
	fprintf(cgiOut, "	   if(Id.indexOf('001103') >= 0 && Object == '1')\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '1';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(Id.indexOf('001104') >= 0 && Object == '1')\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '2';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   if('0' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     if('1' == Object)\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	     else\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('1' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('2' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doChange(task.Id.value, '');\n");
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(task.Id.value.length < 1){alert('��ѡ���豸!'); return;}\n");
	fprintf(cgiOut, "  if(task.Cmd.value.length < 1){alert('��ѡ����!');return;}\n");
	
	fprintf(cgiOut, "  var Id = task.Id.value;\n");
	fprintf(cgiOut, "  var Style = '0';\n");
	fprintf(cgiOut, "  if(Id.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(Id.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var CmdList = task.Cmd.value.split(',');\n");
	fprintf(cgiOut, "  var Cmd = CmdList[1];\n");	
	fprintf(cgiOut, "  var ObjectFlag = CmdList[3];\n");
	fprintf(cgiOut, "  var StatusFlag = CmdList[4];\n");
	fprintf(cgiOut, "  var Object = '';\n");
	
	fprintf(cgiOut, "  if('0' == Style)\n");//��ͨ
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      Object = task.Object.value;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('1' == Style)\n");//����
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(task.Object.value.length < 1 && task.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = task.Tel.value + '//' + task.Object.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('2' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(task.Call.value.length < 1 && task.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = task.Tel.value + '//' + task.Call.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(Object.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Object = ' ';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var len = Object.len();\n");	
	fprintf(cgiOut, "  if(len > 256)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ݳ��ȹ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var acttime = task.Year.value + task.Mont.value + task.Date.value + task.Hour.value + task.Mine.value;\n");
	fprintf(cgiOut, "  if(task.memo.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    task.memo.value = ' ';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if('0' == StatusFlag)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ����δ����Ϊ���ã��ݲ�������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'task.cgi?cmd=10&id='+Id+'&sn='+Cmd+'&cdata='+Object+'&memo='+task.memo.value+'&acttime='+acttime;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'task.cgi?cmd=0';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_device(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	if(NULL != data)
	{
		if(0 == strcmp((char *)data, col_values[0]))
		{
			strcat(changevalue, col_values[0]);
			fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", col_values[0], col_values[1]);
		}
		else
		{
			fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
		}
	}
	else
	{
		if(cnt == 1)
		{
			strcat(changevalue, col_values[0]);
		}	
		fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	}
	return 0;
}

int sqlite3_exec_callback_device_cmd(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != data && 0 == strcmp((char *)data, col_values[1]))
	{
		fprintf(cgiOut, "<option value='%s,%s,%s,%s,%s' selected>%s</option>\n", col_values[0], col_values[1], col_values[2], col_values[4], col_values[3], col_values[2]);
	}
	else
	{
		fprintf(cgiOut, "<option value='%s,%s,%s,%s,%s'>%s</option>\n", col_values[0], col_values[1], col_values[2], col_values[4], col_values[3], col_values[2]);
	}
	return 0;	
}

void QueryCmd()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = "select a.id, a.sn, a.cmdname, a.status, b.object from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and b.flag = '0' and b.flag1 = '0' and a.id = '";
	strcat(sql, id);
	strcat(sql, "'");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_querycmd, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_querycmd(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "%s,%s,%s,%s,%s#", col_values[0], col_values[1], col_values[2], col_values[4], col_values[3]);
	return 0;
}

void AddData()
{
	//��ȡseq
	int rc;
	char * zErrMsg = 0;
	char sql2[128] = "select max(t.seq)+1 from task_info t";
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_add, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
	
	int ret = MsgSend(1);
	fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", getStatusName(ret));
	
	/*
	//����256��
	if(atoi(seq) > 256)
	{
		fprintf(cgiOut, "<script language='javascript'>alert('ʧ��,��ʱ�����ܳ���256��!');</script>\n");
	}
	else
	{
		int ret = MsgSend(1);
		fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", getStatusName(ret));
	}
	*/
}

int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL == col_values[0] || strlen(col_values[0]) == 0)
	{
		memcpy(seq, "1", 10);
	}
	else
	{
		memcpy(seq, col_values[0], 10);
	}
	return 0;
}

int sqlite3_exec_callback_device_call(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	return 0;
}

void DelData()
{
	int ret = MsgSend(3);
	fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", getStatusName(ret));
}

char *StrRightFillSpace(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	int FillLen = len - strlen(strData);
	strcat(FillStr, strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(FillStr, " ");
	}
	return FillStr;
}

//�����߳�
int MsgSend(int flag)
{	
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	//������װ
	BYTE outbuf[2048] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	int len = 0;
	switch(flag)
	{
		case 1://����	
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002008");
				strcat(pdata, StrRightFillSpace(seq, 10));
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 8));
				strcat(pdata, StrRightFillSpace(acttime, 12));
				strcat(pdata, StrRightFillSpace(cdata, 256));
				strcat(pdata, StrRightFillSpace(memo, 128));
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 8 + 12 + 256 + 128;
			break;
		case 2://�༭
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002009");
				strcat(pdata, StrRightFillSpace(seq, 10));
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 8));
				strcat(pdata, StrRightFillSpace(acttime, 12));
				strcat(pdata, StrRightFillSpace(cdata, 256));
				strcat(pdata, StrRightFillSpace(memo, 128));
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 8 + 12 + 256 + 128;
			break;
		case 3://ɾ��
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002010");
				strcat(pdata, StrRightFillSpace(seq, 10));
				len = MSGHDRLEN + 20 + 8 + 10;
			break;
	}
	
	//AddMsg((BYTE *)outbuf, 1024);	
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	
	char *ip = getLocalIP();
	
	//����
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	pSock->SetCompletion();
		
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return SYS_STATUS_FORMAT_ERROR;
	}
	
	char szBuf[512] = {0};
	if(true == pSock->IsPending(30000))
	{
	 	if((len = pSock->Recv(szBuf, 512)) <= 0) 
		{
			pSock->EndSocket();
			return SYS_STATUS_SYS_BUSY;
		}
		
		//���շ���
		pMsgHdr = (PMsgHdr)szBuf;
		char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
		char result[5] = {0};
		strncpy(result, pmsg+20, 4);
		pSock->EndSocket();
		return atoi(result);
	}
	else
	{
		pSock->EndSocket();
		return SYS_STATUS_TIMEOUT;
	}
	
	//�ر�����
	pSock->EndSocket();
	return SYS_STATUS_FAILED;
}
