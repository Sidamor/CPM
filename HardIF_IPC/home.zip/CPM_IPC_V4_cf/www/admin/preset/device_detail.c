#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

//��������
char Sql[1024] = {0};
char cmd[4] = {0};
//Ԥ�õ�����
char PresetData[2048] = {0};
char newPresetData[2048] = {0};
char nindex[10] = {0};
char id[11] = {0};
char cname[31] = {0};
char preset[1024] = {0};

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯԤ�õ�
static void QueryPreset();
static int sqlite3_exec_callback_preset_info(void *data, int n_columns, char **col_values, char **col_names);
//�޸�Ԥ�õ�
static void UpdateData();
//ɾ��Ԥ�õ�
static void UdpPreset();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	
	char *p;
	char strnindex[10] = {0};
	char strnextnindex[10] = {0};
	switch(ret)
	{
		case 0:
			memset(PresetData, 0, sizeof(PresetData));
			memset(newPresetData, 0, sizeof(newPresetData));
			switch(atoi(cmd))
			{
				case 6://Ԥ�õ��ѯ
					QueryPreset();
					printf("%s", PresetData);
					break;
				case 7://����Ԥ�õ�
					QueryPreset();
									
					strcat(strnindex, nindex);
					strcat(strnindex, ",");
					p = strstr(PresetData, strnindex);		
					
					if(p)
					{				
						strncpy(newPresetData, PresetData, strlen(PresetData)-strlen(p));
						strcat(newPresetData, strnindex);
						strcat(newPresetData, cname);
						strcat(newPresetData, ";");
						
						char *subp;
						sprintf(strnextnindex, "%d", atoi(nindex)+1);
						strcat(strnextnindex, ",");
						subp = strstr(PresetData, strnextnindex);
						if(subp)
						{
							strcat(newPresetData, subp);
						}
					}
					else
					{
						strcat(newPresetData, PresetData);
						strcat(newPresetData, strnindex);
						strcat(newPresetData, cname);
						strcat(newPresetData, ";");
					}

					sprintf(cmd, "%s", "7");
					UpdateData();

					memset(PresetData, 0, sizeof(PresetData));
					QueryPreset();
					printf("%s", PresetData);
					break;
				case 8:
					UdpPreset();
					break;
				case 11://�޸�
					UpdateData();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){window.parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){window.open('../index.html', '_top');}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('2')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("preset", preset, sizeof(preset));
	cgiFormString("nindex", nindex, sizeof(nindex));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 6://��ѯԤ�õ�
			strcat(Sql, "select a.id, a.cname, a.preset from device_detail a where a.id = '");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
		case 7://����Ԥ�õ�
			strcat(Sql, "update device_detail set preset = '");
			strcat(Sql, newPresetData);
			strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 8://ɾ��Ԥ�õ�
			strcat(Sql, "update device_detail set preset = '");
			strcat(Sql, preset);
			strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
	}
	return Sql;
}

void QueryPreset()
{
	int rc;
	char * zErrMsg = 0;

	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(6), &sqlite3_exec_callback_preset_info, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	sqlite3_close(db);
}

int sqlite3_exec_callback_preset_info(void *data, int n_columns, char **col_values, char **col_names)
{
	sprintf(PresetData, "%s", col_values[2]);
	return 0;
}

void UdpPreset()
{
	int rc;
	char * zErrMsg = 0;

	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(8), &sqlite3_exec_callback_preset_info, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	sqlite3_close(db);
	printf("0000\n");
}

//�޸�
void UpdateData()
{		
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(atoi(cmd)), &sqlite3_exec_callback_preset_info, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}
