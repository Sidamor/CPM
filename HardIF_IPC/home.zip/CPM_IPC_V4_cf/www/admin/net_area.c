#include <stdio.h>
#include <cgic.h>
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>

//��������
int cnt = 0;
char Sql[1024] = {0};
char cmd[4] = {0};
char id[10] = {0};
char cname[20] = {0};
char point[4096*8] = {0};
char icon[61] = {0};
char sign[2] = {0};
char pos_x[7] = {0};
char pos_y[7] = {0};
char dev_id[11] = {0};
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ��¼
static void QueryData();
//���¼�¼
static void UpdateData();
//ɾ����¼
static void DealData();
static int sqlite3_exec_callback_area(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_device(void *data, int n_columns, char **col_values, char **col_names);
//�����ж�
static void isNodeScene();
static int sqlite3_exec_callback_node(void *data, int n_columns, char **col_values, char **col_names);
//�����ж�
static void isNodeAction();
static int sqlite3_exec_callback_act(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);	
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{
				case 10://����
					sprintf(cmd, "%s", "12");
					UpdateData();
					sprintf(cmd, "%s", "10");
					DealData();
					sprintf(cmd, "%s", "0");
				case 0:
					QueryData();
					break;
				case 13://�����ж�
					isNodeScene();
					break;
				case 14://�����ж�
					isNodeAction();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("point", point, sizeof(point));
	cgiFormString("icon", icon, sizeof(icon));
	cgiFormString("sign", sign, sizeof(sign));
	cgiFormString("pos_x", pos_x, sizeof(pos_x));
	cgiFormString("pos_y", pos_y, sizeof(pos_y));
	cgiFormString("dev_id", dev_id, sizeof(dev_id));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0:
      strcat(Sql, "select t.id, t.cname, t.point, t.icon, t.sign, t.pos_x, t.pos_y from role t order by t.id");
			break;
		case 10://����
			strcat(Sql, "insert into role(id, cname, point, icon, sign, pos_x, pos_y) values('");
			strcat(Sql, id);
			strcat(Sql, "', '");
			strcat(Sql, cname);
			strcat(Sql, "', '");
			strcat(Sql, point);
			strcat(Sql, "', '");
			strcat(Sql, icon);
			strcat(Sql, "', '");
			strcat(Sql, sign);
			strcat(Sql, "', '");
			strcat(Sql, pos_x);
			strcat(Sql, "', '");
			strcat(Sql, pos_y);
			strcat(Sql, "')");
			break;
		case 12://ɾ��
			strcat(Sql, "delete from role where substr(id,1,2) = '60' ");
			break;
	}
	return Sql;
}

void QueryData()
{
  fprintf(cgiOut, "<HTML>\n");
  fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>��Ԫ����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/zTreeStyle2.css' rel='stylesheet'/>\n");	
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/jquery-1.4.4.min.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/jquery.ztree.core-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/jquery.ztree.excheck-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/jquery.ztree.exedit-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/util.js'></script>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "<style>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #3491D6;\n");
	fprintf(cgiOut, "  border: 1px solid #3491D6;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 705px;\n");
	fprintf(cgiOut, "  height:535px;\n");
	fprintf(cgiOut, "  left:20%%;\n");
	fprintf(cgiOut, "  top: 5%%;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, ".actdiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #3491D6;\n");
	fprintf(cgiOut, "  border: 1px solid #3491D6;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 705px;\n");
	fprintf(cgiOut, "  height:400px;\n");
	fprintf(cgiOut, "  left:20%%;\n");
	fprintf(cgiOut, "  top: 5%%;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style='background:#CADFFF'>\n");
	fprintf(cgiOut, "<form name='Corp_DeviceArea' action='net_area.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "<div id='down_bg_2'>\n");
	fprintf(cgiOut, "<div id='cap'><img src='../skin/images/net_area.gif'></div><br>\n");
	fprintf(cgiOut, "<div id='right_table_center'>\n");
	fprintf(cgiOut, "<table width='70%%' style='margin:auto' cellpadding='0' cellspacing='1' border='0'>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width=100%% align=right id='sub_btn'>\n");
	fprintf(cgiOut, "      <img style='cursor:hand' onClick='doSubmit()' src='../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width=100%% align=center>\n");
	fprintf(cgiOut, "      <table cellpadding='0' cellspacing='0' border='1' width='100%%' bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "        <tr valign='top'>\n");
	fprintf(cgiOut, "          <td width='45%%' align='center'>\n");
	fprintf(cgiOut, "            <div class='zTreeDemoBackground' style='width:99%%;height:100%%;border:0px solid #0068a6'><ul id='areaTree' class='ztree'></ul></div>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "          <td width='10%%' align='center'>\n");
	fprintf(cgiOut, "            <br/><br/><br/><br/><br/>\n");
	fprintf(cgiOut, "            <img src='../skin/images/moveNode.png' onfocus='this.blur();' title='�ƶ��ڵ� ��->��' onclick='moveTreeL2R();'>\n");
	fprintf(cgiOut, "            <br/><br/><br/><br/><br/>\n");
	fprintf(cgiOut, "            <img src='../skin/images/moveNodeR.png' onfocus='this.blur();' title='�ƶ��ڵ� ��->��' onclick='moveTreeR2L();'>\n");
	fprintf(cgiOut, "            <br/><br/><br/><br/><br/>\n");	
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "          <td width='45%%' align='center'>\n");
	fprintf(cgiOut, "            <div class='zTreeDemoBackground' style='width:99%%;height:100%%;border:0px solid #0068a6'><ul id='devTree' class='ztree'></ul></div>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='objDiv' class='mydiv'  style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "<div id='actDiv' class='actdiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'      value='10'>\n");
	fprintf(cgiOut, "<input type='hidden' name='Str_List' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//��ϣ����
	fprintf(cgiOut, "var hashTable = new Object();\n");
	fprintf(cgiOut, "function add(key, value)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(key in hashTable)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    \n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    hashTable[key] = value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//������
	fprintf(cgiOut, "var Nodes1 = [];\n");
	fprintf(cgiOut, "var Nodes2 = [];\n");
	fprintf(cgiOut, "var setting = \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  view: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    addHoverDom: addHoverDom,\n");
	fprintf(cgiOut, "    removeHoverDom: removeHoverDom,\n");
	fprintf(cgiOut, "    selectedMulti: false\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  edit: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    enable: true,\n");
	fprintf(cgiOut, "    drag: {isMove: false,isCopy: false},\n");
	fprintf(cgiOut, "    showRenameBtn: setRenameBtn,\n");
	fprintf(cgiOut, "    showRemoveBtn: setRemoveBtn\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  data: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    simpleData:{enable: true}\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  callback: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    beforeRename: beforeRename\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "};\n");
	fprintf(cgiOut, "var setting2 = \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  edit: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    enable: true,\n");
	fprintf(cgiOut, "    showRenameBtn: false,\n");
	fprintf(cgiOut, "    showRemoveBtn: false\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  data: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    simpleData:{enable: true}\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  callback: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    beforeDrop: zTreeBeforeDrop\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "};\n");
	fprintf(cgiOut, "function setRenameBtn(treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(treeNode.tId.substring(0,7) == 'devTree')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return false;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  switch(treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 0:\n");
	fprintf(cgiOut, "        return false;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "        return true;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "        return true;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 3:\n");
	fprintf(cgiOut, "        return true;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 4:\n");
	fprintf(cgiOut, "        return false;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    default:\n");
	fprintf(cgiOut, "        return false;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function setRemoveBtn(treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(treeNode.tId.substring(0,7) == 'devTree')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return false;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  switch(treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 0:\n");
	fprintf(cgiOut, "        return false;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "        return true;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "        return true;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 3:\n");
	fprintf(cgiOut, "        return true;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 4:\n");
	fprintf(cgiOut, "        return true;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    default:\n");
	fprintf(cgiOut, "        return true;\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function addHoverDom(treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(treeNode.tId.substring(0,7) == 'devTree')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return false;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(0 == treeNode.level || 1 == treeNode.level || 2 == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var sObj = $('#' + treeNode.tId + '_span');\n");
	fprintf(cgiOut, "    if (treeNode.editNameFlag || $('#addBtn_'+treeNode.id).length>0)\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    var addStr = \"<span class='button add' id='addBtn_\" + treeNode.id+ \"' title='add node' onfocus='this.blur();'></span>\";\n");
	fprintf(cgiOut, "    sObj.after(addStr);\n");
	fprintf(cgiOut, "    var btn = $('#addBtn_'+treeNode.id);\n");
	fprintf(cgiOut, "    if (btn) btn.bind('click', function()\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var zTree = $.fn.zTree.getZTreeObj('areaTree');\n");
	fprintf(cgiOut, "      var newId = parseInt(treeNode.value + '00', 10);\n");
	fprintf(cgiOut, "      var childNodes = zTree.transformToArray(treeNode);\n");
	fprintf(cgiOut, "      for(var i=0; i<childNodes.length; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(treeNode.value == childNodes[i].pId)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          if(parseInt(childNodes[i].id, 10) > newId)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            newId = parseInt(childNodes[i].id, 10);\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var _newId = newId.toString();\n");
	fprintf(cgiOut, "      if(parseInt(_newId.substring(_newId.length-2, _newId.length)) >= 99)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('��ǰ��ɫ������99�����뾫��!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var strNewId = StrLeftFillZero((newId + 1).toString(), treeNode.value.length+2);\n");
	fprintf(cgiOut, "      zTree.addNodes(treeNode, {id:strNewId, name:'fq'+strNewId, value:strNewId, iconsrc:' ', signstr:'0', pos_xstr:' ', pos_ystr:' ', pId:treeNode.id});\n");
	fprintf(cgiOut, "      return false;\n");
	fprintf(cgiOut, "    });\n");
	
	//����
	fprintf(cgiOut, "    if(1 == treeNode.level || 2 == treeNode.level)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var sObj = $('#' + treeNode.tId + '_a');\n");
	fprintf(cgiOut, "      if (treeNode.editNameFlag || $('#imgBtn_'+treeNode.id).length>0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var imgStr = \"<span class='button img' id='imgBtn_\" + treeNode.id+ \"' title='img node' onfocus='this.blur();'></span>\";\n");
	fprintf(cgiOut, "      sObj.append(imgStr);\n");
	fprintf(cgiOut, "      var btn = $('#imgBtn_'+treeNode.id);\n");
	fprintf(cgiOut, "      if (btn) btn.bind('click', function()\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        doNodeScene(treeNode.id, treeNode.name);\n");
	fprintf(cgiOut, "      });\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	
	//����
	fprintf(cgiOut, "  else if(4 == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var sObj = $('#' + treeNode.tId + '_a');\n");
	fprintf(cgiOut, "    if (treeNode.editNameFlag || $('#actBtn_'+treeNode.id).length>0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    var actStr = \"<span class='button act' id='actBtn_\" + treeNode.id+ \"' title='act node' onfocus='this.blur();'></span>\";\n");
	fprintf(cgiOut, "    sObj.append(actStr);\n");
	fprintf(cgiOut, "    var btn = $('#actBtn_'+treeNode.id);\n");
	fprintf(cgiOut, "    if (btn) btn.bind('click', function()\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      doNodeAction(treeNode.pId, treeNode.id, treeNode.name);\n");
	fprintf(cgiOut, "    });\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function removeHoverDom(treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(0 == treeNode.level || 1 == treeNode.level || 2 == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    $('#addBtn_'+treeNode.id).unbind().remove();\n");
	fprintf(cgiOut, "    if(1 == treeNode.level || 2 == treeNode.level)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      $('#imgBtn_'+treeNode.id).unbind().remove();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(4 == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    $('#actBtn_'+treeNode.id).unbind().remove();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function beforeRename(treeId, treeNode, newName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var className = 'dark';\n");
	fprintf(cgiOut, "  className = (className === 'dark' ? '':'dark');\n");
	fprintf(cgiOut, "  if(newName.Trim().length == 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�ڵ����Ʋ���Ϊ��!');\n");
	fprintf(cgiOut, "    var zTree = $.fn.zTree.getZTreeObj('areaTree');\n");
	fprintf(cgiOut, "    setTimeout(function(){zTree.editName(treeNode)}, 10);\n");
	fprintf(cgiOut, "    return false;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function zTreeBeforeDrop(treeId, treeNodes, targetNode, moveType)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(null == treeNodes || treeNodes.length == 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return false;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<treeNodes.length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(0 == treeNodes[i].level || 1 == treeNodes[i].level)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      return false;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(null == targetNode || 0 == targetNode.level || 1 == targetNode.level || 2 == targetNode.level || 4 == targetNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return false;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if('areaTree' == treeId)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var zTree = $.fn.zTree.getZTreeObj(treeId);\n");
	fprintf(cgiOut, "    var childNodes = zTree.transformToArray(targetNode);\n");
	fprintf(cgiOut, "    for(var i=0; i<childNodes.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(targetNode.value == childNodes[i].pId)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        for(var j=0; j<treeNodes.length; j++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          if(treeNodes[j].id == childNodes[i].id)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            alert('�����豸�Ѵ��ڣ�����!');\n");
	fprintf(cgiOut, "            return false;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<treeNodes.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var zTree2 = $.fn.zTree.getZTreeObj('devTree');\n");
	fprintf(cgiOut, "      zTree2.addNodes(treeNodes[i].getParentNode(), treeNodes[i]);\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function moveTreeL2R()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var zTree1 = $.fn.zTree.getZTreeObj('areaTree');\n");
	fprintf(cgiOut, "  var zTree2 = $.fn.zTree.getZTreeObj('devTree');\n");
	fprintf(cgiOut, "  moveTreeNode(zTree1, zTree2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function moveTreeR2L()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var zTree1 = $.fn.zTree.getZTreeObj('areaTree');\n");
	fprintf(cgiOut, "  var zTree2 = $.fn.zTree.getZTreeObj('devTree');\n");
	fprintf(cgiOut, "  moveTreeNode(zTree2, zTree1);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function moveTreeNode(srcTree, targetTree)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var srcNode = srcTree.getSelectedNodes();\n");
	fprintf(cgiOut, "  var targetNode = targetTree.getSelectedNodes();\n");
	fprintf(cgiOut, "  if(null == srcNode || 0 == srcNode.length)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����ѡ����Ҫ�ƶ����豸!');\n");
	fprintf(cgiOut, "    return false;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  //������Ƴ�\n");
	fprintf(cgiOut, "  if($.fn.zTree.getZTreeObj('areaTree') == srcTree)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    for(var i=0; i<srcNode.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(0 == srcNode[i].level)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('��ǰ�ڵ㲻��ɾ����������ѡ��!');\n");
	fprintf(cgiOut, "        return false;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<srcNode.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      srcTree.removeNode(srcNode[i]);\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  //�ұ����������\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(null == targetNode || 0 == targetNode.length)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('����ѡ����ȷ�����豸�ķ���!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<srcNode.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(0 == srcNode[i].level || 1 == srcNode[i].level)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        return false;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<targetNode.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(0 == targetNode[i].level || 1 == targetNode[i].level || 2 == targetNode[i].level || 4 == targetNode[i].level)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('����ѡ����ȷ�����豸�ķ���!');\n");
	fprintf(cgiOut, "        return false;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<srcNode.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      for(var j=0; j<targetNode.length; j++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var childNodes = targetTree.transformToArray(targetNode[j]);\n");
	fprintf(cgiOut, "        for(var k=0; k<childNodes.length; k++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          if(targetNode[j].value == childNodes[k].pId)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            if(srcNode[i].id == childNodes[k].id)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              alert('�����豸�Ѵ��ڣ�����!');\n");
	fprintf(cgiOut, "              return false;\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<srcNode.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      for(var j=0; j<targetNode.length; j++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        targetTree.addNodes(targetNode[j], srcNode[i]);\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	/*-----------------------------�豸��----------------------------------*/
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = "select t.id, t.cname, t.upper, t.ctype, a.s_icon from device_detail t, device_info a where substr(t.id,1,6) = a.id and t.ctype <> '03' order by t.id ";
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_device, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(3);
	}
	
	/*-----------------------------������----------------------------------*/
	fprintf(cgiOut, "var n = {id:'60', name:'��Ԫ����', value:'60', pId:'-1', iconsrc:' ', signstr:'0', pos_xstr:' ', pos_ystr:' ', isParent:true, open:true};\n");
	fprintf(cgiOut, "Nodes1.push(n);\n");
	char * sql = getSql(atoi(cmd));
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_area, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(3);
	}
	sqlite3_close(db);
	
	/*-----------------------------������----------------------------------*/
	fprintf(cgiOut, "$('#areaTree').empty();\n");
	fprintf(cgiOut, "$.fn.zTree.init($('#areaTree'), setting, Nodes1);\n");
	fprintf(cgiOut, "$('#devTree').empty();\n");
	fprintf(cgiOut, "$.fn.zTree.init($('#devTree'), setting2, Nodes2);\n");
	
	/*-----------------------------�ύ��----------------------------------*/
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var zTree1 = $.fn.zTree.getZTreeObj('areaTree')\n");
	//��2�㲻��64���ж�
	fprintf(cgiOut, "  var level2_Array = zTree1.getNodesByParam('level', 2);\n");
	fprintf(cgiOut, "  for(var i in level2_Array)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var NodeAll = 0;\n");
	fprintf(cgiOut, "    var level4_Array = zTree1.getNodesByParam('level', 4);\n");
	fprintf(cgiOut, "    for(var j in level4_Array)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(level2_Array[i].value == level4_Array[j].pId.substring(0,6))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        NodeAll++;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(NodeAll > 64)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('��2��ڵ��豸�����ó���64������������!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	//�ַ�����֯
	fprintf(cgiOut, "  var Control_Role = '';\n");
	fprintf(cgiOut, "  var tempArray = zTree1.getNodesByParam('level', 1);\n");
	fprintf(cgiOut, "  for(var i in tempArray)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Control_Role += tempArray[i].value + ';' + tempArray[i].name + ';' + tempArray[i].iconsrc + ';' + tempArray[i].signstr + ';' + tempArray[i].pos_xstr + ';' + tempArray[i].pos_ystr + ';' + ' $';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  tempArray = zTree1.getNodesByParam('level', 2);\n");
	fprintf(cgiOut, "  for(var i in tempArray)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Control_Role += tempArray[i].value + ';' + tempArray[i].name + ';' + tempArray[i].iconsrc + ';' + tempArray[i].signstr + ';' + tempArray[i].pos_xstr + ';' + tempArray[i].pos_ystr + ';' + ' $';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  tempArray = zTree1.getNodesByParam('level', 3);\n");
	fprintf(cgiOut, "  for(var i in tempArray)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Control_Role += tempArray[i].value + ';' + tempArray[i].name + ';' + tempArray[i].iconsrc + ';' + tempArray[i].signstr + ';' + tempArray[i].pos_xstr + ';' + tempArray[i].pos_ystr + ';';\n");
	fprintf(cgiOut, "    var childNodes = zTree1.transformToArray(tempArray[i]);\n");
	fprintf(cgiOut, "    for(var j=0; j<childNodes.length; j++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(tempArray[i].value == childNodes[j].pId)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Control_Role += childNodes[j].value + ',';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    Control_Role += ' $';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(Control_Role.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ӽ�ɫ���������豸�ֲ�!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "	 if(Control_Role.length > 21600)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   alert('��ǰ��ɫ���豸�ֲ�����,�뾫��!');\n");
	fprintf(cgiOut, "	   return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(confirm(\"ȷ���ύ?\"))\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   document.getElementById('sub_btn').innerHTML = \"<img style='cursor:hand' src='../skin/images/mini_button_submit_gray.gif'>\";\n");
	fprintf(cgiOut, "	   Corp_DeviceArea.Str_List.value = Control_Role;\n");
	fprintf(cgiOut, "	   Corp_DeviceArea.submit();\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "var reqSta = null;\n");
	fprintf(cgiOut, "function doNodeScene(pId, pCName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  //�ж��Ƿ������\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqSta = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqSta = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqSta.onreadystatechange = function()\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var state = reqSta.readyState;\n");
	fprintf(cgiOut, "    if(state == 4)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var resp = reqSta.responseText;\n");
	fprintf(cgiOut, "      if(null != resp && resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('objDiv').style.display = 'block';\n");
	fprintf(cgiOut, "        var url = 'net_nodescene.cgi?cmd=1&id='+pId+'&cname='+pCName;\n");
	fprintf(cgiOut, "        document.getElementById('objDiv').innerHTML = \"<iframe id='childFrame' name='childFrame' src='\"+url+\"' style='width:100%%;height:100%%;' frameborder=0 allowTransparency='true' scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('��ǰ�ڵ���δ������⣬���ȵ��[�ύ]��⣬��ʹ�ó���ͼ����!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  };\n");
	fprintf(cgiOut, "  var url = 'net_area.cgi?cmd=13&id='+pId+'&currtime='+new Date();\n");
	fprintf(cgiOut, "  reqSta.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqSta.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqSta.send(null);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "var reqAct = null;\n");
	fprintf(cgiOut, "function doNodeAction(pRoleId, pId, pCName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  //�ж��Ƿ������\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqAct = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    reqAct = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  reqAct.onreadystatechange = function()\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var state = reqAct.readyState;\n");
	fprintf(cgiOut, "    if(state == 4)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var resp = reqAct.responseText;\n");
	fprintf(cgiOut, "      if(null != resp && resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('actDiv').style.display = 'block';\n");
	fprintf(cgiOut, "        var url = 'net_nodeaction.cgi?cmd=1&id='+pRoleId+'&point='+pId;\n");
	fprintf(cgiOut, "        document.getElementById('actDiv').innerHTML = \"<iframe id='actionFrame' name='actionFrame' src='\"+url+\"' style='width:100%%;height:100%%;' frameborder=0 allowTransparency='true' scrolling='auto'></iframe>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('��ǰ�ڵ���δ������⣬���ȵ��[�ύ]��⣬��ʹ�ö���Ȩ�޷��书��!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  };\n");
	fprintf(cgiOut, "  var url = 'net_area.cgi?cmd=14&id='+pRoleId+'&dev_id='+pId+'&currtime='+new Date();\n");
	fprintf(cgiOut, "  reqAct.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqAct.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqAct.send(null);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('objDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function closeActDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('actDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

void DealData()
{
	char Str_List[4096*8] = {0};
	cgiFormString("Str_List", Str_List, sizeof(Str_List));
	
	char *p;
	char *buffer = strdup(Str_List);
	p = strtok(buffer, "$");
	while(NULL != p)
	{
		sprintf(point, "%s", "");
		char * save = p + strlen(p) + 1;
		char *temp_p;
		char *temp_buffer = strdup(p);
		temp_p = strtok(temp_buffer, ";");
		int i = 0;
		while(temp_p != NULL)
		{
			switch(i)
			{
				case 0:
					sprintf(id, "%s", temp_p);
					break;
				case 1:
					sprintf(cname, "%s", temp_p);
					break;
				case 2:
					sprintf(icon, "%s", temp_p);
					break;
				case 3:
					sprintf(sign, "%s", temp_p);
					break;
				case 4:
					sprintf(pos_x, "%s", temp_p);
					break;
				case 5:
					sprintf(pos_y, "%s", temp_p);
					break;
				case 6:
					sprintf(point, "%s", temp_p);
					break;
			}
			temp_p = strtok(NULL, ";");
			i++;
		}
		
		/*
		if(strlen(id) == 4 || strlen(id) == 8 || NULL == icon || strlen(icon) == 0)
		{
			sprintf(icon, "%s", "");
		}
		
		if(strlen(id) == 4 || NULL == point || strlen(point) == 0)
		{
			sprintf(point, "%s", "");
		}
		*/
		
		sprintf(cmd, "%s", "10");
		UpdateData();
		
		p = strtok(save, "$");
	}
}

void UpdateData()
{
  int rc = SQLITE_ERROR;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	sqlite3 *db = open_db(DB_PATH);
	if(NULL == db)
	{
		err_msg(1);
		return;
	}
	
	while((rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_area, 0, &zErrMsg)) != SQLITE_OK && NULL != strstr(zErrMsg, "database is locked"));
	if(SQLITE_OK != rc)
	{
		sqlite3_close(db);
		return;
	}
	
	sqlite3_close(db);
}

int sqlite3_exec_callback_area(void *data, int n_columns, char **col_values, char **col_names)
{
	if(strlen(col_values[0]) >= 4 && col_values[0][0] == '6' && col_values[0][1] == '0')
	{
		switch(strlen(col_values[0]))
		{
			case 4:
				fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'60', iconsrc:'%s', signstr:'%s', pos_xstr:'%s', pos_ystr:'%s', isParent:true, open:true};\n", col_values[0], col_values[1], col_values[0], col_values[3], col_values[4], col_values[5], col_values[6]);
				fprintf(cgiOut, "Nodes1.push(node);\n");
				break;
			case 6:
				fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s'.substring(0,4), iconsrc:'%s', signstr:'%s', pos_xstr:'%s', pos_ystr:'%s', isParent:true, open:true};\n", col_values[0], col_values[1], col_values[0], col_values[0], col_values[3], col_values[4], col_values[5], col_values[6]);
				fprintf(cgiOut, "Nodes1.push(node);\n");
				break;
			case 8:
				fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s'.substring(0,6), iconsrc:'%s', signstr:'%s', pos_xstr:'%s', pos_ystr:'%s', isParent:true};\n", col_values[0], col_values[1], col_values[0], col_values[0], col_values[3], col_values[4], col_values[5], col_values[6]);
				fprintf(cgiOut, "Nodes1.push(node);\n");
				
				if(NULL != col_values[2] && strlen(col_values[2]) > 6)
				{
					char *p;
					char *buffer = strdup(col_values[2]);
					p = strtok(buffer, ",");
					while(NULL != p)
					{				
						if(NULL != p && strlen(p) >= 6)
						{
							fprintf(cgiOut, "var Strhash = hashTable['%s'];\n", p);
							fprintf(cgiOut, "var StrName = Strhash.split('$')[0];\n");
							fprintf(cgiOut, "var StrIcon = '../system/' + Strhash.split('$')[1];\n");
							fprintf(cgiOut, "var subnode = {id:'%s', name:StrName, value:'%s', pId:'%s', icon:StrIcon, open:false};\n", p, p, col_values[0]);
							fprintf(cgiOut, "Nodes1.push(subnode);\n");
							//fprintf(cgiOut, "delete(hashTable['%s']);\n", p);
						}
						p = strtok(NULL, ",");
					}
				}
				break;
		}
	}
	return 0;
}

int sqlite3_exec_callback_device(void *data, int n_columns, char **col_values, char **col_names)
{
	char upper[11] = {0};
	if(0 != strcmp(col_values[3], "00") && 0 != strcmp(col_values[3], "01") && 10 == strlen(col_values[2]) && 0 != strcmp(col_values[2], "0011020001"))
		memcpy(upper, "0011020001", 11);
	else
		memcpy(upper, col_values[2], 11);
	
	fprintf(cgiOut, "var node = {id:'%s', name:'%s', value:'%s', pId:'%s', icon:'../system/%s', open:false};\n", col_values[0], col_values[1], col_values[0], upper, col_values[4]);
	fprintf(cgiOut, "Nodes2.push(node);\n");
	fprintf(cgiOut, "add('%s', '%s$%s');\n", col_values[0], col_values[1], col_values[4]);
	return 0;
}

void isNodeScene()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = {0};
	sprintf(sql1, "select t.id, t.cname, t.point, t.icon from role t where t.id = '%s'", id);
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_node, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
	
	if(cnt > 0)
		printf("0000\n");
	else
		printf("3006\n");
}

int sqlite3_exec_callback_node(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

void isNodeAction()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = {0};
	sprintf(sql1, "select t.id, t.cname, t.point, t.icon from role t where t.id = '%s'", id);
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_act, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
	
	if(cnt > 0)
		printf("0000\n");
	else
		printf("3006\n");
}

int sqlite3_exec_callback_act(void *data, int n_columns, char **col_values, char **col_names)
{
	if(strstr(col_values[2], dev_id))
	{
		cnt++;
	}
	return 0;
}
