#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <dirent.h> 
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"
#include "IniFile.h"
#include "DES_Util.h"
#define LINE 2048

//��������
char DESKey[60] = {0};
char uproute[512] = {0};
char Sql[1024] = {0};
char HtmlData[512] = {0};
int cnt = 0;
int cnt1 = 0;
char cmd[4] = {0};
char FillStr[3] = {0};
char flag[2] = {0};
char ip[16] = {0};					//IP
char mask[16] = {0};				//����
char gate[16] = {0};				//����
char gateway_status[2] = {0};//����״̬

char id[7] = {0};					  //���
char cname[51] = {0};				//����
char addr[129] = {0};				//��ַ
char tel[31] = {0};				  //�绰
char contact[11] = {0};			//��ϵ��
char brief[13] = {0};       //���
char nettype[2] = {0};      //ͨѶ��������
char time_out[5] = {0};     //��ʱ����
char staudp[11] = {0};      //״̬��������
char dept[256] = {0};       //��������
char ats[256] = {0};        //��������
char dns_url[60] = {0};     //����
char dns_pwd[60] = {0};     //����
char dns_status[2] = {0};   //����״̬
char dns_ip[20] = {0};      //IP
char dns_port[7] = {0};     //�˿�
char m1key[385] = {0};      //��ҵ����
char systime[16] = {0};     //ϵͳʱ��
char netid[21] = {0};       //���������ʺ�
char netpwd[21] = {0};      //������������
char data_status[2] = {0};  //�ϴ�״̬
char data_ip[20] = {0};     //IP
char data_port[7] = {0};    //�˿�
char data_login[21] = {0};  //CPM���к�
char data_pwd[21] = {0};    //CPM����
char gsm_center[21] = {0};  //��������
char ntp_status[2] = {0};   //NTP״̬
char ntp_hour[5] = {0};     //NTP���
char ntp_svrip[20] = {0};   //NTP������

char msgdata_status[2] = {0};//�ϴ�״̬
char msgdata_ip[20] = {0};
char msgdata_port[7] = {0};
char msgdata_login[21] = {0};
char msgdata_pwd[21] = {0};

char uploadret[2] = {0};

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ
static void QueryData();
//����
static void UpdateData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cnt(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_outset(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_about(void *data, int n_columns, char **col_values, char **col_names);
//��������
static void NetConfig();
static void NetInfo();
static bool SetNetInfo();
//ϵͳʱ��
static void TimeConfig();
static bool SetSysTime();
//ʱ��ͬ��
static void doSync();
static bool SetSync();
//�������
static void doCPMUdp();
static bool doCPMUdpTrue();
//�����
static void doSystem();
bool getFile();
//��������
static void doCPM();
//��������
static void RebootCPM();
//����
static void AboutCPM();
//DDNS����
static void DDNSConfig();
static bool SetDDNS();
//�ϴ�����
static void UPConfig();
static bool SetUP();
//Logo����
static void doLogo();
static void ImgUpload();

int cgiMain()
{
	cgiHeaderContentType("text/html");
	getHtmlData();
	
	cnt = 0;
	cnt1 = 0;
	switch(atoi(cmd))
	{
		case 21://ʱ��ͬ��
			doSync();
			break;
		case 22://ʱ��ͬ��
			if(SetSync())
			{
				fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�');</script>\n");
			}
			else
			{
				fprintf(cgiOut, "<script language='javascript'>alert('����ʧ��');</script>\n");
			}
			//��ѯ
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
			sprintf(cmd, "%s", "0");
			QueryData();
			break;
		case 19://Logo����
			doLogo();
			break;
		case 20://Logo����
			ImgUpload();
			if(0 == strcmp(uploadret, "1"))
			{
				fprintf(cgiOut, "<script language='javascript'>alert('ͼƬ�����ϴ�ʧ�ܣ�����100K����!');</script>\n");
			}
			//��ѯ
			fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�! ΪʹͼƬʵʱ��Ч, ��ɾ������������ر���������´򿪵���!');</script>\n");
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
			sprintf(cmd, "%s", "0");
			QueryData();
			break;
		case 10://�޸�
			UpdateData();
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
		case 0://��ѯ
			QueryData();
			break;
		case 8://��������
			NetConfig();
			break;
		case 9://��������
			if(SetNetInfo())
			{
				fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�');</script>\n");
			}
			else
			{
				fprintf(cgiOut, "<script language='javascript'>alert('����ʧ��');</script>\n");
			}
			//��ѯ			
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
			sprintf(cmd, "%s", "0");
			QueryData();
			break;
		case 13://ϵͳʱ��
			TimeConfig();
			break;
		case 14://ϵͳʱ��
			if(SetSysTime())
			{
				fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�');</script>\n");
			}
			else
			{
				fprintf(cgiOut, "<script language='javascript'>alert('����ʧ��');</script>\n");
			}
			//��ѯ			
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
			sprintf(cmd, "%s", "0");
			QueryData();
			break;
		case 15://DDNS����
			DDNSConfig();
			break;
		case 16://DDNS����
			if(SetDDNS())
			{
				fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�');</script>\n");
			}
			else
			{
				fprintf(cgiOut, "<script language='javascript'>alert('����ʧ��');</script>\n");
			}
			//��ѯ			
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
			sprintf(cmd, "%s", "0");
			QueryData();
			break;
		case 17://�ϴ�����
			UPConfig();
			break;
		case 18://�ϴ�����
			if(SetUP())
			{
				fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�');</script>\n");
			}
			else
			{
				fprintf(cgiOut, "<script language='javascript'>alert('����ʧ��');</script>\n");
			}
			//��ѯ			
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
			sprintf(cmd, "%s", "0");
			QueryData();
			break;
		case 1://����
			AboutCPM();
			break;
		case 2://��������
			RebootCPM();
			break;
		case 3://��������
			doCPM();
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
			sprintf(cmd, "%s", "0");
			QueryData();
			break;
		case 4://�����
			doSystem();
			break;
		case 5://�����
			//�ر�CPM
			system("killall CPM");
			
			//�ļ�����
			if(getFile())
			{
				fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�');</script>\n");
			}
			else
			{
				fprintf(cgiOut, "<script language='javascript'>alert('����ʧ��');</script>\n");
			}		
			
			//��ѯ			
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
			sprintf(cmd, "%s", "0");
			QueryData();
			
			//����CPM
			system("/home/CPM/CPM/startCPM.sh");
			break;
		case 6://�������
			doCPMUdp();
			break;
		case 7://�������
			if(doCPMUdpTrue())
			{
				fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�');</script>\n");
			}
			else
			{
				fprintf(cgiOut, "<script language='javascript'>alert('����ʧ��');</script>\n");
			}
			//��ѯ			
			fprintf(cgiOut, "<script language='javascript'>window.parent.frames.leftFrame.CurrButton.click();</script>\n");
			sprintf(cmd, "%s", "0");
			QueryData();
			break;
	}
	
	return 0;
}

static void getHtmlData()
{
	cgiFormString("uproute", uproute, sizeof(uproute));
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("addr", addr, sizeof(addr));
	cgiFormString("tel", tel, sizeof(tel));
	cgiFormString("contact", contact, sizeof(contact));
	cgiFormString("brief", brief, sizeof(brief));
	cgiFormString("nettype", nettype, sizeof(nettype));
	cgiFormString("time_out", time_out, sizeof(time_out));
	cgiFormString("staudp", staudp, sizeof(staudp));
	cgiFormString("dept", dept, sizeof(dept));
	cgiFormString("ats", ats, sizeof(ats));
	cgiFormString("dns_url", dns_url, sizeof(dns_url));
	cgiFormString("dns_pwd", dns_pwd, sizeof(dns_pwd));
	cgiFormString("dns_status", dns_status, sizeof(dns_status));
	cgiFormString("dns_ip", dns_ip, sizeof(dns_ip));
	cgiFormString("dns_port", dns_port, sizeof(dns_port));
	cgiFormString("systime", systime, sizeof(systime));
	cgiFormString("netid", netid, sizeof(netid));
	cgiFormString("netpwd", netpwd, sizeof(netpwd));
	cgiFormString("data_status", data_status, sizeof(data_status));
	cgiFormString("data_ip", data_ip, sizeof(data_ip));
	cgiFormString("data_port", data_port, sizeof(data_port));		
	cgiFormString("data_login", data_login, sizeof(data_login));	
	cgiFormString("data_pwd", data_pwd, sizeof(data_pwd));
	cgiFormString("flag", flag, sizeof(flag));
	cgiFormString("ip", ip, sizeof(ip));
	cgiFormString("mask", mask, sizeof(mask));
	cgiFormString("gate", gate, sizeof(gate));
	cgiFormString("gateway_status", gateway_status, sizeof(gateway_status));
	cgiFormString("gsm_center", gsm_center, sizeof(gsm_center));
	cgiFormString("ntp_status", ntp_status, sizeof(ntp_status));
	cgiFormString("ntp_hour", ntp_hour, sizeof(ntp_hour));
	cgiFormString("ntp_svrip", ntp_svrip, sizeof(ntp_svrip));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      	strcat(Sql, "select t.id, t.cname, t.addr, t.tel, t.contact, t.brief, t.nettype, t.timeout, t.dept, t.netid, t.netpwd, t.staudp, t.ats from corp_info t");
			break;
		case 10://����
        strcat(Sql, "update corp_info set id = '");
        strcat(Sql, id);
				strcat(Sql, "', cname = '");
				strcat(Sql, cname);
				strcat(Sql, "', addr = '");
				strcat(Sql, addr);			
				strcat(Sql, "', tel = '");
				strcat(Sql, tel);				
				strcat(Sql, "', contact = '");
				strcat(Sql, contact);				
				strcat(Sql, "', brief = '");
				strcat(Sql, brief);
				strcat(Sql, "', nettype = '");
				strcat(Sql, nettype);
				strcat(Sql, "', timeout = '");
				strcat(Sql, time_out);	
				strcat(Sql, "', dept = '");
				strcat(Sql, dept);
				strcat(Sql, "', netid = '");
				strcat(Sql, netid);
				strcat(Sql, "', netpwd = '");
				strcat(Sql, netpwd);
				strcat(Sql, "', staudp = '");
				strcat(Sql, staudp);	
				strcat(Sql, "', ats = '");
				strcat(Sql, ats);	
				strcat(Sql, "'");
			break;
		case 11://����
				strcat(Sql, "insert into corp_info(id, cname, addr, tel, contact, brief, nettype, timeout, dept, m1key, netid, netpwd, staudp, ats)values('");
        strcat(Sql, id);
				strcat(Sql, "', '");
				strcat(Sql, cname);
				strcat(Sql, "', '");
				strcat(Sql, addr);	
				strcat(Sql, "', '");
				strcat(Sql, tel);
				strcat(Sql, "', '");
				strcat(Sql, contact);	
				strcat(Sql, "', '");
				strcat(Sql, brief);
				strcat(Sql, "', '");
				strcat(Sql, nettype);
				strcat(Sql, "', '");
				strcat(Sql, time_out);
				strcat(Sql, "', '");
				strcat(Sql, dept);
				strcat(Sql, "', '");
				strcat(Sql, m1key);				
				strcat(Sql, "', '");
				strcat(Sql, netid);
				strcat(Sql, "', '");
				strcat(Sql, netpwd);
				strcat(Sql, "', '");
				strcat(Sql, staudp);
				strcat(Sql, "', '");
				strcat(Sql, ats);
				strcat(Sql, "')");
			break;
	}
	return Sql;
}

//ʱ��ͬ��
void doSync()
{
	fprintf(cgiOut, "<HTML>\n");
	fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>ʱ��ͬ��</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html; charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style='background:#e0e6ed'>\n");
	fprintf(cgiOut, "<form name='corp_info' action='corp_info.cgi' method='post' target='mainFrame'>\n");
	fprintf(cgiOut, "  <table width='100%%' style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right' colspan=2>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doUpdate();'><font color=green>[����]</font></a>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doClose();' ><font color=green>[�ر�]</font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	
	//NTPClientȡConfig.ini
	get_ini_string("/home/CPM/ntpclient/Config.ini", "NTP", "NTPStatus", "=", ntp_status, sizeof(ntp_status));
	get_ini_string("/home/CPM/ntpclient/Config.ini", "NTP", "NTPHour",   "=", ntp_hour,   sizeof(ntp_hour));
	get_ini_string("/home/CPM/ntpclient/Config.ini", "NTP", "NTPSvr",    "=", ntp_svrip,  sizeof(ntp_svrip));
	
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>ʱ�������IP</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'><input type='text' id='ntp_svrip' name='ntp_svrip' value='%s' style='width:100%%;height:20px;' maxlength=20></td>\n", ntp_svrip);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>ʱ��ͬ�����</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "        <select id='ntp_hour' name='ntp_hour' style='width:100%%;height:20px;'>\n");
	fprintf(cgiOut, "          <option value='1'  %s>ÿ��1Сʱͬ��һ��</option>\n",  0 == strcmp(ntp_hour, "1")?"selected":"");
	fprintf(cgiOut, "          <option value='3'  %s>ÿ��3Сʱͬ��һ��</option>\n",  0 == strcmp(ntp_hour, "3")?"selected":"");
	fprintf(cgiOut, "          <option value='6'  %s>ÿ��6Сʱͬ��һ��</option>\n",  0 == strcmp(ntp_hour, "6")?"selected":"");
	fprintf(cgiOut, "          <option value='12' %s>ÿ��12Сʱͬ��һ��</option>\n", 0 == strcmp(ntp_hour, "12")?"selected":"");
	fprintf(cgiOut, "          <option value='24' %s>ÿ��24Сʱͬ��һ��</option>\n", 0 == strcmp(ntp_hour, "24")?"selected":"");
	fprintf(cgiOut, "          <option value='48' %s>ÿ��48Сʱͬ��һ��</option>\n", 0 == strcmp(ntp_hour, "48")?"selected":"");
	fprintf(cgiOut, "          <option value='72' %s>ÿ��72Сʱͬ��һ��</option>\n", 0 == strcmp(ntp_hour, "72")?"selected":"");
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "        <select id='ntp_status' name='ntp_status' style='width:100%%;height:20px;'>\n");
	fprintf(cgiOut, "          <option value='0' %s>ͣ��</option>\n", 0 == strcmp(ntp_status, "0")?"selected":"");
	fprintf(cgiOut, "          <option value='1' %s>����</option>\n", 0 == strcmp(ntp_status, "1")?"selected":"");
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='22'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doUpdate()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(corp_info.ntp_status.value == '1')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(corp_info.ntp_svrip.value.length < 1){alert('��ѡ������ʱ��ͬ������,����дʱ�������IP��ַ');return;}\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "		 corp_info.submit();\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

bool SetSync()
{
	//�޸�NTP����
	set_ini_string("/home/CPM/ntpclient/Config.ini", "NTP", "NTPStatus", ntp_status);
	set_ini_string("/home/CPM/ntpclient/Config.ini", "NTP", "NTPHour", ntp_hour);
	set_ini_string("/home/CPM/ntpclient/Config.ini", "NTP", "NTPSvr", ntp_svrip);
	
	//����NTP
	system("killall NTPClient");
	if(0 == strcmp(ntp_status, "1"))
	{
		system("/home/CPM/ntpclient/startNTPClient.sh");
	}
	
	return true;
}

//Logo����
void doLogo()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>Logo����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"corp_info\" action=\"corp_info.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "  <table width=\"100%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right'><a href='#' onclick='doClose();'><font color=green>[�ر�]</font></a></td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "        <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "          <tr height='60'>\n");
	fprintf(cgiOut, "            <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              LOGOͼƬ:<input type='file' name='uproute'   title='��ѡ��ͼƬ' value='���' style='width:59%%;height:20px'>    <input type='button' value='����' style='width:50px;height:20px;' onClick='doUpload()'>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "            </td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='20'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doUpload()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var pUrl = corp_info.uproute.value;\n");
	fprintf(cgiOut, "  if(pUrl.indexOf('.jpg') == -1 && pUrl.indexOf('.JPG') == -1 && pUrl.indexOf('.gif') == -1 && pUrl.indexOf('.GIF') == -1 && pUrl.indexOf('.bmp') == -1 && pUrl.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ������LOGOͼƬ?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    corp_info.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

//ͼƬ�ϴ�
void ImgUpload()
{
	cgiFilePtr file;
	int targetFile;
	mode_t mode;
	char name[128];
	
	//�ļ���
	char fimename[10] = {0};
	strcat(fimename, "uproute");
	
	//�洢��
	char fileNameOnServer[64] = {0};
	strcat(fileNameOnServer, "/home/www/skin/images/logo_sub_system_manage.gif");
	
	char contentType[1024];
	char buffer[1024];
	int size;
	int got;

	//ͼƬ·����ȡ
	if (cgiFormFileName(fimename, name, sizeof(name)) != cgiFormSuccess)
	{    
		fprintf(stderr,"could not retrieve filename\n");
	}

	//ͼƬ����    
	cgiFormFileContentType(fimename, contentType, sizeof(contentType));

	//ͼƬ��С
	cgiFormFileSize(fimename, &size);
	if(size/1024 > 100)
	{
		memcpy(uploadret, "1", 2);
	}
	else
	{
		//Ŀǰ�ļ�������ϵͳ��ʱ�ļ����У�ͨ��Ϊ/tmp��ͨ�����������ʱ�ļ�����ʱ�ļ����������û��ļ������ֲ�ͬ�����Բ���ͨ��·��/tmp/userfilename�ķ�ʽ����ļ�    
		if (cgiFormFileOpen(fimename, &file) != cgiFormSuccess)
		{    
			fprintf(stderr,"could not open the file\n");   
		}
		
		//�ڵ�ǰĿ¼�½����µ��ļ�����һ������ʵ������·�������˴��ĺ�������cgi�������ڵ�Ŀ¼����ǰĿ¼�����������ļ�  
		mode = S_IRWXU|S_IRGRP|S_IROTH;
		targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode); 
		if(targetFile < 0)
		{    
			fprintf(stderr,"could not create the new file,%s\n",fileNameOnServer);    
		}
		
		//��ϵͳ��ʱ�ļ��ж����ļ����ݣ����ŵ��մ�����Ŀ���ļ���
		while(cgiFormFileRead(file, buffer, 1024, &got) == cgiFormSuccess)
		{
			if(got > 0)
				write(targetFile, buffer, got);
		}
		cgiFormFileClose(file);
		close(targetFile);
		
		goto END;
		END:
		system("cp /home/www/skin/images/logo_sub_system_manage.gif /home/www/skin/images/logo_sub_device_manage.gif");
		system("cp /home/www/skin/images/logo_sub_system_manage.gif /home/www/skin/images/logo_sub_application_manage.gif");
	}
}

//��������
void NetConfig()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>��������</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"corp_info\" action=\"corp_info.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "  <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right' colspan=2>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doUpdate();'><font color=green>[����]</font></a>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doClose();' ><font color=green>[�ر�]</font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>IP ��&nbsp;&nbsp;ַ</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "        <input type=text id=ip1 name=ip1 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste='doMask_c()'>.\n");
	fprintf(cgiOut, "        <input type=text id=ip2 name=ip2 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste='doMask_c()'>.\n");
	fprintf(cgiOut, "        <input type=text id=ip3 name=ip3 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste='doMask_c()'>.\n");
	fprintf(cgiOut, "        <input type=text id=ip4 name=ip4 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste='doMask_c()'>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "        <input type=text id=mask1 name=mask1 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste=doMask_c()>.\n");
	fprintf(cgiOut, "        <input type=text id=mask2 name=mask2 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste=doMask_c()>.\n");
	fprintf(cgiOut, "        <input type=text id=mask3 name=mask3 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste=doMask_c()>.\n");
	fprintf(cgiOut, "        <input type=text id=mask4 name=mask4 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste=doMask_c()>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'><input type='checkbox' id='gateway_sta' onclick='doGateway()'>Ĭ������</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left' colspan=3>\n");
	fprintf(cgiOut, "        <input type=text id=gate1 name=gate1 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste=doMask_c()>.\n");
	fprintf(cgiOut, "        <input type=text id=gate2 name=gate2 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste=doMask_c()>.\n");
	fprintf(cgiOut, "        <input type=text id=gate3 name=gate3 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste=doMask_c()>.\n");
	fprintf(cgiOut, "        <input type=text id=gate4 name=gate4 value='0' style='width:45px;height:20px;' maxlength=3 size=3 onkeyup='doMask(this)' onbeforepaste=doMask_c()>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='9'>\n");
	fprintf(cgiOut, "  <input type='hidden' name='ip' value=''>\n");
	fprintf(cgiOut, "  <input type='hidden' name='mask' value=''>\n");
	fprintf(cgiOut, "  <input type='hidden' name='gate' value=''>\n");
	fprintf(cgiOut, "  <input type='hidden' name='gateway_status' value='0'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doGateway()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(!document.getElementById('gateway_sta').checked)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('gateway_sta').checked = false;\n");
	fprintf(cgiOut, "    document.getElementById('gate1').style.display = 'none';\n");
	fprintf(cgiOut, "    document.getElementById('gate2').style.display = 'none';\n");
	fprintf(cgiOut, "    document.getElementById('gate3').style.display = 'none';\n");
	fprintf(cgiOut, "    document.getElementById('gate4').style.display = 'none';\n");
	fprintf(cgiOut, "    document.getElementById('gate1').value = '0';\n");
	fprintf(cgiOut, "    document.getElementById('gate2').value = '0';\n");
	fprintf(cgiOut, "    document.getElementById('gate3').value = '0';\n");
	fprintf(cgiOut, "    document.getElementById('gate4').value = '0';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('gateway_sta').checked = true;\n");
	fprintf(cgiOut, "    document.getElementById('gate1').style.display = '';\n");
	fprintf(cgiOut, "    document.getElementById('gate2').style.display = '';\n");
	fprintf(cgiOut, "    document.getElementById('gate3').style.display = '';\n");
	fprintf(cgiOut, "    document.getElementById('gate4').style.display = '';\n");
	fprintf(cgiOut, "    document.getElementById('gate1').value = '0';\n");
	fprintf(cgiOut, "    document.getElementById('gate2').value = '0';\n");
	fprintf(cgiOut, "    document.getElementById('gate3').value = '0';\n");
	fprintf(cgiOut, "    document.getElementById('gate4').value = '0';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doMask(obj)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  obj.value = obj.value.replace(/[^\\d]/g, '');\n");
	fprintf(cgiOut, "  var key1 = event.keyCode;\n");
	fprintf(cgiOut, "	 if(key1 == 37 || key1 == 39)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   obj.blur();\n");
	fprintf(cgiOut, "	 	 nextip = parseInt(obj.name.substr(2,1));\n");
	fprintf(cgiOut, "	 	 nextip = (key1 == 37) ? nextip - 1 : nextip + 1;\n");
	fprintf(cgiOut, "	 	 nextip = (nextip >= 5) ? 1 : nextip;\n");
	fprintf(cgiOut, "	   nextip = (nextip <= 0) ? 4 : nextip;\n");
	//fprintf(cgiOut, "	   eval('ip' + nextip + '.focus()');\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(obj.value.length >= 3)\n");
	fprintf(cgiOut, "	 if(parseInt(obj.value) >= 256 || parseInt(obj.value) <= 0)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   obj.value = '';\n");
	fprintf(cgiOut, "	   obj.focus();\n");
	fprintf(cgiOut, "	   return false;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 else\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   obj.blur();\n");
	fprintf(cgiOut, "	   nextip = parseInt(obj.name.substr(2,1)) + 1;\n");
	fprintf(cgiOut, "	   nextip = (nextip >= 5) ? 1 : nextip;\n");
	fprintf(cgiOut, "	   nextip = (nextip <= 0) ? 4 : nextip;\n");
	//fprintf(cgiOut, "	   eval(\"document.getElementById('\" + \"ip\" + nextip + \"').focus()\");\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doMask_c(obj)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 clipboardData.setData('text',clipboardData.getData('text').replace(/[^\\d]/g,''));\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doUpdate()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(document.getElementById('gateway_sta').checked)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    corp_info.gateway_status.value = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    corp_info.gateway_status.value = '0';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(corp_info.ip1.value.length < 1){alert('����ȷ��дIP��ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.ip2.value.length < 1){alert('����ȷ��дIP��ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.ip3.value.length < 1){alert('����ȷ��дIP��ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.ip4.value.length < 1){alert('����ȷ��дIP��ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.mask1.value.length < 1){alert('����ȷ��д�����ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.mask2.value.length < 1){alert('����ȷ��д�����ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.mask3.value.length < 1){alert('����ȷ��д�����ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.mask4.value.length < 1){alert('����ȷ��д�����ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.gate1.value.length < 1){alert('����ȷ��д���ص�ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.gate2.value.length < 1){alert('����ȷ��д���ص�ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.gate3.value.length < 1){alert('����ȷ��д���ص�ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.gate4.value.length < 1){alert('����ȷ��д���ص�ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.gateway_status.value == '1' && corp_info.gate1.value == '0' && corp_info.gate2.value == '0' && corp_info.gate3.value == '0' && corp_info.gate4.value == '0')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����ȷ��д���ص�ַ');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "	 corp_info.ip.value = corp_info.ip1.value + '.' + corp_info.ip2.value + '.' + corp_info.ip3.value + '.' + corp_info.ip4.value;\n");
	fprintf(cgiOut, "	 corp_info.mask.value = corp_info.mask1.value + '.' + corp_info.mask2.value + '.' + corp_info.mask3.value + '.' + corp_info.mask4.value;\n");
	fprintf(cgiOut, "	 corp_info.gate.value = corp_info.gate1.value + '.' + corp_info.gate2.value + '.' + corp_info.gate3.value + '.' + corp_info.gate4.value;\n");	
	fprintf(cgiOut, "	 if(ip == corp_info.ip.value.Trim() && mask == corp_info.mask.value.Trim() && gate == corp_info.gate.value.Trim())\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 alert('��ǰδ�����κ���Ϣ�������ύ!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "		 if(ip != corp_info.ip.value.Trim())\n");
	fprintf(cgiOut, "		 {\n");
	fprintf(cgiOut, "			 if(confirm('ע��:��ǰ����������IP��ַ,�����ĳɹ�,��رյ�ǰ��ҳ,����IP['+ corp_info.ip.value.Trim() +']����'))\n");
	fprintf(cgiOut, "			 {\n");
	fprintf(cgiOut, "				 corp_info.submit();\n");
	fprintf(cgiOut, "			 }\n");
	fprintf(cgiOut, "		 }\n");
	fprintf(cgiOut, "		 else\n");
	fprintf(cgiOut, "		 {\n");
	fprintf(cgiOut, "			 corp_info.submit();\n");
	fprintf(cgiOut, "		 }\n");
	fprintf(cgiOut, "	}\n");
	fprintf(cgiOut, "}\n");
	
	//������Ϣ
	NetInfo();
	
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

void NetInfo()
{
	FILE *netinfo = fopen("/root/network", "rb+");
	char buffer[256] = {0};
	char Row1[256] = {0};
	char Row2[256] = {0};
	char Row3[256] = {0};
	if(NULL != netinfo)
	{
		int i = 0;
		while(fgets(buffer, 1024, netinfo) != NULL)
	 	{
 			buffer[strlen(buffer)-1] = '\0';//ȥ���з�
			switch(i)
			{
				case 0:
						memcpy(Row1, buffer, 256);
					break;
				case 1:
						memcpy(Row2, buffer, 256);
					break;
				case 2:
						memcpy(Row3, buffer, 256);
					break;
			}
			i++;
	 	}
	 	
	 	if(strlen(Row1) > 0)
	 	{
	 		fprintf(cgiOut, "var Row1 = '%s';\n", Row1);
	 		fprintf(cgiOut, "var ip = Row1.substring(Row1.indexOf('eth0')+4, Row1.indexOf('netmask')).Trim();\n");
	 		fprintf(cgiOut, "var mask = Row1.substring(Row1.indexOf('netmask')+7, Row1.indexOf('up')).Trim();\n");
	 		fprintf(cgiOut, "var iplist = ip.split('.');\n");
	 		fprintf(cgiOut, "var masklist = mask.split('.');\n");
	 		fprintf(cgiOut, "for(var i=0; i<4; i++)\n");
	 		fprintf(cgiOut, "{\n");
	 		fprintf(cgiOut, "  document.getElementById('ip'+(i+1)).value = iplist[i];\n");
	 		fprintf(cgiOut, "  document.getElementById('mask'+(i+1)).value = masklist[i];\n");
	 		fprintf(cgiOut, "}\n");
	 	}
	 		 	
	 	fprintf(cgiOut, "var gate = '0.0.0.0';\n");
	 	if(NULL != Row3 && strlen(Row3) >0)
	 	{			 		
			fprintf(cgiOut, "document.getElementById('gateway_sta').checked = true;\n");
			fprintf(cgiOut, "document.getElementById('gate1').style.display = '';\n");
			fprintf(cgiOut, "document.getElementById('gate2').style.display = '';\n");
			fprintf(cgiOut, "document.getElementById('gate3').style.display = '';\n");
			fprintf(cgiOut, "document.getElementById('gate4').style.display = '';\n");
			fprintf(cgiOut, "var Row3 = '%s';\n", Row3);
	 		fprintf(cgiOut, "gate = Row3.substring(Row3.indexOf('gw')+2).Trim();\n");
	 		fprintf(cgiOut, "var gatelist = gate.split('.');\n");
	 		fprintf(cgiOut, "for(var i=0; i<4; i++)\n");
	 		fprintf(cgiOut, "{\n");
	 		fprintf(cgiOut, "  document.getElementById('gate'+(i+1)).value = gatelist[i];\n");
	 		fprintf(cgiOut, "}\n");
	 	}
	 	else
	 	{
	 		fprintf(cgiOut, "document.getElementById('gateway_sta').checked = false;\n");
			fprintf(cgiOut, "document.getElementById('gate1').style.display = 'none';\n");
			fprintf(cgiOut, "document.getElementById('gate2').style.display = 'none';\n");
			fprintf(cgiOut, "document.getElementById('gate3').style.display = 'none';\n");
			fprintf(cgiOut, "document.getElementById('gate4').style.display = 'none';\n");
			fprintf(cgiOut, "document.getElementById('gate1').value = '0';\n");
			fprintf(cgiOut, "document.getElementById('gate2').value = '0';\n");
			fprintf(cgiOut, "document.getElementById('gate3').value = '0';\n");
			fprintf(cgiOut, "document.getElementById('gate4').value = '0';\n");
	 	}
	}
}

bool SetNetInfo()
{
	char Row1[256] = {0};
	char Row2[256] = {0};
	char Row3[256] = {0};
	strcat(Row1, "/sbin/ifconfig eth0 ");
	strcat(Row1, ip);
	strcat(Row1, " netmask ");
	strcat(Row1, mask);
	strcat(Row1, " up");
	strcat(Row2, "/sbin/route del default");
	if(0 == strcmp(gateway_status, "1"))
	{
		strcat(Row3, "/sbin/route add default gw ");
		strcat(Row3, gate);
	}
	
	FILE *network_bak = fopen("/root/network_bst", "w");
	if(NULL == network_bak)
	{
		return false;
	}
	fputs(Row1, network_bak); //Row1
	fputs("\n", network_bak);
	fputs(Row2, network_bak); //Row2
	fputs("\n", network_bak);
	fputs(Row3, network_bak); //Row3
	fputs("\n", network_bak);
	fclose(network_bak);
	
	chmod("/root/network_bst", 0777);
	if(remove("/root/network") == 0)
	{
		if(rename("/root/network_bst", "/root/network") != 0)
		{
			return false;
		}
	}
	else
	{
		return false;
	}
	
	int ret = 0;
	ret = system("/root/network");
	if(ret != 0)
	{
		return false;
	}
	return true;
}

//ϵͳʱ��
void TimeConfig()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>��������</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"corp_info\" action=\"corp_info.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "  <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right' colspan=2>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doUpdate();'><font color=green>[����]</font></a>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doClose();' ><font color=green>[�ر�]</font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	
	//��ȡϵͳʱ��
	time_t nowtime;
	struct tm *timeinfo;
	time(&nowtime);
	timeinfo = localtime(&nowtime);
	int year, month, day, hour, min, sec;
	year = timeinfo->tm_year + 1900;
	month = timeinfo->tm_mon + 1;
	day = timeinfo->tm_mday;
	hour = timeinfo->tm_hour;
	min = timeinfo->tm_min;
	sec = timeinfo->tm_sec;
	char s_date[11] = {0};
	sprintf(s_date, "%d-%02d-%02d", year, month, day);
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>ϵͳʱ��</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>\n");
	fprintf(cgiOut, "      <input type='text' name='day' onClick='WdatePicker({readOnly:true})' class='Wdate' size='10' style='width:90px' maxlength='10' value='%s'>\n", s_date);
	fprintf(cgiOut, "      <select name='hour' style='width:60px;height:20px'>\n");
	fprintf(cgiOut, "        <option value='00' %s>0�� </option>\n", 0  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='01' %s>1�� </option>\n", 1  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='02' %s>2�� </option>\n", 2  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='03' %s>3�� </option>\n", 3  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='04' %s>4�� </option>\n", 4  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='05' %s>5�� </option>\n", 5  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='06' %s>6�� </option>\n", 6  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='07' %s>7�� </option>\n", 7  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='08' %s>8�� </option>\n", 8  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='09' %s>9�� </option>\n", 9  == hour?"selected":"");
	fprintf(cgiOut, "        <option value='10' %s>10��</option>\n", 10 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='11' %s>11��</option>\n", 11 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='12' %s>12��</option>\n", 12 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='13' %s>13��</option>\n", 13 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='14' %s>14��</option>\n", 14 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='15' %s>15��</option>\n", 15 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='16' %s>16��</option>\n", 16 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='17' %s>17��</option>\n", 17 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='18' %s>18��</option>\n", 18 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='19' %s>19��</option>\n", 19 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='20' %s>20��</option>\n", 20 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='21' %s>21��</option>\n", 21 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='22' %s>22��</option>\n", 22 == hour?"selected":"");
	fprintf(cgiOut, "        <option value='23' %s>23��</option>\n", 23 == hour?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "      <select name='min' style='width:60px;height:20px'>\n");
	fprintf(cgiOut, "        <option value='00' %s>0�� </option>\n", 0  == min?"selected":"");
	fprintf(cgiOut, "        <option value='01' %s>1�� </option>\n", 1  == min?"selected":"");
	fprintf(cgiOut, "    		 <option value='02' %s>2�� </option>\n", 2  == min?"selected":"");
	fprintf(cgiOut, "    	   <option value='03' %s>3�� </option>\n", 3  == min?"selected":"");
	fprintf(cgiOut, "    	   <option value='04' %s>4�� </option>\n", 4  == min?"selected":"");
	fprintf(cgiOut, "        <option value='05' %s>5�� </option>\n", 5  == min?"selected":"");
	fprintf(cgiOut, "        <option value='06' %s>6�� </option>\n", 6  == min?"selected":"");
	fprintf(cgiOut, "        <option value='07' %s>7�� </option>\n", 7  == min?"selected":"");
	fprintf(cgiOut, "        <option value='08' %s>8�� </option>\n", 8  == min?"selected":"");
	fprintf(cgiOut, "        <option value='09' %s>9�� </option>\n", 9  == min?"selected":"");
	fprintf(cgiOut, "        <option value='10' %s>10��</option>\n", 10 == min?"selected":"");
	fprintf(cgiOut, "        <option value='11' %s>11��</option>\n", 11 == min?"selected":"");
	fprintf(cgiOut, "        <option value='12' %s>12��</option>\n", 12 == min?"selected":"");
	fprintf(cgiOut, "        <option value='13' %s>13��</option>\n", 13 == min?"selected":"");
	fprintf(cgiOut, "        <option value='14' %s>14��</option>\n", 14 == min?"selected":"");
	fprintf(cgiOut, "        <option value='15' %s>15��</option>\n", 15 == min?"selected":"");
	fprintf(cgiOut, "        <option value='16' %s>16��</option>\n", 16 == min?"selected":"");
	fprintf(cgiOut, "        <option value='17' %s>17��</option>\n", 17 == min?"selected":"");
	fprintf(cgiOut, "        <option value='18' %s>18��</option>\n", 18 == min?"selected":"");
	fprintf(cgiOut, "        <option value='19' %s>19��</option>\n", 19 == min?"selected":"");
	fprintf(cgiOut, "        <option value='20' %s>20��</option>\n", 20 == min?"selected":"");
	fprintf(cgiOut, "        <option value='21' %s>21��</option>\n", 21 == min?"selected":"");
	fprintf(cgiOut, "        <option value='22' %s>22��</option>\n", 22 == min?"selected":"");
	fprintf(cgiOut, "        <option value='23' %s>23��</option>\n", 23 == min?"selected":"");
	fprintf(cgiOut, "        <option value='24' %s>24��</option>\n", 24 == min?"selected":"");
	fprintf(cgiOut, "        <option value='25' %s>25��</option>\n", 25 == min?"selected":"");
	fprintf(cgiOut, "        <option value='26' %s>26��</option>\n", 26 == min?"selected":"");
	fprintf(cgiOut, "        <option value='27' %s>27��</option>\n", 27 == min?"selected":"");
	fprintf(cgiOut, "        <option value='28' %s>28��</option>\n", 28 == min?"selected":"");
	fprintf(cgiOut, "        <option value='29' %s>29��</option>\n", 29 == min?"selected":"");
	fprintf(cgiOut, "        <option value='30' %s>30��</option>\n", 30 == min?"selected":"");
	fprintf(cgiOut, "        <option value='31' %s>31��</option>\n", 31 == min?"selected":"");
	fprintf(cgiOut, "        <option value='32' %s>32��</option>\n", 32 == min?"selected":"");
	fprintf(cgiOut, "        <option value='33' %s>33��</option>\n", 33 == min?"selected":"");
	fprintf(cgiOut, "        <option value='34' %s>34��</option>\n", 34 == min?"selected":"");
	fprintf(cgiOut, "        <option value='35' %s>35��</option>\n", 35 == min?"selected":"");
	fprintf(cgiOut, "        <option value='36' %s>36��</option>\n", 36 == min?"selected":"");
	fprintf(cgiOut, "        <option value='37' %s>37��</option>\n", 37 == min?"selected":"");
	fprintf(cgiOut, "        <option value='38' %s>38��</option>\n", 38 == min?"selected":"");
	fprintf(cgiOut, "        <option value='39' %s>39��</option>\n", 39 == min?"selected":"");
	fprintf(cgiOut, "        <option value='40' %s>40��</option>\n", 40 == min?"selected":"");
	fprintf(cgiOut, "        <option value='41' %s>41��</option>\n", 41 == min?"selected":"");
	fprintf(cgiOut, "        <option value='42' %s>42��</option>\n", 42 == min?"selected":"");
	fprintf(cgiOut, "        <option value='43' %s>43��</option>\n", 43 == min?"selected":"");
	fprintf(cgiOut, "        <option value='44' %s>44��</option>\n", 44 == min?"selected":"");
	fprintf(cgiOut, "        <option value='45' %s>45��</option>\n", 45 == min?"selected":"");
	fprintf(cgiOut, "        <option value='46' %s>46��</option>\n", 46 == min?"selected":"");
	fprintf(cgiOut, "        <option value='47' %s>47��</option>\n", 47 == min?"selected":"");
	fprintf(cgiOut, "        <option value='48' %s>48��</option>\n", 48 == min?"selected":"");
	fprintf(cgiOut, "        <option value='49' %s>49��</option>\n", 49 == min?"selected":"");
	fprintf(cgiOut, "        <option value='50' %s>50��</option>\n", 50 == min?"selected":"");			
	fprintf(cgiOut, "        <option value='51' %s>51��</option>\n", 51 == min?"selected":"");
	fprintf(cgiOut, "        <option value='52' %s>52��</option>\n", 52 == min?"selected":"");
	fprintf(cgiOut, "        <option value='53' %s>53��</option>\n", 53 == min?"selected":"");
	fprintf(cgiOut, "        <option value='54' %s>54��</option>\n", 54 == min?"selected":"");
	fprintf(cgiOut, "        <option value='55' %s>55��</option>\n", 55 == min?"selected":"");
	fprintf(cgiOut, "        <option value='56' %s>56��</option>\n", 56 == min?"selected":"");
	fprintf(cgiOut, "        <option value='57' %s>57��</option>\n", 57 == min?"selected":"");
	fprintf(cgiOut, "        <option value='58' %s>58��</option>\n", 58 == min?"selected":"");
	fprintf(cgiOut, "        <option value='59' %s>59��</option>\n", 59 == min?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "      <select name='sec' style='width:60px;height:20px'>\n");
	fprintf(cgiOut, "        <option value='00' %s>0�� </option>\n", 0  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='01' %s>1�� </option>\n", 1  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='02' %s>2�� </option>\n", 2  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='03' %s>3�� </option>\n", 3  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='04' %s>4�� </option>\n", 4  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='05' %s>5�� </option>\n", 5  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='06' %s>6�� </option>\n", 6  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='07' %s>7�� </option>\n", 7  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='08' %s>8�� </option>\n", 8  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='09' %s>9�� </option>\n", 9  == sec?"selected":"");
	fprintf(cgiOut, "        <option value='10' %s>10��</option>\n", 10 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='11' %s>11��</option>\n", 11 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='12' %s>12��</option>\n", 12 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='13' %s>13��</option>\n", 13 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='14' %s>14��</option>\n", 14 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='15' %s>15��</option>\n", 15 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='16' %s>16��</option>\n", 16 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='17' %s>17��</option>\n", 17 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='18' %s>18��</option>\n", 18 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='19' %s>19��</option>\n", 19 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='20' %s>20��</option>\n", 20 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='21' %s>21��</option>\n", 21 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='22' %s>22��</option>\n", 22 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='23' %s>23��</option>\n", 23 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='24' %s>24��</option>\n", 24 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='25' %s>25��</option>\n", 25 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='26' %s>26��</option>\n", 26 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='27' %s>27��</option>\n", 27 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='28' %s>28��</option>\n", 28 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='29' %s>29��</option>\n", 29 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='30' %s>30��</option>\n", 30 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='31' %s>31��</option>\n", 31 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='32' %s>32��</option>\n", 32 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='33' %s>33��</option>\n", 33 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='34' %s>34��</option>\n", 34 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='35' %s>35��</option>\n", 35 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='36' %s>36��</option>\n", 36 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='37' %s>37��</option>\n", 37 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='38' %s>38��</option>\n", 38 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='39' %s>39��</option>\n", 39 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='40' %s>40��</option>\n", 40 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='41' %s>41��</option>\n", 41 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='42' %s>42��</option>\n", 42 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='43' %s>43��</option>\n", 43 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='44' %s>44��</option>\n", 44 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='45' %s>45��</option>\n", 45 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='46' %s>46��</option>\n", 46 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='47' %s>47��</option>\n", 47 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='48' %s>48��</option>\n", 48 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='49' %s>49��</option>\n", 49 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='50' %s>50��</option>\n", 50 == sec?"selected":"");			
	fprintf(cgiOut, "        <option value='51' %s>51��</option>\n", 51 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='52' %s>52��</option>\n", 52 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='53' %s>53��</option>\n", 53 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='54' %s>54��</option>\n", 54 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='55' %s>55��</option>\n", 55 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='56' %s>56��</option>\n", 56 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='57' %s>57��</option>\n", 57 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='58' %s>58��</option>\n", 58 == sec?"selected":"");
	fprintf(cgiOut, "        <option value='59' %s>59��</option>\n", 59 == sec?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='14'>\n");
	fprintf(cgiOut, "  <input type='hidden' name='systime' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doUpdate()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var year = corp_info.day.value.substring(0,4);\n");
	fprintf(cgiOut, "	 var month = corp_info.day.value.substring(5,7);\n");
	fprintf(cgiOut, "	 var day = corp_info.day.value.substring(8,10);\n");
	fprintf(cgiOut, "	 corp_info.systime.value = month + day + corp_info.hour.value + corp_info.min.value + year + '.' + corp_info.sec.value;\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "		corp_info.submit();\n");
	fprintf(cgiOut, "	}\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

bool SetSysTime()
{
	char time[256] = {0};
	strcat(time, "date ");
	strcat(time, systime);
	
	int ret = 0;
	ret = system(time);
	if(ret == 0)
	{
		system("/root/CPMClock 0");
	}
	
	return true;
}

//DDNS����
void DDNSConfig()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>DDNS����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"corp_info\" action=\"corp_info.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "  <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right' colspan=2>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doUpdate();'><font color=green>[����]</font></a>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doClose();' ><font color=green>[�ر�]</font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	
	//DDNSȡConfig.ini
	get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsStatus", "=", dns_status, sizeof(dns_status));
	get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsSvrIp", "=", dns_ip, sizeof(dns_ip));
	get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsSvrPort", "=", dns_port, sizeof(dns_port));
	get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsUrl", "=", dns_url, sizeof(dns_url));
	get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsPwd", "=", dns_pwd, sizeof(dns_pwd));
	
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>IP ��&nbsp;&nbsp;ַ</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'><input type='text' id='dns_ip' name='dns_ip'     value='%s' style='width:100%%;height:20px;' maxlength=20></td>\n", dns_ip);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'><input type='text' id='dns_port' name='dns_port' value='%s' style='width:100%%;height:20px;' maxlength=6></td>\n", dns_port);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'><input type='text' id='dns_url' name='dns_url'   value='%s' style='width:100%%;height:20px;' maxlength=30></td>\n", dns_url);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'><input type='text' id='dns_pwd' name='dns_pwd'   value='%s' style='width:100%%;height:20px;' maxlength=6></td>\n", dns_pwd);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "        <select id='dns_status' name='dns_status' style='width:100%%;height:20px;'>\n");
	fprintf(cgiOut, "          <option value='0' %s>ͣ��</option>\n", 0 == strcmp(dns_status, "0")?"selected":"");
	fprintf(cgiOut, "          <option value='1' %s>����</option>\n", 0 == strcmp(dns_status, "1")?"selected":"");
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='16'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doUpdate()\n");
	fprintf(cgiOut, "{\n");
	//Ȩ���ж�
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[256] = {0};
	sprintf(sql1, "select t.status from out_set t where t.id = '0002' and t.status = '1'");
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_outset, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	if(cnt1 <= 0)
	{
		fprintf(cgiOut, "alert('DDNS��̬������������δ���ţ��޷��ύ!');\n");
		fprintf(cgiOut, "return;\n");
	}
	fprintf(cgiOut, "  if(corp_info.dns_status.value == '1')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(corp_info.dns_ip.value.length < 1){alert('��ѡ������DDNS,����дIP��ַ');return;}\n");
	fprintf(cgiOut, "    if(corp_info.dns_port.value.length < 1){alert('��ѡ������DDNS,����д�˿�');return;}\n");
	fprintf(cgiOut, "    if(corp_info.dns_url.value.length < 1){alert('��ѡ������DDNS,����д����');return;}\n");
	fprintf(cgiOut, "    if(corp_info.dns_pwd.value.length < 1){alert('��ѡ������DDNS,����д����');return;}\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "		 corp_info.submit();\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_outset(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt1++;
	return 0;	
}

bool SetDDNS()
{
	//�޸�DDNS����
	set_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsStatus", dns_status);
	set_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsSvrIp", dns_ip);
	set_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsSvrPort", dns_port);
	set_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsUrl", dns_url);
	set_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsPwd", dns_pwd);	
	
	//����DDNS
	system("killall DDNS");
	if(0 == strcmp(dns_status, "1"))
	{
		system("/home/CPM/ddns/startDDNS.sh");
	}
	
	return true;
}

//�ϴ�����
void UPConfig()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>�ϴ�����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"corp_info\" action=\"corp_info.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "  <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right' colspan=2>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doUpdate();'><font color=green>[����]</font></a>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doClose();' ><font color=green>[�ر�]</font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	
	//�ϴ�ȡConfig.ini
	get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteStatus", "=", data_status, sizeof(data_status));
	get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteAddr", "=", data_ip, sizeof(data_ip));
	get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemotePort", "=", data_port, sizeof(data_port));
	get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteLoginId", "=", data_login, sizeof(data_login));
	get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteLoginPwd", "=", data_pwd, sizeof(data_pwd));
	
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>IP ��&nbsp;&nbsp;ַ</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'><input type='text' id='data_ip' name='data_ip'       value='%s' style='width:100%%;height:20px;' maxlength=20></td>\n", data_ip);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'><input type='text' id='data_port' name='data_port'   value='%s' style='width:100%%;height:20px;' maxlength=6></td>\n", data_port);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>�����˺�</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'><input type='text' id='data_login' name='data_login' value='%s' style='width:100%%;height:20px;' maxlength=20></td>\n", data_login);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'><input type='text' id='data_pwd' name='data_pwd'     value='%s' style='width:100%%;height:20px;' maxlength=20></td>\n", data_pwd);
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='30%%' align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "      <td width='70%%' align='left'>\n");
	fprintf(cgiOut, "        <select id='data_status' name='data_status' style='width:100%%;height:20px;'>\n");
	fprintf(cgiOut, "          <option value='0' %s>ͣ��</option>\n", 0 == strcmp(data_status, "0")?"selected":"");
	fprintf(cgiOut, "          <option value='1' %s>����</option>\n", 0 == strcmp(data_status, "1")?"selected":"");
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='18'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doUpdate()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(corp_info.data_status.value == '1')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(corp_info.data_ip.value.length < 1){alert('��ѡ�����������ϴ�,����дIP��ַ');return;}\n");
	fprintf(cgiOut, "    if(corp_info.data_port.value.length < 1){alert('��ѡ�����������ϴ�,����д�˿ں�');return;}\n");
	fprintf(cgiOut, "    if(corp_info.data_login.value.length < 1){alert('��ѡ�����������ϴ�,����д�����ʺ�');return;}\n");
	fprintf(cgiOut, "    if(corp_info.data_pwd.value.length < 1){alert('��ѡ�����������ϴ�,����д��������');return;}\n");	
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "		 corp_info.submit();\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

bool SetUP()
{
	//�޸������ϴ�����
	set_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteStatus", data_status);
	set_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteAddr", data_ip);
	set_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemotePort", data_port);			
	set_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteLoginId", data_login);
	set_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteLoginPwd", data_pwd);
	
	//����CPM
	system("killall CPM");
	system("/home/CPM/CPM/startCPM.sh");	
	
	return true;
}

//��������
void doCPM()
{
	system("killall CPM");
	system("/home/CPM/CPM/startCPM.sh");
	fprintf(cgiOut, "<script language='javascript'>alert('���������ɹ�');</script>\n");
}

//��������
void RebootCPM()
{
	system("killall boa");
	system("killall DDNS");
	system("killall CPM");
	system("/sbin/reboot");
}

//�������
void doCPMUdp()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>�����ļ�</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"corp_info\" action=\"corp_info.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "  <table width=\"100%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right'><a href='#' onclick='doClose();'><font color=green>[�ر�]</font></a></td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "        <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "          <tr height='60'>\n");
	fprintf(cgiOut, "            <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              �����ļ�:<input type='file' name='uproute'   title='��ѡ���ļ�' value='���' style='width:59%%;height:20px'>    <input type='button' value='����' style='width:50px;height:20px;' onClick='doUpload()'>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "            </td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='7'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doUpload()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(corp_info.uproute.value.indexOf('CPM') < 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�ļ�������ȷ��!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('������¹�����,ϵͳ����ͣ����,ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    corp_info.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

//�������
bool doCPMUdpTrue()
{
	cgiFilePtr file;  
	int targetFile;  
	mode_t mode;
	char name[256];
	char buffer[2048];
	int got;
	
	char fileNameOnServer[128] = {0};
	strcat(fileNameOnServer, "/home/CPM/CPM/CPM_NEW");  
	
	if(cgiFormFileName("uproute", name, sizeof(name)) != cgiFormSuccess)
	{    
		//δ֪�ļ�
		return false;
	}
	
	if(cgiFormFileOpen("uproute", &file) != cgiFormSuccess)
	{    
		//�ļ�����
		return false;
	}
	
	mode = S_IRWXU|S_IRGRP|S_IROTH;
	targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode); 
	if(targetFile < 0)
	{   
		//�ļ�����
		return false;
	}
	
	while(cgiFormFileRead(file, buffer, 2048, &got) == cgiFormSuccess)
	{    
		if(got > 0) 
		{
			write(targetFile, buffer, got); 
		} 
	}
		
	cgiFormFileClose(file); 
	close(targetFile);
	
	//�ϴ��ɹ� > ֹͣCPM > ����CPM > ����755Ȩ�� > ɾ���ϴ��ļ� > CPM���� 
	system("killall CPM");
	system("cp /home/CPM/CPM/CPM_NEW /home/CPM/CPM/CPM");
	system("chmod 755 /home/CPM/CPM/CPM");	
	system("rm -rf /home/CPM/CPM/CPM_NEW");
	system("/home/CPM/CPM/startCPM.sh");
	return true;	
}

//�����
void doSystem()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>�����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"corp_info\" action=\"corp_info.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");
	fprintf(cgiOut, "  <table width=\"100%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right'><a href='#' onclick='doClose();'><font color=green>[�ر�]</font></a></td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "        <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "          <tr height='60'>\n");
	fprintf(cgiOut, "            <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              ���ļ�:<input type='file' name='uproute'   title='��ѡ���ļ�' value='���' style='width:59%%;height:20px'>    <input type='button' value='����' style='width:50px;height:20px;' onClick='doUpload()'>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "            </td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd' value='5'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doUpload()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(corp_info.uproute.value.indexOf('Udp_System_File_E') < 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�ļ�������ȷ��!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('����¹����У�������ͣ����������Զ�������ȷ��?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    corp_info.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

//�����
bool getFile()
{
	//1.�ļ�����
	cgiFilePtr file;
	int targetFile;
	mode_t mode;
	char name[256];
	char buffer[4096];
	int got;
	char fileNameOnServer[128] = {0};
	strcat(fileNameOnServer, "/home/CPM/Udp_System_File_E_NEW");
	if(cgiFormFileName("uproute", name, sizeof(name)) != cgiFormSuccess)
	{
		return false;
	}
	if(cgiFormFileOpen("uproute", &file) != cgiFormSuccess)
	{
		return false;
	}
	mode = S_IRWXU|S_IRGRP|S_IROTH;
	targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode);
	if(targetFile < 0)
	{
		return false;
	}
	while(cgiFormFileRead(file, buffer, 4096, &got) == cgiFormSuccess)
	{
		if(got > 0)
		{
			write(targetFile, buffer, got);
		}
	}
	cgiFormFileClose(file);
	close(targetFile);
	
	//2.�ļ�����
	get_ini_string("/home/CPM/CPM/Config.ini", "SYSTEM", "DESKey", "=", DESKey, sizeof(DESKey));
  UnDesFile("/home/CPM/Udp_System_File_E_NEW", "/home/CPM/Udp_System_File_D_NEW", DESKey);
 	
	//3.�滻�ļ�
	system("cp /home/CPM/Udp_System_File_D_NEW /home/CPM/Udp_System_File_D");
	system("rm -rf /home/CPM/Udp_System_File_E_NEW /home/CPM/Udp_System_File_D_NEW");
	
	//4.ִ���ļ�
	system("sqlite3 /home/CPM/tmp.db \".read /home/CPM/Udp_System_File_D\"");
	return true;
}

//����
void AboutCPM()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>����CPM</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"corp_info\" action=\"corp_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "  <table width=\"100%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right'><a href='#' onclick='doClose();'><font color=green>[�ر�]</font></a></td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "        <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "          <tr height='60'>\n");
	fprintf(cgiOut, "            <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "              ���к�:<font id='pro_seq'></font>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              �汾��:<font id='pro_ver'></font>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              ��&nbsp;&nbsp;��:<font id='pro_agt'></font>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              <br>\n");
	fprintf(cgiOut, "              ��&nbsp;&nbsp;��:<font id='pro_cat'></font>\n");
	fprintf(cgiOut, "            </td>\n");
	fprintf(cgiOut, "          </tr>\n");
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	
	int rc;
	char * zErrMsg = 0;
	char sqlabout[128] = {0};
	strcat(sqlabout, "select t.pro_seq, t.pro_ver, t.pro_agt, t.pro_cat from pro_ctrl t");
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sqlabout, &sqlite3_exec_callback_about, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(2);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "  \n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_about(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "document.getElementById('pro_seq').innerHTML = '%s';\n", col_values[0]);
	fprintf(cgiOut, "document.getElementById('pro_ver').innerHTML = '%s';\n", col_values[1]);
	fprintf(cgiOut, "document.getElementById('pro_agt').innerHTML = '%s';\n", col_values[2]);
	fprintf(cgiOut, "document.getElementById('pro_cat').innerHTML = '%s';\n", col_values[3]);
	return 0;
}

void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-��ҵ��Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 40%%;\n");
	fprintf(cgiOut, "  height:40%%;\n");
	fprintf(cgiOut, "  left:30%%;\n");
	fprintf(cgiOut, "  top:30%%;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"corp_info\" action=\"corp_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/corp_info.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"80%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "	 <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='100%%' colspan=4 align='right'><img style=\"cursor:hand\" src=\"../../skin/images/mini_button_submit.gif\" onclick='doEdit()'></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<table width=\"80%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "    <td width=\"100%%\"  align='center' colspan=4>\n");
	fprintf(cgiOut, "      <table boder=0 width='100%%'>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width=\"15%%\"  align='center'><B>������Ϣ</B></td>\n");
	fprintf(cgiOut, "          <td width=\"85%%\"  align='left'>&nbsp;</td>\n");
	//fprintf(cgiOut, "          <td width=\"85%%\"  align='left'><a href='#' onclick='doLogo();'><U><font color=green>LOGO����</font></U></a></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");	
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='left'><input type='text' id='id' name='id' value='' style='width:100%%;height:20px;' maxlength=6></td>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left'><input type='text' id='cname' name='cname' value='' style='width:100%%;height:20px;' maxlength=25></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='left'><input type='text' id='brief' name='brief' value='' style='width:100%%;height:20px;' maxlength=6></td>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ַ</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left'><input type='text' id='addr' name='addr' value='' style='width:100%%;height:20px;' maxlength=60></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>�� ϵ ��</td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='left'><input type='text' id='contact' name='contact' value='' style='width:100%%;height:20px;' maxlength=6></td>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left'><input type='text' id='tel' name='tel' value='' style='width:100%%;height:20px;' maxlength=20></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='left'><input type='text' id='dept' name='dept' value='' style='width:100%%;height:20px;' maxlength=256></td>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left'><input type='text' id='gsm_center' name='gsm_center' value='' style='width:100%%;height:20px;' maxlength=20></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "    <td width='85%%' align='left' colspan=3><input type='text' id='ats' name='ats' value='' style='width:100%%;height:20px;' maxlength=256></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>ҳ�泬ʱ</td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='left'><input type='text' id='time_out' name='time_out' value='' style='width:40%%;height:20px;' maxlength=4>��</td>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>״̬����</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left'><input type='text' id='staudp'   name='staudp'   value='' style='width:40%%;height:20px;' maxlength=4>��</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "    <td width=\"100%%\"  align='center' colspan=4>\n");
	fprintf(cgiOut, "      <table boder=0 width='100%%'>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width=\"15%%\"  align='center'><B>������Ϣ</B></td>\n");
	//<a href='#' onclick='doSystem();'><U><font color=green>�����</font></U></a>&nbsp;&nbsp;
	fprintf(cgiOut, "          <td width=\"85%%\"  align='left'><a href='#' onclick='doNet();'><U><font color=green>��������</font></U></a>&nbsp;&nbsp;<a href='#' onclick='doTime();'><U><font color=green>ϵͳʱ��</font></U></a>&nbsp;&nbsp;<a href='#' onclick='doSync();'><U><font color=green>ʱ��ͬ��</font></U></a>&nbsp;&nbsp;<a href='#' onclick='doCPMUdp();'><U><font color=green>�������</font></U></a>&nbsp;&nbsp;<a href='#' onclick='doCPM();'><U><font color=green>��������</font></U></a>&nbsp;&nbsp;<a href='#' onclick='doReboot();'><U><font color=green>��������</font></U></a>&nbsp;&nbsp;<a href='#' onclick='doAbout();'><U><font color=green>����</font></U></a></td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width=\"100%%\"  align='center' colspan=4>\n");
	fprintf(cgiOut, "      <table boder=0 width='100%%'>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width=\"15%%\"  align='center'>&nbsp;<a href='#' onclick='doDDNS();'><U><B>DDNS</B></U></a>&nbsp;</td>\n");
	fprintf(cgiOut, "          <td width=\"85%%\"  align='right'>&nbsp</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>IP ��&nbsp;&nbsp;ַ</td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='left' id='dns_ip'>&nbsp</td>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left' id='dns_port'>&nbsp</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='left' id='dns_url'>&nbsp</td>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left' id='dns_pwd'>&nbsp</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "    <td width='85%%' align='left' colspan=3 id='dns_sta'><font color=gray>[ͣ��]</font></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "    <td width=\"100%%\"  align='center' colspan=4>\n");
	fprintf(cgiOut, "      <table boder=0 width='100%%'>\n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width=\"15%%\"  align='center'><a href='#' onclick='doDataUP();'><U><B>�����ϴ�</B></U></a></td>\n");
	fprintf(cgiOut, "          <td width=\"85%%\"  align='right'>&nbsp</td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>IP ��&nbsp;&nbsp;ַ</td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='left' id='data_ip'>&nbsp</td>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left' id='data_port'>&nbsp</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>�����˺�</td>\n");
	fprintf(cgiOut, "    <td width='30%%' align='left' id='data_login'>&nbsp</td>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "    <td width='40%%' align='left' id='data_pwd'>&nbsp</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle' class='table_blue'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "    <td width='85%%' align='left' colspan=3 id='data_sta'><font color=gray>[ͣ��]</font></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='aboutDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='10'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char * sql = getSql(atoi(cmd));
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doNet()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'corp_info.cgi?cmd=8';\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doTime()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'corp_info.cgi?cmd=13';\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doSync()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'corp_info.cgi?cmd=21';\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doCPMUdp()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'corp_info.cgi?cmd=6';\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doSystem()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'corp_info.cgi?cmd=4';\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doCPM()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ����������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'corp_info.cgi?cmd=3';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doReboot()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('��ȷ�����������з���������ʱ�Զ�������ִ��?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'corp_info.cgi?cmd=2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doAbout()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'corp_info.cgi?cmd=1';\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doLogo()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'corp_info.cgi?cmd=19';\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doDDNS()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'corp_info.cgi?cmd=15';\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doDataUP()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'corp_info.cgi?cmd=17';\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doEdit()\n");
	fprintf(cgiOut, "{\n");	
	fprintf(cgiOut, "  if(corp_info.id.value.length != 6){alert('����д6λ���');return;}\n");
	fprintf(cgiOut, "  if(corp_info.cname.value.length < 1){alert('����д����');return;}\n");
	fprintf(cgiOut, "  if(corp_info.brief.value.length < 1){alert('����д���');return;}\n");
	fprintf(cgiOut, "  if(corp_info.contact.value.length < 1){alert('����д��ϵ��');return;}\n");
	fprintf(cgiOut, "  if(corp_info.tel.value.length < 1){alert('����д�绰');return;}\n");
	fprintf(cgiOut, "  if(corp_info.addr.value.length < 1){alert('����д��ַ');return;}\n");
	fprintf(cgiOut, "  if(corp_info.dept.value.length < 1){alert('�밴�����ڸ�ʽ[����1,����2,����3]��д��������');return;}\n");
	fprintf(cgiOut, "  if(corp_info.time_out.value.length < 1){alert('����дҳ�泬ʱʱ��');return;}\n");
	fprintf(cgiOut, "  if(corp_info.staudp.value.length < 1){alert('����д״̬��������');return;}\n");
	fprintf(cgiOut, "  for(var i=0; i<corp_info.time_out.value.length; i++)\n");	
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(corp_info.time_out.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('ҳ�泬ʱʱ�����뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(corp_info.time_out.value < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('ҳ�泬ʱʱ���������Ϊ1����!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<corp_info.staudp.value.length; i++)\n");
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if(isNaN(corp_info.staudp.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('״̬�����������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(corp_info.staudp.value < 10)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('״̬���������������Ϊ10��!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "	   corp_info.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{  
	cnt++;
	if(cnt == 1)
	{			
		fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
		fprintf(cgiOut, "document.getElementById('id').value = '%s';\n", col_values[0]);
		fprintf(cgiOut, "document.getElementById('cname').value = '%s';\n", col_values[1]);
		fprintf(cgiOut, "document.getElementById('addr').value = '%s';\n", col_values[2]);
		fprintf(cgiOut, "document.getElementById('tel').value = '%s';\n", col_values[3]);
		fprintf(cgiOut, "document.getElementById('contact').value = '%s';\n", col_values[4]);
		fprintf(cgiOut, "document.getElementById('brief').value = '%s';\n", col_values[5]);
		fprintf(cgiOut, "document.getElementById('time_out').value = '%s';\n", col_values[7]);
		fprintf(cgiOut, "document.getElementById('dept').value = '%s';\n", col_values[8]);
		fprintf(cgiOut, "document.getElementById('staudp').value = '%s';\n", col_values[11]);
		fprintf(cgiOut, "document.getElementById('ats').value = '%s';\n", col_values[12]);
		
		//GSM���ĺ���
		get_ini_string("/home/CPM/CPM/Config.ini", "SYSTEM", "GSMCenter", "=", gsm_center, sizeof(gsm_center));
		fprintf(cgiOut, "document.getElementById('gsm_center').value = '%s';\n", gsm_center);
		
		//DDNSȡConfig.ini
		get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsStatus", "=", dns_status, sizeof(dns_status));
		get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsSvrIp", "=", dns_ip, sizeof(dns_ip));
		get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsSvrPort", "=", dns_port, sizeof(dns_port));
		get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsUrl", "=", dns_url, sizeof(dns_url));
		get_ini_string("/home/CPM/ddns/Config.ini", "DDNS", "DDnsPwd", "=", dns_pwd, sizeof(dns_pwd));
		if(0 == strcmp(dns_status, "1"))
		{
			fprintf(cgiOut, "document.getElementById('dns_sta').innerHTML = '<font color=green>[����]</font>';\n");
		}
		fprintf(cgiOut, "document.getElementById('dns_ip').innerHTML = '%s'+'&nbsp';\n", dns_ip);
		fprintf(cgiOut, "document.getElementById('dns_port').innerHTML = '%s'+'&nbsp';\n", dns_port);
		fprintf(cgiOut, "document.getElementById('dns_url').innerHTML = '%s'+'&nbsp';\n", dns_url);
		fprintf(cgiOut, "document.getElementById('dns_pwd').innerHTML = '%s'+'&nbsp';\n", dns_pwd);
		
		//�ϴ�ȡConfig.ini
		get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteStatus", "=", data_status, sizeof(data_status));
		get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteAddr", "=", data_ip, sizeof(data_ip));
		get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemotePort", "=", data_port, sizeof(data_port));
		get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteLoginId", "=", data_login, sizeof(data_login));
		get_ini_string("/home/CPM/CPM/Config.ini", "PARENT", "RemoteLoginPwd", "=", data_pwd, sizeof(data_pwd));
		if(0 == strcmp(data_status, "1"))
		{
			fprintf(cgiOut, "document.getElementById('data_sta').innerHTML = '<font color=green>[����]</font>';\n");
		}
		fprintf(cgiOut, "document.getElementById('data_ip').innerHTML = '%s'+'&nbsp';\n", data_ip);
		fprintf(cgiOut, "document.getElementById('data_port').innerHTML = '%s'+'&nbsp';\n", data_port);
		fprintf(cgiOut, "document.getElementById('data_login').innerHTML = '%s'+'&nbsp';\n", data_login);
		fprintf(cgiOut, "document.getElementById('data_pwd').innerHTML = '%s'+'&nbsp';\n", data_pwd);
		fprintf(cgiOut, "</SCRIPT>\n");
	}
	return 0;
}

void UpdateData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	//�Ȳ�ѯ
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback_cnt, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	
	if(0 == cnt)
	{
		//�޸�GSM����
		set_ini_string("/home/CPM/CPM/Config.ini", "SYSTEM", "GSMCenter", gsm_center);
		
		//����m1key
		memset(m1key, 0, sizeof(m1key));
		int i,temp,r;
		temp = rand();
		srand(temp);
		r = rand();
		for(i=0; i<384; i++)
		{
			srand(r);
			r = rand();
			m1key[i] = r%26 + 'A';
		}
		m1key[385] = '\0';
		
		//����
		rc = sqlite3_exec(db, getSql(11), &sqlite3_exec_callback, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
		  err_msg(1);
		}	
		fprintf(cgiOut, "<script language='javascript'>alert('�����ɹ�');</script>\n");
	}
	else
	{
		//�޸�GSM����
		set_ini_string("/home/CPM/CPM/Config.ini", "SYSTEM", "GSMCenter", gsm_center);
		
		//�޸�
		rc = sqlite3_exec(db, getSql(10), &sqlite3_exec_callback, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
		  err_msg(1);
		}
		fprintf(cgiOut, "<script language='javascript'>alert('�����ɹ�');</script>\n");
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_cnt(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

