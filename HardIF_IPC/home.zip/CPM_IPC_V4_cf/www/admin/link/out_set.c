#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

//��������
char Sql[1024] = {0};
char list[1024] = {0};

//��������
static char *getSql(int pCmd);
void err_msg(int pType);
static void doSel();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	doSel();
	return 0;
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      	strcat(Sql, "select t.id, t.cname, t.status from out_set t order by t.id");
			break;
	}
	return Sql;
}

void doSel()
{
	memset(list, 0, sizeof(list));
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(2);
	}
	sqlite3_close(db);
	printf("0000%s\n", list);
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat(list, col_values[0]);
	strcat(list, ",");
	strcat(list, col_values[2]);
	strcat(list, ";");
	return 0;
}
