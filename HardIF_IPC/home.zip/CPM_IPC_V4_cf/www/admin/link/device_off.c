#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"

//��������
char Sql[1024] = {0};
char cmd[4] = {0};
int cnt = 0;
char FillStr[1024] = {0};
char changevalue[11] = {0};
int changecount = 0;
char EditSelCmd[31] = {0};
//device_agent
char seq[10] = {0};
char id[11] = {0};
char sn[5] = {0};
char condition[130] = {0};
char valibtime[30] = {0};
char interval[4] = {0};
char d_id[11] = {0};
char d_cmd[9] = {0};
char object[257] = {0};
char acttype[2] = {0};
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
char *StrRightFillSpace(char *strData, int len);
char *getStatusName(int pStatus);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
//���Ӳ�ѯ
static void AddHTML();
static int sqlite3_exec_callback_device_info_upper_agentid(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_device_cmd(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_device_call(void *data, int n_columns, char **col_values, char **col_names);
//�޸Ĳ�ѯ
static void UdpHTML();
static int sqlite3_exec_callback_forudp(void *data, int n_columns, char **col_values, char **col_names);
//�ύ
static void Submit();
static int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cnt(void *data, int n_columns, char **col_values, char **col_names);
//��������
static void QueryCmd();
static int sqlite3_exec_callback_querycmd(void *data, int n_columns, char **col_values, char **col_names);
//ͨѶ
char *getLocalIP();
static int MsgSend(int flag);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	changecount = 0;
	switch(atoi(cmd))
	{
		case 0://��ѯ
			QueryData();
			break;
		case 1://����
			AddHTML();
			break;
		case 2://�༭
			UdpHTML();
			break;
		case 3://�ύ
			Submit();
			break;
		case 4://��������
			QueryCmd();
	}
	
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("seq", seq, sizeof(seq));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("condition", condition, sizeof(condition));
	cgiFormString("valibtime", valibtime, sizeof(valibtime));
	cgiFormString("interval", interval, sizeof(interval));
	cgiFormString("d_id", d_id, sizeof(d_id));
	cgiFormString("d_cmd", d_cmd, sizeof(d_cmd));
	cgiFormString("object", object, sizeof(object));
	cgiFormString("acttype", acttype, sizeof(acttype));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0://��ѯ
      strcat(Sql, "select a.seq, a.id, a.sn, a.condition, a.valibtime, a.interval, a.d_id, a.d_cmd, a.object, a.ctype, b.cname, c.cname, d.cmdname from device_agent a, device_detail b, device_detail c, device_act d where a.id = b.id and a.d_id = c.id and a.d_cmd = d.sn and a.d_id = d.id and a.id = '");
      strcat(Sql, id);
      strcat(Sql, "' and a.ctype = '1' ");
			break;
		case 1://�޸Ĳ�ѯ
			strcat(Sql, "select a.seq, a.id, a.sn, a.condition, a.valibtime, a.interval, a.d_id, a.d_cmd, a.object, a.ctype, b.cname, c.cname, d.cmdname from device_agent a, device_detail b, device_detail c, device_act d where a.id = b.id and a.d_id = c.id and a.d_cmd = d.sn and a.d_id = d.id and a.seq = '");
      strcat(Sql, seq);
      strcat(Sql, "' and a.ctype = '1' ");
			break;
	}
	return Sql;
}

void QueryData()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>���߸澯</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");	
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width:  100%%;\n");
	fprintf(cgiOut, "  height: 100%%;\n");
	fprintf(cgiOut, "  left:0px;\n");
	fprintf(cgiOut, "  top:0px;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"device_off\" action=\"device_off.cgi\" method=\"post\" target=\"mainFrame\">\n");
	//fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "  <table align='center' style='margin:auto;margin-top:5px;' width=\"98%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='200'>\n");
	fprintf(cgiOut, "      <td width='100%%' align=left>\n");
	fprintf(cgiOut, "        <table width=\"100%%\" border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "          <tr height='30'>\n");
	fprintf(cgiOut, "            <td width='100%%' align=left>&nbsp;&nbsp;&nbsp;<img src='../../skin/images/device_cmdadd.png' style='cursor:hand' title='�������߸澯' onclick=\"doAgentAdd('1', '%s', '')\"></td>\n", id);
	fprintf(cgiOut, "          </tr>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	if(0 == cnt)
	{
		fprintf(cgiOut, "        <tr height='30'>\n");
		fprintf(cgiOut, "          <td width='100%%' align=left>&nbsp;&nbsp;&nbsp;��</td>\n");
		fprintf(cgiOut, "        </tr>\n");
	}
	fprintf(cgiOut, "        </table>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table><br>\n");
	//fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div style='text-align:center'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doCancel()' src='../../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='agentDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");	
	//�رմ���
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('agentDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//���ӡ��༭��ɾ��
	fprintf(cgiOut, "function doAgentAdd(pCmd, pId, pSeq)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if('3' == pCmd)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(confirm('ȷ��ɾ����ǰ���߸澯����?'))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(window.XMLHttpRequest){reqDel = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "      else if(window.ActiveXObject){reqDel = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "      reqDel.onreadystatechange = function(){callbackDelName(pId)};\n");			
	fprintf(cgiOut, "      var url = 'device_off.cgi?cmd=3&id='+pId+'&seq='+pSeq+'&acttype=3&currtime='+new Date();\n");
	fprintf(cgiOut, "      reqDel.open(\"get\",url);\n");
	fprintf(cgiOut, "      reqDel.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "      reqDel.send(null);\n");
	fprintf(cgiOut, "      return true;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('agentDiv').style.display = 'block';\n");
	fprintf(cgiOut, "    var url = 'device_off.cgi?cmd='+pCmd+'&id='+pId+'&seq='+pSeq;\n");
	fprintf(cgiOut, "    document.getElementById('agentDiv').innerHTML = \"<iframe id='agentFrame' name='agentFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackDelName(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqDel.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqDel.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "        if(resp.indexOf('�ɹ�') >= 0 || resp.indexOf('�ύ�ɹ�') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          location = 'device_off.cgi?cmd=0&id='+pId;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	fprintf(cgiOut, "<tr height='30'>\n");
	fprintf(cgiOut, "  <td width='100%%' align=left>\n");
	fprintf(cgiOut, "    &nbsp;&nbsp;&nbsp;%d.��[%s]����ʱ��%s %s %s\n", cnt, col_values[10], col_values[11], col_values[12], col_values[8]);
	fprintf(cgiOut, "    &nbsp;<img src='../../skin/images/agent_edit.gif' onClick=\"doAgentAdd('2', '%s', '%s');\" style='cursor:hand' title='�༭���߸澯'>\n", col_values[1], col_values[0]);
	fprintf(cgiOut, "    &nbsp;<img src='../../skin/images/cmddel.gif' onClick=\"doAgentAdd('3', '%s', '%s');\" style='cursor:hand' title='ɾ�����߸澯'>\n", col_values[1], col_values[0]);
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

void AddHTML()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>���߸澯</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");	
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"agent\" action=\"agent.cgi\" method=\"post\" target=\"mainFrame\">\n");
	//fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "  <table align='center' style='margin:auto;margin-top:5px;' width=\"99%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>ʱ��</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Time' id='Time' style='width:90px;height:25px;' onchange=\"doSwitchTime(this.value)\">\n");
	fprintf(cgiOut, "			   <option value='0' selected>���趨</option>\n");
	fprintf(cgiOut, "				 <option value='1'>��ѭ��</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "      <input type='text' id='TimeD' name='TimeD' maxlength='12' value='' style='width:155px;height:20px;display:none;'><font color=red>��ʽ:*0600,*1200</font>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>���</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='link_delay' style='width:250px;height:25px'>\n");
	fprintf(cgiOut, "        <option value='0' >ֻ����һ��</option>\n");
	fprintf(cgiOut, "        <option value='5' >��5���Ӵ���</option>\n");
	fprintf(cgiOut, "        <option value='10'>��10���Ӵ���</option>\n");
	fprintf(cgiOut, "        <option value='20'>��20���Ӵ���</option>\n");
	fprintf(cgiOut, "        <option value='30'>��30���Ӵ���</option>\n");
	fprintf(cgiOut, "        <option value='45'>��45���Ӵ���</option>\n");
	fprintf(cgiOut, "        <option value='60'>��60���Ӵ���</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");	
	fprintf(cgiOut, "    <td width='20%%' align='center'>�豸</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Id' id='Id' style='width:250px;height:25px;' onchange=\"doChange(this.value, '')\">\n");		
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = "select a.id, a.cname from device_detail a, device_act b where a.id = b.id group by a.id order by a.id";
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_device_info_upper_agentid, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Cmd' id='Cmd' style='width:250px;height:25px;' onchange='doChange2(this.value)'>\n");
	
	char sql2[512] = "select a.id, a.sn, a.cmdname, a.status, b.object from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and a.id = '";
	strcat(sql2, changevalue);
	strcat(sql2, "'");
	rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_device_cmd, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Tel' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='Tel' value='' style='width:250px;height:20px;' maxlength=256><font color=red>�������/����</font>\n");	
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Object' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='Object' value='' style='width:250px;height:20px;' maxlength=256>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Call' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select id='CallSN' name='Call' style='width:250px;height:20px;'>\n");
	
	char sql3[512] = "select a.sn, a.cname from call a";
	rc = sqlite3_exec(db, sql3, &sqlite3_exec_callback_device_call, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	sqlite3_close(db);
	
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  </table><br>\n");
	//fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div style='text-align:center'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doAdd()'    src='../../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doCancel()' src='../../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//�༭
	fprintf(cgiOut, "var reqChg = null;\n");
	fprintf(cgiOut, "function doChange(pValue, pSelCmd)\n");
	fprintf(cgiOut, "{\n");
	//��ɾ��
	fprintf(cgiOut, "  var length = document.getElementById('Cmd').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('Cmd').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	//������
	fprintf(cgiOut, "  var CmdType = '0';\n");
	fprintf(cgiOut, "  if(pValue.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(pValue.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqChg.onreadystatechange = function(){callbackChangeName(pValue, pSelCmd, CmdType)};\n");
	fprintf(cgiOut, "  var url = 'device_off.cgi?cmd=4&id='+pValue+'&currtime='+new Date();\n");
	fprintf(cgiOut, "	 reqChg.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqChg.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackChangeName(pValue, pSelCmd, CmdType)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqChg.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqChg.responseText;\n");	
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var list = resp.split('#');\n");
	fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "      		 var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      		 objOption.value = list[i];\n");
	fprintf(cgiOut, "      		 objOption.text = sublist[2];\n");
	fprintf(cgiOut, "      		 document.getElementById('Cmd').add(objOption);\n");
	fprintf(cgiOut, "  			   if(pSelCmd.length > 0)\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "  			     if(pSelCmd == sublist[1])\n");
	fprintf(cgiOut, "  			     {\n");
	fprintf(cgiOut, "  			       objOption.selected = true;\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(agent.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = agent.Object.value.substring(0, agent.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = agent.Object.value.substring(agent.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    agent.Tel.value = tel;\n");
	fprintf(cgiOut, "                    agent.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(agent.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = agent.Tel.value.substring(0, agent.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = agent.Tel.value.substring(agent.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   agent.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "  			     }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "  			   else\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "          	 if(i == 0)\n");
	fprintf(cgiOut, "        	   {\n");
	fprintf(cgiOut, "						   objOption.selected = 'true';\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(agent.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = agent.Object.value.substring(0, agent.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = agent.Object.value.substring(agent.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    agent.Tel.value = tel;\n");
	fprintf(cgiOut, "                    agent.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(agent.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = agent.Tel.value.substring(0, agent.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = agent.Tel.value.substring(agent.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   agent.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doChange2(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 if(pValue.length > 0)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   var list = pValue.split(',');\n");
	fprintf(cgiOut, "	   var Id = list[0];\n");
	fprintf(cgiOut, "	   var SN = list[1];\n");
	fprintf(cgiOut, "	   var CmdName = list[2];\n");
	fprintf(cgiOut, "	   var Object = list[3];\n");
	fprintf(cgiOut, "	   var CmdType = '0';\n");
	fprintf(cgiOut, "	   if(Id.indexOf('001103') >= 0 && Object == '1')\n");//����
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '1';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(Id.indexOf('001104') >= 0 && Object == '1')\n");//����
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '2';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   if('0' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     if('1' == Object)\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	     else\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('1' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('2' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSwitchTime(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "if(pValue == '0'){document.getElementById('TimeD').style.display = 'none';}\n");
	fprintf(cgiOut, "if(pValue == '1'){document.getElementById('TimeD').style.display = '';}\n");
	fprintf(cgiOut, "if(pValue == '2'){document.getElementById('TimeD').style.display = '';}\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doChange(agent.Id.value, '');\n");
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");	
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(agent.Id.value.length < 1){alert('��ѡ�������豸!'); return;}\n");
	fprintf(cgiOut, "  if(agent.Cmd.value.length < 1){alert('��ѡ����������!');return;}\n");
	fprintf(cgiOut, "  var TimeD = ' ';\n");
	fprintf(cgiOut, "  if('0' != agent.Time.value)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    TimeD = agent.TimeD.value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(TimeD.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    TimeD = ' ';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var Id = agent.Id.value;\n");	
	fprintf(cgiOut, "  var Style = '0';\n");
	fprintf(cgiOut, "  if(Id.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(Id.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var CmdList = agent.Cmd.value.split(',');\n");
	fprintf(cgiOut, "  var Cmd = CmdList[1];\n");
	fprintf(cgiOut, "  var ObjectFlag = CmdList[3];\n");
	fprintf(cgiOut, "  var StatusFlag = CmdList[4];\n");
	fprintf(cgiOut, "  var Object = '';\n");
	fprintf(cgiOut, "  if('0' == Style)\n");//��ͨ
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      Object = agent.Object.value;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('1' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(agent.Object.value.length < 1 && agent.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = agent.Tel.value + '//' + agent.Object.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('2' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(agent.Call.value.length < 1 && agent.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = agent.Tel.value + '//' + agent.Call.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(Object.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Object = ' ';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var len = Object.len();\n");
	fprintf(cgiOut, "  if(len > 256)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ݳ��ȹ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if('0' == StatusFlag)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ����δ����Ϊ���ã��ݲ�������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqAdd = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqAdd = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqAdd.onreadystatechange = callbackAddName;\n");		
	fprintf(cgiOut, "    var url = 'device_off.cgi?cmd=3&id=%s&valibtime='+TimeD+'&interval='+agent.link_delay.value+'&d_id='+Id+'&d_cmd='+Cmd+'&object='+Object+'&acttype=1&currtime='+new Date();\n", id);
	fprintf(cgiOut, "    reqAdd.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqAdd.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqAdd.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackAddName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqAdd.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqAdd.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "        if(resp.indexOf('�ɹ�') >= 0 || resp.indexOf('�ύ�ɹ�') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          parent.location = 'device_off.cgi?cmd=0&id=%s';\n", id);
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_device_info_upper_agentid(void *data, int n_columns, char **col_values, char **col_names)
{	
	changecount++;	
	if(NULL != data)
	{
		if(0 == strcmp((char *)data, col_values[0]))
		{
			strcat(changevalue, col_values[0]);
			fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", col_values[0], col_values[1]);
		}
		else
		{
			fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
		}
	}
	else
	{
		if(changecount == 1)
		{
			strcat(changevalue, col_values[0]);
		}
		fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	}
	
	return 0;
}

int sqlite3_exec_callback_device_cmd(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != data && 0 == strcmp((char *)data, col_values[1]))
	{
		memset(EditSelCmd, 0, sizeof(EditSelCmd));
		memcpy(EditSelCmd, col_values[1], 31);
		fprintf(cgiOut, "<option value='%s,%s,%s,%s,%s' selected>%s</option>\n", col_values[0], col_values[1], col_values[2], col_values[4], col_values[3], col_values[2]);
	}
	else
	{
		fprintf(cgiOut, "<option value='%s,%s,%s,%s,%s'>%s</option>\n", col_values[0], col_values[1], col_values[2], col_values[4], col_values[3], col_values[2]);
	}
	return 0;
}

int sqlite3_exec_callback_device_call(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	return 0;
}

void QueryCmd()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	char sql[256] = "select a.id, a.sn, a.cmdname, a.status, b.object from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and a.id = '";
	strcat(sql, id);
	strcat(sql, "'");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_querycmd, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_querycmd(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "%s,%s,%s,%s,%s#", col_values[0], col_values[1], col_values[2], col_values[4], col_values[3]);
	return 0;
}

void UdpHTML()
{
	int rc;
	char * zErrMsg;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_forudp, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}	
	sqlite3_close(db);
}

int sqlite3_exec_callback_forudp(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>���߸澯</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");	
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"agent\" action=\"agent.cgi\" method=\"post\" target=\"mainFrame\">\n");
	//fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "  <table align='center' style='margin:auto;margin-top:5px;' width=\"99%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>ʱ��</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Time' id='Time' style='width:90px;height:25px;' onchange=\"doSwitchTime(this.value)\">\n");
	if(strlen(col_values[4]) < 5)
	{
		fprintf(cgiOut, "	     <option value='0' selected>���趨</option>\n");
	}
	else
	{
		fprintf(cgiOut, "			 <option value='0'>���趨</option>\n");
	}
	
	if(strlen(col_values[4]) > 5 && strlen(col_values[4]) < 15)
	{
		fprintf(cgiOut, "			 <option value='1' selected>��ѭ��</option>\n");
	}
	else
	{
		fprintf(cgiOut, "			 <option value='1'>��ѭ��</option>\n");
	}
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "      <input type='text' id='TimeD' name='TimeD' maxlength='12' value='%s' style='width:155px;height:20px;display:none;'><font color=red>��ʽ:*0600,*1200</font>\n", col_values[4]);		
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>���</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='link_delay' style='width:250px;height:25px'>\n");
	fprintf(cgiOut, "        <option value='0'  %s>ֻ����һ��</option>\n",   0 == strcmp(col_values[5], "0")?"selected":"");
	fprintf(cgiOut, "        <option value='5'  %s>��5���Ӵ��� </option>\n", 0 == strcmp(col_values[5], "5")?"selected":"");
	fprintf(cgiOut, "        <option value='10' %s>��10���Ӵ���</option>\n", 0 == strcmp(col_values[5], "10")?"selected":"");
	fprintf(cgiOut, "        <option value='20' %s>��20���Ӵ���</option>\n", 0 == strcmp(col_values[5], "20")?"selected":"");
	fprintf(cgiOut, "        <option value='30' %s>��30���Ӵ���</option>\n", 0 == strcmp(col_values[5], "30")?"selected":"");
	fprintf(cgiOut, "        <option value='45' %s>��45���Ӵ���</option>\n", 0 == strcmp(col_values[5], "45")?"selected":"");
	fprintf(cgiOut, "        <option value='60' %s>��60���Ӵ���</option>\n", 0 == strcmp(col_values[5], "60")?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>�豸</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Id' id='Id' style='width:250px;height:25px;' onchange=\"doChange(this.value, '')\">\n");		
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = "select a.id, a.cname from device_detail a, device_act b where a.id = b.id group by a.id order by a.id";
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_device_info_upper_agentid, col_values[6], &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Cmd' id='Cmd' style='width:250px;height:25px;' onchange='doChange2(this.value)'>\n");
	
	char sql2[512] = "select a.id, a.sn, a.cmdname, a.status, b.object from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and a.id = '";
	strcat(sql2, changevalue);
	strcat(sql2, "'");
	rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_device_cmd, col_values[7], &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Tel' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='Tel' value='%s' style='width:250px;height:20px;' maxlength=256><font color=red>�������/����</font>\n", col_values[8]);	
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Object' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='Object' value='%s' style='width:250px;height:20px;' maxlength=256>\n", col_values[8]);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Call' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select id='CallSN' name='Call' style='width:250px;height:20px;'>\n");
	
	char sql3[512] = "select a.sn, a.cname from call a";
	rc = sqlite3_exec(db, sql3, &sqlite3_exec_callback_device_call, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	sqlite3_close(db);
	
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  </table><br>\n");
	//fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div style='text-align:center'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doAdd()'    src='../../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doCancel()' src='../../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//�༭
	fprintf(cgiOut, "var reqChg = null;\n");
	fprintf(cgiOut, "function doChange(pValue, pSelCmd)\n");
	fprintf(cgiOut, "{\n");
	//��ɾ��
	fprintf(cgiOut, "  var length = document.getElementById('Cmd').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('Cmd').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	//������
	fprintf(cgiOut, "  var CmdType = '0';\n");
	fprintf(cgiOut, "  if(pValue.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(pValue.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqChg.onreadystatechange = function(){callbackChangeName(pValue, pSelCmd, CmdType)};\n");
	fprintf(cgiOut, "  var url = 'device_off.cgi?cmd=4&id='+pValue+'&currtime='+new Date();\n");
	fprintf(cgiOut, "	 reqChg.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqChg.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackChangeName(pValue, pSelCmd, CmdType)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqChg.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqChg.responseText;\n");	
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var list = resp.split('#');\n");
	fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "      		 var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      		 objOption.value = list[i];\n");
	fprintf(cgiOut, "      		 objOption.text = sublist[2];\n");
	fprintf(cgiOut, "      		 document.getElementById('Cmd').add(objOption);\n");
	fprintf(cgiOut, "  			   if(pSelCmd.length > 0)\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "  			     if(pSelCmd == sublist[1])\n");
	fprintf(cgiOut, "  			     {\n");
	fprintf(cgiOut, "  			       objOption.selected = true;\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(agent.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = agent.Object.value.substring(0, agent.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = agent.Object.value.substring(agent.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    agent.Tel.value = tel;\n");
	fprintf(cgiOut, "                    agent.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(agent.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = agent.Tel.value.substring(0, agent.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = agent.Tel.value.substring(agent.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   agent.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "  			     }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "  			   else\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "          	 if(i == 0)\n");
	fprintf(cgiOut, "        	   {\n");
	fprintf(cgiOut, "						   objOption.selected = 'true';\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(agent.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = agent.Object.value.substring(0, agent.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = agent.Object.value.substring(agent.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    agent.Tel.value = tel;\n");
	fprintf(cgiOut, "                    agent.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(agent.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = agent.Tel.value.substring(0, agent.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = agent.Tel.value.substring(agent.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   agent.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doChange2(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 if(pValue.length > 0)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   var list = pValue.split(',');\n");
	fprintf(cgiOut, "	   var Id = list[0];\n");
	fprintf(cgiOut, "	   var SN = list[1];\n");
	fprintf(cgiOut, "	   var CmdName = list[2];\n");
	fprintf(cgiOut, "	   var Object = list[3];\n");
	fprintf(cgiOut, "	   var CmdType = '0';\n");
	fprintf(cgiOut, "	   if(Id.indexOf('001103') >= 0 && Object == '1')\n");//����
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '1';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(Id.indexOf('001104') >= 0 && Object == '1')\n");//����
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '2';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   if('0' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     if('1' == Object)\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	     else\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('1' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('2' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSwitchTime(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "if(pValue == '0'){document.getElementById('TimeD').style.display = 'none';}\n");
	fprintf(cgiOut, "if(pValue == '1'){document.getElementById('TimeD').style.display = '';}\n");
	fprintf(cgiOut, "if(pValue == '2'){document.getElementById('TimeD').style.display = '';}\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doChange(agent.Id.value, '%s');\n", EditSelCmd);	
	fprintf(cgiOut, "doSwitchTime(agent.Time.value);\n");	
		
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");	
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(agent.Id.value.length < 1){alert('��ѡ�������豸!'); return;}\n");
	fprintf(cgiOut, "  if(agent.Cmd.value.length < 1){alert('��ѡ����������!');return;}\n");
	fprintf(cgiOut, "  var TimeD = ' ';\n");
	fprintf(cgiOut, "  if('0' != agent.Time.value)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    TimeD = agent.TimeD.value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(TimeD.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    TimeD = ' ';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var Id = agent.Id.value;\n");	
	fprintf(cgiOut, "  var Style = '0';\n");
	fprintf(cgiOut, "  if(Id.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(Id.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var CmdList = agent.Cmd.value.split(',');\n");
	fprintf(cgiOut, "  var Cmd = CmdList[1];\n");
	fprintf(cgiOut, "  var ObjectFlag = CmdList[3];\n");
	fprintf(cgiOut, "  var StatusFlag = CmdList[4];\n");
	fprintf(cgiOut, "  var Object = '';\n");
	fprintf(cgiOut, "  if('0' == Style)\n");//��ͨ
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      Object = agent.Object.value;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('1' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(agent.Object.value.length < 1 && agent.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = agent.Tel.value + '//' + agent.Object.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('2' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(agent.Call.value.length < 1 && agent.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = agent.Tel.value + '//' + agent.Call.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(Object.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Object = ' ';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var len = Object.len();\n");	
	fprintf(cgiOut, "  if(len > 256)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ݳ��ȹ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if('0' == StatusFlag)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ����δ����Ϊ���ã��ݲ��ɱ༭!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ���޸�?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqAdd = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqAdd = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqAdd.onreadystatechange = callbackAddName;\n");			
	fprintf(cgiOut, "    var url = 'device_off.cgi?cmd=3&id=%s&seq=%s&valibtime='+TimeD+'&interval='+agent.link_delay.value+'&d_id='+Id+'&d_cmd='+Cmd+'&object='+Object+'&acttype=2&currtime='+new Date();\n", id, seq);
	fprintf(cgiOut, "    reqAdd.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqAdd.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqAdd.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackAddName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqAdd.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqAdd.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "        if(resp.indexOf('�ɹ�') >= 0 || resp.indexOf('�ύ�ɹ�') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          parent.location = 'device_off.cgi?cmd=0&id=%s';\n", id);
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
	return 0;	
}

void Submit()
{
	if(0 == strcmp(acttype, "1"))
	{
		//��������seq
		int rc;
		char * zErrMsg = 0;
		char sql2[128] = "select max(t.seq)+1 from device_agent t";
		sqlite3 *db = open_db(DB_PATH);
		rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_add, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(2);
		}	
		
		//��ѯ����
		memset(sql2, 0, sizeof(sql2));
		sprintf(sql2, "select a.id from device_agent a where a.id = '%s' and a.ctype = '1'", id);
		rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_cnt, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(2);
		}	
		sqlite3_close(db);
	}
	
	if(0 == strcmp(acttype, "1") && cnt >= 5)
	{
		printf("��������5��!\n");
	}
	else
	{
		int ret = MsgSend(atoi(acttype));
		printf("%s\n", getStatusName(ret));
	}
}

int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL == col_values[0] || strlen(col_values[0]) == 0)
	{
		memcpy(seq, "1", 10);
	}
	else
	{
		memcpy(seq, col_values[0], 10);
	}
	return 0;
}

int sqlite3_exec_callback_cnt(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

char *StrRightFillSpace(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	int FillLen = len - strlen(strData);
	strcat(FillStr, strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(FillStr, " ");
	}
	return FillStr;
}

//�����߳�
int MsgSend(int flag)
{	
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	//������װ
	BYTE outbuf[2048] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	int len = 0;
	switch(flag)
	{
		case 1://������������
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002011");
				strcat(pdata, StrRightFillSpace(seq, 10));
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 4));
				strcat(pdata, StrRightFillSpace(condition, 128));
				strcat(pdata, StrRightFillSpace(valibtime, 30));
				strcat(pdata, StrRightFillSpace(interval, 4));
				strcat(pdata, StrRightFillSpace(d_id, 10));
				strcat(pdata, StrRightFillSpace(d_cmd, 8));
				strcat(pdata, StrRightFillSpace(object, 256));
				strcat(pdata, "1");
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 4 + 128 + 30 + 4 + 10 + 8 + 256 + 1;
			break;
		case 2://���������༭
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002012");
				strcat(pdata, StrRightFillSpace(seq, 10));
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 4));
				strcat(pdata, StrRightFillSpace(condition, 128));
				strcat(pdata, StrRightFillSpace(valibtime, 30));
				strcat(pdata, StrRightFillSpace(interval, 4));
				strcat(pdata, StrRightFillSpace(d_id, 10));
				strcat(pdata, StrRightFillSpace(d_cmd, 8));
				strcat(pdata, StrRightFillSpace(object, 256));
				strcat(pdata, "1");
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 4 + 128 + 30 + 4 + 10 + 8 + 256 + 1;
			break;
		case 3://��������ɾ��
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002013");
				strcat(pdata, StrRightFillSpace(seq, 10));
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 4));
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 4;
			break;
	}
	
	//AddMsg((BYTE *)outbuf, 1024);
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	
	char *ip = getLocalIP();
	
	//����
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	pSock->SetCompletion();
		
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return SYS_STATUS_FORMAT_ERROR;
	}
	
	char szBuf[512] = {0};
	if(true == pSock->IsPending(30000))
	{
	 	if((len = pSock->Recv(szBuf, 512)) <= 0)
		{
			pSock->EndSocket();
			return SYS_STATUS_SYS_BUSY;
		}
		
		//���շ���
		pMsgHdr = (PMsgHdr)szBuf;
		char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
		char result[5] = {0};
		strncpy(result, pmsg+20, 4);
		pSock->EndSocket();
		return atoi(result);
	}
	else
	{
		pSock->EndSocket();
		return SYS_STATUS_TIMEOUT;
	}
	
	//�ر�����
	pSock->EndSocket();
	return SYS_STATUS_FAILED;
}
