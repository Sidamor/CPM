#include <stdio.h>
#include <cgic.h>
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>

//��������
char role_id[11] = {0};
char dev_id[11]  = {0};
char dev_cmd[9]  = {0};
char cmdname[21] = {0};
char showdes[65] = {0};
int cnt = 0;
int cntAll = 0;
char cmd[4] = {0};
char id[11] = {0};
char point[4096*8] = {0};
char actlist[4096*8] = {0};
//��������
static void getHtmlData();
void err_msg(int pType);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//��ѯ
static void QueryCmd();
static int sqlite3_exec_callback_act(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_tree_cmd(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_tree_cmdlist(void *data, int n_columns, char **col_values, char **col_names);
static void Update();
static void ShowDes();
static int sqlite3_exec_callback_attr(void *data, int n_columns, char **col_values, char **col_names);
static void ShowDesUdp();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	cntAll = 0;
	switch(atoi(cmd))
	{
		case 1:
			QueryCmd();
			break;
		case 2:
			Update();
			sprintf(cmd, "%s", "1");
			QueryCmd();
			break;
		case 3:
			ShowDes();
			break;
		case 4:
			ShowDesUdp();
			break;
	}
	
	return 0;
}

void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("id", id, sizeof(id));
	cgiFormString("point", point, sizeof(point));
	cgiFormString("actlist", actlist, sizeof(actlist));
	cgiFormString("role_id", role_id, sizeof(role_id));
	cgiFormString("dev_id", dev_id, sizeof(dev_id));
	cgiFormString("dev_cmd", dev_cmd, sizeof(dev_cmd));
	cgiFormString("cmdname", cmdname, sizeof(cmdname));
	cgiFormString("showdes", showdes, sizeof(showdes));
}

void QueryCmd()
{
	fprintf(cgiOut, "<html xmlns:v='urn:schemas-microsoft-com:vml'>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<title>����Ȩ�޷���</title>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content='text/html; charset=gb2312'>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "<script>\n");
	//��ϣ����
	fprintf(cgiOut, "var hashTable = new Object();\n");
	fprintf(cgiOut, "function add(key, value)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(key in hashTable)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    \n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    hashTable[key] = value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 40%%;\n");
	fprintf(cgiOut, "  height:40%%;\n");
	fprintf(cgiOut, "  left:30%%;\n");
	fprintf(cgiOut, "  top:30%%;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n"); 
	fprintf(cgiOut, "<body style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name='net_nodeaction' action='net_nodeaction.cgi' method='post' target='actionFrame'>\n");
	//fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "  <table width='100%%' style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	
	if(NULL != point && strlen(point) > 0)
	{
		int rc;
		char * zErrMsg = 0;
		char sql[4096*4] = {0};
		sqlite3 *db = open_db(DB_PATH);
		sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
		
		//��ѯ�Ѱ󶨶���
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "select t.role_id, t.dev_id, t.dev_cmd, t.area, t.showdes from act_limit t where t.role_id = '%s' and t.dev_id = '%s' order by t.role_id, t.dev_id, t.dev_cmd", id, point);	
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_act, 0, &zErrMsg);
		if(rc != SQLITE_OK )
		{
			err_msg(1);
		}
		
		//��ѯ�豸������
		memset(sql, 0, sizeof(sql));
		sprintf(sql, "select t.id, t.cname from device_detail t where t.id = '%s'", point);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_tree_cmd, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(1);
		}
		sqlite3_close(db);
	}
	else
	{
		fprintf(cgiOut, "  <tr height='30px'>\n");
		fprintf(cgiOut, "    <td width='100%%' align='center'>��!</td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "  <input type='hidden' name='cmd'     value='2'>\n");
	fprintf(cgiOut, "  <input type='hidden' name='id'      value='%s'>\n", id);
	fprintf(cgiOut, "  <input type='hidden' name='point'   value='%s'>\n", point);
	fprintf(cgiOut, "  <input type='hidden' name='actlist' value=''>\n");
	//fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='aboutDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<script language=javascript>\n");
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeActDiv();\n");
	fprintf(cgiOut, "  \n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var actlist = '';\n");
	fprintf(cgiOut, "  for(var i=0; i<%d; i++)\n", cntAll);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('checkbox'+i).checked == true)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      //��ȡ��������\n");
	fprintf(cgiOut, "      var key = net_nodeaction.id.value + document.getElementById('checkbox'+i).value;\n");
	fprintf(cgiOut, "      var value = hashTable[key];\n");
	fprintf(cgiOut, "      if(null == value || value.Trim().length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        value = '';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      actlist += document.getElementById('checkbox'+i).value + document.getElementById('option'+i).value + value + ';';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  net_nodeaction.actlist.value = actlist;\n");
	fprintf(cgiOut, "  if(confirm('ȷ���ύ?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    net_nodeaction.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doShowDes(pRoleId, pId, pSN, pCmdName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  //��ȡ��������\n");
	fprintf(cgiOut, "  var key = pRoleId + pId + pSN;\n");
	fprintf(cgiOut, "  var value = hashTable[key];\n");
	fprintf(cgiOut, "  if(null == value || value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    value = '';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'net_nodeaction.cgi?cmd=3&id=%s&point=%s&role_id='+pRoleId+'&dev_id='+pId+'&dev_cmd='+pSN+'&cmdname='+pCmdName+'&showdes='+value;\n", id, point);
	fprintf(cgiOut, "  document.getElementById('aboutDiv').innerHTML = \"<iframe id='aboutFrame' name='aboutFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('aboutDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</html>\n");
}

int sqlite3_exec_callback_act(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat(actlist, col_values[0]);
	strcat(actlist, ",");
	strcat(actlist, col_values[1]);
	strcat(actlist, ",");
	strcat(actlist, col_values[2]);
	strcat(actlist, ",");
	strcat(actlist, col_values[3]);
	strcat(actlist, ";");
	fprintf(cgiOut, "<script>\n");
	fprintf(cgiOut, "add('%s%s%s', '%s');\n", col_values[0], col_values[1], col_values[2], col_values[4]);
	fprintf(cgiOut, "</script>\n");
	return 0;
}

int sqlite3_exec_callback_tree_cmd(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt = 0;
	
	fprintf(cgiOut, "  <tr height='45px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>\n");
	fprintf(cgiOut, "      <img src='../../skin/images/mini_button_fp.png' style='width:40px;height:40px;cursor:hand;' onClick='doSubmit()'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color=green size=4><B>[%s]</B></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src='../../skin/images/mini_button_fh.png' style='width:40px;height:40px;cursor:hand;' onClick='doReturn()'>\n", col_values[1]);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='left' colspan=2>\n");
	fprintf(cgiOut, "      <table width='100%%' border=0 cellPadding=0 cellSpacing=0>\n");
	fprintf(cgiOut, "        <tr height='30px'>\n");
	
	//����
	int rc;
	char * zErrMsg = 0;
	char sql[256] = {0};
	sprintf(sql, "select t.id, t.sn, t.cmdname, a.dev_type from device_act t, device_info a, device_cmd b where t.id = '%s' and substr(t.id,1,6) = a.id and substr(t.id,1,6) = b.id and t.sn = b.sn and b.cmd_type = '0' order by t.sn", col_values[0]);
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_tree_cmdlist, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	int index = cnt%3;
	switch(index)
	{
		case 1:
				fprintf(cgiOut, "    <td width='25%%' align='center'>&nbsp;</td>\n");
				fprintf(cgiOut, "    <td width='25%%' align='center'>&nbsp;</td>\n");
			break;
		case 2:
				fprintf(cgiOut, "    <td width='25%%' align='center'>&nbsp;</td>\n");
			break;
	}
	
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	return 0;
}

int sqlite3_exec_callback_tree_cmdlist(void *data, int n_columns, char **col_values, char **col_names)
{
	if(0 == cnt%3 && cnt > 0)
	{	
		fprintf(cgiOut, "</tr>\n");
		fprintf(cgiOut, "<tr height='30px'>\n");
	}
	fprintf(cgiOut, "<td width='25%%' align='center'>\n");
	fprintf(cgiOut, "  <table width='100%%'>\n");
	fprintf(cgiOut, "    <tr height='30px'>\n");
	
	//t.id, t.sn, t.cmdname, a.dev_type
	char flag[64] = {0};
	sprintf(flag, "%s,%s,%s,", id, col_values[0], col_values[1]);
	switch(atoi(col_values[3]))
	{
		case 1://��ֵ��
			{
				//00 - ������
				//01 - ��ֵ��
				char checked[10] = {0};
				if(strstr(actlist, flag))
				{
					strcat(checked, "checked");
				}
				
				fprintf(cgiOut, "    <td width='40%%' align='left'>\n");
				fprintf(cgiOut, "      <input type='checkbox' id='checkbox%d' name='checkbox%d' style='width:15px;height:15px;' value='%s%s' %s>%s\n", cntAll, cntAll, col_values[0], col_values[1], checked, col_values[2]);
				fprintf(cgiOut, "    </td>\n");
				fprintf(cgiOut, "    <td width='60%%' align='left'>\n");
				fprintf(cgiOut, "      <select id='option%d' name='option%d' style='width:80px;height:16px;'>\n", cntAll, cntAll);
				
				if(0 == strcmp(col_values[1], "00010001") || 0 == strcmp(col_values[1], "00010002"))
					fprintf(cgiOut, "      <option value='00'>������</option>\n");
				else
					fprintf(cgiOut, "      <option value='01'>��ֵ��</option>\n");
					
				fprintf(cgiOut, "      </select>\n");
				fprintf(cgiOut, "    </td>\n");
				break;
			}
		case 2://��ֵ��
			{
				//00 - ������
				//02 - ��ֵ��-��
				//03 - ��ֵ��-��
				char checked[10] = {0};
				if(strstr(actlist, flag))
				{
					strcat(checked, "checked");
				}
				
				fprintf(cgiOut, "    <td width='40%%' align='left'>\n");
				fprintf(cgiOut, "      <input type='checkbox' id='checkbox%d' name='checkbox%d' style='width:15px;height:15px;' value='%s%s' %s>%s\n", cntAll, cntAll, col_values[0], col_values[1], checked, col_values[2]);
				fprintf(cgiOut, "    </td>\n");
				fprintf(cgiOut, "    <td width='60%%' align='left'>\n");
				fprintf(cgiOut, "      <select id='option%d' name='option%d' style='width:80px;height:16px;'>\n", cntAll, cntAll);
				
				if(0 == strcmp(col_values[1], "00010001") || 0 == strcmp(col_values[1], "00010002"))
				{
					fprintf(cgiOut, "      <option value='00'>������</option>\n");
				}
				else
				{
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "02");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "    <option value='02' selected>��ֵ��-��</option>\n");
					else
						fprintf(cgiOut, "    <option value='02'>��ֵ��-��</option>\n");
						
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "03");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "    <option value='03' selected>��ֵ��-��</option>\n");
					else
						fprintf(cgiOut, "    <option value='03'>��ֵ��-��</option>\n");
				}
				fprintf(cgiOut, "      </select>\n");
				fprintf(cgiOut, "    </td>\n");
				break;
			}
		case 3://��ֵ��
			{
				//00 - ������
				//04 - ��ֵ��-��
				//05 - ��ֵ��-��
				//06 - ��ֵ��-��
				char checked[10] = {0};
				if(strstr(actlist, flag))
				{
					strcat(checked, "checked");
				}
				
				fprintf(cgiOut, "    <td width='40%%' align='left'>\n");
				fprintf(cgiOut, "      <input type='checkbox' id='checkbox%d' name='checkbox%d' style='width:15px;height:15px;' value='%s%s' %s>%s\n", cntAll, cntAll, col_values[0], col_values[1], checked, col_values[2]);
				fprintf(cgiOut, "    </td>\n");
				fprintf(cgiOut, "    <td width='60%%' align='left'>\n");
				fprintf(cgiOut, "      <select id='option%d' name='option%d' style='width:80px;height:16px;'>\n", cntAll, cntAll);
				
				if(0 == strcmp(col_values[1], "00010001") || 0 == strcmp(col_values[1], "00010002"))
				{
					fprintf(cgiOut, "      <option value='00'>������</option>\n");
				}
				else
				{
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "04");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "    <option value='04' selected>��ֵ��-��</option>\n");
					else
						fprintf(cgiOut, "    <option value='04'>��ֵ��-��</option>\n");
						
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "05");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "    <option value='05' selected>��ֵ��-��</option>\n");
					else
						fprintf(cgiOut, "    <option value='05'>��ֵ��-��</option>\n");
						
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "06");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "    <option value='06' selected>��ֵ��-��</option>\n");
					else
						fprintf(cgiOut, "    <option value='06'>��ֵ��-��</option>\n");
				}
				fprintf(cgiOut, "      </select>\n");
				fprintf(cgiOut, "    </td>\n");
				break;
			}
		case 0://�����
		case 4://������
			{
				//00 - ������
				char checked[10] = {0};
				if(strstr(actlist, flag))
				{
					strcat(checked, "checked");
				}
				
				fprintf(cgiOut, "    <td width='40%%' align='left'>\n");
				fprintf(cgiOut, "      <input type='checkbox' id='checkbox%d' name='checkbox%d' style='width:15px;height:15px;' value='%s%s' %s>%s\n", cntAll, cntAll, col_values[0], col_values[1], checked, col_values[2]);
				fprintf(cgiOut, "    </td>\n");
				fprintf(cgiOut, "    <td width='60%%' align='left'>\n");
				fprintf(cgiOut, "      <select id='option%d' name='option%d' style='width:80px;height:16px;'>\n", cntAll, cntAll);
				
				if(0 == strcmp(col_values[1], "00010001") || 0 == strcmp(col_values[1], "00010002"))
					fprintf(cgiOut, "      <option value='00'>������</option>\n");
				else
					fprintf(cgiOut, "      <option value='99'>δ֪��</option>\n");
					
				fprintf(cgiOut, "      </select>\n");
				fprintf(cgiOut, "    </td>\n");
				break;
			}
		case 5://������
			{
				//00 - ������
				//07 - ������-��
				//08 - ������-��
				//09 - ������-��
				//10 - ������-��
				//11 - ������-��
				//12 - ������-��
				char checked[10] = {0};
				if(strstr(actlist, flag))
				{
					strcat(checked, "checked");
				}
				
				fprintf(cgiOut, "    <td width='40%%' align='left'>\n");
				fprintf(cgiOut, "      <input type='checkbox' id='checkbox%d' name='checkbox%d' style='width:15px;height:15px;' value='%s%s' %s>%s\n", cntAll, cntAll, col_values[0], col_values[1], checked, col_values[2]);
				fprintf(cgiOut, "    </td>\n");
				fprintf(cgiOut, "    <td width='60%%' align='left'>\n");
				
				if(0 == strcmp(col_values[1], "00010001") || 0 == strcmp(col_values[1], "00010002"))
				{
					fprintf(cgiOut, "    <select id='option%d' name='option%d' style='width:80px;height:16px;'>\n", cntAll, cntAll);
					fprintf(cgiOut, "      <option value='00'>������</option>\n");
					fprintf(cgiOut, "    </select>\n");
				}
				else
				{
					fprintf(cgiOut, "    <select id='option%d' name='option%d' style='width:80px;height:16px;'>\n", cntAll, cntAll);
					
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "12");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "      <option value='12' selected>������-��</option>\n");
					else
						fprintf(cgiOut, "      <option value='12'>������-��</option>\n");
						
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "07");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "      <option value='07' selected>������-��</option>\n");
					else
						fprintf(cgiOut, "      <option value='07'>������-��</option>\n");
						
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "08");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "      <option value='08' selected>������-��</option>\n");
					else
						fprintf(cgiOut, "      <option value='08'>������-��</option>\n");
						
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "09");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "      <option value='09' selected>������-��</option>\n");
					else
						fprintf(cgiOut, "      <option value='09'>������-��</option>\n");
						
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "10");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "      <option value='10' selected>������-��</option>\n");
					else
						fprintf(cgiOut, "      <option value='10'>������-��</option>\n");
						
					memset(flag, 0, sizeof(flag));
					sprintf(flag, "%s,%s,%s,%s;", id, col_values[0], col_values[1], "11");
					if(strstr(actlist, flag))
						fprintf(cgiOut, "      <option value='11' selected>������-��</option>\n");
					else
						fprintf(cgiOut, "      <option value='11'>������-��</option>\n");
					
					fprintf(cgiOut, "      </select>\n");
					
					if(0 == strcmp(checked, "checked"))
					{
						fprintf(cgiOut, "      <img src='../../skin/images/device_cmdadd.png' style='cursor:hand;' title='��������' onClick=\"doShowDes('%s', '%s', '%s', '%s')\">\n", id, col_values[0], col_values[1], col_values[2]);
					}
				}
				fprintf(cgiOut, "    </td>\n");
				break;
			}
	}
	
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</td>\n");
	
	cnt++;
	cntAll++;
	return 0;
}

void Update()
{
	//ɾ��id�°�
	int rc = SQLITE_ERROR;
	char * zErrMsg;
	char sql[1024] = {0};
	sprintf(sql, "delete from act_limit where role_id = '%s' and dev_id = '%s'", id, point);
	sqlite3 *db = open_db(DB_PATH);
	if(NULL == db)
	{
		err_msg(1);
		return;
	}

	while((rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg)) != SQLITE_OK && NULL != strstr(zErrMsg, "database is locked"));
	if(SQLITE_OK != rc)
	{
		sqlite3_close(db);
		return;
	}
		
	//����id�°�
	if(NULL != actlist && strlen(actlist) > 0)
	{
		char *p;
		char *buffer = strdup(actlist);
		p = strtok(buffer, ";");
		while(NULL != p)
		{
			char dev_id[11] = {0};
			char sn_id[9] = {0};
			char type_id[3] = {0};
			char showdes[65] = {0};
			strncpy(dev_id, p, 10);
			strncpy(sn_id,  p+10, 8);
			strncpy(type_id, p+18, 2);
			strncpy(showdes, p+20, strlen(p)-20);
			
			memset(sql, 0, sizeof(sql));
			sprintf(sql, "insert into act_limit(role_id, dev_id, dev_cmd, area, showdes)values('%s', '%s', '%s', '%s', '%s');", id, dev_id, sn_id, type_id, showdes);
			rc = SQLITE_ERROR;
			while(rc != SQLITE_OK)
			{
				rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
			}
			
			p = strtok(NULL, ";");
		}
	}
	sqlite3_close(db);
	fprintf(cgiOut, "<script>alert('�ɹ�');</script>\n");
}

void ShowDes()
{
	char showdes_id[15] = {0};
	char showdes_fh[2] = {0};
	char showdes_value[30] = {0};
	if(NULL != showdes && strlen(showdes) > 0)
	{
		strncpy(showdes_id,    showdes,    14);
		strncpy(showdes_fh,    showdes+14, 1);
		strncpy(showdes_value, showdes+15, strlen(showdes)-15);
	}
	fprintf(cgiOut, "<HTML>\n");
	fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>��������</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"net_nodeaction\" action=\"net_nodeaction.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "  <table width=\"100%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "    <tr height='25px'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='right' colspan=2>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doUpdate();'><font color=green>[����]</font></a>\n");
	fprintf(cgiOut, "        <a href='#' onclick='doClose();' ><font color=green>[�ر�]</font></a>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "        ��\n");
	fprintf(cgiOut, "        <select name='attr_id' style='width:120px;height:25px;'>\n");
	fprintf(cgiOut, "          <option value='' %s>������</option>\n", 0 == strcmp(showdes, "")?"selected":"");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[256] = {0};
	sprintf(sql1, "select t.id, t.sn, t.attr_name from device_roll t where t.id = '%s' order by t.sn", dev_id);
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_attr, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "        <select name='copm_fh' style='width:50px;height:25px;'>\n");
	fprintf(cgiOut, "          <option value='=' %s>=</option>\n", 0 == strcmp(showdes_fh, "=")?"selected":"");
	fprintf(cgiOut, "          <option value='>' %s>></option>\n", 0 == strcmp(showdes_fh, ">")?"selected":"");
	fprintf(cgiOut, "          <option value='<' %s><</option>\n", 0 == strcmp(showdes_fh, "<")?"selected":"");
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "        <input type='text' name='attr_value' style='width:50px;height:20px;' value='%s' maxlength='10'>\n", showdes_value);
	fprintf(cgiOut, "        ʱ\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "    <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "        <B><font color=green>[%s]</font>������ʾ!</B>\n", cmdname);
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doClose()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doUpdate()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var showdes = '';\n");
	fprintf(cgiOut, "  if(net_nodeaction.attr_id.value.Trim().length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(net_nodeaction.attr_value.value.Trim().length < 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('��������ֵ');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    showdes = net_nodeaction.attr_id.value + net_nodeaction.copm_fh.value + net_nodeaction.attr_value.value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ����������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqEdit = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqEdit = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqEdit.onreadystatechange = callbackEditName;\n");			
	fprintf(cgiOut, "    var url = 'net_nodeaction.cgi?cmd=4&role_id=%s&dev_id=%s&dev_cmd=%s&showdes='+showdes+'&currtime='+new Date();\n", role_id, dev_id, dev_cmd);
	fprintf(cgiOut, "    reqEdit.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqEdit.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqEdit.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackEditName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqEdit.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqEdit.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('�ɹ�');\n");
	fprintf(cgiOut, "          parent.closeDiv();\n");
	fprintf(cgiOut, "          parent.location = 'net_nodeaction.cgi?cmd=1&id=%s&point=%s';\n", id, point);
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('ʧ��');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_attr(void *data, int n_columns, char **col_values, char **col_names)
{
	char strdes[15] = {0};
	strcat(strdes, col_values[0]);
	strcat(strdes, col_values[1]);
	
	if(strstr(showdes, strdes))
		fprintf(cgiOut, "<option value='%s%s' selected>%s</option>\n", col_values[0], col_values[1], col_values[2]);
	else
		fprintf(cgiOut, "<option value='%s%s'>%s</option>\n", col_values[0], col_values[1], col_values[2]);
	
	return 0;
}

void ShowDesUdp()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql2[256] = "";
	sprintf(sql2, "update act_limit set showdes = '%s' where role_id = '%s' and dev_id = '%s' and dev_cmd = '%s'", showdes, role_id, dev_id, dev_cmd);
	rc = sqlite3_exec(db, sql2, NULL, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	printf("0000\n");
}
