#include <stdio.h>
#include <cgic.h>
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

//��������
char uploadret[2] = {0};
int cnt = 0;
char cmd[4] = {0};
char id[7] = {0};
char cname[30] = {0};
char icon[61] = {0};
char point[4096*8] = {0};
char dev_id[11] = {0};
char pos_x[7] = {0};
char pos_y[7] = {0};
//��������
static void getHtmlData();
void err_msg(int pType);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
//����ͼ
static void QueryIcon();
static int sqlite3_exec_callback_icon(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_point(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_marke(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_marke_area(void *data, int n_columns, char **col_values, char **col_names);
//ͣ�ó���ͼ
static void UNUseIcon();
//����ͼ�ϴ�
static void IconUpload();
//δ��ע�豸
static void QueryDev();
static int sqlite3_exec_callback_dev(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_area(void *data, int n_columns, char **col_values, char **col_names);
//��ע��ɾ��
static void DevMarke();
//��λ
static void DevMarkeEdit();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	switch(atoi(cmd))
	{
		case 1://����ͼ
			QueryIcon();
			break;
		case 2://����ͼ�ϴ�
			IconUpload();
			if(0 == strcmp(uploadret, "1"))
			{
				fprintf(cgiOut, "<script language='javascript'>alert('ͼƬ�����ϴ�ʧ�ܣ�����400K����!');</script>\n");
			}
			else
			{
				fprintf(cgiOut, "<script language='javascript'>alert('���³ɹ�! ΪʹͼƬʵʱ��Ч, ��ɾ������������ر���������´򿪵���!');</script>\n");
			}
			sprintf(cmd, "%s", "1");
			QueryIcon();
			break;
		case 3://��ѯ
			QueryDev();
			break;
		case 4://��ע
		case 5://ɾ��
			DevMarke();
			sprintf(cmd, "%s", "1");
			QueryIcon();
			break;
		case 6://��λ
			DevMarkeEdit();
			break;
		case 7://ͣ�ó���ͼ
			UNUseIcon();
			sprintf(cmd, "%s", "1");
			QueryIcon();
			break;
	}
	
	return 0;
}

void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("id", id, sizeof(id));
  cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("icon", icon, sizeof(icon));
	cgiFormString("point", point, sizeof(point));
	cgiFormString("dev_id", dev_id, sizeof(dev_id));
	cgiFormString("pos_x", pos_x, sizeof(pos_x));
	cgiFormString("pos_y", pos_y, sizeof(pos_y));
}

void QueryIcon()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = {0};
	sprintf(sql, "select t.id, t.cname, t.point, t.icon from role t where t.id = '%s'", id);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_icon, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_icon(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<title>������ע</title>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/util.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../../skin/js/dom-drag.js'></script>\n");
	fprintf(cgiOut, "<style>\n");
	fprintf(cgiOut, "  html{height:100%%}\n");
	fprintf(cgiOut, "  body{height:100%%; margin:0px; padding:0px}\n");
	fprintf(cgiOut, "  #container{height:100%%}\n");
	fprintf(cgiOut, "  html,body{width:100%%; height:100%%; margin:0; padding:0;}\n");
	fprintf(cgiOut, "  .mesWindow{border:#C7C5C6 1px solid;background:#CADFFF;}\n");
	fprintf(cgiOut, "  .mesWindowTop{background:#3ea3f9;padding:5px;margin:0;font-weight:bold;text-align:left;font-size:12px; clear:both; line-height:1.5em; position:relative; clear:both;}\n");
	fprintf(cgiOut, "  .mesWindowTop span{ position:absolute; right:5px; top:3px;}\n");
	fprintf(cgiOut, "  .mesWindowContent{margin:4px;font-size:12px; clear:both;}\n");
	fprintf(cgiOut, "  .mesWindow .close{height:15px;width:28px; cursor:pointer;text-decoration:underline;background:#fff}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"net_nodescene\" action=\"net_nodescene.cgi\" method=\"post\" target=\"childFrame\" enctype='multipart/form-data'>\n");
	//fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<table width='100%%' height='100%%' align=center style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='700px' align='left'>\n");
	fprintf(cgiOut, "      %s:\n", cname);
	fprintf(cgiOut, "      <input type='file' name='file' title='��ѡ�񳡾�ͼ'  value='���' style='width:350px;height:20px'>\n");
	fprintf(cgiOut, "      <input type='button' style='width:90px;height:20px;' value='���³���ͼ' onClick=\"doUpload()\">\n");
	fprintf(cgiOut, "      <input type='button' style='width:90px;height:20px;' value='ͣ�ó���ͼ' onClick=\"doUNUse()\">\n");
	fprintf(cgiOut, "      <input type='button' style='width:50px;height:20px;' value='����'       onClick=\"doReturn()\">\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='500px'>\n");
	fprintf(cgiOut, "    <td width='700px' align='left'>\n");
	fprintf(cgiOut, "      <div id='mapdiv' style='text-align:center;width:700px;height:500px;position:relative;left:0;top:0;border:0px solid green;'>\n");
	fprintf(cgiOut, "        <img id='mapimg' src='../%s' style='width:700px;height:500px;'>\n", col_values[3]);
	fprintf(cgiOut, "      </div>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	//fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd'   value='2'>\n");
	fprintf(cgiOut, "<input type='hidden' name='id'    value='%s'>\n", id);
	fprintf(cgiOut, "<input type='hidden' name='cname' value='%s'>\n", cname);
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//����
	fprintf(cgiOut, "function doReturn()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.location = 'net_area.cgi?cmd=0';\n");
	//fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	//ͣ�ó���ͼ
	fprintf(cgiOut, "function doUNUse()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ��ͣ�ó���ͼ?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'net_nodescene.cgi?cmd=7&id=%s&cname=%s';\n", id, cname);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//���³���ͼ
	fprintf(cgiOut, "function doUpload()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var pUrl = net_nodescene.file.value;\n");
	fprintf(cgiOut, "  if(pUrl.indexOf('.jpg') == -1 && pUrl.indexOf('.JPG') == -1 && pUrl.indexOf('.gif') == -1 && pUrl.indexOf('.GIF') == -1 && pUrl.indexOf('.bmp') == -1 && pUrl.indexOf('.BMP') == -1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȷ��ͼƬ��ʽ,֧��jpg,gif,bmp,JPG,GIF,BMP��ʽ!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ�����³���ͼ?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    net_nodescene.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//��ע
	if(NULL != col_values[3] && strlen(col_values[3]) > 6)
	{
		switch(strlen(col_values[0]))
		{
			case 4://����(ƽ��ͼ)
				{
					//��ʾ����
					char sql[4096*8] = {0};
					int rc;
					char * zErrMsg = 0;
					sqlite3 *db = open_db(DB_PATH);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "select a.id, a.cname, a.pos_x, a.pos_y from role a where length(a.id) = 6 and a.id like '%s%s' and a.sign = '1' order by a.id", id, "%");				
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_marke_area, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
						err_msg(3);
					}
					
					//��ʾ�豸
					memset(point, 0, sizeof(point));
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "select a.point from role a where length(a.id) = 8 and a.id like '%s%s' order by a.id", id, "%");				
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_point, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
						err_msg(3);
					}
					
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "select a.id, a.cname, b.icon, a._pos_x, a._pos_y from device_detail a, device_info b where substr(a.id, 1, 6) = b.id and a._sign = '1' and contain('%s', a.id) = 1 order by a.id", point);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_marke, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
						err_msg(3);
					}
					
					sqlite3_close(db);
					
					//�һ���ע
					fprintf(cgiOut, "document.getElementById('mapimg').oncontextmenu = function()\n");
					fprintf(cgiOut, "{\n");
					fprintf(cgiOut, "  var pos_x = window.event.offsetX;\n");
					fprintf(cgiOut, "  var pos_y = window.event.offsetY;\n");
					fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
					fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
					fprintf(cgiOut, "  reqChg.onreadystatechange = function()\n");
					fprintf(cgiOut, "  {\n");
					fprintf(cgiOut, "    var state = reqChg.readyState;\n");
					fprintf(cgiOut, "    if(state == 4)\n");
					fprintf(cgiOut, "    {\n");
					fprintf(cgiOut, "      var resp = reqChg.responseText;\n");
					fprintf(cgiOut, "      if(resp != null && resp.indexOf('���µ���') < 0)\n");
					fprintf(cgiOut, "      {\n");
					fprintf(cgiOut, "        var messContent = '';\n");
					fprintf(cgiOut, "        messContent += \"<div style='text-align:center;margin:10px;'>\";\n");
					fprintf(cgiOut, "        messContent += \"  <select id='Area_Id' name='Area_Id' style='width:120px;height:20px;'>\";\n");
					fprintf(cgiOut, "        var list = resp.split('~');\n");
					fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
					fprintf(cgiOut, "        {\n");
					fprintf(cgiOut, "          var sublist = list[i].split('^');\n");
					fprintf(cgiOut, "          if(6 == sublist[0].length)\n");
					fprintf(cgiOut, "          {\n");
					fprintf(cgiOut, "            messContent += \"<option value='\"+sublist[0]+\"'>\"+sublist[1]+\"</option>\";\n");
					fprintf(cgiOut, "          }\n");
					fprintf(cgiOut, "        }\n");
					fprintf(cgiOut, "        messContent += \"  </select>\";\n");
					fprintf(cgiOut, "        messContent += \"  <input type='button' value='��ע����' onclick=doArea('\"+pos_x+\"','\"+pos_y+\"')>\";\n");
					fprintf(cgiOut, "        messContent += \"</div>\";\n");
					fprintf(cgiOut, "        messContent += \"<div style='text-align:center;margin:10px;'>\";\n");
					fprintf(cgiOut, "        messContent += \"  <select id='Dev_Id' name='Dev_Id' style='width:120px;height:20px;'>\";\n");
					fprintf(cgiOut, "        var list = resp.split('~');\n");
					fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
					fprintf(cgiOut, "        {\n");
					fprintf(cgiOut, "          var sublist = list[i].split('^');\n");
					fprintf(cgiOut, "          if(10 == sublist[0].length)\n");
					fprintf(cgiOut, "          {\n");
					fprintf(cgiOut, "          		messContent += \"  <option value='\"+sublist[0]+\"'>\"+sublist[1]+\"</option>\";\n");
					fprintf(cgiOut, "          }\n");
					fprintf(cgiOut, "        }\n");
					fprintf(cgiOut, "        messContent += \"  </select>\";\n");
					fprintf(cgiOut, "        messContent += \"  <input type='button' value='��ע�豸' onclick=doMark('\"+pos_x+\"','\"+pos_y+\"')>\";\n");
					fprintf(cgiOut, "        messContent += \"</div>\";\n");
					fprintf(cgiOut, "        showMessageBox('���ӱ�ע', messContent , 300, 150);\n");
					fprintf(cgiOut, "      }\n");
					fprintf(cgiOut, "      else\n");
					fprintf(cgiOut, "      {\n");
					fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
					fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
					fprintf(cgiOut, "      }\n");
					fprintf(cgiOut, "    }\n");
					fprintf(cgiOut, "  };\n");
					fprintf(cgiOut, "  var url = 'net_nodescene.cgi?cmd=3&id=%s&cname=%s&point=%s&currtime='+new Date();\n", id, cname, point);
					fprintf(cgiOut, "	 reqChg.open('get', url);\n");
					fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
					fprintf(cgiOut, "  reqChg.send(null);\n");
					fprintf(cgiOut, "  return true;\n");
					fprintf(cgiOut, "}\n");
					
					//�һ���ע
					fprintf(cgiOut, "function doArea(x, y)\n");
					fprintf(cgiOut, "{\n");
					fprintf(cgiOut, "  if(document.getElementById('Area_Id').value.length < 1)\n");
					fprintf(cgiOut, "  {\n");
					fprintf(cgiOut, "    alert('��ѡ������');\n");
					fprintf(cgiOut, "    return;\n");
					fprintf(cgiOut, "  }\n");
					fprintf(cgiOut, "  if(confirm('ȷ�����ӱ�ע?'))\n");
					fprintf(cgiOut, "  {\n");
					fprintf(cgiOut, "    location = 'net_nodescene.cgi?cmd=4&id=%s&cname=%s&dev_id='+document.getElementById('Area_Id').value+'&pos_x='+x+'&pos_y='+y;\n", id, cname);
					fprintf(cgiOut, "  }\n");
					fprintf(cgiOut, "}\n");
				}
				break;
			case 6://����(����ͼ)
				{
					//��ʾ�豸
					memset(point, 0, sizeof(point));
					char sql[4096*8] = {0};
					sprintf(sql, "select a.point from role a where length(a.id) = 8 and a.id like '%s%s' order by a.id", id, "%");
					int rc;
					char * zErrMsg = 0;
					sqlite3 *db = open_db(DB_PATH);
					sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_point, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
						err_msg(3);
					}
					
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "select a.id, a.cname, b.icon, a.pos_x, a.pos_y from device_detail a, device_info b where substr(a.id, 1, 6) = b.id and a.sign = '1' and contain('%s', a.id) = 1 order by a.id", point);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_marke, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
						err_msg(3);
					}
					
					sqlite3_close(db);
					
					//�һ���ע
					fprintf(cgiOut, "document.getElementById('mapimg').oncontextmenu = function()\n");
					fprintf(cgiOut, "{\n");
					fprintf(cgiOut, "  var pos_x = window.event.offsetX;\n");
					fprintf(cgiOut, "  var pos_y = window.event.offsetY;\n");
					fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
					fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
					fprintf(cgiOut, "  reqChg.onreadystatechange = function()\n");
					fprintf(cgiOut, "  {\n");
					fprintf(cgiOut, "    var state = reqChg.readyState;\n");
					fprintf(cgiOut, "    if(state == 4)\n");
					fprintf(cgiOut, "    {\n");
					fprintf(cgiOut, "      var resp = reqChg.responseText;\n");
					fprintf(cgiOut, "      if(resp != null && resp.indexOf('���µ���') < 0)\n");
					fprintf(cgiOut, "      {\n");
					fprintf(cgiOut, "        var messContent = '';\n");
					fprintf(cgiOut, "        messContent += \"<div style='text-align:center;margin:10px;'>\";\n");
					fprintf(cgiOut, "        messContent += \"  <select id='Dev_Id' name='Dev_Id' style='width:120px;height:20px;'>\";\n");
					fprintf(cgiOut, "        var list = resp.split('~');\n");
					fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
					fprintf(cgiOut, "        {\n");
					fprintf(cgiOut, "          var sublist = list[i].split('^');\n");
					fprintf(cgiOut, "          messContent += \"  <option value='\"+sublist[0]+\"'>\"+sublist[1]+\"</option>\";\n");
					fprintf(cgiOut, "        }\n");
					fprintf(cgiOut, "        messContent += \"  </select>\";\n");
					fprintf(cgiOut, "        messContent += \"  <input type='button' value='��ע�豸' onclick=doMark('\"+pos_x+\"','\"+pos_y+\"')>\";\n");
					fprintf(cgiOut, "        messContent += \"</div>\";\n");
					fprintf(cgiOut, "        showMessageBox('���ӱ�ע', messContent , 300, 150);\n");
					fprintf(cgiOut, "      }\n");
					fprintf(cgiOut, "      else\n");
					fprintf(cgiOut, "      {\n");
					fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
					fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
					fprintf(cgiOut, "      }\n");
					fprintf(cgiOut, "    }\n");
					fprintf(cgiOut, "  };\n");
					fprintf(cgiOut, "  var url = 'net_nodescene.cgi?cmd=3&id=%s&cname=%s&point=%s&currtime='+new Date();\n", id, cname, point);
					fprintf(cgiOut, "	 reqChg.open('get', url);\n");
					fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
					fprintf(cgiOut, "  reqChg.send(null);\n");
					fprintf(cgiOut, "  return true;\n");
					fprintf(cgiOut, "}\n");
				}
				break;
		}
		
		//���ýڵ�
		fprintf(cgiOut, "for(var i=0; i<%d; i++)\n", cnt);
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  Drag.init(document.getElementById('dev_' + i), document.getElementById('div_' + i), 0, 700-60, 0, 500-50, false, false, false, false);\n");
		fprintf(cgiOut, "  document.getElementById('div_' + i).onDragEnd = function(x, y)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    doDragEnd(Drag.obj.attributes['value'].value, x, y);\n");
		fprintf(cgiOut, "  };\n");
		fprintf(cgiOut, "}\n");
		
		//�һ���ע
		fprintf(cgiOut, "function doMark(x, y)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(document.getElementById('Dev_Id').value.length < 1)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('��ѡ���豸');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  if(confirm('ȷ�����ӱ�ע?'))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    location = 'net_nodescene.cgi?cmd=4&id=%s&cname=%s&dev_id='+document.getElementById('Dev_Id').value+'&pos_x='+x+'&pos_y='+y;\n", id, cname);
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
		
		//ɾ����ע
		fprintf(cgiOut, "function doDel(pId)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(confirm('ȷ��ȡ����ע?'))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    location = 'net_nodescene.cgi?cmd=5&id=%s&cname=%s&dev_id='+pId;\n", id, cname);
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
		
		//��ק�ӿ�
		fprintf(cgiOut, "function doDragEnd(pId, x, y)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(confirm('ȷ����������?'))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
		fprintf(cgiOut, "    else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
		fprintf(cgiOut, "    reqChg.onreadystatechange = function()\n");
		fprintf(cgiOut, "    {\n");
		fprintf(cgiOut, "      var state = reqChg.readyState;\n");
		fprintf(cgiOut, "      if(state == 4)\n");
		fprintf(cgiOut, "      {\n");
		fprintf(cgiOut, "        var resp = reqChg.responseText;\n");
		fprintf(cgiOut, "        if(resp.indexOf('���µ���') < 0)\n");
		fprintf(cgiOut, "        {\n");
		fprintf(cgiOut, "          if(resp.indexOf('0000') > -1)\n");
		fprintf(cgiOut, "          {\n");
		fprintf(cgiOut, "            alert('�ɹ�');\n");
		fprintf(cgiOut, "            return;\n");
		fprintf(cgiOut, "          }\n");
		fprintf(cgiOut, "          else\n");
		fprintf(cgiOut, "          {\n");
		fprintf(cgiOut, "            alert('ʧ��,�����²���');\n");
		fprintf(cgiOut, "            return;\n");
		fprintf(cgiOut, "          }\n");
		fprintf(cgiOut, "        }\n");
		fprintf(cgiOut, "        else\n");
		fprintf(cgiOut, "        {\n");
		fprintf(cgiOut, "          alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
		fprintf(cgiOut, "          window.open( '../../index.html', '_top');\n");
		fprintf(cgiOut, "        }\n");
		fprintf(cgiOut, "      }\n");
		fprintf(cgiOut, "    };\n");
		fprintf(cgiOut, "    var url = 'net_nodescene.cgi?cmd=6&id=%s&cname=%s&dev_id='+pId+'&pos_x='+x+'&pos_y='+y+'&currtime='+new Date();\n", id, cname);
		fprintf(cgiOut, "	   reqChg.open('get', url);\n");
		fprintf(cgiOut, "    reqChg.setRequestHeader('If-Modified-Since', '0');\n");
		fprintf(cgiOut, "    reqChg.send(null);\n");
		fprintf(cgiOut, "    return true;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
	}
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
	return 0;
}

/********************����(ƽ��ͼ)*****************/
int sqlite3_exec_callback_marke_area(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "var objHtml = '';\n");
	fprintf(cgiOut, "objHtml += \"<div id='div_%d' style='position:absolute;left:%spx;top:%spx;width:60px;height:50px;text-align:right;'>\";\n", cnt, col_values[2], col_values[3]);
	fprintf(cgiOut, "objHtml += \"  <img id='img_%d' style='width:16px;height:16px;cursor:hand;' src='../../skin/images/marke_del.png' onclick=doDel('%s')>\";\n", cnt, col_values[0]);
	fprintf(cgiOut, "objHtml += \"  <div id='dev_%d' value='%s' style='border:1px solid #ffffff;text-align:center;'><img style='width:32px;height:32px;cursor:hand;' src='../../skin/images/scene.png'><br><font size=2 color='#ffffff'>%s</font></div>\";\n", cnt, col_values[0], col_values[1]);
	fprintf(cgiOut, "objHtml += \"</div>\";\n");
	fprintf(cgiOut, "document.getElementById('mapdiv').innerHTML += objHtml;\n");
	cnt++;
	return 0;
}

/********************����(����ͼ)*****************/
int sqlite3_exec_callback_marke(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "var objHtml = '';\n");
	fprintf(cgiOut, "objHtml += \"<div id='div_%d' style='position:absolute;left:%spx;top:%spx;width:60px;height:50px;text-align:right;'>\";\n", cnt, col_values[3], col_values[4]);
	fprintf(cgiOut, "objHtml += \"  <img id='img_%d' style='width:16px;height:16px;cursor:hand;' src='../../skin/images/marke_del.png' onclick=doDel('%s')>\";\n", cnt, col_values[0]);
	fprintf(cgiOut, "objHtml += \"  <div id='dev_%d' value='%s' style='border:1px solid #ffffff;text-align:center;'><img style='width:32px;height:32px;cursor:hand;' src='../../system/%s'><br><font size=2 color='#ffffff'>%s</font></div>\";\n", cnt, col_values[0], col_values[2], col_values[1]);
	fprintf(cgiOut, "objHtml += \"</div>\";\n");
	fprintf(cgiOut, "document.getElementById('mapdiv').innerHTML += objHtml;\n");
	cnt++;
	return 0;
}

/********************����(����ͼ)*****************/
int sqlite3_exec_callback_point(void *data, int n_columns, char **col_values, char **col_names)
{
	strcat(point, col_values[0]);
	return 0;
}

void QueryDev()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
	
	char sql[4096*8] = {0};
	switch(strlen(id))
	{
		case 4://����(ƽ��ͼ)
				{
					//����
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "select a.id, a.cname from role a where length(a.id) = 6 and a.id like '%s%s' and a.sign = '0' order by a.id", id, "%");
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_area, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
						err_msg(3);
					}
					
					//�豸
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "select a.id, a.cname from device_detail a where a._sign = '0' and contain('%s', a.id) = 1 order by a.id", point);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_dev, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
						err_msg(3);
					}
				}
			break;
		case 6://����(����ͼ)
				{
					//�豸
					memset(sql, 0, sizeof(sql));
					sprintf(sql, "select a.id, a.cname from device_detail a where a.sign = '0' and contain('%s', a.id) = 1 order by a.id", point);
					rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_dev, 0, &zErrMsg);
					if(rc != SQLITE_OK)
					{
						err_msg(3);
					}
				}
			break;
	}
	
	sqlite3_close(db);
}

int sqlite3_exec_callback_area(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "%s^%s~", col_values[0], col_values[1]);
	return 0;
}

int sqlite3_exec_callback_dev(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "%s^%s~", col_values[0], col_values[1]);
	return 0;
}

void DevMarke()
{
	char sql[256] = {0};
	switch(strlen(id))
	{
		case 4://����(ƽ��ͼ)
				switch(atoi(cmd))
				{
					case 4:
							switch(strlen(dev_id))
							{
								case 6://����
										sprintf(sql, "update role set sign = '1', pos_x = '%s', pos_y = '%s' where id = '%s'", pos_x, pos_y, dev_id);
									break;
								case 10:
										sprintf(sql, "update device_detail set _sign = '1', _pos_x = '%s', _pos_y = '%s' where id = '%s'", pos_x, pos_y, dev_id);
									break;//�豸
							}
						break;
					case 5:
							switch(strlen(dev_id))
							{
								case 6://����
										sprintf(sql, "update role set sign = '0' where id = '%s'", dev_id);
									break;
								case 10:
										sprintf(sql, "update device_detail set _sign = '0' where id = '%s'", dev_id);
									break;//�豸
							}
						break;
				}
			break;
		case 6://����(����ͼ)
				switch(atoi(cmd))
				{
					case 4:
							sprintf(sql, "update device_detail set sign = '1', pos_x = '%s', pos_y = '%s' where id = '%s'", pos_x, pos_y, dev_id);
						break;
					case 5:
							sprintf(sql, "update device_detail set sign = '0' where id = '%s'", dev_id);
						break;
				}
			break;
	}
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	fprintf(cgiOut, "<script language='javascript'>alert('�ɹ�');</script>\n");
}

void DevMarkeEdit()
{
	char sql[256] = {0};
	switch(strlen(id))
	{
		case 4://����(ƽ��ͼ)
				switch(strlen(dev_id))
				{
					case 6://����
							sprintf(sql, "update role set pos_x = '%s', pos_y = '%s' where id = '%s'", pos_x, pos_y, dev_id);
						break;
					case 10:
							sprintf(sql, "update device_detail set _pos_x = '%s', _pos_y = '%s' where id = '%s'", pos_x, pos_y, dev_id);
						break;//�豸
				}
			break;
		case 6://����(����ͼ)
				sprintf(sql, "update device_detail set pos_x = '%s', pos_y = '%s' where id = '%s'", pos_x, pos_y, dev_id);
			break;
	}
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(3);
	}
	sqlite3_close(db);
	printf("0000\n");
}

void UNUseIcon()
{
	char sql[256] = {0};
	sprintf(sql, "update role set icon = ' ' where id = '%s'", id);
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	//ɾ��ͼƬ
	char delcmd[61] = {0};
	sprintf(delcmd, "rm -rf /home/www/admin/scene/%s.gif", id);
	system(delcmd);
}

void IconUpload()
{
	cgiFilePtr file;
	int targetFile;
	mode_t mode;
	char name[128];
	
	//�ļ���
	char fimename[10] = {0};
	strcat(fimename, "file");
	
	//�洢��
	char fileNameOnServer[64] = {0};
	strcat(fileNameOnServer, "/home/www/admin/scene/");
	strcat(fileNameOnServer, id);
	strcat(fileNameOnServer, ".gif");
	
	char contentType[1024];
	char buffer[1024];
	int size;
	int got;
	
	//ͼƬ·����ȡ
	if (cgiFormFileName(fimename, name, sizeof(name)) != cgiFormSuccess)
	{    
		fprintf(stderr,"could not retrieve filename\n");
	}

	//ͼƬ����    
	cgiFormFileContentType(fimename, contentType, sizeof(contentType));

	//ͼƬ��С
	cgiFormFileSize(fimename, &size);
	if(size/1024 > 400)
	{
		memcpy(uploadret, "1", 2);
	}
	else
	{
		//Ŀǰ�ļ�������ϵͳ��ʱ�ļ����У�ͨ��Ϊ/tmp��ͨ�����������ʱ�ļ�����ʱ�ļ����������û��ļ������ֲ�ͬ�����Բ���ͨ��·��/tmp/userfilename�ķ�ʽ����ļ�    
		if (cgiFormFileOpen(fimename, &file) != cgiFormSuccess)
		{    
			fprintf(stderr,"could not open the file\n");   
		}
		
		//�ڵ�ǰĿ¼�½����µ��ļ�����һ������ʵ������·�������˴��ĺ�������cgi�������ڵ�Ŀ¼����ǰĿ¼�����������ļ�  
		mode = S_IRWXU|S_IRGRP|S_IROTH;
		targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode); 
		if(targetFile < 0)
		{    
			fprintf(stderr,"could not create the new file,%s\n",fileNameOnServer);    
		}
		
		//��ϵͳ��ʱ�ļ��ж����ļ����ݣ����ŵ��մ�����Ŀ���ļ���
		while(cgiFormFileRead(file, buffer, 1024, &got) == cgiFormSuccess)
		{
			if(got > 0)
				write(targetFile, buffer, got);
		}
		cgiFormFileClose(file);
		close(targetFile);
		
		goto END;
		END:
		
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db = open_db(DB_PATH);
		char sql[256] = {0};
		sprintf(sql, "update role set icon = 'scene/%s.gif' where id = '%s'", id, id);
		rc = sqlite3_exec(db, sql, NULL, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(1);
		}
		sqlite3_close(db);
	}
}
