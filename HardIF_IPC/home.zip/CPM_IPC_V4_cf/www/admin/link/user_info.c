#include <stdio.h>
#include <cgic.h>
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"

//��������
char Sql[1024] = {0};
int cnt = 0;
char cmd[4] = {0};
char ics[512] = {0};
char acttype[3] = {0};
char m1key[385] = {0};
char ic_type[2] = {0};
char ic[20] = {0};
char cntAll[9] = {0};//�����û���
char cntNow[9] = {0};//�����û���

//���ֶζ���
char sys_id[5] = {0};
char id[30] = {0};
char pwd[20] = {0};
char cname[20] = {0};
char sex[10] = {0};
char birthday[20] = {0};
char addr[50] = {0};
char tel[20] = {0};
char status[10] = {0};
char sp_role[10] = {0};
char hj_role[10] = {0};
char ykt_role[10] = {0};
char ctrl_role[10] = {0};
char qx[10] = {0};
char newpwd[20] = {0};
char dept_id[5] = {0};
char deptname[30] = {0};
char func_id[5] = {0};

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ��¼
static void QueryData();
//���¼�¼
static int UpdateData();
//��ѯ����
static void SingleQuery();
//������֤�������޸�
static void SingleValidate();
static void AddHtml();
static void AddData();
static int sqlite3_exec_callback_cntall(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cntnow(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_sysid(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_validate(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_agent(void *data, int n_columns, char **col_values, char **col_names);
//����ز���
static void CardExec();
//���Ź���
static void CardManger();
static int sqlite3_exec_callback_card(void *data, int n_columns, char **col_values, char **col_names);
int sqlite3_exec_callback_mikey(void *data, int n_columns, char **col_values, char **col_names);
//socketͨѶ
static int MsgSend(int flag);
//��ȡ����IP
char *getLocalIP();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	switch(atoi(cmd))
	{
		case 0://��ѯ
			QueryData();
			break;
		case 10://����
			AddData();
			sprintf(cmd, "%s", "0");
			QueryData();
			break;
		case 11://�޸�
		case 12://ɾ��
			UpdateData();
			sprintf(cmd, "%s", "0");		
			QueryData();
			break;
		case 13://�޸�����
			SingleValidate();
			if(cnt == 1)
			{
				UpdateData();
				printf("�����޸ĳɹ�!");
			}
			else
			{
				printf("�û������������!");
			}
			break;
		case 14://��������
			sprintf(cmd, "%s", "13");
			UpdateData();			
			printf("�������óɹ�!");
			break;
		case 20://������ѯ
			SingleQuery();
			break;
		case 21:
			AddHtml();
			break;		
		case 4://����ش���
			CardExec();
			sprintf(cmd, "%s", "3");
		case 3://���Ź���
			CardManger();
			break;
	}
	
	return 0;
}

static void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
  cgiFormString("sys_id", sys_id, sizeof(sys_id)); 
	cgiFormString("id", id, sizeof(id));
	cgiFormString("pwd", pwd, sizeof(pwd));
	cgiFormString("cname", cname, sizeof(cname));	
	cgiFormString("sex", sex, sizeof(sex));
	cgiFormString("birthday", birthday, sizeof(birthday));
	cgiFormString("addr", addr, sizeof(addr));
	cgiFormString("tel", tel, sizeof(tel));
	cgiFormString("status", status, sizeof(status));
	cgiFormString("ykt_role", ykt_role, sizeof(ykt_role));
	cgiFormString("hj_role", hj_role, sizeof(hj_role));	
	cgiFormString("ctrl_role", ctrl_role, sizeof(ctrl_role));
	cgiFormString("sp_role", sp_role, sizeof(sp_role));
	cgiFormString("qx", qx, sizeof(qx));
	cgiFormString("newpwd", newpwd, sizeof(newpwd));
	cgiFormString("dept_id", dept_id, sizeof(dept_id));
	cgiFormString("func_id", func_id, sizeof(func_id));
	cgiFormString("deptname", deptname, sizeof(deptname));
	cgiFormString("ics", ics, sizeof(ics));
	cgiFormString("acttype", acttype, sizeof(acttype));	
	cgiFormString("ic", ic, sizeof(ic));
	cgiFormString("ic_type", ic_type, sizeof(ic_type));
}
static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0://�û���Ϣ
      strcat(Sql, "select t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role, t.ykt_role, t.dept_id, a.dept, t.sys_id, b.cname, c.cname, d.cname, t.ctrl_role, e.cname from user_info t, corp_info a, role b, role c, role d, role e where t.qx = b.id and t.sp_role = c.id and t.hj_role = d.id and t.ykt_role = e.id and t.dept_id like '");
      strcat(Sql, func_id);
      strcat(Sql, "%' order by t.sys_id asc");
			break;
		case 1://������Ϣ
      strcat(Sql, "select t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role, t.ykt_role, t.dept_id from user_info t where t.id = '");
			strcat(Sql, id);
			strcat(Sql, "' and t.pwd = '");
			strcat(Sql, pwd);
			strcat(Sql, "' ");
			break;
		case 2://�������ò�ѯ
			strcat(Sql, "select dept from corp_info");
			break;
		case 3://���Ź���
			strcat(Sql, "select t.id, t.ctype, t.identify, t.status, t.ic from card_manager t where t.id = '");
			strcat(Sql, sys_id);
			strcat(Sql, "'");
			break;
		case 4://��������
			strcat(Sql, "insert into card_manager(id, ctype, ic)values('");
			strcat(Sql, sys_id);
			strcat(Sql, "', '");
			strcat(Sql, ic_type);
			strcat(Sql, "', '");
			strcat(Sql, ic);
			strcat(Sql, "') ");
			break; 
		case 5://����ɾ��
			strcat(Sql, "delete from card_manager where id = '");
			strcat(Sql, sys_id);
			strcat(Sql, "' and ic = '");
			strcat(Sql, ic);
			strcat(Sql, "'");
			break;
		case 10://�û�����
			strcat(Sql, "insert into user_info(id, cname, qx, sex, birthday, addr, tel, status, sp_role, hj_role, ykt_role, dept_id, sys_id, ctrl_role)values('");
			strcat(Sql, id);
			strcat(Sql, "', '");
			strcat(Sql, cname);
			strcat(Sql, "', '");
			strcat(Sql, qx);
			strcat(Sql, "', '");
			strcat(Sql, sex);
			strcat(Sql, "', '");
			strcat(Sql, birthday);
			strcat(Sql, "', '");
			strcat(Sql, addr);
			strcat(Sql, "', '");
			strcat(Sql, tel);
			strcat(Sql, "', '");
			strcat(Sql, status);
			strcat(Sql, "', '");
			strcat(Sql, sp_role);
			strcat(Sql, "', '");
			strcat(Sql, hj_role);
			strcat(Sql, "', '");
			strcat(Sql, ykt_role);
			strcat(Sql, "', '");
			strcat(Sql, dept_id);	
			strcat(Sql, "', '");
			strcat(Sql, sys_id);
			strcat(Sql, "', '");
			strcat(Sql, ctrl_role);			
			strcat(Sql, "') ");
			break;
		case 11://�û��޸�
			strcat(Sql, "update user_info set id='");
			strcat(Sql, id);
			strcat(Sql, "', cname = '");
			strcat(Sql, cname);
			strcat(Sql, "', sex = '");
			strcat(Sql, sex);
			strcat(Sql, "', birthday = '");
			strcat(Sql, birthday);
			strcat(Sql, "', addr = '");
			strcat(Sql, addr);
			strcat(Sql, "', tel = '");
			strcat(Sql, tel);
			strcat(Sql, "', status = '");
			strcat(Sql, status);
			strcat(Sql, "', sp_role = '");
			strcat(Sql, sp_role);
			strcat(Sql, "', hj_role = '");
			strcat(Sql, hj_role);
			strcat(Sql, "', ykt_role = '");
			strcat(Sql, ykt_role);
			strcat(Sql, "', ctrl_role = '");
			strcat(Sql, ctrl_role);		
			strcat(Sql, "', dept_id = '");
			strcat(Sql, dept_id);	
			strcat(Sql, "', qx = '");
			strcat(Sql, qx);
      strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
		case 12://�û�ɾ��
			strcat(Sql, "delete from user_info t where t.id='");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
		case 13://��������
			strcat(Sql, "update user_info set pwd='");
			strcat(Sql, newpwd);
			strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
		case 20://�޸������ѯ
      strcat(Sql, "select t.id, t.cname, t.pwd, t.qx, t.sex, t.birthday, t.addr, t.tel, t.status, t.sp_role, t.hj_role, t.ykt_role, t.dept_id from user_info t where upper(t.id) = upper('");
			strcat(Sql, id);
			strcat(Sql, "') ");
			break;
	}
	return Sql;
}
static void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>user_info</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"User_Info\" action=\"user_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/cap_user_info.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");   
	fprintf(cgiOut, "  <table width=\"90%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
  fprintf(cgiOut, "    <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "      <td width='20%%' align='left'>\n");
	fprintf(cgiOut, "        <select id='func_id' name='func_id' style='width:120px;height:20px;' onchange='doSelect()'>\n");
	if(0 == strlen(func_id))
	{
		fprintf(cgiOut, "        <option value='' selected>ȫ��</option>\n");
	}
	else
	{
		fprintf(cgiOut, "        <option value=''>ȫ��</option>\n");
	}
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(2), &sqlite3_exec_callback_agent, func_id, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	
	fprintf(cgiOut, "        </select>\n");
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "      <td width='80%%' align='right' colspan=7><a href=\"user_info.cgi?cmd=21&func_id=%s\" target=\"mainFrame\"><img style=\"cursor:hand\" src=\"../../skin/images/mini_button_add.gif\"></a></td>\n", func_id);
	fprintf(cgiOut, "     </tr>\n");
	fprintf(cgiOut, "     <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "       <td width='100%%' align='right' colspan=8>\n");
	fprintf(cgiOut, "         <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "           <tr>\n");
	fprintf(cgiOut, "             <td width=\"3%%\"  class=\"table_deep_blue\">SN</td>\n");
  fprintf(cgiOut, "             <td width=\"10%%\" class=\"table_deep_blue\">�˺�</td>\n");
	fprintf(cgiOut, "             <td width=\"10%%\" class=\"table_deep_blue\">����</td>\n");
	fprintf(cgiOut, "             <td width=\"10%%\" class=\"table_deep_blue\">����</td>\n");
	fprintf(cgiOut, "             <td width=\"10%%\" class=\"table_deep_blue\">����Ȩ��</td>\n");
	fprintf(cgiOut, "             <td width=\"10%%\" class=\"table_deep_blue\">��Ԫ����</td>\n");
	fprintf(cgiOut, "             <td width=\"10%%\" class=\"table_deep_blue\">���ݷ���</td>\n");
	fprintf(cgiOut, "             <td width=\"10%%\" class=\"table_deep_blue\">��Ƶ����</td>\n");
	fprintf(cgiOut, "             <td width=\"10%%\" class=\"table_deep_blue\">���Ź���</td>\n");
	fprintf(cgiOut, "           </tr>\n");
	
	rc = sqlite3_exec(db, getSql(atoi(cmd)), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "         </table>\n");
	fprintf(cgiOut, "       </td>\n");
	fprintf(cgiOut, "     </tr>\n");
	fprintf(cgiOut, "   </table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doSelect()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "location = 'user_info.cgi?cmd=0&func_id='+User_Info.func_id.value;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_agent(void *data, int n_columns, char **col_values, char **col_names)
{
	if(strstr(col_values[0], "//"))
	{
		/*
		char* split = "//";
		char* split_result = NULL;
		int i = 0;
		split_result = strtok(col_values[0], split);
		while(split_result != NULL)
		{
			i++;
			char * save = split_result+strlen(split_result)+1;	
			char pbranchcorpid[3] = {0};
			char pbranchcorpname[30] = {0};
			char pdeptlist[256] = {0};
			
			sprintf(pbranchcorpid, "%d", i);	  	 	
			memcpy(pbranchcorpid, StrLeftFillZero(pbranchcorpid, 2), 3);
					
			char *temp_p;
			char *temp_buffer = strdup(split_result);
			temp_p = strtok(temp_buffer, "/");
			int j = 0;
			while(NULL != temp_p)
			{
			   switch(j)
			   {
				  case 0:
					 sprintf(pbranchcorpname, "%s", temp_p);
					 break;
				  case 1:
					 sprintf(pdeptlist, "%s", temp_p);
					 break;
			   }
			   temp_p = strtok(NULL, "/");
			   j++;
			}
				
			fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", pbranchcorpid);
			fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", pbranchcorpname);
			fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", pdeptlist);
					
			split_result = strtok(save, split);
		}
		*/
	}
	else
	{
		if(0 < strlen(col_values[0]))
		{
			char* split = ",";
			char* split_result = NULL;
			int i = 0;
			split_result = strtok(col_values[0], split);
			while(split_result != NULL)
			{
				i++;
				char * save = split_result+strlen(split_result)+1;	
				char pdept_id[5] = {0};
	    	char pdept_name[30] = {0};
	    		
	    	sprintf(pdept_id, "%d", i);	    		    	 	
				memcpy(pdept_id, StrLeftFillZero(pdept_id, 4), 5);
				memcpy(pdept_name, split_result, 30);
				
				if(NULL != data && 0 == strcmp(pdept_id, (char*)data))
				{
					fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", pdept_id, pdept_name);
				}
				else
				{
					fprintf(cgiOut, "<option value='%s'>%s</option>\n", pdept_id, pdept_name);
				}		
				
				split_result = strtok(save, split);
			}
		}
	}
	return 0;
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
  if(0 != strcmp(col_values[0], "system") && 0 != strcmp(col_values[0], "admin"))
	{
		cnt++;
		if(cnt%2== 0)
		{
			fprintf(cgiOut, "<tr class='table_blue'>\n");
		}
		else
		{
			fprintf(cgiOut, "<tr class='table_white_l'>\n");
		}
		
		char StrSex[5] = {0};
		switch(atoi(col_values[4]))
		{
			case 0:
				strcat(StrSex, "��");
				break;
			case 1:
				strcat(StrSex, "Ů");
				break;
		}
		
		char dept_name[30] = {0};
		if(0 < strlen(col_values[13]))
		{
			char* split = ",";
			char* split_result = NULL;
			int i = 0;
			split_result = strtok(col_values[13], split);
			while(split_result != NULL)
			{
				i++;
				char * save = split_result+strlen(split_result)+1;	
				char pdept_id[5] = {0};
	    	char pdept_name[30] = {0};
	    		
	    	sprintf(pdept_id, "%d", i);	    		    	 	
				memcpy(pdept_id, StrLeftFillZero(pdept_id, 4), 5);
				memcpy(pdept_name, split_result, 30);
				
				if(0 == strcmp(pdept_id, col_values[12]))
				{
					strcat(dept_name, pdept_name);
					break;
				}
				
				split_result = strtok(save, split);
			}
		}
		
		fprintf(cgiOut, "  <td %s align='center'>%d</td>\n", 0 == strcmp(col_values[8], "1")?"class='font_gray'":"", cnt);
		fprintf(cgiOut, "  <td %s align='center'><a href=\"user_info.cgi?cmd=20&id=%s&cname=%s&qx=%s&sex=%s&birthday=%s&addr=%s&tel=%s&status=%s&sp_role=%s&hj_role=%s&ykt_role=%s&func_id=%s&dept_id=%s&ctrl_role=%s\" target=\"mainFrame\">%s</a></td>\n", 0 == strcmp(col_values[8], "1")?"class='font_gray'":"", col_values[0], col_values[1], col_values[3], col_values[4], col_values[5], col_values[6], col_values[7], col_values[8], col_values[9], col_values[10], col_values[11], func_id, col_values[12], col_values[18], col_values[0]);
		fprintf(cgiOut, "  <td %s align='center'>%s</td>\n", 0 == strcmp(col_values[8], "1")?"class='font_gray'":"", col_values[1]);
		fprintf(cgiOut, "  <td %s align='center'>%s</td>\n", 0 == strcmp(col_values[8], "1")?"class='font_gray'":"", dept_name);
		fprintf(cgiOut, "  <td %s align='center'>%s</td>\n", 0 == strcmp(col_values[8], "1")?"class='font_gray'":"", col_values[15]);	
		fprintf(cgiOut, "  <td %s align='center'>%s</td>\n", 0 == strcmp(col_values[8], "1")?"class='font_gray'":"", col_values[19]);
		fprintf(cgiOut, "  <td %s align='center'>%s</td>\n", 0 == strcmp(col_values[8], "1")?"class='font_gray'":"", col_values[17]);
		fprintf(cgiOut, "  <td %s align='center'>%s</td>\n", 0 == strcmp(col_values[8], "1")?"class='font_gray'":"", col_values[16]);
		fprintf(cgiOut, "  <td %s align='center'><a href='user_info.cgi?cmd=3&id=%s&cname=%s&sex=%s&tel=%s&deptname=%s&func_id=%s&sys_id=%s' target='mainFrame'>���Ź���</a></td>\n", 0 == strcmp(col_values[8], "1")?"class='font_gray'":"", col_values[0], col_values[1], StrSex, col_values[7], dept_name, func_id, col_values[14]);
		fprintf(cgiOut, "</tr>\n");
	}
	
	return 0;
}

void AddHtml()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title></title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style=\"background:#CADFFF\" onload=\"doAuto()\">\n");
	fprintf(cgiOut, "<form name=\"User_Add\" action=\"user_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/cap_user_info.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"60%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right'>\n");
	fprintf(cgiOut, "	     <img style=\"cursor:hand\" onClick=\"doSubmit()\" src=\"../../skin/images/mini_button_submit.gif\">\n");
	fprintf(cgiOut, "		   <img style=\"cursor:hand\" onClick=\"doCancel()\" src=\"../../skin/images/button10.gif\">\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "	 </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<table width=\"60%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "	 <tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "	   <td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "		 <td width=\"35%%\"><input type=\"text\" name=\"id\" style=\"width:120px;height:20px;\" maxlength=\"10\"></td>\n");
	fprintf(cgiOut, "		 <td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "		 <td width=\"35%%\">\n");
	fprintf(cgiOut, "		   <select name='dept_id' id='dept_id' style='width:120px;height:20px'>\n");
	int rc;
	char * zErrMsg = 0;
	//�����ݿ�
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(2), &sqlite3_exec_callback_agent, func_id, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	fprintf(cgiOut, "				 				</select>\n");
	fprintf(cgiOut, "				 			</td>\n");
	fprintf(cgiOut, "				 		</tr>\n");

	fprintf(cgiOut, "					 	<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\"><input type=\"text\" name=\"cname\" style=\"width:120px;height:22px;\"  maxlength=\"5\"></td>\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select name=\"sex\" style=\"width:120px;height:20px\">	\n");
	fprintf(cgiOut, "					      	 <option value=\"0\">��</option>\n");
	fprintf(cgiOut, "					      	 <option value=\"1\">Ů</option> \n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\"><input type=\"text\" name=\"tel\" style=\"width:120px;height:20px;\" maxlength=\"13\"></td>\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��������</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\"><input type=\"text\" name=\"birthday\" onClick=\"WdatePicker({readOnly:true})\" class=\"Wdate\" size=\"10\" maxlength=\"10\" style='width:120px;'></td>\n");
	fprintf(cgiOut, "				 		</tr>\n");

	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ַ</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\" ><input type=\"text\" name=\"addr\" style=\"width:120px;height:20px;\" maxlength=\"60\"></td>\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select name=\"status\" style=\"width:120px;height:20px\">	\n");
	fprintf(cgiOut, "					      	 <option value=\"0\">����</option>\n");
	fprintf(cgiOut, "					      	 <option value=\"1\">ע��</option> \n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">����Ȩ��</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select id=\"qx\" name=\"qx\" style=\"width:120px;height:20px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��Ԫ����</td>\n");
	fprintf(cgiOut, "							<td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select id=\"ykt_role\" name=\"ykt_role\" style=\"width:120px;height:20px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">���ݷ���</td>\n");
	fprintf(cgiOut, "							<td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select id=\"hj_role\" name=\"hj_role\" style=\"width:120px;height:20px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��Ƶ����</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select id=\"sp_role\" name=\"sp_role\" style=\"width:120px;height:20px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				</table>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type=\"hidden\" name=\"cmd\" value=\"10\">\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doAuto()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	doFPRole();\n");
	fprintf(cgiOut, "	doNetArea();\n");
	fprintf(cgiOut, "	doHJArea();\n");
	//fprintf(cgiOut, "	doCtrlArea();\n");
	fprintf(cgiOut, "	doSPArea();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doFPRole()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_FPRole = createXHR();\n");
	fprintf(cgiOut, "  if(m_FPRole)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    m_FPRole.onreadystatechange=callbackForFPRole;\n");
	fprintf(cgiOut, "    var url = \"video_area.cgi?cmd=2&currtime=\"+new Date();\n");
	fprintf(cgiOut, "    m_FPRole.open(\"get\", url);\n");
	fprintf(cgiOut, "    m_FPRole.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSPArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	  m_SPArea = createXHR();\n");
	fprintf(cgiOut, "   if(m_SPArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_SPArea.onreadystatechange=callbackForSPArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=90&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_SPArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_SPArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doNetArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	  m_NetArea = createXHR();\n");
	fprintf(cgiOut, "   if(m_NetArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_NetArea.onreadystatechange=callbackForNetArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=60&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_NetArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_NetArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doHJArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	  m_HJArea = createXHR();\n");
	fprintf(cgiOut, "   if(m_HJArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_HJArea.onreadystatechange=callbackForHJArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=70&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_HJArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_HJArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doCtrlArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	  m_CtrlArea = createXHR();\n");
	fprintf(cgiOut, "   if(m_CtrlArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_CtrlArea.onreadystatechange=callbackForCtrlArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=80&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_CtrlArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_CtrlArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "String.prototype.Trim = function()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  return this.replace(/(^\\s*)|(\\s*$)/g, '');\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "String.prototype.LTrim = function()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  return this.replace(/(^\\s*)/g, '');\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "String.prototype.RTrim = function()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  return this.replace(/(\\s*$)/g, '');\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{ \n");
	fprintf(cgiOut, "	 var id = User_Add.id.value;\n");
	fprintf(cgiOut, "	 var cname = User_Add.cname.value;\n");
	fprintf(cgiOut, "	 var tel = User_Add.tel.value;\n");
	fprintf(cgiOut, "	 var sex = User_Add.sex.value;\n");
	fprintf(cgiOut, "	 var birthday = User_Add.birthday.value;\n");
	fprintf(cgiOut, "	 var status = User_Add.status.value;\n");
	fprintf(cgiOut, "	 var ykt_role = User_Add.ykt_role.value;\n");
	fprintf(cgiOut, "	 var hj_role = User_Add.hj_role.value;\n");
	fprintf(cgiOut, "	 var ctrl_role = '';\n");
	fprintf(cgiOut, "	 var sp_role = User_Add.sp_role.value;\n");
	fprintf(cgiOut, "	 var addr = User_Add.addr.value;\n");
	fprintf(cgiOut, "	 var qx = User_Add.qx.value;\n");
	fprintf(cgiOut, "	 var dept_id = User_Add.dept_id.value;\n");
	fprintf(cgiOut, "	 \n");
	fprintf(cgiOut, "	 if(User_Add.id.value == null || User_Add.id.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�˺Ų���Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	
	fprintf(cgiOut, "	 if(User_Add.id.value.Trim().length == 4)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	  if(!isNaN(User_Add.id.value.Trim()))\n");
	fprintf(cgiOut, "	  {\n");
	fprintf(cgiOut, "	    alert('��ǰ�ʺŲ�����,�����¶���!');\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 	}\n");
	fprintf(cgiOut, "	 }\n");
	
	fprintf(cgiOut, "	 if(User_Add.cname.value == null || User_Add.cname.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"��������Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 \n");
	fprintf(cgiOut, "	 if(User_Add.dept_id.value == null || User_Add.dept_id.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"��ѡ����!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.tel.value == null || User_Add.tel.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�绰����Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.birthday.value == null || User_Add.birthday.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�������ڲ���Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.addr.value == null || User_Add.addr.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"��ַ����Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.qx.value == null || User_Add.qx.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�븳�赱ǰ�ʺŹ���Ȩ�޽�ɫ!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.ykt_role.value == null || User_Add.ykt_role.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�븳�赱ǰ�ʺ���Ԫ������ɫ!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.hj_role.value == null || User_Add.hj_role.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�븳�赱ǰ�ʺ����ݷ�����ɫ!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.sp_role.value == null || User_Add.sp_role.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�븳�赱ǰ�ʺ���Ƶ������ɫ!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(confirm(\"ȷ���������û�?\"))\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	 	  var currURL = \"user_info.cgi?cmd=10&id=\"+id+\"&cname=\"+cname+\"&tel=\"+tel+\"&sex=\"+sex+\"&birthday=\"+birthday+\"&status=\"+status+'&ykt_role='+ykt_role+\"&sp_role=\"+sp_role+\"&hj_role=\"+hj_role+'&ctrl_role='+ctrl_role+\"&addr=\"+addr+'&qx='+qx+'&dept_id='+dept_id+'&func_id=%s';\n", func_id);
	fprintf(cgiOut, "	    location = currURL;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, " \n");
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{ \n");
	fprintf(cgiOut, "	 location = \"user_info.cgi?cmd=0&func_id=%s\";\n", func_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "/*\n");
	fprintf(cgiOut, " *�����첽���ʶ���\n");
	fprintf(cgiOut, " */\n");
	fprintf(cgiOut, "function createXHR() \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    var xhr;\n");
	fprintf(cgiOut, "    try \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        xhr = new ActiveXObject(\"Msxml2.XMLHTTP\");\n");
	fprintf(cgiOut, "    } \n");
	fprintf(cgiOut, "    catch (e) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        try \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            xhr = new ActiveXObject(\"Microsoft.XMLHTTP\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        catch(E) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            xhr = false;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "    if (!xhr && typeof XMLHttpRequest != 'undefined') \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        xhr = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "    return xhr;\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "/*\n");
	fprintf(cgiOut, " *�첽�ص���������\n");
	fprintf(cgiOut, " */\n");
	fprintf(cgiOut, "function callbackForFPRole()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(m_FPRole.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "  	 if(m_FPRole.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var returnValue = m_FPRole.responseText;\n");
	fprintf(cgiOut, "      if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById(\"qx\").options.length = 0;\n");
	fprintf(cgiOut, "				 var TempArray = returnValue.split(\";\");\n");
	/*
	fprintf(cgiOut, "				 var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "				 objOption.value = '000';\n");
	fprintf(cgiOut, "				 objOption.text = '������';\n");
	fprintf(cgiOut, "				 document.getElementById(\"qx\").add(objOption);\n");
	*/
	fprintf(cgiOut, "				 var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "				 for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "				 {\n");
	fprintf(cgiOut, "				   var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "					 objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "					 objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "					 document.getElementById(\"qx\").add(objOption);\n");
	fprintf(cgiOut, "				 }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n"); 
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackForNetArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_NetArea.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_NetArea.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_NetArea.responseText;\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              document.getElementById(\"ykt_role\").options.length = 0;\n");
	fprintf(cgiOut, "							 var TempArray = returnValue.split(\";\");\n");
	/*
	fprintf(cgiOut, "							 var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "							 objOption.value = '6000';\n");
	fprintf(cgiOut, "							 objOption.text = '������';\n");
	fprintf(cgiOut, "							 document.getElementById(\"ykt_role\").add(objOption);\n");
	*/
	fprintf(cgiOut, "						   var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "						   for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "						   {\n");
	fprintf(cgiOut, "						      var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						      objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						      objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						      document.getElementById(\"ykt_role\").add(objOption);\n");
	fprintf(cgiOut, "						   }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackForHJArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_HJArea.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_HJArea.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_HJArea.responseText;\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              document.getElementById(\"hj_role\").options.length = 0;\n");
	fprintf(cgiOut, "							 var TempArray = returnValue.split(\";\");\n");
	/*
	fprintf(cgiOut, "							 var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "							 objOption.value = '7000';\n");
	fprintf(cgiOut, "							 objOption.text = '������';\n");
	fprintf(cgiOut, "							 document.getElementById(\"hj_role\").add(objOption);\n");
	*/
	fprintf(cgiOut, "						   var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "						   for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "						   {\n");
	fprintf(cgiOut, "						      var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						      objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						      objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						      document.getElementById(\"hj_role\").add(objOption);\n");
	fprintf(cgiOut, "						   }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackForCtrlArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_CtrlArea.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_CtrlArea.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_CtrlArea.responseText;\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              document.getElementById(\"ctrl_role\").options.length = 0;\n");
	fprintf(cgiOut, "							 var TempArray = returnValue.split(\";\");\n");
	/*
	fprintf(cgiOut, "							 var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "							 objOption.value = '8000';\n");
	fprintf(cgiOut, "							 objOption.text = '������';\n");
	fprintf(cgiOut, "							 document.getElementById(\"ctrl_role\").add(objOption);\n");
	*/
	fprintf(cgiOut, "						   var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "						   for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "						   {\n");
	fprintf(cgiOut, "						      var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						      objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						      objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						      document.getElementById(\"ctrl_role\").add(objOption);\n");
	fprintf(cgiOut, "						   }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackForSPArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_SPArea.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_SPArea.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_SPArea.responseText;\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              document.getElementById(\"sp_role\").options.length = 0;\n");
	fprintf(cgiOut, "							 var TempArray = returnValue.split(\";\");\n");
	/*
	fprintf(cgiOut, "							 var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "							 objOption.value = '9000';\n");
	fprintf(cgiOut, "							 objOption.text = '������';\n");
	fprintf(cgiOut, "							 document.getElementById(\"sp_role\").add(objOption);\n");
	*/
	fprintf(cgiOut, "						   var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "						   for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "						   {\n");
	fprintf(cgiOut, "						      var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						      objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						      objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						      document.getElementById(\"sp_role\").add(objOption);\n");
	fprintf(cgiOut, "						   }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</html>\n");
}

void SingleQuery()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title></title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style=\"background:#CADFFF\" onload=\"doAuto()\">\n");
	fprintf(cgiOut, "<form name=\"User_Add\" action=\"user_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/cap_user_info.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"60%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right'>\n");
	fprintf(cgiOut, "		   <img style=\"cursor:hand\" onClick=\"doSubmit()\" src=\"../../skin/images/mini_button_submit.gif\">\n");
	fprintf(cgiOut, "			 <img style=\"cursor:hand\" onClick=\"doPwdReset()\" src=\"../../skin/images/mini_button_pwd_reset.gif\">\n");
	fprintf(cgiOut, "			 <img style=\"cursor:hand\" onClick=\"doCancel()\" src=\"../../skin/images/button10.gif\">\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "	 </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<table width=\"60%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "	 <td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "	 <td width=\"35%%\">%s<input type=\"hidden\" name=\"id\" style=\"width:120px;height:20px;\" maxlength=\"10\" value=\"%s\" readonly></td>\n", id, id);
	fprintf(cgiOut, "	 <td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "	 <td width=\"35%%\">\n");
	fprintf(cgiOut, "	   <select name='dept_id' id='dept_id' style='width:120px;height:20px'>\n");
	
	int rc;
	char * zErrMsg = 0;
	//�����ݿ�
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(2), &sqlite3_exec_callback_agent, dept_id, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	
	fprintf(cgiOut, "				 				</select>\n");
	fprintf(cgiOut, "				 			</td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	
	fprintf(cgiOut, "					 	<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\"><input type=\"text\" name=\"cname\" style=\"width:120px;height:20px;\"  maxlength=\"5\" value=\"%s\"></td>\n", cname);
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "							<td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select name=\"sex\" style=\"width:120px;height:20px\">	\n");
	if(0 == strcmp(sex, "0"))
	{
		fprintf(cgiOut, "					      	 <option value=\"0\" selected>��</option><option value=\"1\">Ů</option>\n");
	}
	else
	{
		fprintf(cgiOut, "					      	 <option value=\"0\" >��</option><option value=\"1\" selected>Ů</option>\n");
	}
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "				 			</td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\"><input type=\"text\" name=\"tel\" style=\"width:120px;height:20px;\" maxlength=\"13\" value=\"%s\"></td>\n", tel);
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��������</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\"><input type=\"text\" name=\"birthday\" onClick=\"WdatePicker({readOnly:true})\" class=\"Wdate\" size=\"10\" maxlength=\"10\" value=\"%s\" style='width:120px;'></td>\n", birthday);
	fprintf(cgiOut, "				 		</tr>\n");

	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ַ</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\"><input type=\"text\" name=\"addr\" style=\"width:120px;height:20px;\" maxlength=\"60\" value=\"%s\"></td>\n", addr);
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select name=\"status\" style=\"width:120px;height:20px\">\n");
	if(0 == strcmp(status, "0"))
	{
		fprintf(cgiOut, "					      	 <option value=\"0\" selected>����</option><option value=\"1\">ע��</option>\n");
	}
	else
	{
		fprintf(cgiOut, "					      	 <option value=\"0\" >����</option><option value=\"1\" selected>ע��</option>\n");
	}
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">����Ȩ��</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select id=\"qx\" name=\"qx\" style=\"width:120px;height:20px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��Ԫ����</td>\n");
	fprintf(cgiOut, "							<td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select id=\"ykt_role\" name=\"ykt_role\" style=\"width:120px;height:20px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	
	fprintf(cgiOut, "				 		<tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">���ݷ���</td>\n");
	fprintf(cgiOut, "							<td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select id=\"hj_role\" name=\"hj_role\" style=\"width:120px;height:20px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "					 		<td width=\"15%%\" valign=\"middle\" align=\"center\">��Ƶ����</td>\n");
	fprintf(cgiOut, "					    <td width=\"35%%\">\n");
	fprintf(cgiOut, "					      <select id=\"sp_role\" name=\"sp_role\" style=\"width:120px;height:20px\">\n");
	fprintf(cgiOut, "					      </select>\n");
	fprintf(cgiOut, "					    </td>\n");
	fprintf(cgiOut, "				 		</tr>\n");
	fprintf(cgiOut, "				</table>\n");
	fprintf(cgiOut, "		 </div>\n");
	fprintf(cgiOut, "	</div>\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "</center>\n");
	fprintf(cgiOut, "<input type=\"hidden\" name=\"cmd\" value=\"11\">\n");
	fprintf(cgiOut, "<input type=\"hidden\" name=\"role1\" value=\"%s\">\n", sp_role);
	fprintf(cgiOut, "<input type=\"hidden\" name=\"role2\" value=\"%s\">\n", hj_role);
	fprintf(cgiOut, "<input type=\"hidden\" name=\"role3\" value=\"%s\">\n", ykt_role);
	fprintf(cgiOut, "<input type=\"hidden\" name=\"role4\" value=\"%s\">\n", qx);
	fprintf(cgiOut, "<input type=\"hidden\" name=\"role5\" value=\"%s\">\n", ctrl_role);
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "	\n");
	fprintf(cgiOut, "function doAuto()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	doFPRole();\n");
	fprintf(cgiOut, "	doNetArea();\n");
	fprintf(cgiOut, "	doHJArea();\n");
	//fprintf(cgiOut, "	doCtrlArea();\n");
	fprintf(cgiOut, "	doSPArea();\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function doPwdReset()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "if(confirm('ȷ����������?')){\n");
	fprintf(cgiOut, "	 m_Pwd = createXHR();\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "   if(m_Pwd)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_Pwd.onreadystatechange=callbackForPwdReset;\n");
	fprintf(cgiOut, "      var url = \"user_info.cgi?cmd=14&newpwd=111111&id=%s&currtime=\"+new Date();\n", id);
	fprintf(cgiOut, "      m_Pwd.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_Pwd.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function doFPRole()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_FPRole = createXHR();\n");
	fprintf(cgiOut, "  if(m_FPRole)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "     m_FPRole.onreadystatechange=callbackForFPRole;\n");
	fprintf(cgiOut, "     var url = \"video_area.cgi?cmd=2&currtime=\"+new Date();\n");
	fprintf(cgiOut, "     m_FPRole.open(\"get\", url);\n");
	fprintf(cgiOut, "     m_FPRole.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "     alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doNetArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	  m_NetArea = createXHR();\n");
	fprintf(cgiOut, "   if(m_NetArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_NetArea.onreadystatechange=callbackForNetArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=60&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_NetArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_NetArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doHJArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	  m_HJArea = createXHR();\n");
	fprintf(cgiOut, "   if(m_HJArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_HJArea.onreadystatechange=callbackForHJArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=70&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_HJArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_HJArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doCtrlArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_CtrlArea = createXHR();\n");
	fprintf(cgiOut, "  if(m_CtrlArea)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    m_CtrlArea.onreadystatechange=callbackForCtrlArea;\n");
	fprintf(cgiOut, "    var url = \"video_area.cgi?cmd=1&id=80&currtime=\"+new Date();\n");
	fprintf(cgiOut, "    m_CtrlArea.open(\"get\", url);\n");
	fprintf(cgiOut, "    m_CtrlArea.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doSPArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	  m_SPArea = createXHR();\n");
	fprintf(cgiOut, "   if(m_SPArea)\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      m_SPArea.onreadystatechange=callbackForSPArea;\n");
	fprintf(cgiOut, "      var url = \"video_area.cgi?cmd=1&id=90&currtime=\"+new Date();\n");
	fprintf(cgiOut, "      m_SPArea.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_SPArea.send(null);\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "   else\n");
	fprintf(cgiOut, "   {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");	
	
	fprintf(cgiOut, "String.prototype.Trim = function()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  return this.replace(/(^\\s*)|(\\s*$)/g, '');\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "String.prototype.LTrim = function()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  return this.replace(/(^\\s*)/g, '');\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "String.prototype.RTrim = function()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  return this.replace(/(\\s*$)/g, '');\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var id = User_Add.id.value;\n");
	fprintf(cgiOut, "	 var cname = User_Add.cname.value;\n");
	fprintf(cgiOut, "	 var tel = User_Add.tel.value;\n");
	fprintf(cgiOut, "	 var sex = User_Add.sex.value;\n");
	fprintf(cgiOut, "	 var birthday = User_Add.birthday.value;\n");
	fprintf(cgiOut, "	 var status = User_Add.status.value;\n");
	fprintf(cgiOut, "	 var ykt_role = User_Add.ykt_role.value;\n");
	fprintf(cgiOut, "	 var hj_role = User_Add.hj_role.value;\n");
	fprintf(cgiOut, "	 var ctrl_role = '';\n");
	fprintf(cgiOut, "	 var sp_role = User_Add.sp_role.value;\n");
	fprintf(cgiOut, "	 var addr = User_Add.addr.value;\n");
	fprintf(cgiOut, "	 var qx = User_Add.qx.value;\n");
	fprintf(cgiOut, "	 var dept_id = User_Add.dept_id.value;\n");
	
	fprintf(cgiOut, "	 if(User_Add.id.value == null || User_Add.id.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�˺Ų���Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.cname.value == null || User_Add.cname.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"��������Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 \n");
	fprintf(cgiOut, "	 if(User_Add.dept_id.value == null || User_Add.dept_id.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"��ѡ����!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.tel.value == null || User_Add.tel.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�绰����Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.birthday.value == null || User_Add.birthday.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�������ڲ���Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.addr.value == null || User_Add.addr.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"��ַ����Ϊ��!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.qx.value == null || User_Add.qx.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�븳�赱ǰ�ʺŹ���Ȩ�޽�ɫ!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.ykt_role.value == null || User_Add.ykt_role.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�븳�赱ǰ�ʺ���Ԫ������ɫ!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.hj_role.value == null || User_Add.hj_role.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�븳�赱ǰ�ʺ����ݷ�����ɫ!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(User_Add.sp_role.value == null || User_Add.sp_role.value.Trim().length < 1)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	    alert(\"�븳�赱ǰ�ʺ���Ƶ������ɫ!\");\n");
	fprintf(cgiOut, "	    return;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 if(confirm(\"ȷ�ϱ༭?\"))\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	 	var currURL = \"user_info.cgi?cmd=11&id=\"+id+\"&cname=\"+cname+\"&tel=\"+tel+\"&sex=\"+sex+\"&birthday=\"+birthday+\"&status=\"+status+'&ykt_role='+ykt_role+\"&sp_role=\"+sp_role+\"&hj_role=\"+hj_role+'&ctrl_role='+ctrl_role+\"&addr=\"+addr+'&qx='+qx+'&dept_id='+dept_id+'&func_id=%s';\n", func_id);
	fprintf(cgiOut, "	    location = currURL;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, " \n");
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{ \n");
	fprintf(cgiOut, "	 location = \"user_info.cgi?cmd=0&func_id=%s\";\n", func_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "/*\n");
	fprintf(cgiOut, " *�����첽���ʶ���\n");
	fprintf(cgiOut, " */\n");
	fprintf(cgiOut, "function createXHR() \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    var xhr;\n");
	fprintf(cgiOut, "    try \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        xhr = new ActiveXObject(\"Msxml2.XMLHTTP\");\n");
	fprintf(cgiOut, "    } \n");
	fprintf(cgiOut, "    catch (e) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        try \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            xhr = new ActiveXObject(\"Microsoft.XMLHTTP\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        catch(E) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            xhr = false;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "    if (!xhr && typeof XMLHttpRequest != 'undefined') \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        xhr = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "    return xhr;\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "/*\n");
	fprintf(cgiOut, " *�첽�ص���������\n");
	fprintf(cgiOut, " */\n");
	fprintf(cgiOut, "function callbackForFPRole()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(m_FPRole.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "  	 if(m_FPRole.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var returnValue = m_FPRole.responseText;\n");
	fprintf(cgiOut, "      if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById(\"qx\").options.length = 0;\n");
	/*
	fprintf(cgiOut, "				 var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "				 objOption.value = '000';\n");
	fprintf(cgiOut, "				 objOption.text = '������';\n");
	fprintf(cgiOut, "				 document.getElementById(\"qx\").add(objOption);\n");
	fprintf(cgiOut, "				 if(User_Add.role4.value == '000'){objOption.selected = true;}\n");
	*/
	fprintf(cgiOut, "				 var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "				 for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "				 {\n");
	fprintf(cgiOut, "				   var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "					 if(User_Add.role4.value == TempArray[i].split(\",\")[0]){objOption.selected = true;}\n");
	fprintf(cgiOut, "					 objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "					 objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "					 document.getElementById(\"qx\").add(objOption);\n");
	fprintf(cgiOut, "				 }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n"); 
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackForNetArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(m_NetArea.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(m_NetArea.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "       var returnValue = m_NetArea.responseText;\n");
	fprintf(cgiOut, "       if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "       {\n");
	fprintf(cgiOut, "         document.getElementById(\"ykt_role\").options.length = 0;\n");
	/*
	fprintf(cgiOut, "					var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "					objOption.value = '6000';\n");
	fprintf(cgiOut, "					objOption.text = '������';\n");
	fprintf(cgiOut, "					document.getElementById(\"ykt_role\").add(objOption);\n");
	fprintf(cgiOut, "				  if(User_Add.role2.value == '6000'){objOption.selected = true;}\n");
	*/
	fprintf(cgiOut, "				  var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "					for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "					{\n");
	fprintf(cgiOut, "					  var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						if(User_Add.role3.value == TempArray[i].split(\",\")[0]){objOption.selected = true;}\n");
	fprintf(cgiOut, "						objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						document.getElementById(\"ykt_role\").add(objOption);\n");
	fprintf(cgiOut, "					}\n");
	fprintf(cgiOut, "       }\n");
	fprintf(cgiOut, "       else\n");
	fprintf(cgiOut, "       {\n");
	fprintf(cgiOut, "       }\n");
	fprintf(cgiOut, "     }\n");
	fprintf(cgiOut, "     else \n");
	fprintf(cgiOut, "     {\n");
	fprintf(cgiOut, "       alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "     }\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackForHJArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(m_HJArea.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(m_HJArea.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "       var returnValue = m_HJArea.responseText;\n");
	fprintf(cgiOut, "       if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "       {\n");
	fprintf(cgiOut, "         document.getElementById(\"hj_role\").options.length = 0;\n");
	/*
	fprintf(cgiOut, "					var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "					objOption.value = '7000';\n");
	fprintf(cgiOut, "					objOption.text = '������';\n");
	fprintf(cgiOut, "					document.getElementById(\"hj_role\").add(objOption);\n");
	fprintf(cgiOut, "				  if(User_Add.role2.value == '7000'){objOption.selected = true;}\n");
	*/
	fprintf(cgiOut, "				  var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "					for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "					{\n");
	fprintf(cgiOut, "					  var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "						if(User_Add.role2.value == TempArray[i].split(\",\")[0]){objOption.selected = true;}\n");
	fprintf(cgiOut, "						objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "						objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "						document.getElementById(\"hj_role\").add(objOption);\n");
	fprintf(cgiOut, "					}\n");
	fprintf(cgiOut, "       }\n");
	fprintf(cgiOut, "       else\n");
	fprintf(cgiOut, "       {\n");
	fprintf(cgiOut, "       }\n");
	fprintf(cgiOut, "     }\n");
	fprintf(cgiOut, "     else \n");
	fprintf(cgiOut, "     {\n");
	fprintf(cgiOut, "       alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "     }\n");
	fprintf(cgiOut, "   }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function callbackForCtrlArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(m_CtrlArea.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(m_CtrlArea.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var returnValue = m_CtrlArea.responseText;\n");
	fprintf(cgiOut, "      if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById(\"ctrl_role\").options.length = 0;\n");
	/*
	fprintf(cgiOut, "				 var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "				 objOption.value = '8000';\n");
	fprintf(cgiOut, "				 objOption.text = '������';\n");
	fprintf(cgiOut, "				 document.getElementById(\"ctrl_role\").add(objOption);\n");
	fprintf(cgiOut, "				 if(User_Add.role5.value == '8000'){objOption.selected = true;}\n");
	*/
	fprintf(cgiOut, "				 var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "				 for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "				 {\n");
	fprintf(cgiOut, "				   var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "					 if(User_Add.role5.value == TempArray[i].split(\",\")[0]){objOption.selected = true;}\n");
	fprintf(cgiOut, "					 objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "					 objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "					 document.getElementById(\"ctrl_role\").add(objOption);\n");
	fprintf(cgiOut, "				 }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackForSPArea()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(m_SPArea.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(m_SPArea.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var returnValue = m_SPArea.responseText;\n");
	fprintf(cgiOut, "      if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById(\"sp_role\").options.length = 0;\n");
	/*
	fprintf(cgiOut, "				 var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "				 objOption.value = '9000';\n");
	fprintf(cgiOut, "				 objOption.text = '������';\n");
	fprintf(cgiOut, "				 document.getElementById(\"sp_role\").add(objOption);\n");
	fprintf(cgiOut, "				 if(User_Add.role1.value == '9000'){objOption.selected = true;}\n");
	*/
	fprintf(cgiOut, "				 var TempArray = returnValue.split(\";\");\n");
	fprintf(cgiOut, "				 for(i=0; i<TempArray.length-1; i++)\n");
	fprintf(cgiOut, "				 {\n");
	fprintf(cgiOut, "				   var objOption = document.createElement(\"OPTION\");\n");
	fprintf(cgiOut, "					 if(User_Add.role1.value == TempArray[i].split(\",\")[0]){objOption.selected = true;}\n");
	fprintf(cgiOut, "					 objOption.value = TempArray[i].split(\",\")[0];\n");
	fprintf(cgiOut, "					 objOption.text = TempArray[i].split(\",\")[1];\n");
	fprintf(cgiOut, "					 document.getElementById(\"sp_role\").add(objOption);\n");
	fprintf(cgiOut, "				 }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function callbackForPwdReset()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "    if (m_Pwd.readyState == 4) \n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "        if (m_Pwd.status == 200) \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            var returnValue = m_Pwd.responseText;\n");
	fprintf(cgiOut, "\n");
	fprintf(cgiOut, "            if(returnValue != null && returnValue.length > 0)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "            alert(returnValue);\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "            else\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "               \n"); 
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "        } \n");
	fprintf(cgiOut, "        else \n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "            alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</html>\n");
}
void AddData()
{
  int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	rc = sqlite3_exec(db, getSql(20), &sqlite3_exec_callback_add, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	if(0 == cnt)
	{
		//�����û���
		char sql[256] = {0};
		strcat(sql, "select maxrecodecnt01 from config");
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cntall, 0, &zErrMsg);
		if(NULL == cntAll || 0 == strlen(cntAll))
		{
			memcpy(cntAll, "50", 9);//��ȡ����ֵĬ��50
		}
		
		//�����û���
		memset(sql, 0, sizeof(sql));
		strcat(sql, "select count(*) from user_info where id <> 'system' and id <> 'admin' and status = '0'");
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cntnow, 0, &zErrMsg);
		if(NULL == cntNow || 0 == strlen(cntNow))
		{
			memcpy(cntNow, "0", 9);//��ȡ����ֵĬ��0
		}
		
		if(atoi(cntNow) < atoi(cntAll))
		{
			//����ϵͳ���
			memset(sql, 0, sizeof(sql));
			strcat(sql, "select max(t.sys_id)+1 from user_info t");
			rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_sysid, 0, &zErrMsg);
			if(rc!=SQLITE_OK)
			{
				err_msg(1);
			}
			
			//�����û�
			rc = sqlite3_exec(db, getSql(10), &sqlite3_exec_callback, 0, &zErrMsg);
			if(rc!=SQLITE_OK)
			{
				err_msg(1);
			}
		}
		else
		{
			fprintf(cgiOut, "<script language='javascript'>alert('ʧ��,���õ��û�������Ϊ%s��!');</script>\n", cntAll);
		}
	}
	else
	{
		fprintf(cgiOut, "<script language='javascript'>alert('ʧ��,���ʺ��Ѵ���!');</script>\n");
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_sysid(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL == col_values[0] || strlen(col_values[0]) == 0)
	{
		strcat(sys_id, "0001");
	}
	else
	{
		strcat(sys_id, StrLeftFillZero(col_values[0], 4));
	}
	return 0;
}

int sqlite3_exec_callback_cntall(void *data, int n_columns, char **col_values, char **col_names)
{
	memset(cntAll, 0, sizeof(cntAll));
	memcpy(cntAll, col_values[0], 9);
	return 0;
}

int sqlite3_exec_callback_cntnow(void *data, int n_columns, char **col_values, char **col_names)
{
	memset(cntNow, 0, sizeof(cntNow));
	memcpy(cntNow, col_values[0], 9);
	return 0;
}

int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

int UpdateData()
{
  int ret = 1;
  int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char * sql = getSql(atoi(cmd));
	
	if(11 == atoi(cmd) && 0 == strcmp(status, "0"))
	{
		//�����û���
		char cursql[256] = {0};
		strcat(cursql, "select maxrecodecnt01 from config");
		rc = sqlite3_exec(db, cursql, &sqlite3_exec_callback_cntall, 0, &zErrMsg);
		if(NULL == cntAll || 0 == strlen(cntAll))
		{
			memcpy(cntAll, "50", 9);//��ȡ����ֵĬ��50
		}
		
		//�����û���
		memset(cursql, 0, sizeof(cursql));
		strcat(cursql, "select count(*) from user_info where id <> 'system' and id <> 'admin' and status = '0'");
		rc = sqlite3_exec(db, cursql, &sqlite3_exec_callback_cntnow, 0, &zErrMsg);
		if(NULL == cntNow || 0 == strlen(cntNow))
		{
			memcpy(cntNow, "0", 9);//��ȡ����ֵĬ��0
		}
		if(atoi(cntNow) < atoi(cntAll))
		{
			rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
			if(rc != SQLITE_OK)
			{
				err_msg(1);
			}
		}
		else
		{
			fprintf(cgiOut, "<script language='javascript'>alert('ʧ��,���õ��û�������Ϊ%s��!');</script>\n", cntAll);
		}
	}
	else
	{
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(1);
		}
	}
	
	sqlite3_close(db);
  return ret;
}

static void SingleValidate()
{
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(1);
	
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_validate, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_validate(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

void CardManger()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title></title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/My97DatePicker/WdatePicker.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body style=\"background:#CADFFF\" onload='devInit();'>\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "	 <div id=\"cap\"><img src=\"../../skin/images/kahaoguanli.gif\"/></div><br>\n");
	fprintf(cgiOut, "	 <div id=\"right_table_center\">\n");
	fprintf(cgiOut, "    <form name=\"CardManger\" action=\"user_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "	   <table width=\"60%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "		   <tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "			   <td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "				   <td width=\"35%%\">%s</td>\n", cname);
	fprintf(cgiOut, "					 <td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "					 <td width=\"35%%\">%s</td>\n", deptname);
	fprintf(cgiOut, "				 </tr>\n");
	fprintf(cgiOut, "				 <tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "				   <td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "					 <td width=\"35%%\">%s</td>\n", sex);
	fprintf(cgiOut, "					 <td width=\"15%%\" valign=\"middle\" align=\"center\">��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "					 <td width=\"35%%\">%s</td>\n", tel);
	fprintf(cgiOut, "				 </tr>\n");	
	fprintf(cgiOut, "				 <tr height=\"90\" valign=\"middle\">\n");
	fprintf(cgiOut, "				   <td width=\"15%%\" valign=\"middle\" align=\"center\">\n");
	fprintf(cgiOut, "				 	   <table width='100%%' style='margin:auto' border=0 cellPadding=0 cellSpacing=0  bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "				 		   <tr>\n");
	fprintf(cgiOut, "				 		     <td width='100%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "				 		   </tr>\n");
	fprintf(cgiOut, "				 		   <tr>\n");
	fprintf(cgiOut, "				 		     <td width='100%%' align='center'>(�Ѱ�)</td>\n");
	fprintf(cgiOut, "				 		   </tr>\n");
	fprintf(cgiOut, "				 		 </table>\n");
	fprintf(cgiOut, "				 	 </td>\n");
	fprintf(cgiOut, "					 <td width=\"85%%\" colspan=3 valign='top'>\n");
	fprintf(cgiOut, "				 	   <table width='100%%' border=0 cellPadding=0 cellSpacing=0  bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "				 		   <tr>\n");
	fprintf(cgiOut, "				 		     <td width='40%%' align='left'><input type='checkbox' name='All' id = 'All' value='0' onClick='selectAll()'/>ȫѡ</td>\n");
	fprintf(cgiOut, "				 		  	 <td width='20%%' align='left'>����</td>\n");
	fprintf(cgiOut, "				 		  	 <td width='40%%' align='left'>״̬</td>\n");
	fprintf(cgiOut, "				 		   </tr>\n");
	
	int rc;
	char * zErrMsg = 0;
	//�����ݿ�
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(3), &sqlite3_exec_callback_card, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	
	fprintf(cgiOut, "				 		 </table>\n");
	fprintf(cgiOut, "				 	 </td>\n");
	fprintf(cgiOut, "				 </tr>\n");	
	fprintf(cgiOut, "				 <tr height=\"30\" valign=\"middle\">\n");
	fprintf(cgiOut, "				   <td width=\"100%%\" colspan=4 align='center'>\n");
	//fprintf(cgiOut, "			  	   <img style=\"cursor:hand\" onClick=\"doLockCard()\" src=\"../../skin/images/guashi.gif\">\n");
	//fprintf(cgiOut, "			  		 <img style=\"cursor:hand\" onClick=\"doOpCard()\"   src=\"../../skin/images/jiegua.gif\">\n");
	fprintf(cgiOut, "			  		 <img style=\"cursor:hand\" onClick=\"doDel()\"      src=\"../../skin/images/shanchu.gif\">\n");
	fprintf(cgiOut, "			  		 <img style=\"cursor:hand\" onClick=\"doCancel()\"   src=\"../../skin/images/button10.gif\">\n");
	fprintf(cgiOut, "				 	 </td>\n");
	fprintf(cgiOut, "				 </tr>\n");
	fprintf(cgiOut, "			 </table><br><br>\n");
	fprintf(cgiOut, "      <input type=\"hidden\" name=\"cmd\" value=\"0\">\n");
	fprintf(cgiOut, "      <input type=\"hidden\" name=\"ic\" value=\"\">\n");
	fprintf(cgiOut, "      </form>\n");
	fprintf(cgiOut, "		 </div>\n");	
	
	fprintf(cgiOut, "    <div style=\"text-align:center\">\n");
	fprintf(cgiOut, "		   <img style=\"cursor:hand\" onClick=\"doMFAdd()\"    src=\"../../skin/images/add_ic.gif\">\n");
	fprintf(cgiOut, "			 <img style=\"cursor:hand\" onClick=\"doIDAdd()\"    src=\"../../skin/images/add_id.gif\">\n");
	fprintf(cgiOut, "		 </div>\n");
	
	fprintf(cgiOut, "	   <div id='right_table_center'>\n");
 	fprintf(cgiOut, "	 		 <table style='display:none;margin:auto;' id='Card1' width='60%%' border=1 cellPadding=0 cellSpacing=0 bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "	       <tr height='30px' valign='middle'>\n");
	fprintf(cgiOut, "		       <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "			 		 <td width='85%%' align='center'>\n");
	fprintf(cgiOut, "				     <table width='100%%' style='margin:auto' border=0 cellPadding=0 cellSpacing=0  bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "					     <tr height='30px'>\n");
	fprintf(cgiOut, "						     <td width=70%% align=left><object style='width:98%%;height:25px' id='rf_ocx' codebase='../../cab/card_v1.cab#version=1,0,0,8' classid='clsid:0CCC6C3A-1F60-4610-AA5C-03F3B17CBCBC'></object></td>\n");
	fprintf(cgiOut, "						     <td width=10%% align=center><input type='button' style='width:65px;height:25px' value='��ȡ�豸' onClick='devGet()'></td>\n");
	fprintf(cgiOut, "						     <td width=10%% align=center><input type='button' style='width:65px;height:25px' value='����ʼ��' onClick='doOpenCard()'></td>\n");
	fprintf(cgiOut, "						     <td width=10%% align=center><input type='button' style='width:65px;height:25px' value='������'   onClick='doReturnCard()'></td>\n");
	fprintf(cgiOut, "					     </tr>\n");
	fprintf(cgiOut, "				     </table>\n");	
	fprintf(cgiOut, "			     </td>\n");		    	
	fprintf(cgiOut, "		     </tr>\n");
	fprintf(cgiOut, "	     </table>\n");	
	fprintf(cgiOut, "      <form name=\"CardAdd\" action=\"user_info.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "	     <table width='60%%' style='margin:auto' border=1 cellPadding=0 cellSpacing=0  bordercolor='#3491D6' borderColorDark='#ffffff'>\n");
	fprintf(cgiOut, "	 	     <tr height='30px' valign='middle' style='display:none;' id='Card2'>\n");
	fprintf(cgiOut, "			     <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "			     <td width='85%%' align='left'>\n");
	fprintf(cgiOut, "				     <input type='text' style='width:100%%';height:30px' value='' name='ic' maxlength=16>\n");	
	fprintf(cgiOut, "			     </td>\n");
	fprintf(cgiOut, "		     </tr>\n");
	fprintf(cgiOut, "		     <tr height='30px' valign='middle' style='display:none;' id='Card3'>\n");
	fprintf(cgiOut, "			     <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "			     <td width='85%%' align='left' id='Card5'>&nbsp</td>\n");
	fprintf(cgiOut, "		     </tr>\n");
	fprintf(cgiOut, "		     <tr height='30px' valign='middle' style='display:none;' id='Card4'>\n");
	fprintf(cgiOut, "			     <td width='100%%' align='center' colspan=2>\n");
	fprintf(cgiOut, "			       <img style=\"cursor:hand\" onClick='doAdd()'       src=\"../../skin/images/open_card.gif\">\n");
	fprintf(cgiOut, "			       <img style=\"cursor:hand\" onClick='doHidden()'    src=\"../../skin/images/open_back.gif\">\n");
	fprintf(cgiOut, "			     </td>\n");
	fprintf(cgiOut, "		     </tr>\n");
	fprintf(cgiOut, "	     </table>\n");
	fprintf(cgiOut, "      <input name='add_ic' type='hidden' value=''>\n");
	fprintf(cgiOut, "      <input name='ctype' type='hidden' value=''>\n");
	fprintf(cgiOut, "      </form>\n");
	fprintf(cgiOut, "    </div>\n");	
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function selectAll()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	for(var i=0; i<%d; i++)\n", cnt);
	fprintf(cgiOut, "	{\n");
	fprintf(cgiOut, "		var Name = 'cbx' + Number(i).toString();\n");
	fprintf(cgiOut, "		document.getElementById(Name).checked = CardManger.All.checked;\n");
	fprintf(cgiOut, "	}\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function doLockCard()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	var Cds  = '';\n");
	fprintf(cgiOut, "	var tag  = 0;\n");
	fprintf(cgiOut, "	for(var i=0; i<%d; i++)\n", cnt);
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, " 	var Name = 'cbx' + Number(i).toString();\n");
	fprintf(cgiOut, " 	var Sim_Num = document.getElementById(Name).value;\n");
	fprintf(cgiOut, "   if(document.getElementById(Name).checked)\n");
	fprintf(cgiOut, " 	{\n");
	fprintf(cgiOut, " 		tag++;\n");
	fprintf(cgiOut, " 		if(tag == 1)\n");
	fprintf(cgiOut, " 		{\n");
	fprintf(cgiOut, " 			Cds = Sim_Num;\n");
	fprintf(cgiOut, " 		}\n");
	fprintf(cgiOut, " 		else\n");
	fprintf(cgiOut, " 		{\n");
	fprintf(cgiOut, " 			Cds = Cds + ',' + Sim_Num;\n");
	fprintf(cgiOut, " 		}\n");
	fprintf(cgiOut, " 	}\n");
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, " if(tag == 0)\n");
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, " 	alert('��ѡ��Ҫ��ʧ�Ŀ���!');\n");
	fprintf(cgiOut, " 	return;\n");
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, " if(tag > 20)\n");
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, " 	alert('�������û�������20λ����!');\n");
	fprintf(cgiOut, " 	return;\n");
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, " if(confirm('��ȷ��Ҫ��ʧѡ�еĿ���?'))\n");
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, "		location = 'user_info.cgi?cmd=4&id=%s&sys_id=%s&cname=%s&sex=%s&tel=%s&deptname=%s&func_id=%s&ics='+Cds+'&acttype=2';\n", id, sys_id, cname, sex, tel, deptname, func_id);
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, "} \n");
	
	fprintf(cgiOut, "function doOpCard()\n");
	fprintf(cgiOut, "{ \n");
	fprintf(cgiOut, "	var Cds  = '';\n");
	fprintf(cgiOut, "	var tag  = 0;\n");
	fprintf(cgiOut, "	for(var i=0; i<%d; i++)\n", cnt);
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, " 	var Name = 'cbx' + Number(i).toString();\n");
	fprintf(cgiOut, " 	var Sim_Num = document.getElementById(Name).value;\n");
	fprintf(cgiOut, "   if(document.getElementById(Name).checked)\n");
	fprintf(cgiOut, " 	{\n");
	fprintf(cgiOut, " 		tag++;\n");
	fprintf(cgiOut, " 		if(tag == 1)\n");
	fprintf(cgiOut, " 		{\n");
	fprintf(cgiOut, " 			Cds = Sim_Num;\n");
	fprintf(cgiOut, " 		}\n");
	fprintf(cgiOut, " 		else\n");
	fprintf(cgiOut, " 		{\n");
	fprintf(cgiOut, " 			Cds = Cds + ',' + Sim_Num;\n");
	fprintf(cgiOut, " 		}\n");
	fprintf(cgiOut, " 	}\n");	
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, " if(tag == 0)\n");
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, " 	alert('��ѡ��Ҫ��ҵĿ���!');\n");
	fprintf(cgiOut, " 	return;\n");
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, " if(tag > 20)\n");
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, " 	alert('�������û�������20λ����!');\n");
	fprintf(cgiOut, " 	return;\n");
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, " if(confirm('��ȷ��Ҫ���ѡ�еĿ���?'))\n");
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, "		location = 'user_info.cgi?cmd=4&id=%s&sys_id=%s&cname=%s&sex=%s&tel=%s&deptname=%s&func_id=%s&ics='+Cds+'&acttype=3';\n", id, sys_id, cname, sex, tel, deptname, func_id);
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, "} \n");
	
	fprintf(cgiOut, "function doDel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	var Cds  = '';\n");
	fprintf(cgiOut, "	var tag  = 0;\n");
	fprintf(cgiOut, "	for(var i=0; i<%d; i++)\n", cnt);
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, " 	var Name = 'cbx' + Number(i).toString();\n");
	fprintf(cgiOut, " 	var Sim_Num = document.getElementById(Name).value;\n");
	fprintf(cgiOut, "   if(document.getElementById(Name).checked)\n");
	fprintf(cgiOut, " 	{\n");
	fprintf(cgiOut, " 		tag++;\n");
	fprintf(cgiOut, " 		if(tag == 1)\n");
	fprintf(cgiOut, " 		{\n");
	fprintf(cgiOut, " 			Cds = Sim_Num;\n");
	fprintf(cgiOut, " 		}\n");
	fprintf(cgiOut, " 		else\n");
	fprintf(cgiOut, " 		{\n");
	fprintf(cgiOut, " 			Cds = Cds + ',' + Sim_Num;\n");
	fprintf(cgiOut, " 		}\n");
	fprintf(cgiOut, " 	}\n");
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, " if(tag == 0)\n");
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, " 	alert('��ѡ��Ҫɾ���Ŀ���!');\n");
	fprintf(cgiOut, " 	return;\n");
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, " if(tag > 20)\n");
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, " 	alert('�������û�������20λ����!');\n");
	fprintf(cgiOut, " 	return;\n");
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, " if(confirm('��ȷ��Ҫɾ��ѡ�еĿ���?'))\n");
	fprintf(cgiOut, " {\n");
	fprintf(cgiOut, "		location = 'user_info.cgi?cmd=4&id=%s&sys_id=%s&cname=%s&sex=%s&tel=%s&deptname=%s&func_id=%s&ics='+Cds+'&acttype=4';\n", id, sys_id, cname, sex, tel, deptname, func_id);
	fprintf(cgiOut, " }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doMFAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	document.all.Card1.style.display = '';\n");
	fprintf(cgiOut, "	document.all.Card2.style.display = 'none';\n");
	fprintf(cgiOut, "	document.all.Card4.style.display = '';\n");
	fprintf(cgiOut, "	document.all.Card3.style.display = '';\n");
	fprintf(cgiOut, "	document.getElementById('Card5').innerText = 'MF��';\n");
	fprintf(cgiOut, "	CardAdd.ctype.value = '1';\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doIDAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	document.all.Card1.style.display = 'none';\n");
	fprintf(cgiOut, "	document.all.Card2.style.display = '';\n");
	fprintf(cgiOut, "	document.all.Card4.style.display = '';\n");
	fprintf(cgiOut, "	document.all.Card3.style.display = '';\n");
	fprintf(cgiOut, "	document.getElementById('Card5').innerText = 'ID��';\n");
	fprintf(cgiOut, "	CardAdd.ctype.value = '3';\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doHidden()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	document.all.Card1.style.display = 'none';\n");
	fprintf(cgiOut, "	document.all.Card2.style.display = 'none';\n");
	fprintf(cgiOut, "	document.all.Card4.style.display = 'none';\n");
	fprintf(cgiOut, "	document.all.Card3.style.display = 'none';\n");
	fprintf(cgiOut, "	document.getElementById('Card5').innerText = '';\n");
	fprintf(cgiOut, "	CardAdd.ctype.value = '';\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	if('3' == CardAdd.ctype.value)\n");
	fprintf(cgiOut, "	{\n");
	fprintf(cgiOut, "		if(CardAdd.ic.value.length < 1)\n");
	fprintf(cgiOut, "		{\n");
	fprintf(cgiOut, "			alert('�����뿨��');\n");
	fprintf(cgiOut, "			return;\n");
	fprintf(cgiOut, "		}\n");
	fprintf(cgiOut, "		var ic_type = CardAdd.ctype.value;\n");
	fprintf(cgiOut, "		var ic = CardAdd.ic.value;\n");
	fprintf(cgiOut, "	  var ics = CardAdd.ctype.value + ',' + CardAdd.ic.value;\n");
	fprintf(cgiOut, "	}\n");
	fprintf(cgiOut, "	else if('1' == CardAdd.ctype.value)\n");
	fprintf(cgiOut, "	{\n");
	fprintf(cgiOut, "		if(CardAdd.add_ic.value.length < 1)\n");
	fprintf(cgiOut, "		{\n");
	fprintf(cgiOut, "			alert('���ȡ����');\n");
	fprintf(cgiOut, "			return;\n");
	fprintf(cgiOut, "		}\n");
	fprintf(cgiOut, "		var ic_type = CardAdd.ctype.value;\n");
	fprintf(cgiOut, "		var ic = CardAdd.add_ic.value;\n");
	fprintf(cgiOut, "	  var ics = CardAdd.ctype.value + ',' + CardAdd.add_ic.value;\n");
	fprintf(cgiOut, "	}\n");
	
	fprintf(cgiOut, "	if(confirm('��ȷ��?'))\n");
	fprintf(cgiOut, "	{\n");
	fprintf(cgiOut, "		location = 'user_info.cgi?cmd=4&id=%s&sys_id=%s&cname=%s&sex=%s&tel=%s&deptname=%s&func_id=%s&acttype=1&ics='+ics+'&ic_type='+ic_type+'&ic='+ic;\n", id, sys_id, cname, sex, tel, deptname, func_id);
	fprintf(cgiOut, "	}\n");
	fprintf(cgiOut, "}\n");
	
	//ȡ��ҵ����
	char sql[128] = "select a.m1key from corp_info a";
	memset(m1key, 0, sizeof(m1key));
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_mikey, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	fprintf(cgiOut, "function devInit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var Comms = rf_ocx.OcxInit('', '%s', 2);\n", m1key);
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function devGet()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var ret = rf_ocx.OcxComSelect();\n");
	fprintf(cgiOut, "  if(ret)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ȡ�豸�ɹ�!');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function doOpenCard()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var curId = rf_ocx.OcxGetCurId();\n");
	
	fprintf(cgiOut, "  if(curId.length < 6)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����ʼ��ʧ�ܣ���ȷ�Ͽ������Ϳ�Ƭ������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var vstatus = curId.substr(0,4);\n");
	fprintf(cgiOut, "  if('0000' != vstatus)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  CardAdd.add_ic.value = curId.substr(5);\n");
	fprintf(cgiOut, "  var CardType = curId.substr(4, 1);\n");
	fprintf(cgiOut, "  var ret = rf_ocx.OcxCardOpen(CardAdd.add_ic.value, parseFloat(CardType), '%s');\n", sys_id);
	fprintf(cgiOut, "  if(16 == parseInt(ret))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�����ɹ�,����:' + CardAdd.add_ic.value);\n");
	fprintf(cgiOut, "    doAdd();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(0 == parseInt(ret))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����ʧ��,��ȷ���ǿտ�,�����Ի���պ�����');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(parseInt(ret) < 16 && parseInt(ret) >0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����ʼ��ʧ��,ֻ�ɹ���ʼ��'+parseInt(ret)+'������,���Ȼ���һ�¿��ٿ���!');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doReturnCard()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var curId = rf_ocx.OcxGetCurId();\n");
	fprintf(cgiOut, "  if(curId.length < 6)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('������ʧ�ܣ���ȷ�Ͽ������Ϳ�Ƭ������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var vstatus = curId.substr(0,4);\n");
	fprintf(cgiOut, "  if('0000' != vstatus)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var ic = curId.substr(5);\n");
	fprintf(cgiOut, "  var CardType = curId.substr(4, 1);\n");
	fprintf(cgiOut, "  var ret = rf_ocx.OcxCardReturn(ic, parseFloat(CardType));\n");
	fprintf(cgiOut, "  if(16 == parseInt(ret))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�ÿ����ǿտ�������:' + ic);\n");
	fprintf(cgiOut, "		 location = 'user_info.cgi?cmd=4&id=%s&sys_id=%s&cname=%s&sex=%s&tel=%s&deptname=%s&func_id=%s&ics='+ic+'&acttype=4';\n", id, sys_id, cname, sex, tel, deptname, func_id);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(0 == parseInt(ret))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('������ʧ�ܣ������Ի���ϵ����֧��!');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(parseInt(ret) < 16 && parseInt(ret) >0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('������ʧ��,ֻ�ɹ��ָ�'+parseInt(ret)+'���������������Ի���!');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 location = \"user_info.cgi?cmd=0&func_id=%s\";\n", func_id);
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</html>\n");
}

int sqlite3_exec_callback_mikey(void *data, int n_columns, char **col_values, char **col_names)
{
	memcpy(m1key, col_values[0], 385);
	return 0;
}

int sqlite3_exec_callback_card(void *data, int n_columns, char **col_values, char **col_names)
{
	char ctypename[10] = {0};
	char statusname[10] = {0};
	switch(atoi(col_values[1]))
	{
		case 1:
				strcat(ctypename, "M1��");
			break;
		case 2:
				strcat(ctypename, "RF-GM��");
			break;
		case 3:
				strcat(ctypename, "ID��");
			break;
		case 4:
				strcat(ctypename, "RF-ZT��");
			break;
		case 5:
				strcat(ctypename, "ָ�ƿ�");
			break;
	}
	switch(atoi(col_values[3]))
	{
		case 0:
				strcat(statusname, "����");
			break;
		case 1:
				strcat(statusname, "��ʧ");
			break;
		case 2:
				strcat(statusname, "ע��");
			break;
	}
	fprintf(cgiOut, "<tr>\n");
	fprintf(cgiOut, "	<td width='40%%' align='left'><input type='checkbox' name='cbx%d' id='cbx%d' value='%s'>%s</td>\n", cnt, cnt, col_values[4], col_values[4]);
	fprintf(cgiOut, "	<td width='20%%' align='left'>%s</td>\n", ctypename);
	fprintf(cgiOut, "	<td width='40%%' align='left'>%s</td>\n", statusname);
	fprintf(cgiOut, "</tr>\n");
	
	cnt++;
	return 0;
}

void CardExec()
{
	char *buffer;
	char *p;
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	switch(atoi(acttype))
	{
		case 1://����			
				rc = sqlite3_exec(db, getSql(4), &sqlite3_exec_callback_card, 0, &zErrMsg);
				if(rc != SQLITE_OK )
				{
				  err_msg(1);
				}
			break;
		case 4://ɾ��			
				buffer = strdup(ics);
				p = strtok(buffer, ",");
				while(NULL != p)
				{
					memset(ic, 0, sizeof(ic));
					memcpy(ic, p, 20);
					
					rc = sqlite3_exec(db, getSql(5), &sqlite3_exec_callback_card, 0, &zErrMsg);
					if(rc != SQLITE_OK )
					{
					  err_msg(1);
					}
				
					p = strtok(NULL, ",");
				}			
			break;
		case 2://��ʧ
		case 3://���		
				int ret = MsgSend(1);
				switch(ret)
				{
					case 0:
							fprintf(cgiOut, "<script language='javascript'>alert('ʧ��,�����²���');</script>\n");
						break;
					case 1:
							fprintf(cgiOut, "<script language='javascript'>alert('�ύ�ɹ�');</script>\n");
						break;
					case 2:
							fprintf(cgiOut, "<script language='javascript'>alert('�����ɹ�');</script>\n");
						break;
				}
			break;
	}
	sqlite3_close(db);
}

//�����߳�
int MsgSend(int flag)
{
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return 0;
	}
	
	//������װ
	BYTE outbuf[2048] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	int len = 0;
	switch(flag)
	{
		case 1:
				memcpy(pdata, "00009012", 8);
				memcpy(pdata+8, acttype, 2);
				memcpy(pdata+10, sys_id, 4);
				memcpy(pdata+14, ics, 512);
				len = MSGHDRLEN + 8 + 2 + 4 + 512;
			break;
	}
	
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	
	char *ip = getLocalIP();
	
	//����
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return 0;
	}
	
	pSock->SetCompletion();
		
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return 0;
	}
	
	char szBuf[512] = {0};
	if(true == pSock->IsPending(30000))
	{
	 	if((len = pSock->Recv(szBuf, 512)) <= 0) 
		{
			pSock->EndSocket();
			return 0;
		}
		
		//AddMsg((BYTE *)szBuf, 100);
		pMsgHdr = (PMsgHdr)szBuf;
		char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
		
		//���سɹ�
		if(0 == strcmp(pmsg, "0000"))
		{
			pSock->EndSocket();
			return 2;
		}	
		else if(0 == strcmp(pmsg, "3000"))
		{
			pSock->EndSocket();
			return 1;
		}	
		else
		{
			pSock->EndSocket();
			return 0;
		}
	}
	else
	{
		pSock->EndSocket();
		return 0;
	}
	
	//�ر�����
	pSock->EndSocket();
	return 0;
}
