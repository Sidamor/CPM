#include <stdio.h>
#include <cgic.h>
#include "sqlite3.h"
#include "session.h"
#include "util.h"
#include <string.h>
#include <stdlib.h>

//��������
char cmd[4] = {0};
char Sql[1024] = {0};
char id[10] = {0};
char cname[20] = {0};
char point[2048] = {0};

//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback_role(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_info(void *data, int n_columns, char **col_values, char **col_names);
//����
static void CmdData();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	switch(atoi(cmd))
	{
		case 10://����
		case 11://�޸�
		case 12://ɾ��
				CmdData();
			break;
		case 0://��ѯ
				QueryData();
			break;
	}
	
	return 0;
}

static void getHtmlData()
{
  cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("point", point, sizeof(point));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0://��ɫ
      strcat(Sql, "select t.id, t.cname, t.point from role t where length(t.id) = 3 order by t.id ");
			break;
		case 1://����
      strcat(Sql, "select t.id, t.cname from fp_info t where t.status = '0' order by t.id");
			break;
		case 10://����
			strcat(Sql, "insert into role(id, cname, point)values('");
			strcat(Sql, id);
			strcat(Sql, "', '");
			strcat(Sql, cname);
			strcat(Sql, "', '");
			strcat(Sql, point);
			strcat(Sql, "')");
			break;
		case 11://�޸�
			strcat(Sql, "update role set cname = '");
			strcat(Sql, cname);
			strcat(Sql, "', point = '");
			strcat(Sql, point);
			strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 12://ɾ��
			strcat(Sql, "delete from role where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
	}
	return Sql;
}

void CmdData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	rc = sqlite3_exec(db, getSql(atoi(cmd)), &sqlite3_exec_callback_role, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(2);
	}
	
	sqlite3_close(db);
	printf("0000\n");
}

void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>����Ȩ��</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<link rel=\"stylesheet\" href=\"../../skin/css/zTreeStyle.css\" type=\"text/css\">\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/jquery-1.4.2.js\"></script>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/jquery-ztree-2.5.js\"></script>\n");	
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"fp_role\" action=\"fp_role.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/fp_role.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"70%%\" style='margin:auto' cellpadding=\"0\" cellspacing=\"1\" border=\"0\">");
	fprintf(cgiOut, "  <tr height='30px'>");
	fprintf(cgiOut, "    <td width=100%% align=right>");
	fprintf(cgiOut, "      <img style=\"cursor:hand\" onClick=\"doSubmit()\" src=\"../../skin/images/mini_button_submit.gif\">\n");
	fprintf(cgiOut, "    </td>");
	fprintf(cgiOut, "  </tr>");
	fprintf(cgiOut, "  <tr height='30px'>");
	fprintf(cgiOut, "    <td width=100%% align=center>");	
	fprintf(cgiOut, "      <table cellpadding=\"0\" cellspacing=\"0\" border=\"1\" width=\"100%%\" bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">");
	fprintf(cgiOut, "        <tr valign=\"top\">\n");
	fprintf(cgiOut, "          <td width='50%%' align='center'>\n");
	fprintf(cgiOut, "	           <div class='zTreeDemoBackground' style='width:99%%;height:400px;border:0px solid #0068a6'><ul id=\"roleTree\" class=\"tree\"></ul></div>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "          <td width='50%%' align='center'>\n");
	fprintf(cgiOut, "	           <div class='zTreeDemoBackground' style='width:99%%;height:400px;border:0px solid #0068a6'><ul id=\"infoTree\" class=\"tree\"></ul></div>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>");
	fprintf(cgiOut, "  </tr>");
	fprintf(cgiOut, "</table>");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='id' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='cname' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='point' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "var zTree1, zTree2;\n");
	fprintf(cgiOut, "var setting_Tree1, setting_Tree2;\n");
	fprintf(cgiOut, "setting_Tree1 = {	\n");
	fprintf(cgiOut, "	editable: true,\n");
	fprintf(cgiOut, "	edit_renameBtn: setRenameBtn,\n");
	fprintf(cgiOut, "	edit_removeBtn: setRemoveBtn,\n");
	fprintf(cgiOut, "	keepParent: true,\n");	
	fprintf(cgiOut, "	addHoverDom: addHoverDom,\n");
	fprintf(cgiOut, "	removeHoverDom: removeHoverDom,\n");
	fprintf(cgiOut, "	callback:{click: zTreeOnClick, beforeRemove: zTreeBeforeDel}\n");
	fprintf(cgiOut, "};\n");
	fprintf(cgiOut, "setting_Tree2 = {\n");
	fprintf(cgiOut, " checkable : true\n");
	fprintf(cgiOut, "};\n");

	fprintf(cgiOut, "function addHoverDom(treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 removeHoverDom(treeId, treeNode); \n");
	fprintf(cgiOut, "	 var aObj = $(\"#\" + treeNode.tId + '_a'); \n");
	fprintf(cgiOut, "  if(0 == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "  		var editStr = \"<button type='button' class='diyBtn1' id='diyBtn_\" +treeNode.id+ \"' onfocus='this.blur();'></button>\";\n");
	fprintf(cgiOut, "  		aObj.append(editStr);\n");
	fprintf(cgiOut, "  		var btn = $(\"#diyBtn_\"+treeNode.id);\n");
	fprintf(cgiOut, "  		if(btn) btn.bind(\"click\", function(){addTreeNode(treeId, treeNode);});\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function removeHoverDom(treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(0 == treeNode.level || 1 == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "			$(\"#diyBtn_\"+treeNode.id).unbind().remove();\n");
	fprintf(cgiOut, "			$(\"#diyBtn_space_\" +treeNode.id).unbind().remove();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function setRenameBtn(treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	switch(treeNode.level)	\n");
	fprintf(cgiOut, "	{\n");
	fprintf(cgiOut, "	case 0:\n");
	fprintf(cgiOut, "		return false;\n");
	fprintf(cgiOut, "		break;\n");
	fprintf(cgiOut, "	case 1:\n");
	fprintf(cgiOut, "		return true;\n");
	fprintf(cgiOut, "		break;\n");
	fprintf(cgiOut, "	}\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function setRemoveBtn(treeNode)\n");
	fprintf(cgiOut, "{\n");	
	fprintf(cgiOut, "	 switch(treeNode.level)	\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "		 case 0:\n");
	fprintf(cgiOut, "		     return false;\n");
	fprintf(cgiOut, "			 break;\n");
	fprintf(cgiOut, "		 case 1:\n");
	fprintf(cgiOut, "				 return true;\n");
	fprintf(cgiOut, "			 break;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function zTreeBeforeDel(treeId, treeNode) \n");
	fprintf(cgiOut, "{ \n");
	fprintf(cgiOut, "  if(treeNode)\n");
	fprintf(cgiOut, "	 { \n");
	fprintf(cgiOut, "	   doDel(treeNode.value);\n");
	fprintf(cgiOut, "		 return true;\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function StrLeftFillZero(strData, len)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var str = strData;\n");
	fprintf(cgiOut, "  var FillLen = len - str.length;\n");
	fprintf(cgiOut, "  for(var i=0; i < FillLen; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    str = '0' + str;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  return str;\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function addTreeNode(treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 var parentNode = treeNode;\n");
	fprintf(cgiOut, "	 var newId = parseInt(parentNode.value + '00', 10);\n");
	fprintf(cgiOut, "	 for(var i in parentNode.nodes)\n");
	fprintf(cgiOut, "	 {\n");
  fprintf(cgiOut, "		 if(parseInt(parentNode.nodes[i].value, 10) > newId)\n");
  fprintf(cgiOut, "		 {\n");
  fprintf(cgiOut, "			 newId = parseInt(parentNode.nodes[i].value, 10);\n");
  fprintf(cgiOut, "		 }\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "	 var strNewId = StrLeftFillZero((newId + 1).toString(), 3);\n"); 
	fprintf(cgiOut, "  doAdd(strNewId, 'fq'+strNewId);\n");
	fprintf(cgiOut, "	 zTree1.addNodes(parentNode, [{name:'fq'+strNewId, value:strNewId, id:'', icon:'../../skin/images/root.png'}], false);	\n");	
	fprintf(cgiOut, "	 zTree1.refresh();\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doAdd(pId, pCName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_Add = createXHR();\n");
	fprintf(cgiOut, "  if(m_Add)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "     m_Add.onreadystatechange=callbackForAdd;\n");
	fprintf(cgiOut, "     var url = 'fp_role.cgi?cmd=10&id='+pId+'&cname='+pCName+'&currtime='+new Date();\n");
	fprintf(cgiOut, "     m_Add.open(\"get\", url);\n");
	fprintf(cgiOut, "     m_Add.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "     alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doDel(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 m_Del = createXHR();\n");
	fprintf(cgiOut, "  if(m_Del)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "     m_Del.onreadystatechange=callbackForDel;\n");
	fprintf(cgiOut, "     var url = 'fp_role.cgi?cmd=12&id='+pId+'&currtime='+new Date();\n");
	fprintf(cgiOut, "     m_Del.open(\"get\", url);\n");
	fprintf(cgiOut, "     m_Del.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "     alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function createXHR()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var xhr;\n");
	fprintf(cgiOut, "  try\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    xhr = new ActiveXObject(\"Msxml2.XMLHTTP\");\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  catch(e)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    try\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      xhr = new ActiveXObject(\"Microsoft.XMLHTTP\");\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    catch(E)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      xhr = false;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(!xhr && typeof XMLHttpRequest != 'undefined')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    xhr = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  return xhr;\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackForAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(m_Add.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "  	 if(m_Add.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var returnValue = m_Add.responseText;\n");
	fprintf(cgiOut, "      if(null != returnValue && returnValue == '0000')\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function callbackForDel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(m_Del.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "  	 if(m_Del.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var returnValue = m_Del.responseText;\n");
	fprintf(cgiOut, "      if(null != returnValue && returnValue == '0000')\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function zTreeOnClick(event, treeId, treeNode) \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if('0' == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    zTree2.checkAllNodes(false);\n");
	fprintf(cgiOut, "    fp_role.id.value = '';\n");
	fprintf(cgiOut, "    fp_role.cname.value = '';\n");
	fprintf(cgiOut, "    fp_role.point.value = '';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if('1' == treeNode.level)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    fp_role.id.value = treeNode.value;\n");
	fprintf(cgiOut, "    fp_role.cname.value = treeNode.name;\n");
	fprintf(cgiOut, "    fp_role.point.value = treeNode.id;\n");
	fprintf(cgiOut, "    zTree2.checkAllNodes(false);\n");
	fprintf(cgiOut, "    if(treeNode.id.length > 0)\n");
	fprintf(cgiOut, "  	 {\n");
	fprintf(cgiOut, "  	   var arrTmp = treeNode.id.split(',');\n");
	fprintf(cgiOut, "  	   var preNode;\n");
	fprintf(cgiOut, "  	   for(var i=0; i<arrTmp.length; i++)\n");
	fprintf(cgiOut, "  	   {\n");
	fprintf(cgiOut, "  	     var tmp = arrTmp[i];\n");
	fprintf(cgiOut, "  	     var checkNode = info_GetNodeById(tmp);\n");
	fprintf(cgiOut, "  	     if(null != checkNode)\n");
	fprintf(cgiOut, "  	     {\n");
	fprintf(cgiOut, "  	     	 checkNode.checked = true;\n");
	fprintf(cgiOut, "  	       if(!preNode)\n");
	fprintf(cgiOut, "  	       {\n");
	fprintf(cgiOut, "  	         zTree2.updateNode(checkNode, true);\n");
	fprintf(cgiOut, "  	       }\n");
	fprintf(cgiOut, "  	       else if(preNode.parentNode != checkNode.parentNode)\n");
	fprintf(cgiOut, "  	       {\n");
	fprintf(cgiOut, "  	         zTree2.updateNode(checkNode, true);\n");
	fprintf(cgiOut, "  	       }\n");
	fprintf(cgiOut, "  	       else\n");
	fprintf(cgiOut, "  	       {\n");
	fprintf(cgiOut, "  	         zTree2.updateNode(checkNode, false);\n");
	fprintf(cgiOut, "  	       }\n");
	fprintf(cgiOut, "  	       preNode = checkNode;\n");
	fprintf(cgiOut, "  	     }\n");
	fprintf(cgiOut, "  	   }\n");
	fprintf(cgiOut, "  	 }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function role_GetNodeById(pvalue) \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	if(pvalue.length > 0) \n");
	fprintf(cgiOut, "	{\n");
	fprintf(cgiOut, "		treeNode = zTree1.getNodeByParam(\"value\", pvalue);\n");
	fprintf(cgiOut, "		return treeNode;\n");
	fprintf(cgiOut, "	}\n");
	fprintf(cgiOut, "}\n");
		
	fprintf(cgiOut, "function info_GetNodeById(pvalue) \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	if(pvalue.length > 0) \n");
	fprintf(cgiOut, "	{\n");
	fprintf(cgiOut, "		treeNode = zTree2.getNodeByParam(\"value\", pvalue);\n");
	fprintf(cgiOut, "		return treeNode;\n");
	fprintf(cgiOut, "	}\n");
	fprintf(cgiOut, "}\n");
	
	/*------------------------------------��ɫ---------------------------------------*/
	fprintf(cgiOut, "zTree1 = $(\"#roleTree\").zTree(setting_Tree1, [{name:'����Ȩ��', value:'0', id:''}]);\n");
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback_role, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(3);
	}
	
	/*------------------------------------����---------------------------------------*/
	fprintf(cgiOut, "zTree2 = $(\"#infoTree\").zTree(setting_Tree2, null);\n");
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_info, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(3);
	}

	sqlite3_close(db);

	
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(fp_role.id.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����ѡ��Ȩ�޽ڵ�!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  var selectedNode = zTree1.getSelectedNode();\n");
	
	fprintf(cgiOut, "  var point = '';\n");
	fprintf(cgiOut, "  var tempArray = zTree2.getCheckedNodes(true);\n");
	fprintf(cgiOut, "  for(var i=0; i<tempArray.length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(!tempArray[i].isParent)\n");
	fprintf(cgiOut, "      point += tempArray[i].value + ',';\n");
	fprintf(cgiOut, "  }\n");
	
	/*
	fprintf(cgiOut, "  if(selectedNode.name == fp_role.cname.value && point == fp_role.point.value)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ���޸�!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
  */
  
	fprintf(cgiOut, "  if(confirm(\"ȷ���ύ?\"))\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   m_Edit = createXHR();\n");
	fprintf(cgiOut, "    if(m_Edit)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      m_Edit.onreadystatechange=callbackForEdit;\n");
	fprintf(cgiOut, "      var url = 'fp_role.cgi?cmd=11&id='+fp_role.id.value+'&cname='+selectedNode.name+'&point='+point+'&currtime='+new Date();\n");
	fprintf(cgiOut, "      m_Edit.open(\"get\", url);\n");
	fprintf(cgiOut, "      m_Edit.send(null);\n");
	fprintf(cgiOut, "      selectedNode.id = point;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert(\"�������֧�֣�������������\");\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function callbackForEdit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(m_Edit.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "  	 if(m_Edit.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var returnValue = m_Edit.responseText;\n");
	fprintf(cgiOut, "      if(null != returnValue && returnValue.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('�༭�ɹ�!');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('�༭ʧ��!');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert(\"ҳ������쳣��\");\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	
	fprintf(cgiOut, "</SCRIPT>\n");	
	fprintf(cgiOut, "</HTML>\n");
}


int sqlite3_exec_callback_role(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "var parent_node = role_GetNodeById('0');\n");
	fprintf(cgiOut, "zTree1.addNodes(parent_node, [{name:'%s', value:'%s', id:'%s', icon:'../../skin/images/root.png'}], true);\n", col_values[1], col_values[0], col_values[2]);
	
	return 0;
}
int sqlite3_exec_callback_info(void *data, int n_columns, char **col_values, char **col_names)
{
	char Node1[3] = {0};
	char Node2[5] = {0};
	switch(strlen(col_values[0]))
	{
		case 2:
				fprintf(cgiOut, "var parent_node = info_GetNodeById('%s');\n", col_values[0]);
				fprintf(cgiOut, "zTree2.addNodes(parent_node, [{name:'%s', value:'%s'}], true);\n", col_values[1], col_values[0]);
			break;
		case 4:		
				Node1[0] = col_values[0][0];
				Node1[1] = col_values[0][1];
				Node1[2] = '\0';		
				fprintf(cgiOut, "var parent_node = info_GetNodeById('%s');\n", Node1);
				fprintf(cgiOut, "zTree2.addNodes(parent_node, [{name:'%s', value:'%s'}], true);\n", col_values[1], col_values[0]);
			break;
		case 6:		
				Node2[0] = col_values[0][0];
				Node2[1] = col_values[0][1];
				Node2[2] = col_values[0][2];
				Node2[3] = col_values[0][3];
				Node2[4] = '\0';		
				fprintf(cgiOut, "var parent_node = info_GetNodeById('%s');\n", Node2);
				fprintf(cgiOut, "zTree2.addNodes(parent_node, [{name:'%s', value:'%s'}], true);\n", col_values[1], col_values[0]);
			break;
	}
	return 0;
}
