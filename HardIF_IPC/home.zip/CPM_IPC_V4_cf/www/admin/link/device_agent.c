#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"

//��������
char Sql[1024] = {0};
char cmd[4] = {0};
int cnt = 0;
char GetName[128] = {0};
char FillStr[1024] = {0};
char changevalue[11] = {0};
int changecount = 0;
char EditSelCmd[31] = {0};
//device_agent
char seq[10] = {0};
char id[11] = {0};
char sn[5] = {0};
char condition[257] = {0};
char valibtime[30] = {0};
char interval[5] = {0};
char d_id[11] = {0};
char d_cmd[9] = {0};
char object[257] = {0};
char acttype[2] = {0};
char cname[31] = {0};
char attr_name[31] = {0};
//�رշ��ز���
char level[2] = {0};
char fromtype[2] = {0};
//�����༭
char con1[8]  = {0};
char con2[60] = {0};
char con3[8]  = {0};
char con4[60] = {0};
char conindex[8] = {0};
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
char *StrRightFillSpace(char *strData, int len);
char *getStatusName(int pStatus);
//���Ӳ�ѯ
static void AddHTML();
static int sqlite3_exec_callback_device_info_upper_agentid(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_device_cmd(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_device_call(void *data, int n_columns, char **col_values, char **col_names);
//�޸Ĳ�ѯ
static void UdpHTML();
static int sqlite3_exec_callback_forudp(void *data, int n_columns, char **col_values, char **col_names);
//�ύ
static void Submit();
static int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cnt(void *data, int n_columns, char **col_values, char **col_names);
//��������
static void QueryCmd();
static int sqlite3_exec_callback_querycmd(void *data, int n_columns, char **col_values, char **col_names);
//�����༭
static void doCondition();
static int sqlite3_exec_callback_devid(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_Con2(void *data, int n_columns, char **col_values, char **col_names);
//������ݱ༭
static void doFastCondition();
static int sqlite3_exec_callback_fastcond(void *data, int n_columns, char **col_values, char **col_names);
//��ѯ�ɼ�����
static void doSelAttr();
static int sqlite3_exec_callback_devsn(void *data, int n_columns, char **col_values, char **col_names);
//��ѯ��ֵ����
static void doDataChg();
static int sqlite3_exec_callback_datachg(void *data, int n_columns, char **col_values, char **col_names);		
//��ȡ����
char *getCName(int pCType, char *pId, char *pSN);
static int sqlite3_exec_callback_getname(void *data, int n_columns, char **col_values, char **col_names);
//ͨѶ
char *getLocalIP();
static int MsgSend(int flag);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	cnt = 0;
	changecount = 0;
	switch(atoi(cmd))
	{
		case 1://����
			AddHTML();
			break;
		case 2://�༭
			UdpHTML();
			break;
		case 3://�ύ
			Submit();
			break;
		case 4://��������
			QueryCmd();
			break;
		case 5://�����༭
			doCondition();
			break;
		case 6://��ѯ�ɼ�����
			doSelAttr();
			break;
		case 7://������ݱ༭
			doFastCondition();
			break;
		case 8://��ѯ��ֵ����
			doDataChg();
			break;
	}
	
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("seq", seq, sizeof(seq));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("condition", condition, sizeof(condition));
	cgiFormString("valibtime", valibtime, sizeof(valibtime));
	cgiFormString("interval", interval, sizeof(interval));
	cgiFormString("d_id", d_id, sizeof(d_id));
	cgiFormString("d_cmd", d_cmd, sizeof(d_cmd));
	cgiFormString("object", object, sizeof(object));
	cgiFormString("acttype", acttype, sizeof(acttype));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("attr_name", attr_name, sizeof(attr_name));
	
	cgiFormString("level", level, sizeof(level));
	cgiFormString("fromtype", fromtype, sizeof(fromtype));
	
	cgiFormString("con1", con1, sizeof(con1));
	cgiFormString("con2", con2, sizeof(con2));
	cgiFormString("con3", con3, sizeof(con3));
	cgiFormString("con4", con4, sizeof(con4));
	cgiFormString("conindex", conindex, sizeof(conindex));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0://�޸Ĳ�ѯ
			strcat(Sql, "select a.seq, a.id, a.sn, a.condition, a.valibtime, a.interval, a.d_id, a.d_cmd, a.object, a.ctype, b.cname, c.cname, d.cmdname from device_agent a, device_detail b, device_detail c, device_act d where a.id = b.id and a.d_id = c.id and a.d_id = d.id and a.d_cmd = d.sn and a.seq = '");
      strcat(Sql, seq);
      strcat(Sql, "' and a.ctype = '0' ");
			break;
	}
	return Sql;
}

void doFastCondition()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[512] = {0};
	sprintf(sql, "select a.seq, a.id, a.sn, a.condition, a.valibtime, a.interval, a.d_id, a.d_cmd, a.object, a.ctype, b.cname, c.cname, d.cmdname, e.attr_name from device_agent a, device_detail b, device_detail c, device_act d, device_roll e where a.id = b.id and a.d_id = c.id and a.d_id = d.id and a.d_cmd = d.sn and a.id = e.id and a.sn = e.sn and a.seq = '%s'", seq);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_fastcond, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_fastcond(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>��������</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");	
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 60%%;\n");
	fprintf(cgiOut, "  height:50%%;\n");
	fprintf(cgiOut, "  left:20%%;\n");
	fprintf(cgiOut, "  top: 25%%;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"agent\" action=\"agent.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<table align='center' style='margin:auto;margin-top:5px;' align='center' width=\"98%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='200px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='left' valign='top'><br>\n");
	fprintf(cgiOut, "      <div id='ConD0'><img src='../../skin/images/device_cmdadd.png' style='cursor:hand' title='��������' onclick=\"doConditionAdd('0', '%s', '%s', '0', '', '', '');\"></div>\n", col_values[1], col_values[2]);
	if(NULL != col_values[3] && strlen(col_values[3]) > 0)
	{		
		int i = 0;
		char* split_result = NULL;
    char* savePtr = NULL;
    split_result = strtok_r(col_values[3], "@", &savePtr);
    while(NULL != split_result)
		{
			char con_id[11] = {0};
			char con_sn[5] = {0};
			char con1[2]   = {0};
			char con1_fh[2]= {0};
			char con2[60]  = {0};
			char con3[2]   = {0};
			char con3_fh[2]={0};
			char con4[30]  = {0};				
			char con_idname[128] = {0};
			char con2_idname[128]= {0};
			strncpy(con_id, split_result+1, 10);
			strncpy(con_sn, split_result+11, 4);
			strncpy(con1, split_result+15, 1);
			strncpy(con2, split_result+16, 60);	
			if(0 == strcmp(con1, ">"))
			{
				strcat(con1_fh, "0");
			}
			else if(0 == strcmp(con1, "="))
			{
				strcat(con1_fh, "1");
			}
			else if(0 == strcmp(con1, "<"))
			{
				strcat(con1_fh, "2");
			}	
			memcpy(con_idname, getCName(1, con_id, con_sn), 128);
			if(strstr(con2, "P") && (strstr(con2, "+") || strstr(con2, "-") || strstr(con2, "��") || strstr(con2, "��")))
			{
				memset(con2, 0, sizeof(con2));
				strncpy(con2, split_result+16, 15);	
				strncpy(con3, split_result+31, 1);
				strncpy(con4, split_result+32, 30);
			}
			memcpy(con2_idname, con2, 128);
			if(strstr(con2_idname, "P") && NULL != con3 && NULL != con4 && strlen(con3) > 0 && strlen(con4) > 0)
			{
				memset(con2_idname, 0, sizeof(con2_idname));
				memcpy(con2_idname, getCName(2, con2, ""), 128);
			}		
			if(0 == strcmp(con3, "+"))
			{
				strcat(con3_fh, "0");
			}
			else if(0 == strcmp(con3, "-"))
			{
				strcat(con3_fh, "1");
			}
			else if(0 == strcmp(con3, "��"))
			{
				strcat(con3_fh, "2");
			}	
			else if(0 == strcmp(con3, "��"))
			{
				strcat(con3_fh, "3");
			}	
			
			i++;			
			if(1 == i)
			{
				fprintf(cgiOut, "<div id='ConD%d'>%d.%s %s %s%s%s \n", i, i, con_idname, con1, con2_idname, con3, con4);
				fprintf(cgiOut, "  <img src='../../skin/images/agent_edit.gif' style='cursor:hand' title='�༭' onclick=\"doConditionAdd('%d', '%s', '%s', '%s', '%s', '%s', '%s');\">\n", i, con_id, con_sn, con1_fh, con2, con3_fh, con4);
				fprintf(cgiOut, "  <input type='hidden' id='ConDValue%d' name='ConDValue%d' value='%s'>\n", i, i, split_result);
				fprintf(cgiOut, "</div>\n");
			}
			else
			{
				fprintf(cgiOut, "<div id='ConD%d'>%d.%s %s %s%s%s \n", i, i, con_idname, con1, con2_idname, con3, con4);
				fprintf(cgiOut, "  <img src='../../skin/images/agent_edit.gif' style='cursor:hand' title='�༭' onclick=\"doConditionAdd('%d', '%s', '%s', '%s', '%s', '%s', '%s');\">\n", i, con_id, con_sn, con1_fh, con2, con3_fh, con4);
				fprintf(cgiOut, "  <input type='hidden' id='ConDValue%d' name='ConDValue%d' value='%s'>\n", i, i, split_result);
				fprintf(cgiOut, "  <img src='../../skin/images/cmddel.gif' style='cursor:hand' title='ɾ��' onclick=doConditionDel('%d')>\n", i);
				fprintf(cgiOut, "</div>\n");
			}
			split_result = strtok_r(NULL, "@", &savePtr);
		}	
		for(int j=i+1; j<=8; j++)
		{
			fprintf(cgiOut, "  <div id='ConD%d' style='display:none'></div>\n", j);
		}		
	}
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<div style='text-align:center;padding-top:5px;'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doAdd()'    src='../../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doCancel()' src='../../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='conDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "<input type='hidden' name='Condition' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//�رմ���
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('conDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//�������ӡ��༭
	fprintf(cgiOut, "function doConditionAdd(pIndex, pId, pSN, pCon1, pCon2, pCon3, pCon4)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var index = pIndex;\n");
	fprintf(cgiOut, "  if('0' == index)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    for(var i=2; i<=9; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(i == 9)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���֧��8������!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(document.getElementById('ConD'+i).style.display == 'none')\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        index = i;\n");
	fprintf(cgiOut, "        break;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('conDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'device_agent.cgi?cmd=5&id='+pId+'&sn='+pSN+'&con1='+pCon1+'&con2='+pCon2+'&con3='+pCon3+'&con4='+pCon4+'&conindex='+index+'&cname=%s&attr_name=%s';\n", col_values[10], col_values[13]);
	fprintf(cgiOut, "  document.getElementById('conDiv').innerHTML = \"<iframe id='conFrame' name='conFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//����ɾ��
	fprintf(cgiOut, "function doConditionDel(pIndex)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('ConD'+pIndex).style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");	
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  agent.Condition.value = '';\n");
	fprintf(cgiOut, "  var cnt = 0;\n");
	fprintf(cgiOut, "  for(var i=1; i<=8; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('ConD'+i).style.display == '')\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      cnt++;\n");
	fprintf(cgiOut, "      if(1 == cnt)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        agent.Condition.value += document.getElementById('ConDValue'+i).value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        agent.Condition.value += '@' + document.getElementById('ConDValue'+i).value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(agent.Condition.value.length < 1){alert('����д����!'); return;}\n");
	fprintf(cgiOut, "  var ConDlen = agent.Condition.value.len();\n");
	fprintf(cgiOut, "  if(ConDlen > 128)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ù������뾫��!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  agent.Condition.value = agent.Condition.value.replace(/\\+/g,'%%2B');\n");
	fprintf(cgiOut, "  if(confirm('ȷ���޸�?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqAdd = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqAdd = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqAdd.onreadystatechange = callbackAddName;\n");			
	fprintf(cgiOut, "    var url = 'device_agent.cgi?cmd=3&seq=%s&id=%s&sn=%s&condition='+agent.Condition.value+'&valibtime=%s&interval=%s&d_id=%s&d_cmd=%s&object=%s&acttype=2&currtime='+new Date();\n", col_values[0], col_values[1], col_values[2], col_values[4], col_values[5], col_values[6], col_values[7], col_values[8]);
	fprintf(cgiOut, "    reqAdd.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqAdd.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqAdd.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackAddName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqAdd.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqAdd.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
	return 0;
}

void doCondition()
{
	//conindex��id��sn��cname��attr_name��con1��con2��con3��con4
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>�����༭</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#d2d2e9\">\n");
	fprintf(cgiOut, "<form name=\"device_agent\" action=\"device_agent.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<table align='center' style='margin:auto;margin-top:5px;' width=\"99%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>�豸</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	if(0 == strcmp(conindex, "1"))
	{
		fprintf(cgiOut, "    %s\n", cname);
		fprintf(cgiOut, "    <input type='hidden' name='devId' value='%s'>\n", id);
	}
	else
	{
		fprintf(cgiOut, "    <select name='devId' style='width:98%%;height:20px;' onchange='doChange(this.value);'>\n");
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db = open_db(DB_PATH);
		char sql[512] = "select a.id, a.cname from device_detail a, device_roll b where a.id = b.id group by a.id order by a.id";
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_devid, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(1);
		}
		sqlite3_close(db);
		fprintf(cgiOut, "    </select>\n");
	}
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	if(0 == strcmp(conindex, "1"))
	{
		fprintf(cgiOut, "    %s\n", attr_name);
		fprintf(cgiOut, "    <input type='hidden' name='devSN' value='%s'>\n", sn);
	}
	else
	{
		fprintf(cgiOut, "    <select name='devSN' id='devSN' style='width:98%%;height:20px;'>\n");
		fprintf(cgiOut, "    </select>\n");
	}
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Con1' style='width:60px;height:20px;'>\n");
	fprintf(cgiOut, "        <option value='0' %s>></option>\n", 0 == strcmp(con1, "0")?"selected":"");
	fprintf(cgiOut, "        <option value='1' %s>=</option>\n", 0 == strcmp(con1, "1")?"selected":"");
	fprintf(cgiOut, "        <option value='2' %s><</option>\n", 0 == strcmp(con1, "2")?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>��ֵ</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left' id='DataChg'>\n");
	if(NULL == con3 || 0 == strlen(con3))
	{
		fprintf(cgiOut, "    <input type='text' id='Con2' name='Con2' value='%s' style='width:85%%;height:20px;' maxlength=10>\n", con2);
		fprintf(cgiOut, "    <img src='../../skin/images/datachg.png' style='cursor:hand;width:20px;height:20px;' valign='middle' title='תΪѡȡ����' onclick=\"doDataChg('2')\">\n");
	}
	else
	{
		fprintf(cgiOut, "    <select id='Con2' name='Con2' style='width:55%%;height:20px;'>\n");
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db = open_db(DB_PATH);
		char sql[512] = {0};
		sprintf(sql, "select 'P' || a.id || a.sn as id, '[' || b.cname || ']�ɼ���[' || a.Attr_Name || ']' as cname from device_roll a, device_detail b where a.id = b.id and (a.id || a.sn) <> '%s%s' order by a.id, a.sn;", id, sn);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_Con2, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(1);
		}
		sqlite3_close(db);
		fprintf(cgiOut, "    </select>\n");
		fprintf(cgiOut, "    <select id='Con3' name='Con3' style='width:20%%;height:20px;'>\n");
		fprintf(cgiOut, "      <option value='0' %s>+</option>\n", 0 == strcmp(con3, "0")?"selected":"");
		fprintf(cgiOut, "      <option value='1' %s>-</option>\n", 0 == strcmp(con3, "1")?"selected":"");
		//fprintf(cgiOut, "      <option value='2' %s>��</option>\n", 0 == strcmp(con3, "2")?"selected":"");
		//fprintf(cgiOut, "      <option value='3' %s>��</option>\n", 0 == strcmp(con3, "3")?"selected":"");
		fprintf(cgiOut, "    </select>\n");
		fprintf(cgiOut, "    <input type='text' id='Con4' name='Con4' value='%s' style='width:10%%;height:20px;' maxlength=10>\n", con4);
		fprintf(cgiOut, "    <img src='../../skin/images/datachg.png' style='cursor:hand;width:20px;height:20px;' valign='middle' title='תΪ�ֹ���д' onclick=\"doDataChg('1')\">\n");
	}
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>\n");
	fprintf(cgiOut, "      <img src='../../skin/images/consave.gif'    style='cursor:hand' onclick='doSave();'>\n");
	fprintf(cgiOut, "      <img src='../../skin/images/savereturn.gif' style='cursor:hand' onclick='doCancel();'>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	//��ֵ�л�
	fprintf(cgiOut, "function doDataChg(pCType)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('DataChg').innerHTML = '';\n");
	fprintf(cgiOut, "  var objHTML = '';\n");
	fprintf(cgiOut, "  if('1' == pCType)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    objHTML += \"<input type='text' id='Con2' name='Con2' value='' style='width:85%%;height:20px;' maxlength=10>\";\n");
	fprintf(cgiOut, "    objHTML += \"<img src='../../skin/images/datachg.png' style='cursor:hand;width:20px;height:20px;' valign='middle' title='תΪѡȡ����' onclick=doDataChg('2')>\";\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    objHTML += \"<select id='Con2' name='Con2' style='width:55%%;height:20px;'>\";\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqSta = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqSta = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqSta.onreadystatechange = function()\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var state = reqSta.readyState;\n");
	fprintf(cgiOut, "      if(state == 4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var resp = reqSta.responseText;\n");
	fprintf(cgiOut, "        if(null != resp && resp.Trim().length > 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var list = resp.split('#');\n");
	fprintf(cgiOut, "          for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "            objHTML += \"<option value='\"+sublist[0]+\"'>\"+sublist[1]+\"</option>\";\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    };\n");
	fprintf(cgiOut, "    var url = 'device_agent.cgi?cmd=8&id=%s&sn=%s&currtime='+new Date();\n", id, sn);
	fprintf(cgiOut, "    reqSta.open('GET',url,false);\n");
	fprintf(cgiOut, "    reqSta.send(null);\n");
	fprintf(cgiOut, "    objHTML += \"</select>\";\n");
	fprintf(cgiOut, "    objHTML += \"<select id='Con3' name='Con3' style='width:20%%;height:20px;'>\";\n");
	fprintf(cgiOut, "    objHTML += \"  <option value='0'>+</option>\";\n");
	fprintf(cgiOut, "    objHTML += \"  <option value='1'>-</option>\";\n");
	//fprintf(cgiOut, "    objHTML += \"  <option value='2'>��</option>\";\n");
	//fprintf(cgiOut, "    objHTML += \"  <option value='3'>��</option>\";\n");
	fprintf(cgiOut, "    objHTML += \"</select>\";\n");
	fprintf(cgiOut, "    objHTML += \"<input type='text' id='Con4' name='Con4' value='0' style='width:10%%;height:20px;' maxlength=10>\";\n");
	fprintf(cgiOut, "    objHTML += \"<img src='../../skin/images/datachg.png' style='cursor:hand;width:20px;height:20px;' valign='middle' title='תΪ�ֹ���д' onclick=doDataChg('1')>\";\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('DataChg').innerHTML = objHTML;\n");
	fprintf(cgiOut, "}\n");
	//�������
	fprintf(cgiOut, "function doChange(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var length = document.getElementById('devSN').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('devSN').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqChg.onreadystatechange = callbackChangeName;\n");
	fprintf(cgiOut, "  var url = 'device_agent.cgi?cmd=6&id='+pId+'&currtime='+new Date();\n");
	fprintf(cgiOut, "	 reqChg.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqChg.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackChangeName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqChg.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqChg.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var list = resp.split('#');\n");
	fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "      		 var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      		 objOption.value = sublist[0];\n");
	fprintf(cgiOut, "      		 objOption.text  = sublist[1];\n");
	fprintf(cgiOut, "      		 document.getElementById('devSN').add(objOption);\n");
	fprintf(cgiOut, "          if(sublist[0] == '%s')\n", sn);
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            objOption.selected = true;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	if(0 != strcmp(conindex, "1"))
	{
		fprintf(cgiOut, "doChange(device_agent.devId.value);\n");
	}
	fprintf(cgiOut, "function doSave()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_agent.devId.value.length < 1){alert('��ѡ���豸');return;}\n");
	fprintf(cgiOut, "  if(device_agent.devSN.value.length < 1){alert('��ѡ�����');return;}\n");
	fprintf(cgiOut, "  if(device_agent.Con2.value.Trim().length < 1){alert('����д����');return;}\n");
	fprintf(cgiOut, "  var devSNName = '';\n");
	fprintf(cgiOut, "  if('%s' == '1')\n", conindex);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    devSNName = '%s';\n", attr_name);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    devSNName = document.getElementById('devSN').options[document.getElementById('devSN').selectedIndex].text;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var Con1FH = '';\n");
	fprintf(cgiOut, "  switch(parseInt(device_agent.Con1.value))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 0:\n");
	fprintf(cgiOut, "        Con1FH = '>';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "        Con1FH = '=';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "        Con1FH = '<';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var Con3VA = '';\n");
	fprintf(cgiOut, "  var Con3FH = '';\n");
	fprintf(cgiOut, "  if(device_agent.Con3)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Con3VA = device_agent.Con3.value;\n");
	fprintf(cgiOut, "    switch(parseInt(device_agent.Con3.value))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      case 0:\n");
	fprintf(cgiOut, "          Con3FH = '+';\n");
	fprintf(cgiOut, "        break;\n");
	fprintf(cgiOut, "      case 1:\n");
	fprintf(cgiOut, "          Con3FH = '-';\n");
	fprintf(cgiOut, "        break;\n");
	fprintf(cgiOut, "      case 2:\n");
	fprintf(cgiOut, "          Con3FH = '��';\n");
	fprintf(cgiOut, "        break;\n");
	fprintf(cgiOut, "      case 3:\n");
	fprintf(cgiOut, "          Con3FH = '��';\n");
	fprintf(cgiOut, "        break;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var Con4VA = '';\n");
	fprintf(cgiOut, "  if(device_agent.Con4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(device_agent.Con4.value.Trim().length < 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('����д��ֵ���޻����ޣ���������0');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<device_agent.Con4.value.length; i++)\n");	
	fprintf(cgiOut, "    {\n");	
	fprintf(cgiOut, "      if(device_agent.Con4.value.charAt(i) != '.' && isNaN(device_agent.Con4.value.charAt(i)))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���޻��������뺬�Ƿ��ַ�!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    Con4VA = device_agent.Con4.value.Trim();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var Con2Name = device_agent.Con2.value;\n");
	fprintf(cgiOut, "  if(device_agent.Con3)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Con2Name = document.getElementById('Con2').options[document.getElementById('Con2').selectedIndex].text;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  window.parent.document.getElementById('ConD%s').style.display = '';\n", conindex);
	fprintf(cgiOut, "  var obj = '';\n");
	fprintf(cgiOut, "  if('1' == '%s')\n", conindex);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    obj = '%s.' + devSNName + ' '+ Con1FH + ' ' + Con2Name + Con3FH + Con4VA + ' &nbsp;';\n", conindex);
	fprintf(cgiOut, "    obj += \"<img src='../../skin/images/agent_edit.gif' style='cursor:hand' title='�༭' onclick=doConditionAdd('%s','\"+device_agent.devId.value+\"','\"+device_agent.devSN.value+\"','\"+device_agent.Con1.value+\"','\"+device_agent.Con2.value+\"','\"+Con3VA+\"','\"+Con4VA+\"');>&nbsp;&nbsp;\";\n", conindex);
	fprintf(cgiOut, "    obj += \"<input type='hidden' id='ConDValue%s' name='ConDValue%s' value='P\"+device_agent.devId.value+device_agent.devSN.value+Con1FH+device_agent.Con2.value+Con3FH+Con4VA+\"'>\"\n", conindex, conindex);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    obj = '%s.' + devSNName + ' '+ Con1FH + ' ' + Con2Name + Con3FH + Con4VA + ' &nbsp;';\n", conindex);
	fprintf(cgiOut, "    obj += \"<img src='../../skin/images/agent_edit.gif' style='cursor:hand' title='�༭' onclick=doConditionAdd('%s','\"+device_agent.devId.value+\"','\"+device_agent.devSN.value+\"','\"+device_agent.Con1.value+\"','\"+device_agent.Con2.value+\"','\"+Con3VA+\"','\"+Con4VA+\"');>&nbsp;&nbsp;\";\n", conindex);
	fprintf(cgiOut, "    obj += \"<img src='../../skin/images/cmddel.gif'     style='cursor:hand' title='ɾ��' onclick=doConditionDel('%s')>\"\n", conindex);
	fprintf(cgiOut, "    obj += \"<input type='hidden' id='ConDValue%s' name='ConDValue%s' value='P\"+device_agent.devId.value+device_agent.devSN.value+Con1FH+device_agent.Con2.value+Con3FH+Con4VA+\"'>\"\n", conindex, conindex);
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  window.parent.document.getElementById('ConD%s').innerHTML = obj;\n", conindex);
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</html>\n");
}

int sqlite3_exec_callback_devid(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<option value='%s' %s>%s</option>\n", col_values[0], 0 == strcmp(id, col_values[0])?"selected":"", col_values[1]);
	return 0;	
}

int sqlite3_exec_callback_Con2(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<option value='%s' %s>%s</option>\n", col_values[0], 0 == strcmp(con2, col_values[0])?"selected":"", col_values[1]);
	return 0;	
}

void doDataChg()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[512] = {0};
	sprintf(sql, "select 'P' || a.id || a.sn as id, '[' || b.cname || ']�ɼ���[' || a.Attr_Name || ']' as cname from device_roll a, device_detail b where a.id = b.id and (a.id || a.sn) <> '%s%s' order by a.id, a.sn;", id, sn);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_datachg, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_datachg(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "%s,%s#", col_values[0], col_values[1]);
	return 0;
}

void doSelAttr()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[128] = "select a.sn, a.attr_name from device_roll a where a.id = '";
	strcat(sql, id);
	strcat(sql, "' order by a.sn");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_devsn, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_devsn(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "%s,%s#", col_values[0], col_values[1]);
	return 0;
}

void AddHTML()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>��������</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");	
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 60%%;\n");
	fprintf(cgiOut, "  height:50%%;\n");
	fprintf(cgiOut, "  left:20%%;\n");
	fprintf(cgiOut, "  top: 25%%;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"agent\" action=\"agent.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<table style='margin:auto;margin-top:5px;' align='center' width=\"98%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      %s\n", attr_name);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>&nbsp;&nbsp;����&nbsp;<img src='../../skin/images/device_cmdadd.png' style='cursor:hand' title='��������' onclick=\"doConditionAdd('0', '%s', '%s', '0', '', '', '');\"></td>\n", id, sn);
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <div id='ConD1'>1.%s > 1 &nbsp;<img src='../../skin/images/agent_edit.gif' style='cursor:hand' title='�༭' onclick=\"doConditionAdd('1', '%s', '%s', '0', '1', '', '');\"><input type='hidden' id='ConDValue1' name='ConDValue1' value='P%s%s>1'></div>\n", attr_name, id, sn, id, sn);
	fprintf(cgiOut, "      <div id='ConD2' style='display:none'></div>\n");
	fprintf(cgiOut, "      <div id='ConD3' style='display:none'></div>\n");
	fprintf(cgiOut, "      <div id='ConD4' style='display:none'></div>\n");
	fprintf(cgiOut, "      <div id='ConD5' style='display:none'></div>\n");
	fprintf(cgiOut, "      <div id='ConD6' style='display:none'></div>\n");
	fprintf(cgiOut, "      <div id='ConD7' style='display:none'></div>\n");
	fprintf(cgiOut, "      <div id='ConD8' style='display:none'></div>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>ʱ��</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Time' id='Time' style='width:90px;height:25px;' onchange=\"doSwitchTime(this.value)\">\n");
	fprintf(cgiOut, "			   <option value='0' selected>���趨</option>\n");
	fprintf(cgiOut, "				 <option value='1'>��ѭ��</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "      <input type='text' id='TimeD' name='TimeD' maxlength='12' value='' style='width:125px;height:20px;display:none;'><font color=red>��ʽ:*0600,*1200</font>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>���</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='link_delay' style='width:90px;height:25px'>\n");
	fprintf(cgiOut, "        <option value=' '  >������</option>\n");
	fprintf(cgiOut, "        <option value='5'  >5���� </option>\n");
	fprintf(cgiOut, "        <option value='10' >10����</option>\n");
	fprintf(cgiOut, "        <option value='20' >20����</option>\n");
	fprintf(cgiOut, "        <option value='30' >30����</option>\n");
	fprintf(cgiOut, "        <option value='45' >45����</option>\n");
	fprintf(cgiOut, "        <option value='60' >60����</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");	
	fprintf(cgiOut, "    <td width='20%%' align='center'>�豸</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Id' id='Id' style='width:250px;height:25px;' onchange=\"doChange(this.value, '')\">\n");		
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = "select a.id, a.cname from device_detail a, device_act b where a.id = b.id group by a.id order by a.id";
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_device_info_upper_agentid, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Cmd' id='Cmd' style='width:250px;height:25px;' onchange='doChange2(this.value)'>\n");	
	char sql2[512] = "select a.id, a.sn, a.cmdname, a.status, b.object from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and b.flag = '0' and b.flag1 = '0' and a.id = '";
	strcat(sql2, changevalue);
	strcat(sql2, "'");
	rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_device_cmd, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Tel' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='Tel' value='' style='width:250px;height:20px;' maxlength=256><font color=red>�������/����</font>\n");	
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Object' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='Object' value='' style='width:250px;height:20px;' maxlength=256>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Call' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select id='CallSN' name='Call' style='width:250px;height:20px;'>\n");
	
	char sql3[512] = "select a.sn, a.cname from call a";
	rc = sqlite3_exec(db, sql3, &sqlite3_exec_callback_device_call, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	sqlite3_close(db);
	
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<div style='text-align:center;padding-top:5px;'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doAdd()'    src='../../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doCancel()' src='../../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='conDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "<input type='hidden' name='Condition' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//�رմ���
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('conDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//�������ӡ��༭
	fprintf(cgiOut, "function doConditionAdd(pIndex, pId, pSN, pCon1, pCon2, pCon3, pCon4)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var index = pIndex;\n");
	fprintf(cgiOut, "  if('0' == index)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    for(var i=2; i<=9; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(i == 9)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���֧��8������!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(document.getElementById('ConD'+i).style.display == 'none')\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        index = i;\n");
	fprintf(cgiOut, "        break;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('conDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'device_agent.cgi?cmd=5&id='+pId+'&sn='+pSN+'&con1='+pCon1+'&con2='+pCon2+'&con3='+pCon3+'&con4='+pCon4+'&conindex='+index+'&cname=%s&attr_name=%s';\n", cname, attr_name);
	fprintf(cgiOut, "  document.getElementById('conDiv').innerHTML = \"<iframe id='conFrame' name='conFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//����ɾ��
	fprintf(cgiOut, "function doConditionDel(pIndex)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('ConD'+pIndex).style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//�༭
	fprintf(cgiOut, "var reqChg = null;\n");
	fprintf(cgiOut, "function doChange(pValue, pSelCmd)\n");
	fprintf(cgiOut, "{\n");
	//��ɾ��
	fprintf(cgiOut, "  var length = document.getElementById('Cmd').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('Cmd').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	//������
	fprintf(cgiOut, "  var CmdType = '0';\n");
	fprintf(cgiOut, "  if(pValue.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(pValue.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqChg.onreadystatechange = function(){callbackChangeName(pValue, pSelCmd, CmdType)};\n");
	fprintf(cgiOut, "  var url = 'device_agent.cgi?cmd=4&id='+pValue+'&currtime='+new Date();\n");
	fprintf(cgiOut, "	 reqChg.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqChg.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackChangeName(pValue, pSelCmd, CmdType)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqChg.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqChg.responseText;\n");	
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var list = resp.split('#');\n");
	fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "      		 var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      		 objOption.value = list[i];\n");
	fprintf(cgiOut, "      		 objOption.text = sublist[2];\n");
	fprintf(cgiOut, "      		 document.getElementById('Cmd').add(objOption);\n");
	fprintf(cgiOut, "  			   if(pSelCmd.length > 0)\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "  			     if(pSelCmd == sublist[1])\n");
	fprintf(cgiOut, "  			     {\n");
	fprintf(cgiOut, "  			       objOption.selected = true;\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(agent.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = agent.Object.value.substring(0, agent.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = agent.Object.value.substring(agent.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    agent.Tel.value = tel;\n");
	fprintf(cgiOut, "                    agent.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(agent.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = agent.Tel.value.substring(0, agent.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = agent.Tel.value.substring(agent.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   agent.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "  			     }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "  			   else\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "          	 if(i == 0)\n");
	fprintf(cgiOut, "        	   {\n");
	fprintf(cgiOut, "						   objOption.selected = 'true';\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(agent.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = agent.Object.value.substring(0, agent.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = agent.Object.value.substring(agent.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    agent.Tel.value = tel;\n");
	fprintf(cgiOut, "                    agent.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(agent.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = agent.Tel.value.substring(0, agent.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = agent.Tel.value.substring(agent.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   agent.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doChange2(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 if(pValue.length > 0)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   var list = pValue.split(',');\n");
	fprintf(cgiOut, "	   var Id = list[0];\n");
	fprintf(cgiOut, "	   var SN = list[1];\n");
	fprintf(cgiOut, "	   var CmdName = list[2];\n");
	fprintf(cgiOut, "	   var Object = list[3];\n");
	fprintf(cgiOut, "	   var CmdType = '0';\n");
	fprintf(cgiOut, "	   if(Id.indexOf('001103') >= 0 && Object == '1')\n");//����
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '1';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(Id.indexOf('001104') >= 0 && Object == '1')\n");//����
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '2';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   if('0' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     if('1' == Object)\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	     else\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('1' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('2' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSwitchTime(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "if(pValue == '0'){document.getElementById('TimeD').style.display = 'none';}\n");
	fprintf(cgiOut, "if(pValue == '1'){document.getElementById('TimeD').style.display = '';}\n");
	fprintf(cgiOut, "if(pValue == '2'){document.getElementById('TimeD').style.display = '';}\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doChange(agent.Id.value, '');\n");
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");	
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  agent.Condition.value = '';\n");
	fprintf(cgiOut, "  var cnt = 0;\n");
	fprintf(cgiOut, "  for(var i=1; i<=8; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('ConD'+i).style.display == '')\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      cnt++;\n");
	fprintf(cgiOut, "      if(1 == cnt)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        agent.Condition.value += document.getElementById('ConDValue'+i).value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        agent.Condition.value += '@' + document.getElementById('ConDValue'+i).value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(agent.Condition.value.length < 1){alert('����д����!'); return;}\n");
	fprintf(cgiOut, "  var ConDlen = agent.Condition.value.len();\n");
	fprintf(cgiOut, "  if(ConDlen > 128)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ù������뾫��!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  agent.Condition.value = agent.Condition.value.replace(/\\+/g,'%%2B');\n");
	fprintf(cgiOut, "  if(agent.Id.value.length < 1){alert('��ѡ�������豸!'); return;}\n");
	fprintf(cgiOut, "  if(agent.Cmd.value.length < 1){alert('��ѡ����������!');return;}\n");
	fprintf(cgiOut, "  var TimeD = ' ';\n");
	fprintf(cgiOut, "  if('0' != agent.Time.value)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    TimeD = agent.TimeD.value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(TimeD.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    TimeD = ' ';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var Id = agent.Id.value;\n");	
	fprintf(cgiOut, "  var Style = '0';\n");
	fprintf(cgiOut, "  if(Id.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(Id.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var CmdList = agent.Cmd.value.split(',');\n");
	fprintf(cgiOut, "  var Cmd = CmdList[1];\n");
	fprintf(cgiOut, "  var ObjectFlag = CmdList[3];\n");
	fprintf(cgiOut, "  var StatusFlag = CmdList[4];\n");
	fprintf(cgiOut, "  var Object = '';\n");
	fprintf(cgiOut, "  if('0' == Style)\n");//��ͨ
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      Object = agent.Object.value;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('1' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(agent.Object.value.length < 1 && agent.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = agent.Tel.value + '//' + agent.Object.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('2' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(agent.Call.value.length < 1 && agent.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = agent.Tel.value + '//' + agent.Call.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(Object.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Object = ' ';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var len = Object.len();\n");
	fprintf(cgiOut, "  if(len > 256)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ݳ��ȹ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if('0' == StatusFlag)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ����δ����Ϊ���ã��ݲ�������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqAdd = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqAdd = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqAdd.onreadystatechange = callbackAddName;\n");		
	fprintf(cgiOut, "    var url = 'device_agent.cgi?cmd=3&seq=%s&id=%s&sn=%s&valibtime='+TimeD+'&interval='+agent.link_delay.value+'&d_id='+Id+'&d_cmd='+Cmd+'&object='+Object+'&acttype=1&currtime='+new Date()+'&condition='+agent.Condition.value;\n", seq, id, sn);
	fprintf(cgiOut, "    reqAdd.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqAdd.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqAdd.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackAddName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqAdd.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqAdd.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "        if(resp.indexOf('�ɹ�') >= 0 || resp.indexOf('�ύ�ɹ�') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          parent.location = 'device_roll.cgi?cmd=0&id=%s&sn=%s&level=%s&fromtype=%s';\n", id, sn, level, fromtype);
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_device_info_upper_agentid(void *data, int n_columns, char **col_values, char **col_names)
{	
	changecount++;	
	if(NULL != data)
	{
		if(0 == strcmp((char *)data, col_values[0]))
		{
			strcat(changevalue, col_values[0]);
			fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", col_values[0], col_values[1]);
		}
		else
		{
			fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
		}
	}
	else
	{
		if(changecount == 1)
		{
			strcat(changevalue, col_values[0]);
		}
		fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	}
	
	return 0;
}

int sqlite3_exec_callback_device_cmd(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != data && 0 == strcmp((char *)data, col_values[1]))
	{
		memset(EditSelCmd, 0, sizeof(EditSelCmd));
		memcpy(EditSelCmd, col_values[1], 31);
		fprintf(cgiOut, "<option value='%s,%s,%s,%s,%s' selected>%s</option>\n", col_values[0], col_values[1], col_values[2], col_values[4], col_values[3], col_values[2]);
	}
	else
	{
		fprintf(cgiOut, "<option value='%s,%s,%s,%s,%s'>%s</option>\n", col_values[0], col_values[1], col_values[2], col_values[4], col_values[3], col_values[2]);
	}
	return 0;
}

int sqlite3_exec_callback_device_call(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	return 0;
}

void QueryCmd()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	char sql[256] = "select a.id, a.sn, a.cmdname, a.status, b.object from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and b.flag = '0' and b.flag1 = '0' and a.id = '";
	strcat(sql, id);
	strcat(sql, "'");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_querycmd, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_querycmd(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "%s,%s,%s,%s,%s#", col_values[0], col_values[1], col_values[2], col_values[4], col_values[3]);
	return 0;
}

void UdpHTML()
{
	int rc;
	char * zErrMsg;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback_forudp, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}	
	sqlite3_close(db);
}

int sqlite3_exec_callback_forudp(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>��������</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");	
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 60%%;\n");
	fprintf(cgiOut, "  height:50%%;\n");
	fprintf(cgiOut, "  left:20%%;\n");
	fprintf(cgiOut, "  top: 25%%;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"agent\" action=\"agent.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<table align='center' style='margin:auto;margin-top:5px;' width=\"98%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      %s\n", attr_name);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>&nbsp;&nbsp;����&nbsp;<img src='../../skin/images/device_cmdadd.png' style='cursor:hand' title='��������' onclick=\"doConditionAdd('0', '%s', '%s', '0', '', '', '');\"></td>\n", id, sn);
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	if(NULL != col_values[3] && strlen(col_values[3]) > 0)
	{		
		int i = 0;
		char* split_result = NULL;
    char* savePtr = NULL;
    split_result = strtok_r(col_values[3], "@", &savePtr);
    while(NULL != split_result)
		{
			char con_id[11] = {0};
			char con_sn[5]  = {0};
			char con1[2]    = {0};
			char con1_fh[2] = {0};
			char con2[60]   = {0};
			char con3[2]    = {0};
			char con3_fh[2] = {0};
			char con4[30]   = {0};
			char con_idname[128] = {0};
			char con2_idname[128]= {0};
			strncpy(con_id, split_result+1, 10);
			strncpy(con_sn, split_result+11, 4);
			strncpy(con1, split_result+15, 1);
			strncpy(con2, split_result+16, 60);	
			if(0 == strcmp(con1, ">"))
			{
				strcat(con1_fh, "0");
			}
			else if(0 == strcmp(con1, "="))
			{
				strcat(con1_fh, "1");
			}
			else if(0 == strcmp(con1, "<"))
			{
				strcat(con1_fh, "2");
			}	
			memcpy(con_idname, getCName(1, con_id, con_sn), 128);
			if(strstr(con2, "P") && (strstr(con2, "+") || strstr(con2, "-") || strstr(con2, "��") || strstr(con2, "��")))
			{
				memset(con2, 0, sizeof(con2));
				strncpy(con2, split_result+16, 15);	
				strncpy(con3, split_result+31, 1);
				strncpy(con4, split_result+32, 30);
			}
			memcpy(con2_idname, con2, 128);
			if(strstr(con2_idname, "P") && NULL != con3 && NULL != con4 && strlen(con3) > 0 && strlen(con4) > 0)
			{
				memset(con2_idname, 0, sizeof(con2_idname));
				memcpy(con2_idname, getCName(2, con2, ""), 128);
			}		
			if(0 == strcmp(con3, "+"))
			{
				strcat(con3_fh, "0");
			}
			else if(0 == strcmp(con3, "-"))
			{
				strcat(con3_fh, "1");
			}
			else if(0 == strcmp(con3, "��"))
			{
				strcat(con3_fh, "2");
			}	
			else if(0 == strcmp(con3, "��"))
			{
				strcat(con3_fh, "3");
			}	
			
			i++;			
			if(1 == i)
			{
				fprintf(cgiOut, "<div id='ConD%d'>%d.%s %s %s%s%s \n", i, i, con_idname, con1, con2_idname, con3, con4);
				fprintf(cgiOut, "  <img src='../../skin/images/agent_edit.gif' style='cursor:hand' title='�༭' onclick=\"doConditionAdd('%d', '%s', '%s', '%s', '%s', '%s', '%s');\">\n", i, con_id, con_sn, con1_fh, con2, con3_fh, con4);
				fprintf(cgiOut, "  <input type='hidden' id='ConDValue%d' name='ConDValue%d' value='%s'>\n", i, i, split_result);
				fprintf(cgiOut, "</div>\n");
			}
			else
			{
				fprintf(cgiOut, "<div id='ConD%d'>%d.%s %s %s%s%s \n", i, i, con_idname, con1, con2_idname, con3, con4);
				fprintf(cgiOut, "  <img src='../../skin/images/agent_edit.gif' style='cursor:hand' title='�༭' onclick=\"doConditionAdd('%d', '%s', '%s', '%s', '%s', '%s', '%s');\">\n", i, con_id, con_sn, con1_fh, con2, con3_fh, con4);
				fprintf(cgiOut, "  <input type='hidden' id='ConDValue%d' name='ConDValue%d' value='%s'>\n", i, i, split_result);
				fprintf(cgiOut, "  <img src='../../skin/images/cmddel.gif' style='cursor:hand' title='ɾ��' onclick=doConditionDel('%d')>\n", i);
				fprintf(cgiOut, "</div>\n");
			}
			split_result = strtok_r(NULL, "@", &savePtr);
		}	
		for(int j=i+1; j<=8; j++)
		{
			fprintf(cgiOut, "  <div id='ConD%d' style='display:none'></div>\n", j);
		}		
	}
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>ʱ��</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Time' id='Time' style='width:90px;height:25px;' onchange=\"doSwitchTime(this.value)\">\n");
	if(strlen(col_values[4]) < 5)
	{
		fprintf(cgiOut, "	     <option value='0' selected>���趨</option>\n");
	}
	else
	{
		fprintf(cgiOut, "			 <option value='0'>���趨</option>\n");
	}
	
	if(strlen(col_values[4]) > 5 && strlen(col_values[4]) < 15)
	{
		fprintf(cgiOut, "			 <option value='1' selected>��ѭ��</option>\n");
	}
	else
	{
		fprintf(cgiOut, "			 <option value='1'>��ѭ��</option>\n");
	}
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "      <input type='text' id='TimeD' name='TimeD' maxlength='12' value='%s' style='width:125px;height:20px;display:none;'><font color=red>��ʽ:*0600,*1200</font>\n", col_values[4]);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>���</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='link_delay' style='width:90px;height:25px'>\n");
	fprintf(cgiOut, "        <option value=' '  %s>������</option>\n", 0 == strcmp(col_values[5], " ")?"selected":"");
	fprintf(cgiOut, "        <option value='5'  %s>5���� </option>\n", 0 == strcmp(col_values[5], "5")?"selected":"");
	fprintf(cgiOut, "        <option value='10' %s>10����</option>\n", 0 == strcmp(col_values[5], "10")?"selected":"");
	fprintf(cgiOut, "        <option value='20' %s>20����</option>\n", 0 == strcmp(col_values[5], "20")?"selected":"");
	fprintf(cgiOut, "        <option value='30' %s>30����</option>\n", 0 == strcmp(col_values[5], "30")?"selected":"");
	fprintf(cgiOut, "        <option value='45' %s>45����</option>\n", 0 == strcmp(col_values[5], "45")?"selected":"");
	fprintf(cgiOut, "        <option value='60' %s>60����</option>\n", 0 == strcmp(col_values[5], "60")?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>�豸</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Id' id='Id' style='width:250px;height:25px;' onchange=\"doChange(this.value, '')\">\n");		
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = "select a.id, a.cname from device_detail a, device_act b where a.id = b.id group by a.id order by a.id";
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_device_info_upper_agentid, col_values[6], &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='Cmd' id='Cmd' style='width:250px;height:25px;' onchange='doChange2(this.value)'>\n");	
	char sql2[512] = "select a.id, a.sn, a.cmdname, a.status, b.object from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and b.flag = '0' and b.flag1 = '0' and a.id = '";
	strcat(sql2, changevalue);
	strcat(sql2, "'");
	rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_device_cmd, col_values[7], &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Tel' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='Tel' value='%s' style='width:250px;height:20px;' maxlength=256><font color=red>�������/����</font>\n", col_values[8]);	
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Object' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='Object' value='%s' style='width:250px;height:20px;' maxlength=256>\n", col_values[8]);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	fprintf(cgiOut, "  <tr height='30px' id='Call' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='20%%' align='center'>����</td>\n");
	fprintf(cgiOut, "    <td width='80%%' align='left'>\n");
	fprintf(cgiOut, "      <select id='CallSN' name='Call' style='width:250px;height:20px;'>\n");
	
	char sql3[512] = "select a.sn, a.cname from call a";
	rc = sqlite3_exec(db, sql3, &sqlite3_exec_callback_device_call, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	sqlite3_close(db);
	
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<div style='text-align:center;padding-top:5px;'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doAdd()'    src='../../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doCancel()' src='../../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='conDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "<input type='hidden' name='Condition' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//�رմ���
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('conDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//�������ӡ��༭
	fprintf(cgiOut, "function doConditionAdd(pIndex, pId, pSN, pCon1, pCon2, pCon3, pCon4)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var index = pIndex;\n");
	fprintf(cgiOut, "  if('0' == index)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    for(var i=2; i<=9; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(i == 9)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���֧��8������!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(document.getElementById('ConD'+i).style.display == 'none')\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        index = i;\n");
	fprintf(cgiOut, "        break;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('conDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'device_agent.cgi?cmd=5&id='+pId+'&sn='+pSN+'&con1='+pCon1+'&con2='+pCon2+'&con3='+pCon3+'&con4='+pCon4+'&conindex='+index+'&cname=%s&attr_name=%s';\n", cname, attr_name);
	fprintf(cgiOut, "  document.getElementById('conDiv').innerHTML = \"<iframe id='conFrame' name='conFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//����ɾ��
	fprintf(cgiOut, "function doConditionDel(pIndex)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('ConD'+pIndex).style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//�༭
	fprintf(cgiOut, "var reqChg = null;\n");
	fprintf(cgiOut, "function doChange(pValue, pSelCmd)\n");
	fprintf(cgiOut, "{\n");
	//��ɾ��
	fprintf(cgiOut, "  var length = document.getElementById('Cmd').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('Cmd').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	//������
	fprintf(cgiOut, "  var CmdType = '0';\n");
	fprintf(cgiOut, "  if(pValue.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(pValue.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    CmdType = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqChg.onreadystatechange = function(){callbackChangeName(pValue, pSelCmd, CmdType)};\n");
	fprintf(cgiOut, "  var url = 'device_agent.cgi?cmd=4&id='+pValue+'&currtime='+new Date();\n");
	fprintf(cgiOut, "	 reqChg.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqChg.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackChangeName(pValue, pSelCmd, CmdType)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqChg.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqChg.responseText;\n");	
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var list = resp.split('#');\n");
	fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "      		 var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      		 objOption.value = list[i];\n");
	fprintf(cgiOut, "      		 objOption.text = sublist[2];\n");
	fprintf(cgiOut, "      		 document.getElementById('Cmd').add(objOption);\n");
	fprintf(cgiOut, "  			   if(pSelCmd.length > 0)\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "  			     if(pSelCmd == sublist[1])\n");
	fprintf(cgiOut, "  			     {\n");
	fprintf(cgiOut, "  			       objOption.selected = true;\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(agent.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = agent.Object.value.substring(0, agent.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = agent.Object.value.substring(agent.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    agent.Tel.value = tel;\n");
	fprintf(cgiOut, "                    agent.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(agent.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = agent.Tel.value.substring(0, agent.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = agent.Tel.value.substring(agent.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   agent.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "  			     }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "  			   else\n");
	fprintf(cgiOut, "  			   {\n");
	fprintf(cgiOut, "          	 if(i == 0)\n");
	fprintf(cgiOut, "        	   {\n");
	fprintf(cgiOut, "						   objOption.selected = 'true';\n");
	fprintf(cgiOut, "              if('1' == sublist[3])\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if('0' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('1' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "                  if(agent.Object.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "                  {\n");
	fprintf(cgiOut, "                    var tel = agent.Object.value.substring(0, agent.Object.value.indexOf('//'));\n");
	fprintf(cgiOut, "                    var obj = agent.Object.value.substring(agent.Object.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "                    agent.Tel.value = tel;\n");
	fprintf(cgiOut, "                    agent.Object.value = obj;\n");
	fprintf(cgiOut, "                  }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "                else if('2' == CmdType)\n");
	fprintf(cgiOut, "	               {\n");
	fprintf(cgiOut, "	                 document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	                 document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	                 document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	                 if(agent.Tel.value.indexOf('//') >= 0)\n");
	fprintf(cgiOut, "	                 {\n");
	fprintf(cgiOut, "	                   var tel = agent.Tel.value.substring(0, agent.Tel.value.indexOf('//'));\n");
	fprintf(cgiOut, "	                   var call = agent.Tel.value.substring(agent.Tel.value.indexOf('//')+2);\n");
	fprintf(cgiOut, "	                   agent.Tel.value = tel;\n");
	fprintf(cgiOut, "	                   var CallLength = document.getElementById('CallSN').length;\n");
	fprintf(cgiOut, "	                   for(var i=0; i<CallLength; i++)\n");
	fprintf(cgiOut, "	                   {\n");
	fprintf(cgiOut, "	                     var CallOption = document.getElementById('CallSN').options[i];\n");
	fprintf(cgiOut, "	                     if(CallOption.value == call)\n");
	fprintf(cgiOut, "	                     {\n");
	fprintf(cgiOut, "	                       CallOption.selected = 'true';\n");
	fprintf(cgiOut, "	                     }\n");
	fprintf(cgiOut, "	                   }\n");
	fprintf(cgiOut, "	                 }\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "                document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "  			   }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doChange2(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "	 if(pValue.length > 0)\n");
	fprintf(cgiOut, "	 {\n");
	fprintf(cgiOut, "	   var list = pValue.split(',');\n");
	fprintf(cgiOut, "	   var Id = list[0];\n");
	fprintf(cgiOut, "	   var SN = list[1];\n");
	fprintf(cgiOut, "	   var CmdName = list[2];\n");
	fprintf(cgiOut, "	   var Object = list[3];\n");
	fprintf(cgiOut, "	   var CmdType = '0';\n");
	fprintf(cgiOut, "	   if(Id.indexOf('001103') >= 0 && Object == '1')\n");//����
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '1';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if(Id.indexOf('001104') >= 0 && Object == '1')\n");//����
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     CmdType = '2';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   if('0' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     if('1' == Object)\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	     else\n");
	fprintf(cgiOut, "	       document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('1' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = 'none';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = '';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	   else if('2' == CmdType)\n");
	fprintf(cgiOut, "	   {\n");
	fprintf(cgiOut, "	     document.getElementById('Tel').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Call').style.display = '';\n");
	fprintf(cgiOut, "	     document.getElementById('Object').style.display = 'none';\n");
	fprintf(cgiOut, "	   }\n");
	fprintf(cgiOut, "	 }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doSwitchTime(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "if(pValue == '0'){document.getElementById('TimeD').style.display = 'none';}\n");
	fprintf(cgiOut, "if(pValue == '1'){document.getElementById('TimeD').style.display = '';}\n");
	fprintf(cgiOut, "if(pValue == '2'){document.getElementById('TimeD').style.display = '';}\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doChange(agent.Id.value, '%s');\n", EditSelCmd);	
	fprintf(cgiOut, "doSwitchTime(agent.Time.value);\n");		
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");	
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  agent.Condition.value = '';\n");
	fprintf(cgiOut, "  var cnt = 0;\n");
	fprintf(cgiOut, "  for(var i=1; i<=8; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('ConD'+i).style.display == '')\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      cnt++;\n");
	fprintf(cgiOut, "      if(1 == cnt)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        agent.Condition.value += document.getElementById('ConDValue'+i).value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        agent.Condition.value += '@' + document.getElementById('ConDValue'+i).value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(agent.Condition.value.length < 1){alert('����д����!'); return;}\n");
	fprintf(cgiOut, "  var ConDlen = agent.Condition.value.len();\n");
	fprintf(cgiOut, "  if(ConDlen > 128)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ù������뾫��!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  agent.Condition.value = agent.Condition.value.replace(/\\+/g,'%%2B');\n");
	fprintf(cgiOut, "  if(agent.Id.value.length < 1){alert('��ѡ�������豸!'); return;}\n");
	fprintf(cgiOut, "  if(agent.Cmd.value.length < 1){alert('��ѡ����������!');return;}\n");
	fprintf(cgiOut, "  var TimeD = ' ';\n");
	fprintf(cgiOut, "  if('0' != agent.Time.value)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    TimeD = agent.TimeD.value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(TimeD.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    TimeD = ' ';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var Id = agent.Id.value;\n");	
	fprintf(cgiOut, "  var Style = '0';\n");
	fprintf(cgiOut, "  if(Id.indexOf('001103') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '1';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if(Id.indexOf('001104') >= 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Style = '2';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var CmdList = agent.Cmd.value.split(',');\n");
	fprintf(cgiOut, "  var Cmd = CmdList[1];\n");
	fprintf(cgiOut, "  var ObjectFlag = CmdList[3];\n");
	fprintf(cgiOut, "  var StatusFlag = CmdList[4];\n");
	fprintf(cgiOut, "  var Object = '';\n");
	fprintf(cgiOut, "  if('0' == Style)\n");//��ͨ
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      Object = agent.Object.value;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('1' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(agent.Object.value.length < 1 && agent.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = agent.Tel.value + '//' + agent.Object.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else if('2' == Style)\n");//����
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if('1' == ObjectFlag)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(agent.Call.value.length < 1 && agent.Tel.value.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = ' ';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        Object = agent.Tel.value + '//' + agent.Call.value;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(Object.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Object = ' ';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var len = Object.len();\n");	
	fprintf(cgiOut, "  if(len > 256)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ݳ��ȹ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if('0' == StatusFlag)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ����δ����Ϊ���ã��ݲ��ɱ༭!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ���޸�?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqAdd = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqAdd = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqAdd.onreadystatechange = callbackAddName;\n");			
	fprintf(cgiOut, "    var url = 'device_agent.cgi?cmd=3&seq=%s&id=%s&sn=%s&condition='+agent.Condition.value+'&valibtime='+TimeD+'&interval='+agent.link_delay.value+'&d_id='+Id+'&d_cmd='+Cmd+'&object='+Object+'&acttype=2&currtime='+new Date();\n", seq, id, sn);
	fprintf(cgiOut, "    reqAdd.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqAdd.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqAdd.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackAddName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqAdd.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqAdd.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "        if(resp.indexOf('�ɹ�') >= 0 || resp.indexOf('�ύ�ɹ�') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          parent.location = 'device_roll.cgi?cmd=0&id=%s&sn=%s&level=%s&fromtype=%s';\n", id, sn, level, fromtype);
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
	return 0;	
}

void Submit()
{
	if(0 == strcmp(acttype, "1"))
	{
		//��������seq
		int rc;
		char * zErrMsg = 0;
		char sql2[128] = "select max(t.seq)+1 from device_agent t";
		sqlite3 *db = open_db(DB_PATH);
		rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_add, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(2);
		}	
		
		//��ѯ����
		memset(sql2, 0, sizeof(sql2));
		sprintf(sql2, "select a.id from device_agent a where a.id = '%s' and a.sn = '%s' and a.ctype = '0'", id, sn);
		rc = sqlite3_exec(db, sql2, &sqlite3_exec_callback_cnt, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(2);
		}		
		sqlite3_close(db);
	}
	
	int ret = MsgSend(atoi(acttype));
	printf("%s\n", getStatusName(ret));
	
	/*
	if(0 == strcmp(acttype, "1") && cnt >= 256)
	{
		printf("��������256��!\n");
	}
	else
	{
		int ret = MsgSend(atoi(acttype));
		printf("%s\n", getStatusName(ret));
	}
	*/
}

int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL == col_values[0] || strlen(col_values[0]) == 0)
	{
		memcpy(seq, "1", 10);
	}
	else
	{
		memcpy(seq, col_values[0], 10);
	}
	return 0;
}

int sqlite3_exec_callback_cnt(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

//��ȡ����
char *getCName(int pCType, char *pId, char *pSN)
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	char sql[512] = {0};
	switch(pCType)
	{
		case 1:
				strcat(sql, "select a.attr_name from device_roll a where a.id = '");
				strcat(sql, pId);
				strcat(sql, "' and a.sn = '");
				strcat(sql, pSN);
				strcat(sql, "'");
			break;
		case 2:
				strcat(sql, "select '[' || b.cname || ']�ɼ���[' || a.Attr_Name || ']' as cname from device_roll a, device_detail b where a.id = b.id and ('P' || a.id || a.sn) = '");
				strcat(sql, pId);
				strcat(sql, "'");
			break;
	}
	
	memset(GetName, 0, sizeof(GetName));
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_getname, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	return GetName;
}

int sqlite3_exec_callback_getname(void *data, int n_columns, char **col_values, char **col_names)
{
	memcpy(GetName, col_values[0], 128);
	return 0;
}

char *StrRightFillSpace(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	int FillLen = len - strlen(strData);
	strcat(FillStr, strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(FillStr, " ");
	}
	return FillStr;
}

//�����߳�
int MsgSend(int flag)
{	
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	//������װ
	BYTE outbuf[2048] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	int len = 0;
	switch(flag)
	{
		case 1://��������
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002011");
				strcat(pdata, StrRightFillSpace(seq, 10));
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 4));
				strcat(pdata, StrRightFillSpace(condition, 128));
				strcat(pdata, StrRightFillSpace(valibtime, 30));
				strcat(pdata, StrRightFillSpace(interval, 4));
				strcat(pdata, StrRightFillSpace(d_id, 10));
				strcat(pdata, StrRightFillSpace(d_cmd, 8));
				strcat(pdata, StrRightFillSpace(object, 256));
				strcat(pdata, "0");
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 4 + 128 + 30 + 4 + 10 + 8 + 256 + 1;
			break;
		case 2://�����༭
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002012");
				strcat(pdata, StrRightFillSpace(seq, 10));				
				strcat(pdata, StrRightFillSpace(id, 10));		
				strcat(pdata, StrRightFillSpace(sn, 4));
				strcat(pdata, StrRightFillSpace(condition, 128));
				strcat(pdata, StrRightFillSpace(valibtime, 30));	
				strcat(pdata, StrRightFillSpace(interval, 4));
				strcat(pdata, StrRightFillSpace(d_id, 10));
				strcat(pdata, StrRightFillSpace(d_cmd, 8));
				strcat(pdata, StrRightFillSpace(object, 256));
				strcat(pdata, "0");
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 4 + 128 + 30 + 4 + 10 + 8 + 256 + 1;
			break;
		case 3://����ɾ��
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002013");
				strcat(pdata, StrRightFillSpace(seq, 10));
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 4));
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 4;
			break;
	}
	
	//AddMsg((BYTE *)outbuf, 1024);
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	
	char *ip = getLocalIP();
	
	//����
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	pSock->SetCompletion();
		
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return SYS_STATUS_FORMAT_ERROR;
	}
	
	char szBuf[512] = {0};
	if(true == pSock->IsPending(30000))
	{
	 	if((len = pSock->Recv(szBuf, 512)) <= 0) 
		{
			pSock->EndSocket();
			return SYS_STATUS_SYS_BUSY;
		}
		
		//���շ���
		pMsgHdr = (PMsgHdr)szBuf;
		char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
		char result[5] = {0};
		strncpy(result, pmsg+20, 4);
		pSock->EndSocket();
		return atoi(result);
	}
	else
	{
		pSock->EndSocket();
		return SYS_STATUS_TIMEOUT;
	}
	
	//�ر�����
	pSock->EndSocket();
	return SYS_STATUS_FAILED;
}
