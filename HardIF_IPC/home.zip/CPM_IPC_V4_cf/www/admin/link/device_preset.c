#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"

//��������
char Sql[1024] = {0};
char cmd[4]    = {0};
int cnt = 0;
int ip_type = 0;//0Ĭ��Ϊ����
//��ƵԤ��
char PresetData[2048]    = {0};
char newPresetData[2048] = {0};
char nindex[10]          = {0};
char id[11]              = {0};
char cname[31]           = {0};
char preset[1024]        = {0};
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
//��ȡ�ͻ���IP��ַ
static void cgiGetenv(char **s, char *var);
//IP���ж�(0:������1:������)
static int getIP_Type();
//̽ͷ��ѯ
static void QueryData();
static int sqlite3_exec_callback_dvr_tree(void *data, int n_columns, char **col_values, char **col_names);
//��ѯԤ�õ�
static void QueryPreset();
static int sqlite3_exec_callback_preset_info(void *data, int n_columns, char **col_values, char **col_names);
//�޸�Ԥ�õ�
static void UpdateData();
//ɾ��Ԥ�õ�
static void UdpPreset();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();
	
	char *p;
	char strnindex[10] = {0};
	char strnextnindex[10] = {0};
	
	cnt = 0;
	memset(PresetData, 0, sizeof(PresetData));
	memset(newPresetData, 0, sizeof(newPresetData));
	switch(atoi(cmd))
	{
		case 0://̽ͷ��ѯ
			cgiGetenv(&cgiRemoteAddr, "REMOTE_ADDR");
			ip_type = getIP_Type();
			QueryData();
			break;
		case 6://Ԥ�õ��ѯ
			QueryPreset();
			printf("%s", PresetData);
			break;
		case 7://����Ԥ�õ�
			QueryPreset();
			
			strcat(strnindex, nindex);
			strcat(strnindex, ",");
			p = strstr(PresetData, strnindex);
			if(p)
			{
				strncpy(newPresetData, PresetData, strlen(PresetData)-strlen(p));
				strcat(newPresetData, strnindex);
				strcat(newPresetData, cname);
				strcat(newPresetData, ";");
				
				char *subp;
				sprintf(strnextnindex, "%d", atoi(nindex)+1);
				strcat(strnextnindex, ",");
				subp = strstr(PresetData, strnextnindex);
				if(subp)
				{
					strcat(newPresetData, subp);
				}
			}
			else
			{
				strcat(newPresetData, PresetData);
				strcat(newPresetData, strnindex);
				strcat(newPresetData, cname);
				strcat(newPresetData, ";");
			}
			
			sprintf(cmd, "%s", "7");
			UpdateData();
			
			memset(PresetData, 0, sizeof(PresetData));
			QueryPreset();
			printf("%s", PresetData);
			break;
		case 8://ɾ��Ԥ�õ�
			UdpPreset();
			break;
	}
	
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("preset", preset, sizeof(preset));
	cgiFormString("nindex", nindex, sizeof(nindex));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 6://��ѯԤ�õ�
			strcat(Sql, "select a.id, a.cname, a.preset from device_detail a where a.id = '");
			strcat(Sql, id);
			strcat(Sql, "' ");
			break;
		case 7://����Ԥ�õ�
			strcat(Sql, "update device_detail set preset = '");
			strcat(Sql, newPresetData);
			strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 8://ɾ��Ԥ�õ�
			strcat(Sql, "update device_detail set preset = '");
			strcat(Sql, preset);
			strcat(Sql, "' where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
	}
	return Sql;
}

void cgiGetenv(char **s, char *var)
{
	*s = getenv(var);
	if (!(*s)) {
		*s = "";
	}
}

int getIP_Type()
{
	int resp = 0;
	char tempip[20] = {0};
	if(NULL == cgiRemoteAddr || strlen(cgiRemoteAddr) < 3)
	{
		return 0;
	}

	char ip1[4] = {0};
	char ip2[9] = {0};
	char ip3[5] = {0};
	
	sprintf(ip1, "%s", "10.");
	sprintf(ip2, "%s", "192.168.");
	sprintf(ip3, "%s", "172.");
	
	strncpy(tempip, cgiRemoteAddr, strlen(ip1));
	if(0 == strcmp(tempip, ip1))
	{
		resp = 1;
		return resp;
	}
	memset(tempip, 0, sizeof(tempip));
	strncpy(tempip, cgiRemoteAddr, strlen(ip2));
	if(0 == strcmp(tempip, ip2))
	{
		resp = 1;
		return resp;
	}
	memset(tempip, 0, sizeof(tempip));
	strncpy(tempip, cgiRemoteAddr, strlen(ip3));
	if(0 == strcmp(tempip, ip3) && strlen(cgiRemoteAddr) >= 7)
	{
		memset(tempip, 0, sizeof(tempip));
		tempip[0] = cgiRemoteAddr[4];
		tempip[1] = cgiRemoteAddr[5];
		if('.' == cgiRemoteAddr[6] && atoi(tempip) >= 16 && atoi(tempip) <= 32)
		{
			resp = 1;
		  return resp;
		}
	}
	return resp;
}

void QueryData()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head>\n");
	fprintf(cgiOut, "<title>̽ͷ��ѯ</title>\n");
	fprintf(cgiOut, "<meta http-equiv=Content-Type content='text/html;charset=gb2312'>\n");
	fprintf(cgiOut, "<link type='text/css' href='../../skin/css/main.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<body onbeforeunload='doDeletePlayer()' onclose='doDeletePlayer()'>\n");
	fprintf(cgiOut, "  <div id='container' style='float:left;overflow:hidden;width:60%;min-width:987px;_width:987px;margin:0 0 0 0;background:#595957;'>\n");
	fprintf(cgiOut, "    <div style='width:987px;height:60px;border:0px solid #0068a6;text-align:left;overflow-x:no;overflow-y:auto;'>\n");
	fprintf(cgiOut, "      <table width='97%%' border=0>\n");
	fprintf(cgiOut, "        <tr height='25px'>\n");
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql1[512] = "select t.id, t.cname, t.upper, t.private_attr, t.upper_channel, a.s_icon, b.private_attr as upper_private_attr from device_detail t, device_info a, device_detail b where substr(t.id,1,6) = a.id and t.upper = b.id and t.ctype = '03' and t.upper <> '0011010001' order by t.id";
	rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_dvr_tree, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(3);
	}
	sqlite3_close(db);
	
	int x = cnt%4;
	switch(x)
	{
		case 1:
			fprintf(cgiOut, "<td width='75%%' align='left' colspan=3>&nbsp;</td>\n");
			break;
		case 2:
			fprintf(cgiOut, "<td width='50%%' align='left' colspan=2>&nbsp;</td>\n");
			break;
		case 3:
			fprintf(cgiOut, "<td width='25%%' align='left'>&nbsp;</td>\n");
			break;
	}
	
	fprintf(cgiOut, "        </tr>\n");
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </div>\n");
	fprintf(cgiOut, "    <div>\n");
	fprintf(cgiOut, "      <OBJECT id='BestPlayer'\n");
	fprintf(cgiOut, "        codeBase='../../cab/BPlayer.cab#version=1,0,0,3'\n");
	fprintf(cgiOut, "        classid='clsid:F695FFBD-37DC-4118-B1AB-6CBBE35D053F'\n");
	fprintf(cgiOut, "        width='987'\n");
	fprintf(cgiOut, "        height='420' VIEWASTEXT events='True'>\n");
	fprintf(cgiOut, "        <PARAM NAME='MRL' VALUE=''>\n");
	fprintf(cgiOut, "        <PARAM NAME='ShowDisplay' VALUE='True'>\n");
	fprintf(cgiOut, "        <PARAM NAME='AutoLoop'    VALUE='false'>\n");
	fprintf(cgiOut, "        <PARAM NAME='AutoPlay'    VALUE='true'>\n");
	fprintf(cgiOut, "        <PARAM NAME='Volume'      VALUE='50'>\n");
	fprintf(cgiOut, "        <PARAM NAME='StartTime'   VALUE='0'>\n");
	fprintf(cgiOut, "      </OBJECT>\n");
	fprintf(cgiOut, "      <script language='javascript'>\n");
	fprintf(cgiOut, "        setTimeout(function(){BestPlayer.ResetPlayer(3,1);}, 10);\n");
	fprintf(cgiOut, "      </script>\n");
	fprintf(cgiOut, "    </div>\n");
	fprintf(cgiOut, "  </div>\n");
	fprintf(cgiOut, "  <iframe id='ChildFrame' name='ChildFrame' style='position:absolute;left:802px;top:80px;width:170px;height:350px;' \n");
	fprintf(cgiOut, "    frameborder='no' \n");
	fprintf(cgiOut, "    border='0'       \n");
	fprintf(cgiOut, "    marginwidth='0'  \n");
	fprintf(cgiOut, "    marginheight='0' \n");
	fprintf(cgiOut, "    scrolling='no'   \n");
	fprintf(cgiOut, "    src='device_preset_ctrl.html'>\n");
  fprintf(cgiOut, "  </iframe>\n");
  fprintf(cgiOut, "  <input id='CurrDeviceId' name='CurrDeviceId' type='hidden' value=''/>\n");
  fprintf(cgiOut, "  <input id='CurrChannel'  name='CurrChannel'  type='hidden' value=''/>\n");
	fprintf(cgiOut, "</body>\n");
	fprintf(cgiOut, "<script LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doDeletePlayer()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  BestPlayer.StopAll();\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doDVR(pSN, CurrIp_Type, CurrDeviceId, CurrChannel, CurrIP, CurrPort, CurrINIP, CurrINPort, CurrLoginId, CurrLoginPwd, CurrStream, CurrPan_Tilt)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  for(var i=0; i<%d; i++)\n", cnt);
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(document.getElementById('radio'+i))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(i == parseInt(pSN))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('radio'+i).checked = true;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('radio'+i).checked = false;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  //������Ƶ\n");
	fprintf(cgiOut, "  var Using_Ip = '';\n");
	fprintf(cgiOut, "  var Using_Port = '';\n");
	fprintf(cgiOut, "  if(CurrIp_Type == '1')//������\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Using_Ip = CurrINIP;\n");
	fprintf(cgiOut, "    Using_Port = CurrINPort;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Using_Ip = CurrIp;\n");
	fprintf(cgiOut, "    Using_Port = CurrPort;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(null == Using_Ip || Using_Ip.length < 3 || null == Using_Port || Using_Port.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('DVR��δ����IP��˿ڣ���������������Ƶ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  //alert(Using_Ip+ ','+Using_Port);\n");
	fprintf(cgiOut, "  BestPlayer.PlayDvr(parseInt(CurrStream), 1, parseInt(CurrPan_Tilt, 10), parseInt(CurrChannel, 10), Using_Ip, parseInt(Using_Port, 10), CurrLoginId, CurrLoginPwd);\n");
	fprintf(cgiOut, "  //��ѯԤ�õ�\n");
	fprintf(cgiOut, "  document.getElementById('CurrDeviceId').value = CurrDeviceId;\n");
	fprintf(cgiOut, "  document.getElementById('CurrChannel').value = CurrChannel;\n");
	fprintf(cgiOut, "  doPresetSelect(CurrChannel, CurrDeviceId);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doPresetSelect(CurrChannel, CurrDeviceId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(null == CurrChannel || CurrChannel.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  xhr = createXHR();\n");
	fprintf(cgiOut, "  if(xhr)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    xhr.onreadystatechange = callbackFunction;\n");
	fprintf(cgiOut, "    var url = 'device_preset.cgi?cmd=6&id='+CurrDeviceId+'&currtime='+new Date();\n");
	fprintf(cgiOut, "    xhr.open('get', url);\n");
	fprintf(cgiOut, "    xhr.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������֧�֣�������������');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function createXHR()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var xhr;\n");
	fprintf(cgiOut, "  try\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    xhr = new ActiveXObject('Msxml2.XMLHTTP');\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  catch(e)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    try\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      xhr = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    catch(E)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      xhr = false;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(!xhr && typeof XMLHttpRequest != 'undefined')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    xhr = new XMLHttpRequest();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  return xhr;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackFunction()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(xhr.readyState == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(xhr.status == 200)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var objTable = ChildFrame.PresetTable;\n");
	fprintf(cgiOut, "      var resp = xhr.responseText;\n");
	fprintf(cgiOut, "      if(null == resp || resp.length < 1)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var rowlen = objTable.rows.length;\n");
	fprintf(cgiOut, "        for(var rowIndex = 0; rowIndex<rowlen; rowIndex++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          objTable.deleteRow(0);\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      resp = resp.substring(0, resp.length-1);\n");
	fprintf(cgiOut, "      var rowlen = objTable.rows.length;\n");
	fprintf(cgiOut, "      for(var rowIndex = 0; rowIndex<rowlen; rowIndex++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objTable.deleteRow(0);\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var tempArray = resp.split(';');\n");
	fprintf(cgiOut, "      var i = 0;\n");
	fprintf(cgiOut, "      for(i=0; i<tempArray.length; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var tempValue = tempArray[i].split(',')[0];\n");
	fprintf(cgiOut, "        var tempName = tempArray[i].split(',')[1];\n");
	fprintf(cgiOut, "        var subRow = objTable.insertRow(parseInt(i));\n");
	fprintf(cgiOut, "        subRow.height = '20px';\n");
	fprintf(cgiOut, "        var subCellLeft = subRow.insertCell(0);\n");
	fprintf(cgiOut, "        subCellLeft.width = '10%%';\n");
	fprintf(cgiOut, "        subCellLeft.innerHTML = tempValue;\n");
	fprintf(cgiOut, "        var subCellCenter = subRow.insertCell(1);\n");
	fprintf(cgiOut, "        subCellCenter.width = '50%%';\n");
	fprintf(cgiOut, "        subCellCenter.innerHTML = tempName;\n");
	fprintf(cgiOut, "        var subCellright = subRow.insertCell(2);\n");
	fprintf(cgiOut, "        subCellright.align = 'center';\n");
	fprintf(cgiOut, "        subCellright.width = '20%%';\n");
	fprintf(cgiOut, "        subCellright.innerHTML = \"<a href='#' onClick=doPresetCtl('\"+tempValue+\"')>ת��</a>\";\n");
	fprintf(cgiOut, "        var subCellright = subRow.insertCell(3);\n");
	fprintf(cgiOut, "        subCellright.align = 'center';\n");
	fprintf(cgiOut, "        subCellright.width = '20%%';\n");
	fprintf(cgiOut, "        subCellright.innerHTML = \"<a href='#' onClick=doPresetDel('\"+tempArray[i]+\"','\"+resp+\"')>ɾ��</a>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(i < 14)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        for(; i<14; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var subRow = objTable.insertRow(parseInt(i));\n");
	fprintf(cgiOut, "          subRow.height = '20px';\n");
	fprintf(cgiOut, "          var subCellLeft = subRow.insertCell(0);\n");
	fprintf(cgiOut, "          subCellLeft.width = '10%%';\n");
	fprintf(cgiOut, "          subCellLeft.innerHTML = '&nbsp';\n");
	fprintf(cgiOut, "          var subCellCenter = subRow.insertCell(1);\n");
	fprintf(cgiOut, "          subCellCenter.width = '50%%';\n");
	fprintf(cgiOut, "          subCellCenter.innerHTML = '&nbsp';\n");
	fprintf(cgiOut, "          var subCellright = subRow.insertCell(2);\n");
	fprintf(cgiOut, "          subCellright.width = '20%%';\n");
	fprintf(cgiOut, "          subCellright.innerHTML = '&nbsp';\n");
	fprintf(cgiOut, "          var subCellright = subRow.insertCell(3);\n");
	fprintf(cgiOut, "          subCellright.width = '20%%';\n");
	fprintf(cgiOut, "          subCellright.innerHTML = '&nbsp';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('ҳ������쳣��');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</html>\n");
}

int sqlite3_exec_callback_dvr_tree(void *data, int n_columns, char **col_values, char **col_names)
{
	char outip[21]      = {0};
	char outport[10]    = {0};
	char inip[21]       = {0};
	char inport[10]     = {0};
	char login_id[21]   = {0};
	char login_pwd[21]  = {0};
	char code_stream[2] = {0};
	char pan_tilt[2]    = {0};
	
	sprintf(outip,       "%s", define_sscanf(col_values[6], "outip="));
	sprintf(outport,     "%s", define_sscanf(col_values[6], "outport="));
	sprintf(inip,        "%s", define_sscanf(col_values[6], "inip="));
	sprintf(inport,      "%s", define_sscanf(col_values[6], "inport="));
	sprintf(login_id,    "%s", define_sscanf(col_values[6], "login_id="));
	sprintf(login_pwd,   "%s", define_sscanf(col_values[6], "login_pwd="));
	sprintf(code_stream, "%s", define_sscanf(col_values[6], "code_stream="));
	sprintf(pan_tilt,    "%s", define_sscanf(col_values[3], "pan_tilt="));
	
	if(0 != strcmp(pan_tilt, "0"))
	{
		if(0 == cnt%4 && cnt > 0)
		{
			fprintf(cgiOut, "</tr>\n");
			fprintf(cgiOut, "<tr height='25px'>\n");
		}
		
		fprintf(cgiOut, "<td width='25%%' align='left'>\n");
		fprintf(cgiOut, "  <input type='radio' id='radio%d' name='radio%d' onclick=\"doDVR('%d','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')\">%s\n", cnt, cnt, cnt, ip_type, col_values[0], col_values[4], outip, outport, inip, inport, login_id, login_pwd, code_stream, pan_tilt, col_values[1]);
		fprintf(cgiOut, "</td>\n");
		
		cnt++;
	}
	
	return 0;
}

void QueryPreset()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(6), &sqlite3_exec_callback_preset_info, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_preset_info(void *data, int n_columns, char **col_values, char **col_names)
{
	sprintf(PresetData, "%s", col_values[2]);
	return 0;
}

void UdpPreset()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(8), &sqlite3_exec_callback_preset_info, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	printf("0000\n");
}

//�޸�
void UpdateData()
{		
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(atoi(cmd)), &sqlite3_exec_callback_preset_info, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}
