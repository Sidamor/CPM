#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"
//��������
char Sql[1024] = {0};
char cmd[4] = {0};
int cnt = 0;
int cnt2 = 0;
int cnt3 = 0;
int cnt4 = 0;
int cnt5 = 0;
char FillStr[1024] = {0};
char level[2] = {0};               //����ʱ����
char channel_type[10] = {0};       //�ӿ�����
char sn[9] = {0};                  //�������
char cmdname[30] = {0};            //��������
char v_id[11] = {0};					     //����������
char v_sn[9] = {0};						     //����������
char v_private_attr[256] = {0};    //����˽�����Դ��
char object[520] = {0};
char isflag[2] = {0};              //���¼����
char isflag2[2] = {0};
char isobject[2] = {0};
char obj_insert[9] = {0};
char realmode[4096] = {0};         //ʵʱģʽ��Ϣ
char ctype1[3] = {0};
char ctype2[3] = {0};
char ctype3[5] = {0};
char self_idflag[2] = {0};
char self_value[128] = {0};
char self_value2[128] = {0};
char self_parent[21] = {0};
char self_ischag[2] = {0};
//��device_detail
char id[11] = {0};								 //���
char cname[31] = {0};							 //����
char upper[11] = {0};              //�ϼ����
char upper_channel[3] = {0};       //�ϼ�ͨ����
char be_on[2] = {0};							 //Ŀǰ�Ƿ�����0:����,1:����
char status[2] = {0};							 //״̬0ͣ��,1����
char dev_type[3] = {0};            //Ӧ������
char self_id[21] = {0};            //��ͨ����
char preset[1024] = {0};           //Ԥ�õ�����
char private_attr[256] = {0};	     //˽�����Դ��
char brief[21] = {0};              //���
char memo[129] = {0};              //��ע
char info_upper[11] = {0};         //�ϼ���ſ���
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
void icuContainiFunc(sqlite3_context *p, int nArg, sqlite3_value **apArg);
char *getStatusName(int pStatus);
char *StrLeftFillZero(char *strData, int len);
char *StrRightFillSpace(char *strData, int len);
void AddMsg(unsigned char *str,int num);
//��ȡ���¶���
char *getB_NCmd(int pCType, char *pId, char *pModeId, char *pSN);
static int sqlite3_exec_callback_getB_NCmd(void *data, int n_columns, char **col_values, char **col_names);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
//����ҳ��
static void QueryForAdd();
static void QueryAgent();
static int sqlite3_exec_callback_manufacturer(void *data, int n_columns, char **col_values, char **col_names);
static void QueryDeviceInfo();
static int sqlite3_exec_callback_device_info(void *data, int n_columns, char **col_values, char **col_names);
static void UpperChannel();
static int sqlite3_exec_callback_upperchannel(void *data, int n_columns, char **col_values, char **col_names);
//����
static void AddTrue();
static int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names);
//�޸�ҳ��
static void QueryForUdp();
static int sqlite3_exec_callback_forudp(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_attr(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_alert(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cmd(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cmd_0(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_selforupd(void *data, int n_columns, char **col_values, char **col_names);
//�޸�
static void UdpTrue();
//ɾ��
static void DelTrue();
//�����༭
static void CmdAdd();
static int sqlite3_exec_callback_act_dev(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cmdadd(void *data, int n_columns, char **col_values, char **col_names);
static void CmdAddTrue();
static void CmdActTrue();
static void CmdObject();
static int sqlite3_exec_callback_call(void *data, int n_columns, char **col_values, char **col_names);
static void QueryAct();
static int sqlite3_exec_callback_queryact(void *data, int n_columns, char **col_values, char **col_names);
//��ѯִ�л���
static void SelForAct();
static int sqlite3_exec_callback_selforact(void *data, int n_columns, char **col_values, char **col_names);
//ͨѶ
static int MsgSend(int flag);
char *getLocalIP();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			cnt2 = 0;
			cnt3 = 0;
			cnt4 = 0;
			cnt5 = 0;
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://����ҳ��
					QueryForAdd();
					break;
				case 2://��ѯ�豸����
					QueryDeviceInfo();
					break;
				case 3://����
					AddTrue();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 4://�޸�ҳ��
					QueryForUdp();
					break;
				case 5://�޸�
					UdpTrue();
					break;
				case 6://ɾ��
					DelTrue();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 7://��ѯ����
					QueryAgent();
					break;
				case 8://�����༭
					CmdAdd();
					break;
				case 13://������ѯ
					QueryAct();
					break;
				case 9://�����༭
					CmdAddTrue();
					break;
				case 10://����ִ��
					CmdActTrue();
					break;
				case 11://����ִ��
					CmdObject();
					break;
				case 12://��ѯִ�л���
					SelForAct();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){window.parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){window.open('../index.html', '_top');}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('2')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("upper", upper, sizeof(upper));
	cgiFormString("upper_channel", upper_channel, sizeof(upper_channel));
	cgiFormString("be_on", be_on, sizeof(be_on));
	cgiFormString("status", status, sizeof(status));
	cgiFormString("ctype", dev_type, sizeof(dev_type));
	cgiFormString("self_id", self_id, sizeof(self_id));
	cgiFormString("preset", preset, sizeof(preset));
	cgiFormString("private_attr", private_attr, sizeof(private_attr));
	cgiFormString("brief", brief, sizeof(brief));
	cgiFormString("memo", memo, sizeof(memo));
	
	cgiFormString("level", level, sizeof(level));	
	cgiFormString("channel_type", channel_type, sizeof(channel_type));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("cmdname", cmdname, sizeof(cmdname));
	cgiFormString("v_id", v_id, sizeof(v_id));
	cgiFormString("v_sn", v_sn, sizeof(v_sn));
	cgiFormString("v_private_attr", v_private_attr, sizeof(v_private_attr));
	cgiFormString("object", object, sizeof(object));
	cgiFormString("isflag", isflag, sizeof(isflag));
	cgiFormString("isflag2", isflag2, sizeof(isflag2));
	cgiFormString("isobject", isobject, sizeof(isobject));
	cgiFormString("obj_insert", obj_insert, sizeof(obj_insert));
	cgiFormString("ctype1", ctype1, sizeof(ctype1));
	cgiFormString("ctype2", ctype2, sizeof(ctype2));
	cgiFormString("ctype3", ctype3, sizeof(ctype3));
	cgiFormString("self_idflag", self_idflag, sizeof(self_idflag));
	cgiFormString("self_value", self_value, sizeof(self_value));
	cgiFormString("self_value2", self_value2, sizeof(self_value2));
	cgiFormString("self_parent", self_parent, sizeof(self_parent));
	cgiFormString("self_ischag", self_ischag, sizeof(self_ischag));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0://��ѯ
      strcat(Sql, "select a.id, a.cname, a.upper, a.upper_channel, a.be_on, a.status, a.ctype, a.self_id, a.preset, a.private_attr, b.brief, c.cname, c.s_icon, c.composition, c.private_attr, c.channel_type, a.brief, c.id, c.ctype1, c.ctype2, c.ctype3, a.memo from device_detail a, manufacturer b, device_info c where substr(a.id,1,3) = b.id and substr(a.id,1,6) = c.id order by a.id");
			break;
		case 1://���̲�ѯ
			strcat(Sql, "select a.id, a.brief from manufacturer a, device_info b where a.id = substr(b.id,1,3) and contain(b.channel_type, '");
			strcat(Sql, channel_type);
			strcat(Sql, "') = 1 and b.status = '1' group by a.id order by a.id");		
			break;
		case 2://���ݳ��̲�����
			strcat(Sql, "select a.id, a.cname, a.private_attr, a.ctype1, a.ctype2, a.ctype3 from device_info a where substr(a.id,1,3) = '");
			strcat(Sql, id);
			strcat(Sql, "' and a.status = '1' and a.id <> '001101' and a.id <> '001102' and a.id <> '001103' and a.id <> '001104' and contain(a.channel_type, '");
			strcat(Sql, channel_type);
			strcat(Sql, "') = 1 order by a.id");
			break;
		case 3://�������ɱ��
			strcat(Sql, "select max(substr(a.id,7,4))+1 from device_detail a where substr(a.id,1,6) = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 4://�޸Ĳ�ѯ
			strcat(Sql, "select a.id, a.cname, a.upper, a.upper_channel, a.be_on, a.status, a.ctype, a.self_id, a.preset, a.private_attr, b.brief, c.cname, c.s_icon, c.composition, c.private_attr, c.channel_type, a.brief, c.id, c.ctype1, c.ctype2, c.ctype3, a.memo from device_detail a, manufacturer b, device_info c where substr(a.id,1,3) = b.id and substr(a.id,1,6) = c.id and a.id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 5://��ѯ�ӿ�
			strcat(Sql, "select b.composition from device_detail a, device_info b where substr(a.id,1,6) = b.id and a.id = '");
			strcat(Sql, info_upper);
			strcat(Sql, "' order by a.id");
			break;
		case 10://����
			strcat(Sql, "insert into device_detail(id, cname, upper, upper_channel, ctype, self_id, private_attr, status, brief, memo)values('");
			strcat(Sql, id);
			strcat(Sql, "', '");
			strcat(Sql, cname);
			strcat(Sql, "', '");
			strcat(Sql, upper);
			strcat(Sql, "', '");
			strcat(Sql, upper_channel);
			strcat(Sql, "', '");
			strcat(Sql, dev_type);
			strcat(Sql, "', '");
			strcat(Sql, self_id);
			strcat(Sql, "', '");
			strcat(Sql, private_attr);
			strcat(Sql, "', '");
			strcat(Sql, "2");
			strcat(Sql, "', '");
			strcat(Sql, brief);
			strcat(Sql, "', '");
			strcat(Sql, memo);
			strcat(Sql, "')");
			break;
		case 11://�޸�
			strcat(Sql, "update device_detail set cname = '");
      strcat(Sql, cname);
			strcat(Sql, "', ctype = '");
      strcat(Sql, dev_type);
			strcat(Sql, "', self_id = '");
      strcat(Sql, self_id);
      strcat(Sql, "', private_attr = '");
      strcat(Sql, private_attr);   
      strcat(Sql, "', brief = '");
      strcat(Sql, brief); 
      strcat(Sql, "', memo = '");
      strcat(Sql, memo);
			strcat(Sql, "' where id = '");
      strcat(Sql, id);
			strcat(Sql, "'");
			break;		
		case 12://ɾ��
			strcat(Sql, "delete from device_detail where id = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
		case 13://ɾ��
			strcat(Sql, "delete from device_detail where upper = '");
			strcat(Sql, id);
			strcat(Sql, "'");
			break;
	}
	return Sql;
}

void QueryData()
{
	fprintf(cgiOut, "<HTML>\n");
  fprintf(cgiOut, "<HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-�豸����</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv='Content-Type' content='text/html;charset=gb2312'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/style.css' rel='stylesheet'/>\n");
	fprintf(cgiOut, "<link type='text/css' href='../skin/css/zTreeStyle2.css' rel='stylesheet'/>\n");	
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/jquery-1.4.4.min.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/jquery.ztree.core-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/jquery.ztree.excheck-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/jquery.ztree.exedit-3.4.js'></script>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/util.js'></script>\n");
	fprintf(cgiOut, "<script language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</script>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"device_detail\" action=\"device_topo.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../skin/images/device_set.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"85%%\" style='margin:auto' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "      <a href='device_detail.cgi?cmd=0'><U><font color=green>ת�ӿ���</font></U></a>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center'>\n");
	fprintf(cgiOut, "      <table width=\"100%%\" style='margin:auto' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "        <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "          <td width='20%%' align='right'valign='top'><ul id='areaTree' class='ztree'></ul></td>\n");
	fprintf(cgiOut, "          <td width='80%%' align='center' valign='top'>\n");
	fprintf(cgiOut, "	           <table width='100%%' border=0>\n");
	fprintf(cgiOut, "	 	           <tr>\n");
	fprintf(cgiOut, "	 	 	           <td width='100%%' align=right>&nbsp;<img id='add' src=\"../skin/images/mini_button_add.gif\" style='cursor:hand;display:none' onClick='doAdd()'/><img id='delete' src=\"../skin/images/submit_delete.gif\" style='cursor:hand;display:none' onClick='doDelete()'/><img id='edit' style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doEdit()'></td>\n");
	fprintf(cgiOut, "	 	           </tr>\n");
	fprintf(cgiOut, "	 	           <tr>\n");
	fprintf(cgiOut, "	 	 	           <td width='100%%' align=left id='Dev_Type'><iframe id='childFrame' name='childFrame' src='' frameborder=0 width='100%%' height='400px' scrolling='auto'></iframe></td>\n");
	fprintf(cgiOut, "	 	           </tr>\n");
	fprintf(cgiOut, "	           </table>\n");
	fprintf(cgiOut, "          </td>\n");
	fprintf(cgiOut, "        </tr>\n");	
	fprintf(cgiOut, "      </table>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");	
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='level' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='cname' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='upper' value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "var Nodes1 = [];\n");
  fprintf(cgiOut, "var setting = \n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  edit: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    enable: false\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  data: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    simpleData:{enable: true}\n");
	fprintf(cgiOut, "  },\n");
	fprintf(cgiOut, "  callback: \n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    onClick: zTreeOnClick\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "};\n");
  
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(3);
	}
	sqlite3_close(db);
	
	if(cnt == 0)
	{
		fprintf(cgiOut, "var node = {name:'����', value:'-1', target:'mainFrame', icon:'../skin/images/camera.png', pId:'-1', id:'-1', ctype1:'', open:true};\n");
		fprintf(cgiOut, "Nodes1.push(node);\n");
		memset(id, 0, sizeof(id));
		memcpy(id, "-1", 11);
	}
	
	//������
	fprintf(cgiOut, "$('#areaTree').empty();\n");
	fprintf(cgiOut, "$.fn.zTree.init($('#areaTree'), setting, Nodes1);\n");
	
	//���
	fprintf(cgiOut, "function zTreeOnClick(event, treeId, treeNode)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(treeNode.value == '-1')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('add').style.display = 'none';\n");
	fprintf(cgiOut, "    document.getElementById('delete').style.display = 'none';\n");
	fprintf(cgiOut, "    var url = 'device_topo.cgi?cmd=1&level=0&upper=&upper_channel=';\n");
	fprintf(cgiOut, "    document.getElementById(\"Dev_Type\").innerHTML = \"<iframe id='childFrame' name='childFrame' src='\"+url+\"' frameborder=0 width='100%%' height='400px' scrolling='auto'></iframe>\";\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    device_detail.level.value = treeNode.level;\n");
	fprintf(cgiOut, "    device_detail.cname.value = treeNode.name;\n");
	fprintf(cgiOut, "    device_detail.upper.value = treeNode.value;\n");		
	fprintf(cgiOut, "    if('0' == treeNode.level)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(treeNode.value.indexOf('0011010001') >= 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('add').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('delete').style.display = 'none';\n");
	fprintf(cgiOut, "        document.getElementById('edit').style.display = '';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('add').style.display = 'none';\n");
	fprintf(cgiOut, "        document.getElementById('delete').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('edit').style.display = '';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if('1' == treeNode.level)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      document.getElementById('add').style.display = '';\n");
	fprintf(cgiOut, "      document.getElementById('edit').style.display = '';\n");
	fprintf(cgiOut, "      if(treeNode.value.indexOf('0011020001') >= 0)\n");
	fprintf(cgiOut, "        document.getElementById('delete').style.display = 'none';\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "        document.getElementById('delete').style.display = '';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if('2' == treeNode.level)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(treeNode.ctype1.length == 2)\n");
	fprintf(cgiOut, "        document.getElementById('add').style.display = '';\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "        document.getElementById('add').style.display = 'none';\n");
	fprintf(cgiOut, "      if(treeNode.value.indexOf('0011030001') >= 0 || treeNode.value.indexOf('0011040001') >= 0)\n");
	fprintf(cgiOut, "        document.getElementById('delete').style.display = 'none';\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "        document.getElementById('delete').style.display = '';\n");
	fprintf(cgiOut, "      document.getElementById('edit').style.display = '';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if('3' == treeNode.level)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      document.getElementById('add').style.display = 'none';\n");
	fprintf(cgiOut, "      document.getElementById('delete').style.display = '';\n");
	fprintf(cgiOut, "      document.getElementById('edit').style.display = '';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    var url = 'device_topo.cgi?cmd=4&id='+treeNode.value+'&level='+treeNode.level;\n");
	fprintf(cgiOut, "    document.getElementById(\"Dev_Type\").innerHTML = \"<iframe id='childFrame' name='childFrame' src='\"+url+\"' frameborder=0 width='100%%' height='400px' scrolling='auto'></iframe>\";\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_detail.cname.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����ѡ���ϼ��ڵ�');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var url = 'device_topo.cgi?cmd=1&cname='+device_detail.cname.value+'&upper='+device_detail.upper.value+'&level='+device_detail.level.value;\n");
	fprintf(cgiOut, "  document.getElementById(\"Dev_Type\").innerHTML = \"<iframe id='childFrame' name='childFrame' src='\"+url+\"' frameborder=0 width='100%%' height='400px' scrolling='auto'></iframe>\";\n");	
	fprintf(cgiOut, "}\n");
	
  //ɾ��
	fprintf(cgiOut, "function doDelete()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_detail.cname.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����ѡ��Ҫɾ�����豸');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var memo = '';\n");
	fprintf(cgiOut, "  switch(parseInt(device_detail.level.value))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "        memo = 'ɾ��['+ device_detail.cname.value +']�����¼��豸Ҳ��һ��ɾ����ȷ��?';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 0:\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "    case 3:\n");
	fprintf(cgiOut, "        memo = 'ɾ��['+ device_detail.cname.value +']��ȷ��?';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm(memo))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'device_topo.cgi?cmd=6&id='+device_detail.upper.value+'&level='+device_detail.level.value;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	//�ύ
	fprintf(cgiOut, "function doEdit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  window.frames['childFrame'].device_detail.CurrButton.click();\n");
	fprintf(cgiOut, "}\n");
	
	//Ĭ����ʾ
	fprintf(cgiOut, "function doView(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(pId == '-1')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var url = 'device_topo.cgi?cmd=1&level=0&upper=&upper_channel=';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var url = 'device_topo.cgi?cmd=4&id='+pId+'&level=0';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById(\"Dev_Type\").innerHTML = \"<iframe id='childFrame' name='childFrame' src='\"+url+\"' frameborder=0 width='100%%' height='400px' scrolling='auto'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "setTimeout(\"doView('%s');\", 300);\n", id);
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	if(10 != strlen(col_values[2]))//����
	{
		cnt++;
		fprintf(cgiOut, "var node = {name:'%s', value:'%s', parent:'-1', icon:'../system/%s', pId:'-1', id:'%s', ctype1:'%s', open:true};\n", col_values[1], col_values[0], col_values[12], col_values[0], col_values[18]);
		fprintf(cgiOut, "Nodes1.push(node);\n");
		memset(id, 0, sizeof(id));
		memcpy(id, col_values[0], 11);
	}
	else
	{
		fprintf(cgiOut, "if('%s' == '01')\n", col_values[6]);	
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  var node = {name:'%s', value:'%s', parent:'%s', icon:'../system/%s', pId:'%s', id:'%s', ctype1:'%s', open:false};\n", col_values[1], col_values[0], col_values[2], col_values[12], col_values[2], col_values[0], col_values[18]);
		fprintf(cgiOut, "  Nodes1.push(node);\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "else\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  var node = {name:'%s', value:'%s', parent:'%s', icon:'../system/%s', pId:'%s', id:'%s', ctype1:'%s', open:false};\n", col_values[1], col_values[0], col_values[2], col_values[12], col_values[2], col_values[0], col_values[18]);
		fprintf(cgiOut, "  Nodes1.push(node);\n");
		fprintf(cgiOut, "}\n");
	}
	return 0;
}

void DelTrue()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	//�޸�
	switch(atoi(level))
	{
		case 1:	
				rc = sqlite3_exec(db, getSql(12), &sqlite3_exec_callback, 0, &zErrMsg);
				if(rc != SQLITE_OK )
				{
				  err_msg(1);
				}
				rc = sqlite3_exec(db, getSql(13), &sqlite3_exec_callback, 0, &zErrMsg);
				if(rc != SQLITE_OK )
				{
				  err_msg(1);
				}
				sqlite3_close(db);
				fprintf(cgiOut, "<script language='javascript'>alert('�ɹ�');</script>\n");
			break;
		case 0:
		case 2:
		case 3:
				sqlite3_close(db);
				int ret = MsgSend(3);
				fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", getStatusName(ret));
			break;
	}	
	//sqlite3_close(db);
}

//�ϼ��ӿڲ�ѯ
void UpperChannel()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	rc = sqlite3_exec(db, getSql(5), &sqlite3_exec_callback_upperchannel, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	sqlite3_close(db);
}

int sqlite3_exec_callback_upperchannel(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != col_values[0] && strlen(col_values[0]) > 0)
	{
		char* split = ";";
		char* split_result = NULL;
		split_result = strtok( col_values[0], split);
		while( split_result != NULL )
		{
			char interfaceid[10] = {0};
			char interfacename[20] = {0}; 
			char interfacetype[10] = {0};
			char * p_save = split_result+strlen(split_result)+1;
			char *temp_p;
			char *temp_buffer = strdup(split_result);
			temp_p = strtok(temp_buffer, ",");
			int i = 0;
			while(NULL != temp_p)
			{
			   switch(i)
			   {
				  case 0:
					 sprintf(interfaceid, "%s", temp_p);
					 break;
				  case 1:
					 sprintf(interfacename, "%s", temp_p);
					 break;
					case 2:
					 sprintf(interfacetype, "%s", temp_p);					
					 break;
			   }
			   temp_p = strtok(NULL, ",");
			   i++;
			}
					
			if(strlen(upper_channel) > 0)
			{//�༭
				if(strstr(channel_type, interfacetype))
				{
					if(0 == strcmp(upper_channel, interfaceid))
					{
						fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", interfaceid, interfacename);
					}
					else
					{
						fprintf(cgiOut, "<option value='%s'>%s</option>\n", interfaceid, interfacename);
					}		
				}				
			}
			else
			{//����
				fprintf(cgiOut, "<option value='%s,%s'>%s</option>\n", interfaceid, interfacetype, interfacename);
			}
					
			split_result = strtok(p_save, split);
		}
	}
	
	return 0;
}

//������������ҳ��
void QueryForAdd()
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>���´���������ƽ̨-�豸����</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"device_detail\" action=\"device_topo.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<table width=\"100%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>�ϼ��豸</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left'>%s</td>\n", cname);
	fprintf(cgiOut, "    <td width='15%%'  align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left'>\n");
	fprintf(cgiOut, "      <select name='info_upper_channel' style='width:120px;height:25px' onchange='doSel(this.value)'>\n");
	if(0 == strcmp(level, "2"))
	{
		memset(info_upper, 0, sizeof(info_upper));
		memcpy(info_upper, "0011020001", 11);
	}
	else
	{
		memset(info_upper, 0, sizeof(info_upper));
		memcpy(info_upper, upper, 11);
	}
	UpperChannel();
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left'>\n");
	fprintf(cgiOut, "      <select id='agentid' name='agentid' style='width:120px;height:25px' onchange='doChange(device_detail.agentid.value)'>\n");
	fprintf(cgiOut, "	     </select>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left'>\n");
	fprintf(cgiOut, "	     <select id='info_type' name='info_type' style='width:120px;height:25px' onchange='doChange2(this.value);'>\n");	
	fprintf(cgiOut, "			 </select>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left'>***<input type='hidden' name='id' value=''></td>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left'><input type='text' name='cname' value='' style='width:120px;height:20px' maxlength=10></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>Ӧ������</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left'>\n");
	fprintf(cgiOut, "	     <select name='ctype' style='width:120px;height:25px'>\n");
	//fprintf(cgiOut, "        <option value='00'>���ز�</option>\n");
	//fprintf(cgiOut, "        <option value='01'>������</option>\n");
	//fprintf(cgiOut, "        <option value='02'>һ��ͨ</option>\n");
	fprintf(cgiOut, "        <option value='04'>Ӧ�ò�</option>\n");
	fprintf(cgiOut, "        <option value='03'>��Ƶ��</option>\n");
	//fprintf(cgiOut, "        <option value='05'>ϵͳ��</option>\n");
	fprintf(cgiOut, "			 </select>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left'><input type='text' name='brief' value='' style='width:120px;height:20px' maxlength=5></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ע</td>\n");
	fprintf(cgiOut, "    <td width='85%%'  align='left' colspan=3><input type='text' name='memo' value='' style='width:98%%;height:20px' maxlength=64></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	//����ִ�л�����֧���ִ�л���
	fprintf(cgiOut, "  <tr height='30' id='TR0' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>ִ�л���</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left'>\n");
	fprintf(cgiOut, "	     <select id='ctype1' name='ctype1' style='width:120px;height:25px' onchange='doChange3(this.value);'>\n");
	fprintf(cgiOut, "			 </select>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "    <td width='15%%'  align='center'>�ӿ�ͨ��</td>\n");
	fprintf(cgiOut, "    <td width='35%%'  align='left' id='ctype2'>\n");
	fprintf(cgiOut, "	   </td>\n");
	fprintf(cgiOut, "	   <input type='hidden' name='ctype3'      value=''>\n");
	fprintf(cgiOut, "	   <input type='hidden' name='self_idflag' value=''>\n");
	fprintf(cgiOut, "	   <input type='hidden' name='self_comcnt' value=''>\n");
	fprintf(cgiOut, "	   <input type='hidden' name='self_value'  value=''>\n");
	fprintf(cgiOut, "	   <input type='hidden' name='self_value2' value=''>\n");
	fprintf(cgiOut, "	   <input type='hidden' name='self_parent' value=''>\n");
	fprintf(cgiOut, "	   <input type='hidden' name='preset'      value=''>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' id='TR1' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD11' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "  	 <td width='35%%' id='TD12' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD13' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='35%%' id='TD14' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' id='TR2' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD21' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "  	 <td width='35%%' id='TD22' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD23' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='35%%' id='TD24' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' id='TR3' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD31' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "  	 <td width='35%%' id='TD32' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD33' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='35%%' id='TD34' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' id='TR4' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD41' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "  	 <td width='35%%' id='TD42' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD43' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='35%%' id='TD44' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' id='TR5' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD51' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "  	 <td width='35%%' id='TD52' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD53' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='35%%' id='TD54' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' id='TR6' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD61' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "  	 <td width='35%%' id='TD62' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD63' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='35%%' id='TD64' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' id='TR7' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD71' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "  	 <td width='35%%' id='TD72' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD73' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='35%%' id='TD74' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30' id='TR8' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD81' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "  	 <td width='35%%' id='TD82' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD83' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "    <td width='35%%' id='TD84' align='left'>&nbsp;</td>\n");
	fprintf(cgiOut, "  </tr>\n");	
	fprintf(cgiOut, "  <tr height='30' id='TR9' style='display:none'>\n");
	fprintf(cgiOut, "    <td width='15%%' id='TD91' align='center'>&nbsp;</td>\n");
	fprintf(cgiOut, "  	 <td width='85%%' id='TD92' align='left' colspan=3>&nbsp;</td>\n");
	fprintf(cgiOut, "  </tr>\n");	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='3'>\n");
	fprintf(cgiOut, "<input type='hidden' name='upper' value='%s'>\n", upper);
	fprintf(cgiOut, "<input type='hidden' name='upper_channel' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='level' value='%s'>\n", level);
	fprintf(cgiOut, "<input type='hidden' name='private_attr' value=''>\n");
	fprintf(cgiOut, "<input id='CurrButton' name='CurrButton' type='button' onClick='doAdd()' style='display:none'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "window.parent.document.getElementById('add').style.display = 'none';\n");
	fprintf(cgiOut, "window.parent.document.getElementById('delete').style.display = 'none';\n");
	fprintf(cgiOut, "window.parent.document.getElementById('edit').style.display = '';\n");
	//��ѯ����
	fprintf(cgiOut, "var reqAgent = null;\n");
	fprintf(cgiOut, "function doSel(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var length1 = document.getElementById('agentid').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length1; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('agentid').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var length2 = document.getElementById('info_type').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length2; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('info_type').remove(0);\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  var channel_type = '';\n");	
	fprintf(cgiOut, "  if(pId.length > 0)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    channel_type = pId.split(',')[1];\n");
  fprintf(cgiOut, "  }\n"); 
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqAgent = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqAgent = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqAgent.onreadystatechange = callbackAgentName;\n");
	fprintf(cgiOut, "  var url = 'device_topo.cgi?cmd=7&channel_type='+channel_type;\n");
	fprintf(cgiOut, "  reqAgent.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqAgent.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqAgent.send(null);\n");
	fprintf(cgiOut, "  return true;\n");	
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doSel(device_detail.info_upper_channel.value);\n");
	fprintf(cgiOut, "function callbackAgentName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqAgent.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqAgent.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var list = resp.split('#');\n");
	fprintf(cgiOut, "      for(var i=0; i<list.length && list[i].length>1; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var sublist = list[i].split(';');\n");
	fprintf(cgiOut, "        var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "        objOption.value = sublist[0];\n");
	fprintf(cgiOut, "        objOption.text = sublist[1];\n");
	fprintf(cgiOut, "        document.getElementById('agentid').add(objOption);\n");
	fprintf(cgiOut, "        if(0 == i)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          doChange(sublist[0]);\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//��ѯ����
	fprintf(cgiOut, "var reqSel = null;\n");
	fprintf(cgiOut, "function doChange(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var channel_type = '';\n");
	fprintf(cgiOut, "  if(device_detail.info_upper_channel.value.length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    channel_type = device_detail.info_upper_channel.value.split(',')[1];\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var length = document.getElementById('info_type').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('info_type').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqSel = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqSel = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqSel.onreadystatechange = callbackSelName;\n");
	fprintf(cgiOut, "  var url = 'device_topo.cgi?cmd=2&id='+pId+'&channel_type='+channel_type;\n");
	fprintf(cgiOut, "  reqSel.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqSel.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqSel.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");	
	fprintf(cgiOut, "function callbackSelName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqSel.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqSel.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var list = resp.split('#');\n");
	fprintf(cgiOut, "      for(var i=0; i<list.length && list[i].length>1; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var sublist = list[i].split(';');\n");
	fprintf(cgiOut, "        var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "        objOption.value = list[i];\n");
	fprintf(cgiOut, "        objOption.text = sublist[1];\n");
	fprintf(cgiOut, "        document.getElementById('info_type').add(objOption);\n");
	fprintf(cgiOut, "        if(0 == i)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          doChange2(list[i]);\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "doChange(device_detail.agentid.value);\n");
	//��ѯִ�л���
	fprintf(cgiOut, "var reqAct = null;\n");
	fprintf(cgiOut, "function SelForAct(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var length = document.getElementById('ctype1').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('ctype1').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var length2 = document.getElementById('ctype2').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length2; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('ctype2').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(pValue.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqAct = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqAct = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqAct.onreadystatechange = callbackActName;\n");
	fprintf(cgiOut, "  var url = 'device_topo.cgi?cmd=12&ctype1='+pValue;\n");
	fprintf(cgiOut, "  reqAct.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqAct.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqAct.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackActName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqAct.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqAct.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var list = resp.split('@');\n");
	fprintf(cgiOut, "      for(var i=0; i<list.length && list[i].length>1; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var sublist = list[i].split('#');\n");
	fprintf(cgiOut, "        var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "        objOption.value = list[i];\n");
	fprintf(cgiOut, "        objOption.text = sublist[1];\n");
	fprintf(cgiOut, "        document.getElementById('ctype1').add(objOption);\n");
	fprintf(cgiOut, "        if(sublist[0].indexOf('%s') >= 0)\n", upper);
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          objOption.selected = true;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        if(0 == i)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          doChange3(list[i]);\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doChange3(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('ctype2').innerHTML = '';\n");
	fprintf(cgiOut, "  if(pValue.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var list = pValue.split('#');\n");
	fprintf(cgiOut, "  if(list[3].length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var objHTML = '';\n");
	fprintf(cgiOut, "    var sublist = list[3].split(';');\n");
	fprintf(cgiOut, "    for(var i=0; i<sublist.length && sublist[i].length>1; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var sublist2 = sublist[i].split(',');\n");
	fprintf(cgiOut, "      objHTML += \"<input type='checkbox' id='checkbox\"+i+\"' name='checkbox\"+i+\"' value='\"+sublist2[0]+\"'>\" + sublist2[1] + \"&nbsp;&nbsp;\";\n");
	fprintf(cgiOut, "      if(i > 0 && (i+1)%%4 == 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objHTML += '<br>';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(device_detail.ctype3.value.substring(2,4) != '00')\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      objHTML += '<br>';\n");
	fprintf(cgiOut, "      objHTML += '------------------';\n");
	fprintf(cgiOut, "      objHTML += '<br>';\n");
	fprintf(cgiOut, "    	 for(var i=0; i<sublist.length && sublist[i].length>1; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var j = i + sublist.length - 1;\n");
	fprintf(cgiOut, "        var sublist2 = sublist[i].split(',');\n");
	fprintf(cgiOut, "        objHTML += \"<input type='checkbox' id='checkbox\"+j+\"' name='checkbox\"+j+\"' value='\"+sublist2[0]+\"'>\" + sublist2[1] + \"&nbsp;&nbsp;\";\n");
	fprintf(cgiOut, "        if(i > 0 && (i+1)%%4 == 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          objHTML += '<br>';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    document.getElementById('ctype2').innerHTML = objHTML;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//���Ͳ���
	fprintf(cgiOut, "function doChange2(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('TD11').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD12').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD13').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD14').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD21').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD22').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD23').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD24').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD31').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD32').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD33').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD34').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD41').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD42').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD43').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD44').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD51').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD52').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD53').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD54').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD61').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD62').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD63').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD64').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD71').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD72').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD73').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TD74').innerHTML = '&nbsp;';\n");
	fprintf(cgiOut, "  document.getElementById('TR1').style.display = 'none';\n");
	fprintf(cgiOut, "  document.getElementById('TR2').style.display = 'none';\n");
	fprintf(cgiOut, "  document.getElementById('TR3').style.display = 'none';\n");
	fprintf(cgiOut, "  document.getElementById('TR4').style.display = 'none';\n");
	fprintf(cgiOut, "  document.getElementById('TR5').style.display = 'none';\n");
	fprintf(cgiOut, "  document.getElementById('TR6').style.display = 'none';\n");
	fprintf(cgiOut, "  document.getElementById('TR7').style.display = 'none';\n");
	fprintf(cgiOut, "  document.getElementById('TR8').style.display = 'none';\n");
	fprintf(cgiOut, "  document.getElementById('TR9').style.display = 'none';\n");
	fprintf(cgiOut, "  var pPrivate_Attr = '';\n");
	fprintf(cgiOut, "  if(null != pValue && pValue.length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var list = pValue.split(';');\n");
	fprintf(cgiOut, "    if(list[2].length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      pPrivate_Attr = list[2];\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(list[4].length > 0 && parseInt(list[4]) >= 11)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      document.getElementById('TR0').style.display = '';\n");
	fprintf(cgiOut, "      device_detail.ctype3.value = list[5];\n");
	fprintf(cgiOut, "      device_detail.self_comcnt.value = parseInt(list[5].substring(0,2));\n");
	fprintf(cgiOut, "      SelForAct(list[4]);\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      document.getElementById('TR0').style.display = 'none';\n");
	fprintf(cgiOut, "      device_detail.ctype3.value = '';\n");
	fprintf(cgiOut, "      device_detail.self_comcnt.value = '';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(pPrivate_Attr.length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var i = 0;\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('outip') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "      document.getElementById('TD11').innerHTML = \"���� IP\";\n");
	fprintf(cgiOut, "      document.getElementById('TD12').innerHTML = \"<input type='text' name='outip' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('outport') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"�����˿�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<input type='text' name='outport' value='' style='width:120px;height:20px' maxlength=5>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"�����˿�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<input type='text' name='outport' value='' style='width:120px;height:20px' maxlength=5>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('inip') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"���� IP\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<input type='text' name='inip' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"���� IP\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<input type='text' name='inip' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"���� IP\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<input type='text' name='inip' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('inport') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"�����˿�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<input type='text' name='inport' value='' style='width:120px;height:20px' maxlength=5>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"�����˿�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<input type='text' name='inport' value='' style='width:120px;height:20px' maxlength=5>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"�����˿�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<input type='text' name='inport' value='' style='width:120px;height:20px' maxlength=5>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"�����˿�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<input type='text' name='inport' value='' style='width:120px;height:20px' maxlength=5>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('login_id') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "       i++;\n");
	fprintf(cgiOut, "       if(1 == i)\n");
	fprintf(cgiOut, "       {\n");
	fprintf(cgiOut, "         document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "         document.getElementById('TD11').innerHTML = \"��½�˺�\";\n");
	fprintf(cgiOut, "         document.getElementById('TD12').innerHTML = \"<input type='text' name='login_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "       }\n");
	fprintf(cgiOut, "       else if(2 == i)\n");
	fprintf(cgiOut, "       {\n");
	fprintf(cgiOut, "         document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "         document.getElementById('TD13').innerHTML = \"��½�˺�\";\n");
	fprintf(cgiOut, "         document.getElementById('TD14').innerHTML = \"<input type='text' name='login_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "       }\n");
	fprintf(cgiOut, "       else if(3 == i)\n");
	fprintf(cgiOut, "       {\n");
	fprintf(cgiOut, "         document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "         document.getElementById('TD21').innerHTML = \"��½�˺�\";\n");
	fprintf(cgiOut, "         document.getElementById('TD22').innerHTML = \"<input type='text' name='login_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "       }\n");
	fprintf(cgiOut, "       else if(4 == i)\n");
	fprintf(cgiOut, "       {\n");
	fprintf(cgiOut, "         document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "         document.getElementById('TD23').innerHTML = \"��½�˺�\";\n");
	fprintf(cgiOut, "         document.getElementById('TD24').innerHTML = \"<input type='text' name='login_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "       }\n");
	fprintf(cgiOut, "       else if(5 == i)\n");
	fprintf(cgiOut, "       {\n");
	fprintf(cgiOut, "         document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "         document.getElementById('TD31').innerHTML = \"��½�˺�\";\n");
	fprintf(cgiOut, "         document.getElementById('TD32').innerHTML = \"<input type='text' name='login_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "       }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('login_pwd') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"��½����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<input type='text' name='login_pwd' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"��½����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<input type='text' name='login_pwd' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"��½����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<input type='text' name='login_pwd' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"��½����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<input type='text' name='login_pwd' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"��½����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<input type='text' name='login_pwd' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"��½����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<input type='text' name='login_pwd' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('code_stream') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<select name='code_stream' style='width:120px;height:25px'><option value='1'>����</option><option value='2'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<select name='code_stream' style='width:120px;height:25px'><option value='1'>����</option><option value='2'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<select name='code_stream' style='width:120px;height:25px'><option value='1'>����</option><option value='2'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<select name='code_stream' style='width:120px;height:25px'><option value='1'>����</option><option value='2'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<select name='code_stream' style='width:120px;height:25px'><option value='1'>����</option><option value='2'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<select name='code_stream' style='width:120px;height:25px'><option value='1'>����</option><option value='2'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<select name='code_stream' style='width:120px;height:25px'><option value='1'>����</option><option value='2'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('pan_tilt') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"��̨����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<select name='pan_tilt' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"��̨����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<select name='pan_tilt' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"��̨����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<select name='pan_tilt' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"��̨����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<select name='pan_tilt' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"��̨����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<select name='pan_tilt' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"��̨����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<select name='pan_tilt' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"��̨����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<select name='pan_tilt' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"��̨����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<select name='pan_tilt' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('authmode') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<select name='authmode' style='width:120px;height:25px'><option value='0'>������</option><option value='1'>������</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<select name='authmode' style='width:120px;height:25px'><option value='0'>������</option><option value='1'>������</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<select name='authmode' style='width:120px;height:25px'><option value='0'>������</option><option value='1'>������</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<select name='authmode' style='width:120px;height:25px'><option value='0'>������</option><option value='1'>������</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<select name='authmode' style='width:120px;height:25px'><option value='0'>������</option><option value='1'>������</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<select name='authmode' style='width:120px;height:25px'><option value='0'>������</option><option value='1'>������</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<select name='authmode' style='width:120px;height:25px'><option value='0'>������</option><option value='1'>������</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<select name='authmode' style='width:120px;height:25px'><option value='0'>������</option><option value='1'>������</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(9 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD51').innerHTML = \"��������\";\n");
	fprintf(cgiOut, "        document.getElementById('TD52').innerHTML = \"<select name='authmode' style='width:120px;height:25px'><option value='0'>������</option><option value='1'>������</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('self_id') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(9 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD51').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD52').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(10 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD53').innerHTML = \"��ͨ����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD54').innerHTML = \"<input type='text' name='self_id' value='' style='width:120px;height:20px' maxlength=20>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('bpt') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(9 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD51').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD52').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(10 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD53').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD54').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(11 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD61').innerHTML = \"�� �� ��\";\n");
	fprintf(cgiOut, "        document.getElementById('TD62').innerHTML = \"<select name='bpt' style='width:120px;height:25px'><option value=''>��</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='1200'>1200</option><option value='2400'>2400</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='4800'>4800</option><option value='9600' selected>9600</option><option value='14400'>14400</option><option value='19200'>19200</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='38400'>38400</option><option value='56000'>56000</option><option value='57600'>57600</option>\"\n");
	fprintf(cgiOut, "        +\"<option value='115200'>115200</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('databyte') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(9 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD51').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD52').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(10 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD53').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD54').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(11 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD61').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD62').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(12 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD63').innerHTML = \"�� �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD64').innerHTML = \"<select name='databyte' style='width:120px;height:25px'><option value='5'>5</option><option value='6'>6</option><option value='7'>7</option><option value='8' selected>8</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('stopbyte') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(9 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD51').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD52').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(10 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD53').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD54').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(11 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD61').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD62').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(12 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD63').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD64').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(13 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR7').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD71').innerHTML = \"ͣ ֹ λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD72').innerHTML = \"<select name='stopbyte' style='width:120px;height:25px'><option value='1'>1</option><option value='2'>2</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('checkbyte') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(9 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD51').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD52').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(10 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD53').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD54').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(11 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD61').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD62').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(12 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD63').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD64').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(13 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR7').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD71').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD72').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(14 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR7').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD73').innerHTML = \"У �� λ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD74').innerHTML = \"<select name='checkbyte' style='width:120px;height:25px'><option value='None'>None</option><option value='Odd'>Odd</option><option value='Even'>Even</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('cover_flag') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(9 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD51').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD52').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(10 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD53').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD54').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(11 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD61').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD62').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(12 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD63').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD64').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(13 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR7').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD71').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD72').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(14 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR7').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD73').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD74').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(15 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR8').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD81').innerHTML = \"��¼����\";\n");
	fprintf(cgiOut, "        document.getElementById('TD82').innerHTML = \"<select name='cover_flag' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('rolltimeout') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(9 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD51').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD52').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(10 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD53').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD54').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(11 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD61').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD62').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(12 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD63').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD64').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(13 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR7').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD71').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD72').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(14 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR7').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD73').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD74').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(15 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR8').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD81').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD82').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(16 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR8').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD83').innerHTML = \"��Ѳ��ʱ\";\n");
	fprintf(cgiOut, "        document.getElementById('TD84').innerHTML = \"<input type='text' name='rolltimeout' value='' style='width:90px;height:20px' maxlength=4> ����\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(pPrivate_Attr.indexOf('isUpload') >= 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      i++;\n");
	fprintf(cgiOut, "      if(1 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD11').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD12').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(2 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD13').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD14').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(3 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD21').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD22').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(4 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD23').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD24').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(5 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD31').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD32').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(6 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD33').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD34').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(7 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD41').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD42').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(8 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR4').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD43').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD44').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(9 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD51').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD52').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");	
	fprintf(cgiOut, "      else if(10 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR5').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD53').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD54').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(11 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD61').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD62').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(12 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR6').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD63').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD64').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(13 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR7').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD71').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD72').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(14 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR7').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD73').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD74').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(15 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR8').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD81').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD82').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(16 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR8').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD83').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD84').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(17 == i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        document.getElementById('TR9').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('TD91').innerHTML = \"�Ƿ��ϴ�\";\n");
	fprintf(cgiOut, "        document.getElementById('TD92').innerHTML = \"<select name='isUpload' style='width:120px;height:25px'><option value='0'>��</option><option value='1'>��</option></select>\";\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//����
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_detail.info_type.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ѡ���豸���Ҽ�����');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.cname.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������豸����');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(document.getElementById('TR0').style.display == '')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(device_detail.ctype1.value.length < 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('��ѡ��ִ�л���');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    var cnt = 0;\n");
	fprintf(cgiOut, "    for(var i=0; i<63; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(document.getElementById('checkbox'+i))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        cnt++;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	
	fprintf(cgiOut, "    var preset = '';\n");
	fprintf(cgiOut, "    var self_value = 0;\n");
	fprintf(cgiOut, "    var self_value2 = 0;\n");
	fprintf(cgiOut, "    var checkcnt = 0;\n");
	fprintf(cgiOut, "    if(device_detail.ctype3.value.substring(2,4) == '00')\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      for(var i=0; i<cnt; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(document.getElementById('checkbox'+i).checked)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          checkcnt++;\n");
	fprintf(cgiOut, "          preset += '1';\n");
	fprintf(cgiOut, "          self_value += parseInt(document.getElementById('checkbox'+i).value);\n");
	fprintf(cgiOut, "          if(1 == checkcnt)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            for(var j=i; j<(i+parseInt(device_detail.self_comcnt.value)); j++)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              if(document.getElementById('checkbox'+j))\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if(document.getElementById('checkbox'+j).checked == false)\n");
	fprintf(cgiOut, "                {\n");
	fprintf(cgiOut, "                  alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "                  return;\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "                return;\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          preset += '0';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(preset.indexOf('1') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(checkcnt != parseInt(device_detail.self_comcnt.value))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      device_detail.self_value.value = self_value;\n");
	fprintf(cgiOut, "      device_detail.self_value2.value = '0';\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      for(var i=0; i<cnt/2; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(document.getElementById('checkbox'+i).checked)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          checkcnt++;\n");
	fprintf(cgiOut, "          preset += '1';\n");
	fprintf(cgiOut, "          self_value += parseInt(document.getElementById('checkbox'+i).value);\n");
	fprintf(cgiOut, "          if(1 == checkcnt)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            for(var j=i; j<(i+parseInt(device_detail.self_comcnt.value)); j++)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              if(document.getElementById('checkbox'+j))\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if(document.getElementById('checkbox'+j).checked == false)\n");
	fprintf(cgiOut, "                {\n");
	fprintf(cgiOut, "                  alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "                  return;\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "                return;\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          preset += '0';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(preset.indexOf('1') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(checkcnt != parseInt(device_detail.self_comcnt.value))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      checkcnt = 0;\n");
	fprintf(cgiOut, "      for(var i=cnt/2; i<cnt; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if(document.getElementById('checkbox'+i).checked)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          checkcnt++;\n");
	fprintf(cgiOut, "          preset += '1';\n");
	fprintf(cgiOut, "          self_value2 += parseInt(document.getElementById('checkbox'+i).value);\n");
	fprintf(cgiOut, "          if(1 == checkcnt)\n");
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            for(var j=i; j<(i+parseInt(device_detail.self_comcnt.value)); j++)\n");
	fprintf(cgiOut, "            {\n");
	fprintf(cgiOut, "              if(document.getElementById('checkbox'+j))\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                if(document.getElementById('checkbox'+j).checked == false)\n");
	fprintf(cgiOut, "                {\n");
	fprintf(cgiOut, "                  alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "                  return;\n");
	fprintf(cgiOut, "                }\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "              else\n");
	fprintf(cgiOut, "              {\n");
	fprintf(cgiOut, "                alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "                return;\n");
	fprintf(cgiOut, "              }\n");
	fprintf(cgiOut, "            }\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          preset += '0';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(preset.substring(cnt/2).indexOf('1') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(checkcnt != parseInt(device_detail.self_comcnt.value))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      device_detail.self_value.value = self_value;\n");
	fprintf(cgiOut, "      device_detail.self_value2.value = self_value2;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    device_detail.self_idflag.value = '1';\n");
	fprintf(cgiOut, "    device_detail.self_parent.value = device_detail.ctype1.value.split('#')[2];\n");
	fprintf(cgiOut, "    device_detail.preset.value = preset;\n");
	fprintf(cgiOut, "    if(device_detail.self_parent.value.length != 2)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('ִ�л�����ͨ�������ô���!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    device_detail.ctype3.value = '';\n");
	fprintf(cgiOut, "    device_detail.self_idflag.value = '';\n");
	fprintf(cgiOut, "    device_detail.self_value.value = '';\n");
	fprintf(cgiOut, "    device_detail.self_value2.value = '';\n");
	fprintf(cgiOut, "    device_detail.self_parent.value = '';\n");
	fprintf(cgiOut, "    device_detail.preset.value = '';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var private_attr = '';\n");
	fprintf(cgiOut, "  if(device_detail.outip)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'outip=' + device_detail.outip.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.outport)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'outport=' + device_detail.outport.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.inip)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'inip=' + device_detail.inip.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.inport)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'inport=' + device_detail.inport.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.login_id)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'login_id=' + device_detail.login_id.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.login_pwd)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'login_pwd=' + device_detail.login_pwd.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.code_stream)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'code_stream=' + device_detail.code_stream.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.pan_tilt)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'pan_tilt=' + device_detail.pan_tilt.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.authmode)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'authmode=' + device_detail.authmode.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.bpt)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'bpt=' + device_detail.bpt.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.databyte)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'databyte=' + device_detail.databyte.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.stopbyte)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'stopbyte=' + device_detail.stopbyte.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.checkbyte)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'checkbyte=' + device_detail.checkbyte.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.cover_flag)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'cover_flag=' + device_detail.cover_flag.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");	
	fprintf(cgiOut, "  if(device_detail.rolltimeout)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(device_detail.rolltimeout.value.Trim().length < 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('��������Ѳ��ʱʱ��');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<device_detail.rolltimeout.value.Trim().length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(isNaN(device_detail.rolltimeout.value.charAt(i)))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('��Ѳ��ʱ���뺬�Ƿ��ַ�');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    private_attr += 'rolltimeout=' + device_detail.rolltimeout.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_detail.isUpload)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    private_attr += 'isUpload=' + device_detail.isUpload.value.Trim() + ',';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  device_detail.private_attr.value = private_attr;\n");
	fprintf(cgiOut, "  device_detail.id.value = device_detail.info_type.value.split(';')[0].Trim();\n");
	fprintf(cgiOut, "  if(device_detail.info_upper_channel.value.length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    device_detail.upper_channel.value = device_detail.info_upper_channel.value.split(',')[0];\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ���ύ?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(device_detail.ctype3.value.length == 4)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      device_detail.ctype3.value = device_detail.ctype3.value.substring(2);\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    device_detail.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

void QueryAgent()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
	rc = sqlite3_exec(db, getSql(1), &sqlite3_exec_callback_manufacturer, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_manufacturer(void *data, int n_columns, char **col_values, char **col_names)
{
	printf("%s;%s#\n", col_values[0], col_values[1]);
	return 0;
}

void QueryDeviceInfo()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	sqlite3_create_function(db, "contain", -1, SQLITE_UTF8, 0, icuContainiFunc, 0, 0);
	rc = sqlite3_exec(db, getSql(2), &sqlite3_exec_callback_device_info, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_device_info(void *data, int n_columns, char **col_values, char **col_names)
{
	printf("%s;%s;%s;%s;%s;%s#\n", col_values[0], col_values[1], col_values[2], col_values[3], col_values[4], col_values[5]);
	return 0;
}

//����
void AddTrue()
{
	if(0 == strcmp(self_idflag, "1"))
	{
		strcat(self_parent, self_id);
		memset(self_id, 0, sizeof(self_id));
		memcpy(self_id, self_parent, 21);
		sprintf(self_value, "%04X", atoi(self_value));
		sprintf(self_value2, "%04X", atoi(self_value2));
	}
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	//���ɱ��
	rc = sqlite3_exec(db, getSql(3), &sqlite3_exec_callback_add, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	
	//���
	switch(atoi(level))
	{
		case 0:
				rc = sqlite3_exec(db, getSql(10), &sqlite3_exec_callback, 0, &zErrMsg);
				if( rc!=SQLITE_OK )
				{
				  err_msg(1);
				}
				sqlite3_close(db);
			break;
		case 1:
		case 2:
				sqlite3_close(db);
				int ret = MsgSend(1);
				if((0 == ret || 3000 == ret) && 0 == strcmp(self_idflag, "1"))
				{//�󶨼̵���
					memset(sn, 0, sizeof(sn));
					memset(object, 0, sizeof(object));
					strcat(sn, "00020001");
					strcat(object, self_value);
					strcat(object, self_value2);
					strcat(object, ctype3);
					ret = MsgSend(5);
					fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", getStatusName(ret));
				}
				else
				{
					fprintf(cgiOut, "<script language='javascript'>alert('%s');</script>\n", getStatusName(ret));
				}
			break;
	}
	//sqlite3_close(db);
}

int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL == col_values[0] || strlen(col_values[0]) == 0)
	{
		strcat(id, "0001");
	}
	else
	{
		strcat(id, StrLeftFillZero(col_values[0], 4));
	}
	return 0;
}

//�޸�ҳ��
void QueryForUdp()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db;	
	db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(4), &sqlite3_exec_callback_forudp, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);		
}

int sqlite3_exec_callback_forudp(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	memset(id, 0, sizeof(id));
	memset(cname, 0, sizeof(cname));
	memcpy(id, col_values[0], 11);
	memcpy(cname, col_values[1], 31);
	memset(channel_type, 0, sizeof(channel_type));
	memcpy(channel_type, col_values[15], 10);
	
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>���´���������ƽ̨-�豸����</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");	
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 80%%;\n");
	fprintf(cgiOut, "  height:95%%;\n");
	fprintf(cgiOut, "  left:10%%;\n");
	fprintf(cgiOut, "  top:2%%;\n");;
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, ".cmddiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 50%%;\n");
	fprintf(cgiOut, "  height:50%%;\n");
	fprintf(cgiOut, "  left:25%%;\n");
	fprintf(cgiOut, "  top: 25%%;\n");;
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"device_detail\" action=\"device_topo.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<table width=\"100%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	
	if(0 == strcmp(level, "2") || 0 == strcmp(level, "3"))
	{
		//״̬
		char statusname[60] = {0};
		switch(atoi(col_values[5]))
		{
			case 0:
					strcat(statusname, "����");
				break;
			case 1:
					strcat(statusname, "<font color=gray>����</font>");
				break;
			default:
					strcat(statusname, "<font color=green>����</font>");
				break;
		}
		//�ӿ�
		memset(upper, 0, sizeof(upper));
		memset(upper_channel, 0, sizeof(upper_channel));
		memcpy(upper, col_values[2], 11);
		memcpy(upper_channel, col_values[3], 3);
		
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='15%%'  align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
		fprintf(cgiOut, "    <td width='35%%'  align='left'>\n");
	  fprintf(cgiOut, "      <select name='upper_channel' style='width:120px;height:25px'>\n");
		
		if(0 == strcmp(level, "3"))
		{
			memset(info_upper, 0, sizeof(info_upper));
			memcpy(info_upper, "0011020001", 11);
		}
		else
		{
			memset(info_upper, 0, sizeof(info_upper));
			memcpy(info_upper, upper, 11);
		}
		UpperChannel();
		
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "    <td width='15%%'  align='center'>״&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;̬</td>\n");
	  fprintf(cgiOut, "    <td width='35%%'  align='left'>%s</td>\n", statusname);
		fprintf(cgiOut, "  </tr>\n");
	}	
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%' align='left'>%s</td>\n", col_values[10]);
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%' align='left'>%s</td>\n", col_values[11]);
	fprintf(cgiOut, "  </tr>\n");

	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%' align='left'>%s<input type='hidden' name='id' value='%s'></td>\n", col_values[0], col_values[0]);
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
	fprintf(cgiOut, "    <td width='35%%' align='left'><input type='text' name='cname' value='%s' style='width:120px;height:20px' maxlength=10></td>\n", col_values[1]);
	fprintf(cgiOut, "  </tr>\n");
	
	char ctypename[20] = {0};
	switch(atoi(col_values[6]))
	{
		case 0:
				strcat(ctypename, "���ز�");
			break;
		case 1:
				strcat(ctypename, "������");
			break;
		case 5:
				strcat(ctypename, "ϵͳ��");
			break;
		default:
				strcat(ctypename, "Ӧ�ò�");
			break;
	} 
	//Ӧ������
	if(0 == strcmp(col_values[6], "00") || 0 == strcmp(col_values[6], "01") || 0 == strcmp(col_values[6], "05"))
	{
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='15%%' align='center'>Ӧ������</td>\n");
		fprintf(cgiOut, "    <td width='35%%' align='left'>\n");
		fprintf(cgiOut, "      %s\n", ctypename);
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
		fprintf(cgiOut, "    <td width='35%%' align='left'><input type='text' name='brief' value='%s' style='width:120px;height:20px' maxlength=5></td>\n", col_values[16]);
		fprintf(cgiOut, "  </tr>\n");
		fprintf(cgiOut, "  <input type='hidden' name='ctype' value='%s'>\n", col_values[6]);
	}
	else
	{
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='15%%' align='center'>Ӧ������</td>\n");
		fprintf(cgiOut, "    <td width='35%%' align='left'>\n");
		fprintf(cgiOut, "      <select name='ctype' style='width:120px;height:25px'>\n");
		fprintf(cgiOut, "        <option value='03' %s>��Ƶ��</option>\n", 0 == strcmp(col_values[6], "03")?"selected":"");
		fprintf(cgiOut, "        <option value='04' %s>Ӧ�ò�</option>\n", 0 == strcmp(col_values[6], "04")?"selected":"");
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</td>\n");
		fprintf(cgiOut, "    <td width='35%%' align='left'><input type='text' name='brief' value='%s' style='width:120px;height:20px' maxlength=5></td>\n", col_values[16]);
		fprintf(cgiOut, "  </tr>\n");
	}
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='15%%' align='center'>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ע</td>\n");
	fprintf(cgiOut, "    <td width='85%%' align='left' colspan=3><input type='text' name='memo' value='%s' style='width:98%%;height:20px' maxlength=64></td>\n", col_values[21]);
	fprintf(cgiOut, "  </tr>\n");
	
	//a.id, a.cname, a.upper, a.upper_channel, a.be_on, a.status, a.ctype, a.self_id, a.preset, a.private_attr, b.brief, c.cname, c.s_icon, c.composition, c.private_attr, c.channel_type, a.brief, c.id, c.ctype1, c.ctype2, c.ctype3
	if(NULL != col_values[19] && strlen(col_values[19]) > 0 && atoi(col_values[19]) >= 11)
	{
		//����ִ�л�����֧���ִ�л���
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='15%%'  align='center'>ִ�л���</td>\n");
		fprintf(cgiOut, "    <td width='35%%'  align='left'>\n");
		fprintf(cgiOut, "	     <select id='ctype1' name='ctype1' style='width:120px;height:25px' onchange='doChange3(this.value);'>\n");
		int rc;
		char * zErrMsg;
		sqlite3 *db = open_db(DB_PATH);		
		char sqlattr[1024] = {0};
		sprintf(sqlattr, "select a.id, a.cname, a.self_id, b.composition, b.ctype1, b.ctype2 from device_detail a, device_info b where substr(a.id,1,6) = b.id and b.ctype1 = '%s' order by a.id", col_values[19]);
		rc = sqlite3_exec(db, sqlattr, &sqlite3_exec_callback_selforupd, col_values[7], &zErrMsg);
		if(rc != SQLITE_OK )
		{
		  err_msg(1);
		}
		sqlite3_close(db);
		fprintf(cgiOut, "			 </select>\n");
		fprintf(cgiOut, "	   </td>\n");
		fprintf(cgiOut, "    <td width='15%%'  align='center'>�ӿ�ͨ��</td>\n");
		fprintf(cgiOut, "    <td width='35%%'  align='left' id='ctype2'>\n");
		fprintf(cgiOut, "	   </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	
	int i = 0;
	if(strstr(col_values[14], "outip"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>�� �� IP</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><input type='text' name='outip' value='%s' style='width:120px;height:20px' maxlength=20></td>\n", define_sscanf(col_values[9], "outip="));		
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}

	if(strstr(col_values[14], "outport"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>�����˿�</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><input type='text' name='outport' value='%s' style='width:120px;height:20px' maxlength=5></td>\n", define_sscanf(col_values[9], "outport="));	
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "inip"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>�� �� IP</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><input type='text' name='inip' value='%s' style='width:120px;height:20px' maxlength=20></td>\n", define_sscanf(col_values[9], "inip="));		
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}

	if(strstr(col_values[14], "inport"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>�����˿�</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><input type='text' name='inport' value='%s' style='width:120px;height:20px' maxlength=5></td>\n", define_sscanf(col_values[9], "inport="));		
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
		
	if(strstr(col_values[14], "login_id"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>��½�˺�</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><input type='text' name='login_id' value='%s' style='width:120px;height:20px' maxlength=20></td>\n", define_sscanf(col_values[9], "login_id="));	
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "login_pwd"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>��½����</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><input type='text' name='login_pwd' value='%s' style='width:120px;height:20px' maxlength=20></td>\n", define_sscanf(col_values[9], "login_pwd="));		
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}

	if(strstr(col_values[14], "code_stream"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>��������</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><select name='code_stream' style='width:120px;height:25px'>\n");
		fprintf(cgiOut, "<option value='1' %s>����</option>\n", 0 == strcmp(define_sscanf(col_values[9], "code_stream="), "1")?"selected":"");
		fprintf(cgiOut, "<option value='2' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[9], "code_stream="), "2")?"selected":"");
    fprintf(cgiOut, "</select></td>\n");		
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "pan_tilt"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>��̨����</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><select name='pan_tilt' style='width:120px;height:25px'>\n");
		fprintf(cgiOut, "<option value='0' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[9], "pan_tilt="), "0")?"selected":"");
		fprintf(cgiOut, "<option value='1' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[9], "pan_tilt="), "1")?"selected":"");	
		fprintf(cgiOut, "</select></td>\n");	
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "authmode"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%' align='center'>��������</td>\n");
	  fprintf(cgiOut, "<td width='35%%' align='left'><select name='authmode' style='width:120px;height:25px'>\n"); 
	  fprintf(cgiOut, "<option value='0' %s>������</option>\n", 0 == strcmp(define_sscanf(col_values[9], "authmode="), "0")?"selected":"");
		fprintf(cgiOut, "<option value='1' %s>������</option>\n", 0 == strcmp(define_sscanf(col_values[9], "authmode="), "1")?"selected":"");			
	  fprintf(cgiOut, "</select></td>\n");	  	
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
		
	if(strstr(col_values[14], "self_id"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%' align='center'>��ͨ����</td>\n");
	  fprintf(cgiOut, "<td width='35%%' align='left'><input type='text' name='self_id' value='%s' style='width:120px;height:20px' maxlength=20></td>\n", col_values[7]);		
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "bpt"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%' align='center'>�� �� ��</td>\n");
		fprintf(cgiOut, "<td width='35%%' align='left'><select name='bpt' style='width:120px;height:25px'>\n");
		fprintf(cgiOut, "<option value=''>��</option>\n");
		fprintf(cgiOut, "<option value='1200' %s>1200</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "1200")?"selected":"");
		fprintf(cgiOut, "<option value='2400' %s>2400</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "2400")?"selected":"");
		fprintf(cgiOut, "<option value='4800' %s>4800</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "4800")?"selected":"");
		fprintf(cgiOut, "<option value='9600' %s>9600</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "9600")?"selected":"");
		fprintf(cgiOut, "<option value='14400' %s>14400</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "14400")?"selected":"");
		fprintf(cgiOut, "<option value='19200' %s>19200</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "19200")?"selected":"");
		fprintf(cgiOut, "<option value='38400' %s>38400</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "38400")?"selected":"");
		fprintf(cgiOut, "<option value='56000' %s>56000</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "56000")?"selected":"");
		fprintf(cgiOut, "<option value='57600' %s>57600</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "57600")?"selected":"");
		fprintf(cgiOut, "<option value='115200' %s>115200</option>\n", 0 == strcmp(define_sscanf(col_values[9], "bpt="), "115200")?"selected":"");
		fprintf(cgiOut, "</select></td>\n");		
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "databyte"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%' align='center'>�� �� λ</td>\n");
		fprintf(cgiOut, "<td width='35%%' align='left'><select name='databyte' style='width:120px;height:25px'>\n");	
		fprintf(cgiOut, "<option value='5' %s>5</option>\n", 0 == strcmp(define_sscanf(col_values[9], "databyte="), "5")?"selected":"");
		fprintf(cgiOut, "<option value='6' %s>6</option>\n", 0 == strcmp(define_sscanf(col_values[9], "databyte="), "6")?"selected":"");
		fprintf(cgiOut, "<option value='7' %s>7</option>\n", 0 == strcmp(define_sscanf(col_values[9], "databyte="), "7")?"selected":"");
		fprintf(cgiOut, "<option value='8' %s>8</option>\n", 0 == strcmp(define_sscanf(col_values[9], "databyte="), "8")?"selected":"");
		fprintf(cgiOut, "</select></td>\n");		
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "stopbyte"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%' align='center'>ͣ ֹ λ</td>\n");
		fprintf(cgiOut, "<td width='35%%' align='left'><select name='stopbyte' style='width:120px;height:25px'>\n");	
		fprintf(cgiOut, "<option value='1' %s>1</option>\n", 0 == strcmp(define_sscanf(col_values[9], "stopbyte="), "1")?"selected":"");
		fprintf(cgiOut, "<option value='2' %s>2</option>\n", 0 == strcmp(define_sscanf(col_values[9], "stopbyte="), "2")?"selected":"");
		fprintf(cgiOut, "</select></td>\n");	
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "checkbyte"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%' align='center'>У �� λ</td>\n");
		fprintf(cgiOut, "<td width='35%%' align='left'><select name='checkbyte' style='width:120px;height:25px'>\n");	
		fprintf(cgiOut, "<option value='None'  %s>None</option>\n",  0 == strcmp(define_sscanf(col_values[9], "checkbyte="), "None")?"selected":"");
		fprintf(cgiOut, "<option value='Odd'   %s>Odd</option>\n",   0 == strcmp(define_sscanf(col_values[9], "checkbyte="), "Odd")?"selected":"");
		fprintf(cgiOut, "<option value='Even'  %s>Even</option>\n",  0 == strcmp(define_sscanf(col_values[9], "checkbyte="), "Even")?"selected":"");
		fprintf(cgiOut, "</select></td>\n");		
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
		
	if(strstr(col_values[14], "cover_flag"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>��¼����</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><select name='cover_flag' style='width:120px;height:25px'>\n");
		fprintf(cgiOut, "<option value='0' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[9], "cover_flag="), "0")?"selected":"");
		fprintf(cgiOut, "<option value='1' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[9], "cover_flag="), "1")?"selected":"");	
		fprintf(cgiOut, "</select></td>\n");	
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "rolltimeout"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>��Ѳ��ʱ</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><input type='text' name='rolltimeout' value='%s' style='width:90px;height:20px' maxlength=4> ����</td>\n", define_sscanf(col_values[9], "rolltimeout="));
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
	if(strstr(col_values[14], "isUpload"))
	{
		if(i%2 == 0)
		{
			fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
		}
		fprintf(cgiOut, "<td width='15%%'  align='center'>�Ƿ��ϴ�</td>\n");
		fprintf(cgiOut, "<td width='35%%'  align='left'><select name='isUpload' style='width:120px;height:25px'>\n");
		fprintf(cgiOut, "<option value='0' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[9], "isUpload="), "0")?"selected":"");
		fprintf(cgiOut, "<option value='1' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[9], "isUpload="), "1")?"selected":"");	
		fprintf(cgiOut, "</select></td>\n");	
		if(i%2 == 1)
		{
			fprintf(cgiOut, "</tr>\n");
		}
		i++;
	}
	
  if(i%2 == 1)
  {
		fprintf(cgiOut, "<td width='15%%' align='center'>&nbsp</td>\n");
		fprintf(cgiOut, "<td width='35%%' align='left'>&nbsp</td>\n");
		fprintf(cgiOut, "</tr>\n");
  }
  
  //���߸澯
  int rc;
	char * zErrMsg;
	sqlite3 *db = open_db(DB_PATH);		
	char sqlattr[1024] = {0};
	sprintf(sqlattr, "select a.id, a.sn from device_roll a where a.id = '%s'", col_values[0]);
	rc = sqlite3_exec(db, sqlattr, &sqlite3_exec_callback_alert, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	if(cnt4 > 0)
	{
		cnt4 = 0;
		memset(sqlattr, 0, sizeof(sqlattr));
		sprintf(sqlattr, "select a.id, a.sn from device_agent a where a.id = '%s' and a.ctype = '1'", col_values[0]);
		rc = sqlite3_exec(db, sqlattr, &sqlite3_exec_callback_alert, 0, &zErrMsg);
		if(rc != SQLITE_OK )
		{
		  err_msg(1);
		}	
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='15%%'  align='center'>���߸澯</td>\n");
		fprintf(cgiOut, "    <td width='85%%'  align='left' colspan=3>\n");
		if(cnt4 > 0)
			fprintf(cgiOut, "    &nbsp;<a href='#' onclick=\"doOff('%s')\"><font color=green>[������]</font></a>\n", col_values[0]);
		else
			fprintf(cgiOut, "    &nbsp;<a href='#' onclick=\"doOff('%s')\"><font color=gray>[δ����]</font></a>\n", col_values[0]);
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
  //�ɼ�����
  memset(sqlattr, 0, sizeof(sqlattr));
	sprintf(sqlattr, "select a.id, a.sn, a.attr_name, a.status from device_roll a where a.id = '%s'", col_values[0]);
	rc = sqlite3_exec(db, sqlattr, &sqlite3_exec_callback_attr, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	if(cnt2 > 0)
	{
		fprintf(cgiOut, "      </tr>\n");
		fprintf(cgiOut, "    </table>\n");
		fprintf(cgiOut, "  </td>\n");
		fprintf(cgiOut, "</tr>\n");
	}
	//��������(���ɷ���)
	memset(sqlattr, 0, sizeof(sqlattr));
	sprintf(sqlattr, "select a.id, a.sn, a.cmdname, a.status, b.object, b.flag, b.flag1 from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and b.cmd_type = '1' and a.id = '%s' order by a.sn", col_values[0]);
	rc = sqlite3_exec(db, sqlattr, &sqlite3_exec_callback_cmd, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	if(cnt3 > 0)
	{
		fprintf(cgiOut, "      </tr>\n");
		fprintf(cgiOut, "    </table>\n");
		fprintf(cgiOut, "  </td>\n");
		fprintf(cgiOut, "</tr>\n");
	}
	//��������(��������)
	memset(sqlattr, 0, sizeof(sqlattr));
	sprintf(sqlattr, "select a.id, a.sn, a.cmdname, a.status, b.object, b.flag, b.flag1 from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and b.cmd_type = '0' and a.id = '%s' order by a.sn", col_values[0]);
	rc = sqlite3_exec(db, sqlattr, &sqlite3_exec_callback_cmd_0, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	if(cnt5 > 0)
	{
		fprintf(cgiOut, "      </tr>\n");
		fprintf(cgiOut, "    </table>\n");
		fprintf(cgiOut, "  </td>\n");
		fprintf(cgiOut, "</tr>\n");
	}
	sqlite3_close(db);
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='popDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "<div id='cmdDiv' class='cmddiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "<input type='hidden' name='private_attr' value=''>\n");
	fprintf(cgiOut, "<input id='CurrButton' name='CurrButton' type='button' onClick='doEdit()' style='display:none'>\n");
	fprintf(cgiOut, "<input type='hidden' name='ctype3'      value='%s'>\n", col_values[20]);
	fprintf(cgiOut, "<input type='hidden' name='self_idflag' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='self_comcnt' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='self_value'  value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='self_value2' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='self_parent' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='self_ischag' value=''>\n");
	fprintf(cgiOut, "<input type='hidden' name='preset'      value=''>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//ִ�л����ӿ�
	if(NULL != col_values[19] && strlen(col_values[19]) > 0 && atoi(col_values[19]) >= 11)
	{
		fprintf(cgiOut, "if(device_detail.self_id)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  device_detail.self_id.value = device_detail.self_id.value.substring(2);\n");
		fprintf(cgiOut, "}\n");
	}
	fprintf(cgiOut, "function doChange3(pValue)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('ctype2').innerHTML = '';\n");
	fprintf(cgiOut, "  if(pValue.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var list = pValue.split('#');\n");
	fprintf(cgiOut, "  if(list[3].length > 0)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var objHTML = '';\n");
	fprintf(cgiOut, "    var sublist = list[3].split(';');\n");
	fprintf(cgiOut, "    for(var i=0; i<sublist.length && sublist[i].length>1; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var checkflag = '';\n");
	fprintf(cgiOut, "      if(list[2] == '%s'.substring(0,2))\n", col_values[7]);
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        if('%s'.charAt(i) == '1')\n", col_values[8]);
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          checkflag = 'checked';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      var sublist2 = sublist[i].split(',');\n");
	fprintf(cgiOut, "      objHTML += \"<input type='checkbox' id='checkbox\"+i+\"' name='checkbox\"+i+\"' value='\"+sublist2[0]+\"' \"+checkflag+\">\" + sublist2[1] + \"&nbsp;&nbsp;\";\n");
	fprintf(cgiOut, "      if(i > 0 && (i+1)%%4 == 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        objHTML += '<br>';\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(device_detail.ctype3.value.substring(2,4) != '00')\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      objHTML += '<br>';\n");
	fprintf(cgiOut, "      objHTML += '------------------';\n");
	fprintf(cgiOut, "      objHTML += '<br>';\n");
	fprintf(cgiOut, "    	 for(var i=0; i<sublist.length && sublist[i].length>1; i++)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var j = i + sublist.length - 1;\n");
	fprintf(cgiOut, "        var checkflag = '';\n");
	fprintf(cgiOut, "        if(list[2] == '%s'.substring(0,2))\n", col_values[7]);
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          if('%s'.charAt(j) == '1')\n", col_values[8]);
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            checkflag = 'checked';\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        var sublist2 = sublist[i].split(',');\n");
	fprintf(cgiOut, "        objHTML += \"<input type='checkbox' id='checkbox\"+j+\"' name='checkbox\"+j+\"' value='\"+sublist2[0]+\"' \"+checkflag+\">\" + sublist2[1] + \"&nbsp;&nbsp;\";\n");
	fprintf(cgiOut, "        if(i > 0 && (i+1)%%4 == 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          objHTML += '<br>';\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    document.getElementById('ctype2').innerHTML = objHTML;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	if(NULL != col_values[19] && strlen(col_values[19]) > 0 && atoi(col_values[19]) >= 11)
	{
		fprintf(cgiOut, "doChange3(device_detail.ctype1.value);\n");
	}
	//�رյ�����
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'none';\n");
	fprintf(cgiOut, "  document.getElementById('cmdDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//���߸澯
	fprintf(cgiOut, "function doOff(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'device_off.cgi?cmd=0&id='+pId;\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').innerHTML = \"<iframe id='offFrame' name='offFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//�ɼ�����
	fprintf(cgiOut, "function doAttrAdd(pId, pSN)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('popDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'device_roll.cgi?cmd=0&id='+pId+'&sn='+pSN+'&level=%s&fromtype=2';\n", level);
	fprintf(cgiOut, "  document.getElementById('popDiv').innerHTML = \"<iframe id='divFrame' name='divFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='auto'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//��������
	fprintf(cgiOut, "function doCmdAdd(pId, pSN)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('cmdDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'device_topo.cgi?cmd=8&id='+pId+'&sn='+pSN+'&level=%s';\n", level);
	fprintf(cgiOut, "  document.getElementById('cmdDiv').innerHTML = \"<iframe id='cmdFrame' name='cmdFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");
	//����ִ��
	fprintf(cgiOut, "function doCmdAct(pId, pSN, pCmdName, pStatus, pObject, pFlag, pFlag1)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if('0' == pStatus)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ����δ��Ч�����ɲ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if('0' == pObject && '0' == pFlag1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var object = ' ';\n");
  fprintf(cgiOut, "    if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(window.XMLHttpRequest)\n");
  fprintf(cgiOut, "      {\n");
  fprintf(cgiOut, "        reqSend = new XMLHttpRequest();\n");
  fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "      {\n");
  fprintf(cgiOut, "        reqSend = new ActiveXObject('Microsoft.XMLHTTP');\n");
  fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      reqSend.onreadystatechange = function(){callbackSendName(pSN, pCmdName)};\n");
	fprintf(cgiOut, "      var url = 'device_topo.cgi?cmd=10&id='+pId+'&sn='+pSN+'&object='+object+'&isflag='+pFlag;\n");
	fprintf(cgiOut, "      reqSend.open(\"get\",url);\n");
	fprintf(cgiOut, "      reqSend.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "      reqSend.send(null);\n");
	fprintf(cgiOut, "      return true;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('cmdDiv').style.display = 'block';\n");
	fprintf(cgiOut, "    var url = 'device_topo.cgi?cmd=11&id='+pId+'&sn='+pSN+'&cmdname='+pCmdName+'&isobject='+pObject+'&isflag2='+pFlag1;\n");
	fprintf(cgiOut, "    document.getElementById('cmdDiv').innerHTML = \"<iframe id='cmdFrame' name='cmdFrame' src='\"+url+\"' style='width:100%%;height:100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackSendName(pSN, pCmdName)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqSend.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqSend.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('����:['+pCmdName+'], ���:['+resp+']');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//�༭
	fprintf(cgiOut, "var reqEdit = null;\n");
	fprintf(cgiOut, "function doEdit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_detail.cname.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������豸����');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	if(NULL != col_values[19] && strlen(col_values[19]) > 0 && atoi(col_values[19]) >= 11)
	{
		fprintf(cgiOut, "device_detail.self_comcnt.value = device_detail.ctype3.value.substring(0,2);\n");
		fprintf(cgiOut, "if(device_detail.ctype1.value.length < 1)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "    alert('��ѡ��ִ�л���');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "var cnt = 0;\n");
		fprintf(cgiOut, "for(var i=0; i<63; i++)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(document.getElementById('checkbox'+i))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    cnt++;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
		
		fprintf(cgiOut, "var preset = '';\n");
		fprintf(cgiOut, "var self_value = 0;\n");
		fprintf(cgiOut, "var self_value2 = 0;\n");
		fprintf(cgiOut, "var checkcnt = 0;\n");
		fprintf(cgiOut, "if(device_detail.ctype3.value.substring(2,4) == '00')\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  for(var i=0; i<cnt; i++)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    if(document.getElementById('checkbox'+i).checked)\n");
		fprintf(cgiOut, "    {\n");
		fprintf(cgiOut, "      checkcnt++;\n");
		fprintf(cgiOut, "      preset += '1';\n");
		fprintf(cgiOut, "      self_value += parseInt(document.getElementById('checkbox'+i).value);\n");
		fprintf(cgiOut, "      if(1 == checkcnt)\n");
		fprintf(cgiOut, "      {\n");
		fprintf(cgiOut, "        for(var j=i; j<(i+parseInt(device_detail.self_comcnt.value)); j++)\n");
		fprintf(cgiOut, "        {\n");
		fprintf(cgiOut, "          if(document.getElementById('checkbox'+j))\n");
		fprintf(cgiOut, "          {\n");
		fprintf(cgiOut, "            if(document.getElementById('checkbox'+j).checked == false)\n");
		fprintf(cgiOut, "            {\n");
		fprintf(cgiOut, "              alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "              return;\n");
		fprintf(cgiOut, "            }\n");
		fprintf(cgiOut, "          }\n");
		fprintf(cgiOut, "          else\n");
		fprintf(cgiOut, "          {\n");
		fprintf(cgiOut, "            alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "            return;\n");
		fprintf(cgiOut, "          }\n");
		fprintf(cgiOut, "        }\n");
		fprintf(cgiOut, "      }\n");
		fprintf(cgiOut, "    }\n");
		fprintf(cgiOut, "    else\n");
		fprintf(cgiOut, "    {\n");
		fprintf(cgiOut, "      preset += '0';\n");
		fprintf(cgiOut, "    }\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  if(preset.indexOf('1') < 0)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  if(checkcnt != parseInt(device_detail.self_comcnt.value))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  device_detail.self_value.value = self_value;\n");
		fprintf(cgiOut, "  device_detail.self_value2.value = '0';\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "else\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  for(var i=0; i<cnt/2; i++)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    if(document.getElementById('checkbox'+i).checked)\n");
		fprintf(cgiOut, "    {\n");
		fprintf(cgiOut, "      checkcnt++;\n");
		fprintf(cgiOut, "      preset += '1';\n");
		fprintf(cgiOut, "      self_value += parseInt(document.getElementById('checkbox'+i).value);\n");
		fprintf(cgiOut, "      if(1 == checkcnt)\n");
		fprintf(cgiOut, "      {\n");
		fprintf(cgiOut, "        for(var j=i; j<(i+parseInt(device_detail.self_comcnt.value)); j++)\n");
		fprintf(cgiOut, "        {\n");
		fprintf(cgiOut, "          if(document.getElementById('checkbox'+j))\n");
		fprintf(cgiOut, "          {\n");
		fprintf(cgiOut, "            if(document.getElementById('checkbox'+j).checked == false)\n");
		fprintf(cgiOut, "            {\n");
		fprintf(cgiOut, "              alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "              return;\n");
		fprintf(cgiOut, "            }\n");
		fprintf(cgiOut, "          }\n");
		fprintf(cgiOut, "          else\n");
		fprintf(cgiOut, "          {\n");
		fprintf(cgiOut, "            alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "            return;\n");
		fprintf(cgiOut, "          }\n");
		fprintf(cgiOut, "        }\n");
		fprintf(cgiOut, "      }\n");
		fprintf(cgiOut, "    }\n");
		fprintf(cgiOut, "    else\n");
		fprintf(cgiOut, "    {\n");
		fprintf(cgiOut, "      preset += '0';\n");
		fprintf(cgiOut, "    }\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  if(preset.indexOf('1') < 0)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  if(checkcnt != parseInt(device_detail.self_comcnt.value))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  checkcnt = 0;\n");
		fprintf(cgiOut, "  for(var i=cnt/2; i<cnt; i++)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    if(document.getElementById('checkbox'+i).checked)\n");
		fprintf(cgiOut, "    {\n");
		fprintf(cgiOut, "      checkcnt++;\n");
		fprintf(cgiOut, "      preset += '1';\n");
		fprintf(cgiOut, "      self_value2 += parseInt(document.getElementById('checkbox'+i).value);\n");
		fprintf(cgiOut, "      if(1 == checkcnt)\n");
		fprintf(cgiOut, "      {\n");
		fprintf(cgiOut, "        for(var j=i; j<(i+parseInt(device_detail.self_comcnt.value)); j++)\n");
		fprintf(cgiOut, "        {\n");
		fprintf(cgiOut, "          if(document.getElementById('checkbox'+j))\n");
		fprintf(cgiOut, "          {\n");
		fprintf(cgiOut, "            if(document.getElementById('checkbox'+j).checked == false)\n");
		fprintf(cgiOut, "            {\n");
		fprintf(cgiOut, "              alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "              return;\n");
		fprintf(cgiOut, "            }\n");
		fprintf(cgiOut, "          }\n");
		fprintf(cgiOut, "          else\n");
		fprintf(cgiOut, "          {\n");
		fprintf(cgiOut, "            alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "            return;\n");
		fprintf(cgiOut, "          }\n");
		fprintf(cgiOut, "        }\n");
		fprintf(cgiOut, "      }\n");
		fprintf(cgiOut, "    }\n");
		fprintf(cgiOut, "    else\n");
		fprintf(cgiOut, "    {\n");
		fprintf(cgiOut, "      preset += '0';\n");
		fprintf(cgiOut, "    }\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  if(preset.substring(cnt/2).indexOf('1') < 0)\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  if(checkcnt != parseInt(device_detail.self_comcnt.value))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('ִ�л����Ľӿ�ͨ�����ô���!');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "  device_detail.self_value.value = self_value;\n");
		fprintf(cgiOut, "  device_detail.self_value2.value = self_value2;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "device_detail.self_idflag.value = '1';\n");
		fprintf(cgiOut, "device_detail.self_parent.value = device_detail.ctype1.value.split('#')[2];\n");
		fprintf(cgiOut, "device_detail.preset.value = preset;\n");
		fprintf(cgiOut, "if(device_detail.self_parent.value.length != 2)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('ִ�л�����ͨ�������ô���!');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "if(device_detail.preset.value == '%s' && device_detail.self_parent.value == '%s'.substring(0,2))\n", col_values[8], col_values[7]);
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  device_detail.self_ischag.value = '';\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "else\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  device_detail.self_ischag.value = '1';\n");
		fprintf(cgiOut, "}\n");
	}
	else
	{
		fprintf(cgiOut, "device_detail.ctype3.value = '';\n");
		fprintf(cgiOut, "device_detail.self_ischag.value = '';\n");
		fprintf(cgiOut, "device_detail.self_idflag.value = '';\n");
		fprintf(cgiOut, "device_detail.self_value.value = '';\n");
		fprintf(cgiOut, "device_detail.self_value2.value = '';\n");
		fprintf(cgiOut, "device_detail.self_parent.value = '';\n");
		fprintf(cgiOut, "device_detail.preset.value = '';\n");
	}
	
	fprintf(cgiOut, "  //˽�в���\n");
	fprintf(cgiOut, "  var Private_Attr = '';\n");	
  if(strstr(col_values[14], "outip"))
	{
		fprintf(cgiOut, "Private_Attr += 'outip=' + device_detail.outip.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "outport"))
	{
		fprintf(cgiOut, "Private_Attr += 'outport=' + device_detail.outport.value.Trim() + ',';\n");
	}	
	if(strstr(col_values[14], "inip"))
	{
		fprintf(cgiOut, "Private_Attr += 'inip=' + device_detail.inip.value.Trim() + ',';\n");
	}	
	if(strstr(col_values[14], "inport"))
	{
		fprintf(cgiOut, "Private_Attr += 'inport=' + device_detail.inport.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "login_id"))
	{
		fprintf(cgiOut, "Private_Attr += 'login_id=' + device_detail.login_id.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "login_pwd"))
	{
		fprintf(cgiOut, "Private_Attr += 'login_pwd=' + device_detail.login_pwd.value.Trim() + ',';\n");
	}	
	if(strstr(col_values[14], "code_stream"))
	{
		fprintf(cgiOut, "Private_Attr += 'code_stream=' + device_detail.code_stream.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "pan_tilt"))
	{
		fprintf(cgiOut, "Private_Attr += 'pan_tilt=' + device_detail.pan_tilt.value.Trim() + ',';\n");
	}	
	if(strstr(col_values[14], "authmode"))
	{
		fprintf(cgiOut, "Private_Attr += 'authmode=' + device_detail.authmode.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "bpt"))
	{
		fprintf(cgiOut, "Private_Attr += 'bpt=' + device_detail.bpt.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "databyte"))
	{
		fprintf(cgiOut, "Private_Attr += 'databyte=' + device_detail.databyte.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "stopbyte"))
	{
		fprintf(cgiOut, "Private_Attr += 'stopbyte=' + device_detail.stopbyte.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "checkbyte"))
	{
		fprintf(cgiOut, "Private_Attr += 'checkbyte=' + device_detail.checkbyte.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "cover_flag"))
	{
		fprintf(cgiOut, "Private_Attr += 'cover_flag=' + device_detail.cover_flag.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "rolltimeout"))
	{
		fprintf(cgiOut, "if(device_detail.rolltimeout.value.Trim().length < 1)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('��������Ѳ��ʱʱ��');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "for(var i=0; i<device_detail.rolltimeout.value.Trim().length; i++)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(isNaN(device_detail.rolltimeout.value.charAt(i)))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('��Ѳ��ʱ���뺬�Ƿ��ַ�');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "Private_Attr += 'rolltimeout=' + device_detail.rolltimeout.value.Trim() + ',';\n");
	}
	if(strstr(col_values[14], "isUpload"))
	{
		fprintf(cgiOut, "Private_Attr += 'isUpload=' + device_detail.isUpload.value.Trim() + ',';\n");
	}
	
	fprintf(cgiOut, "var Self_Id = '';\n");
	if(strstr(col_values[14], "self_id"))
	{
		fprintf(cgiOut, "Self_Id = device_detail.self_id.value.Trim();\n");
	}
	
	fprintf(cgiOut, "  var Upper_Channel = '%s';\n", col_values[3]);
	if(0 == strcmp(level, "2") || 0 == strcmp(level, "3"))
	{
		fprintf(cgiOut, "Upper_Channel = device_detail.upper_channel.value;\n");
	}
	
	fprintf(cgiOut, "  var ctype3 = device_detail.ctype3.value;\n");
	fprintf(cgiOut, "  if(ctype3.length == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    ctype3 = ctype3.substring(2,4);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ���༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqEdit = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqEdit = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqEdit.onreadystatechange = callbackEditName;\n");			
	fprintf(cgiOut, "    var url = 'device_topo.cgi?cmd=5&id='+device_detail.id.value+'&cname='+device_detail.cname.value+'&brief='+device_detail.brief.value+'&memo='+device_detail.memo.value+'&private_attr='+Private_Attr+'&ctype='+device_detail.ctype.value+'&self_id='+Self_Id+'&level=%s&upper=%s&upper_channel='+Upper_Channel+'&status=%s&self_idflag='+device_detail.self_idflag.value+'&self_value='+device_detail.self_value.value+'&self_parent='+device_detail.self_parent.value+'&self_ischag='+device_detail.self_ischag.value+'&preset='+device_detail.preset.value+'&self_value2='+device_detail.self_value2.value+'&ctype3='+ctype3+'&currtime='+new Date();\n", level, col_values[2], col_values[5]);
	fprintf(cgiOut, "    reqEdit.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqEdit.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqEdit.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackEditName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqEdit.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqEdit.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
	
	return 0;
}

int sqlite3_exec_callback_alert(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt4++;
	return 0;
}

int sqlite3_exec_callback_attr(void *data, int n_columns, char **col_values, char **col_names)
{
	if(0 == cnt2)
	{
		fprintf(cgiOut, "<tr height='30'>\n");
		fprintf(cgiOut, "  <td width='15%%'  align='center'>�ɼ�����</td>\n");
		fprintf(cgiOut, "  <td width='85%%'  align='left' colspan=3>\n");
		fprintf(cgiOut, "    <table width='100%%' border=0>\n");
		fprintf(cgiOut, "      <tr height='30px'>\n");
	}
	
	char rollstr[60] = {0};
	if(0 == strcmp(col_values[3], "1"))
	{
		strcat(rollstr, "[<font color=green>�ɼ���</font>]");
	}
	else
	{
		strcat(rollstr, "[<font color=gray>δ�ɼ�</font>]");
	}
	
	if(0 == cnt2%3 && cnt2 > 0)	
	{	
		fprintf(cgiOut, "</tr>\n");
		fprintf(cgiOut, "<tr height='30px'>\n");
	}
	
	fprintf(cgiOut, "<td width='33%%' align='center'>\n");
	fprintf(cgiOut, "  <table width='100%%'>\n");
	fprintf(cgiOut, "    <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "        <a href='#' onClick=\"doAttrAdd('%s', '%s')\">%s&nbsp;%s</a>\n", col_values[0], col_values[1], col_values[2], rollstr);
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</td>\n");
		
	cnt2++;
	return 0;
}

int sqlite3_exec_callback_cmd(void *data, int n_columns, char **col_values, char **col_names)
{
	if(0 == cnt3)
	{
		fprintf(cgiOut, "<tr height='30'>\n");
		fprintf(cgiOut, "  <td width='15%%'  align='center'>��������<br>(���ɷ���)</td>\n");
		fprintf(cgiOut, "  <td width='85%%'  align='left' colspan=3>\n");
		fprintf(cgiOut, "    <table width='100%%' border=0>\n");
		fprintf(cgiOut, "      <tr height='30px'>\n");
	}
	
	char rollstr[60] = {0};
	if(0 == strcmp(col_values[3], "1"))
	{
		strcat(rollstr, "[<font color=green>����Ч</font>]");
	}
	else
	{
		strcat(rollstr, "[<font color=gray>δ��Ч</font>]");
	}
	
	if(0 == cnt3%3 && cnt3 > 0)	
	{	
		fprintf(cgiOut, "</tr>\n");
		fprintf(cgiOut, "<tr height='30px'>\n");
	}
	
	fprintf(cgiOut, "<td width='33%%' align='center'>\n");
	fprintf(cgiOut, "  <table width='100%%'>\n");
	fprintf(cgiOut, "    <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "        <input type='button' value='%s' style='width:70px;height:20px;cursor:hand;' onClick=\"doCmdAct('%s', '%s', '%s', '%s', '%s', '%s', '%s')\">&nbsp;<a href='#' onClick=\"doCmdAdd('%s', '%s')\">%s</a>\n", col_values[2], col_values[0], col_values[1], col_values[2], col_values[3], col_values[4], col_values[5], col_values[6], col_values[0], col_values[1], rollstr);
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</td>\n");
		
	cnt3++;
	return 0;
}

int sqlite3_exec_callback_cmd_0(void *data, int n_columns, char **col_values, char **col_names)
{
	if(0 == cnt5)
	{
		fprintf(cgiOut, "<tr height='30'>\n");
		fprintf(cgiOut, "  <td width='15%%'  align='center'>��������<br>(��������)</td>\n");
		fprintf(cgiOut, "  <td width='85%%'  align='left' colspan=3>\n");
		fprintf(cgiOut, "    <table width='100%%' border=0>\n");
		fprintf(cgiOut, "      <tr height='30px'>\n");
	}
	
	char rollstr[60] = {0};
	if(0 == strcmp(col_values[3], "1"))
	{
		strcat(rollstr, "[<font color=green>����Ч</font>]");
	}
	else
	{
		strcat(rollstr, "[<font color=gray>δ��Ч</font>]");
	}
	
	if(0 == cnt5%3 && cnt5 > 0)	
	{	
		fprintf(cgiOut, "</tr>\n");
		fprintf(cgiOut, "<tr height='30px'>\n");
	}
	
	fprintf(cgiOut, "<td width='33%%' align='center'>\n");
	fprintf(cgiOut, "  <table width='100%%'>\n");
	fprintf(cgiOut, "    <tr height='30px'>\n");
	fprintf(cgiOut, "      <td width='100%%' align='left'>\n");
	fprintf(cgiOut, "        <input type='button' value='%s' style='width:70px;height:20px;cursor:hand;' onClick=\"doCmdAct('%s', '%s', '%s', '%s', '%s', '%s', '%s')\">&nbsp;<a href='#' onClick=\"doCmdAdd('%s', '%s')\">%s</a>\n", col_values[2], col_values[0], col_values[1], col_values[2], col_values[3], col_values[4], col_values[5], col_values[6], col_values[0], col_values[1], rollstr);
	fprintf(cgiOut, "      </td>\n");
	fprintf(cgiOut, "    </tr>\n");
	fprintf(cgiOut, "  </table>\n");
	fprintf(cgiOut, "</td>\n");
		
	cnt5++;
	return 0;
}

void UdpTrue()
{
	if(0 == strcmp(self_idflag, "1"))
	{
		strcat(self_parent, self_id);
		memset(self_id, 0, sizeof(self_id));
		memcpy(self_id, self_parent, 21);
		sprintf(self_value, "%04X", atoi(self_value));
		sprintf(self_value2, "%04X", atoi(self_value2));
	}
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	//�޸�
	switch(atoi(level))
	{
		case 0:	
		case 1:		
				rc = sqlite3_exec(db, getSql(11), &sqlite3_exec_callback, 0, &zErrMsg);
				if(rc != SQLITE_OK )
				{
				  err_msg(1);
				}
				sqlite3_close(db);
				printf("�ɹ�\n");
			break;	
		case 2:
		case 3:
				sqlite3_close(db);
				int ret = MsgSend(2);				
				if((0 == ret || 3000 == ret) && 0 == strcmp(self_idflag, "1") && 0 == strcmp(self_ischag, "1"))
				{//�󶨼̵���		
					memset(sn, 0, sizeof(sn));
					memset(object, 0, sizeof(object));
					strcat(sn, "00020001");
					strcat(object, self_value);
					strcat(object, self_value2);
					strcat(object, ctype3);
					ret = MsgSend(5);
					printf("%s\n", getStatusName(ret));
				}
				else
				{
					printf("%s\n", getStatusName(ret));
				}
			break;
	}	
	//sqlite3_close(db);
}

void CmdAdd()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = {0};
	sprintf(sql, "select a.id, a.sn, a.cmdname, a.status, a.private_attr, a.v_id, a.v_sn, b.private_attr, b.ctype from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and a.id = '%s' and a.sn = '%s'", id, sn);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cmdadd, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_cmdadd(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>��������</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#d2d2e9\">\n");
	fprintf(cgiOut, "<form name=\"cmdadd\" action=\"cmdadd.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<table width=\"98%%\" align='center' style='margin:auto;margin-top:5px' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='35%%' align='center'>��������</td>\n");
	fprintf(cgiOut, "    <td width='65%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='cmdname' style='width:90%%;height:20px' value='%s' maxlength=10>\n", col_values[2]);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='35%%' align='center'>�Ƿ���Ч</td>\n");
	fprintf(cgiOut, "    <td width='65%%' align='left'>\n");
	fprintf(cgiOut, "      <select name='status' style='width:90%%;height:20px'>\n");
	fprintf(cgiOut, "        <option value='0' %s>��</option>\n", 0 == strcmp(col_values[3], "0")?"selected":"");
	fprintf(cgiOut, "        <option value='1' %s>��</option>\n", 0 == strcmp(col_values[3], "1")?"selected":"");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	//�Ƿ��ϴ�
	if(strstr(col_values[7], "isUpload"))
	{
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='35%%' align='center'>�Ƿ��ϴ�</td>\n");
		fprintf(cgiOut, "    <td width='65%%' align='left'>\n");
		fprintf(cgiOut, "      <select name='isUpload' style='width:90%%;height:20px'>\n");
		fprintf(cgiOut, "        <option value='0' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[4], "isUpload="), "0")?"selected":"");
		fprintf(cgiOut, "        <option value='1' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[4], "isUpload="), "1")?"selected":"");
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	
	//����ת��
	if(0 == strcmp(col_values[8], "1"))
	{
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='35%%' align='center'>����ת��</td>\n");
		fprintf(cgiOut, "    <td width='65%%' align='left'>\n");
		fprintf(cgiOut, "      <select name='v_id' id='v_id' style='width:50%%;height:20px' onchange='doChange(this.value);'>\n");
		
		int rc;
		char * zErrMsg = 0;
		char sql1[1024] = {0};
		sprintf(sql1, "select a.id, a.cname from device_detail a, device_act b where a.id = b.id and a.id <> '%s' group by a.id", id);
		sqlite3 *db = open_db(DB_PATH);	
		rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_act_dev, col_values[5], &zErrMsg);
		if(rc != SQLITE_OK)
		{
		  err_msg(1);
		}
		sqlite3_close(db);
		
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "      ��\n");
		fprintf(cgiOut, "      <select name='v_sn' id='v_sn' style='width:30%%;height:20px'>\n");
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	else
	{
		fprintf(cgiOut, "  <input type='hidden' name='v_id' value=''>\n");
		fprintf(cgiOut, "  <input type='hidden' name='v_sn' value=''>\n");
	}
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>\n");	
	fprintf(cgiOut, "      <input type='button' value='�ύ' style='width:40px;height:22px' onClick=\"doEdit();\">\n");
	fprintf(cgiOut, "      <input type='button' value='����' style='width:40px;height:22px' onClick=\"doCancel();\">\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	//����ת��
	fprintf(cgiOut, "function doChange(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var length = document.getElementById('v_sn').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('v_sn').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(pId.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqChg.onreadystatechange = callbackChangeName;\n");
	fprintf(cgiOut, "  var url = 'device_topo.cgi?cmd=13&id='+pId+'&currtime='+new Date();\n");
	fprintf(cgiOut, "	 reqChg.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqChg.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackChangeName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqChg.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqChg.responseText;\n");	
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var list = resp.split('#');\n");
	fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "      		 var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      		 objOption.value = sublist[0];\n");
	fprintf(cgiOut, "      		 objOption.text  = sublist[1];\n");
	fprintf(cgiOut, "      		 document.getElementById('v_sn').add(objOption);\n");
	fprintf(cgiOut, "          if('%s' == sublist[0])\n", col_values[6]);
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            objOption.selected = true;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	if(0 == strcmp(col_values[8], "1"))
	{
		fprintf(cgiOut, "doChange(cmdadd.v_id.value);\n");
	}
	
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	
	//�༭
  fprintf(cgiOut, "var reqSend = null;\n");
  fprintf(cgiOut, "function doEdit()\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  if(cmdadd.cmdname.value.Trim().length < 1)\n");
  fprintf(cgiOut, "  {\n");
  fprintf(cgiOut, "    alert('����д��������!');\n");
  fprintf(cgiOut, "    return;\n");
  fprintf(cgiOut, "  }\n");
  fprintf(cgiOut, "  var Private_Attr = '';\n");
  if(strstr(col_values[7], "isUpload"))
	{
		fprintf(cgiOut, "Private_Attr += 'isUpload='+cmdadd.isUpload.value+',';\n");
	}
	fprintf(cgiOut, "  if(confirm('ȷ���༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      reqSend = new XMLHttpRequest();\n");
  fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      reqSend = new ActiveXObject('Microsoft.XMLHTTP');\n");
  fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqSend.onreadystatechange = callbackSendName;\n");
	fprintf(cgiOut, "    var url = 'device_topo.cgi?cmd=9&id=%s&sn=%s&cmdname='+cmdadd.cmdname.value.Trim()+'&status='+cmdadd.status.value+'&v_private_attr='+Private_Attr+'&v_id='+cmdadd.v_id.value+'&v_sn='+cmdadd.v_sn.value;\n", id, sn);
	fprintf(cgiOut, "    reqSend.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqSend.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqSend.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackSendName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqSend.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqSend.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "        if(resp.indexOf('�ɹ�') >= 0 || resp.indexOf('�ύ�ɹ�') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "  				 parent.closeDiv();\n");
	fprintf(cgiOut, "          parent.location = 'device_topo.cgi?cmd=4&id=%s&level=%s';\n", id, level);
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
	return 0;	
}

int sqlite3_exec_callback_act_dev(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != (char *)data && 0 == strcmp(col_values[0], (char *)data))
	{
		fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", col_values[0], col_values[1]);
	}
	else
	{
		fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	}
	return 0;
}

void QueryAct()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = "select a.sn, a.cmdname from device_act a, device_cmd b where substr(a.id,1,6) = b.id and a.sn = b.sn and a.id = '";
	strcat(sql, id);
	strcat(sql, "' and b.ctype = '0' order by a.sn");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_queryact, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_queryact(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "%s,%s#", col_values[0], col_values[1]);
	return 0;
}

void CmdAddTrue()
{
	int ret = MsgSend(4);
	printf("%s\n", getStatusName(ret));
}

void CmdActTrue()
{
	if(NULL != isflag && (0 == strcmp(isflag, "1") || 0 == strcmp(isflag, "2")))
	{
		int ret = MsgSend(6);
		switch(ret)
		{
			default:
					printf("ʧ��\n");
				break;
			case 0:
					//����
					if(NULL != realmode && strstr(realmode, "}"))
					{
						char curr_Mode[5] = {0};
						char curr_SN[5] = {0};
						int i = 0;
						char* split_result = NULL;
				    char* savePtr = NULL;
				    split_result = strtok_r(realmode, "}", &savePtr);
				    while(NULL != split_result)
						{
							if(0 == i)
							{
								strncpy(curr_Mode, split_result+11, 4);
								strncpy(curr_SN, split_result+15, 4);
								break;
							}						
							i++;
							split_result = strtok_r(NULL, "}", &savePtr);
						}
						
						memset(sn, 0, sizeof(sn));
						memcpy(sn, getB_NCmd(atoi(isflag), id, curr_Mode, curr_SN), 9);
						if(NULL != sn && strlen(sn) == 8)
						{
							int ret2 = MsgSend(5);
							printf("%s\n", getStatusName(ret2));
						}
						else
						{
							printf("ʧ��\n");
						}						
					}
					else
					{
						printf("ʧ��\n");
					}			
				break;
		}
	}
	else if(NULL != isflag && 0 == strcmp(isflag, "3"))
	{//����ģʽ
		int ret = MsgSend(6);
		switch(ret)
		{
			default:
					printf("ʧ��\n");
				break;
			case 0:
					//����
					if(NULL != realmode && strstr(realmode, "}"))
					{
						char curr_Mode[5] = {0};
						char curr_SN[5] = {0};
						int i = 0;
						char* split_result = NULL;
				    char* savePtr = NULL;
				    split_result = strtok_r(realmode, "}", &savePtr);
				    while(NULL != split_result)
						{
							if(0 == i)
							{
								strncpy(curr_Mode, split_result+11, 4);
								strncpy(curr_SN, split_result+15, 4);
								break;
							}						
							i++;
							split_result = strtok_r(NULL, "}", &savePtr);
						}
						
						memset(sn, 0, sizeof(sn));
						strcat(sn, curr_Mode);
						strcat(sn, obj_insert);
						if(NULL != sn && strlen(sn) == 8)
						{
							int ret2 = MsgSend(5);
							printf("%s\n", getStatusName(ret2));
						}
						else
						{
							printf("ʧ��\n");
						}						
					}
					else
					{
						printf("ʧ��\n");
					}			
				break;
		}
	}
	else
	{
		int ret = MsgSend(5);
		printf("%s\n", getStatusName(ret));
	}
}

char *getB_NCmd(int pCType, char *pId, char *pModeId, char *pSN)
{
	memset(FillStr, 0, sizeof(FillStr));
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	char sql[512] = {0};
	switch(pCType)
	{
		case 1://��һ����
				strcat(sql, "select a.b_sn from device_cmd a where a.id = substr('");
				strcat(sql, pId);
				strcat(sql, "',1,6) and a.sn = '");
				strcat(sql, pModeId);
				strcat(sql, pSN);
				strcat(sql, "'");
			break;
		case 2://��һ����
				strcat(sql, "select a.n_sn from device_cmd a where a.id = substr('");
				strcat(sql, pId);
				strcat(sql, "',1,6) and a.sn = '");
				strcat(sql, pModeId);
				strcat(sql, pSN);
				strcat(sql, "'");
			break;
	}
	
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_getB_NCmd, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	return FillStr;
}

int sqlite3_exec_callback_getB_NCmd(void *data, int n_columns, char **col_values, char **col_names)
{
	memcpy(FillStr, col_values[0], 9);
	return 0;
}

void CmdObject()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>Զ�̿���</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "<script type='text/javascript' src='../skin/js/util.js' charset='gb2312'></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");
	fprintf(cgiOut, "</HEAD>\n");
	fprintf(cgiOut, "<BODY style=\"background:#d2d2e9\">\n");
	fprintf(cgiOut, "<form name=\"ObjHtml\" action=\"device_topo.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<table width=\"98%%\" align='center' style='margin:auto;margin-top:10px' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	
	//������ģʽ
	if(0 == strcmp(isflag2, "0"))
	{
		if(0 == strncmp(id, "001103", 6))
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='tel' style='width:90%%;height:20px' value='' maxlength=200>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='obj' style='width:90%%;height:20px' value='' maxlength=100>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
		else if(0 == strncmp(id, "001104", 6))
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='tel' style='width:90%%;height:20px' value='' maxlength=200>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <select name='obj' style='width:90%%;height:20px'>\n");
			
			int rc;
			char * zErrMsg = 0;
			sqlite3 *db = open_db(DB_PATH);
			char sql[128] = {0};
			sprintf(sql, "select a.sn, a.cname from call a");
			rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_call, 0, &zErrMsg);
			if(rc != SQLITE_OK)
			{
			  err_msg(1);
			}
			sqlite3_close(db);
			
			fprintf(cgiOut, "    </select>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
		else
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='obj' style='width:90%%;height:20px' value='' maxlength=256>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
	}
	//����ģʽ
	else if(0 == strcmp(isflag2, "1"))
	{
		fprintf(cgiOut, "<tr height='30'>\n");
		fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
		fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
		fprintf(cgiOut, "    <input type='text' name='obj_insert' style='width:90%%;height:20px' value='' maxlength=4>\n");
		fprintf(cgiOut, "  </td>\n");
		fprintf(cgiOut, "</tr>\n");	
		if(0 == strcmp(isobject, "1"))
		{
			fprintf(cgiOut, "<tr height='30'>\n");
			fprintf(cgiOut, "  <td width='20%%' align='center'>����</td>\n");
			fprintf(cgiOut, "  <td width='80%%' align='left'>\n");
			fprintf(cgiOut, "    <input type='text' name='obj' style='width:90%%;height:20px' value='' maxlength=256>\n");
			fprintf(cgiOut, "  </td>\n");
			fprintf(cgiOut, "</tr>\n");
		}
	}	
		
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='center' colspan=2>\n");	
	fprintf(cgiOut, "      <input type='button' value='�ر�' style='width:40px;height:22px' onClick=\"doCancel();\">\n");
	fprintf(cgiOut, "      <input type='button' value='�ύ' style='width:40px;height:22px' onClick=\"doSend('%s');\">\n", id);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<script language='javascript'>\n");
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	//doSend����
  fprintf(cgiOut, "var reqSend = null;\n");
  fprintf(cgiOut, "function doSend(pId)\n");
  fprintf(cgiOut, "{\n");
  fprintf(cgiOut, "  var object = '';\n");
  fprintf(cgiOut, "  var obj_insert = '';\n");
  fprintf(cgiOut, "  var isflag = '';\n");
  //������ģʽ
	if(0 == strcmp(isflag2, "0"))
	{
		fprintf(cgiOut, "var isflag = '0';\n");
	  fprintf(cgiOut, "if('001103' == pId.substring(0,6) || '001104' == pId.substring(0,6))\n");//���š�����
	  fprintf(cgiOut, "{\n");
	  fprintf(cgiOut, "  if(ObjHtml.tel.value.Trim().length < 1)\n");
	  fprintf(cgiOut, "  {\n");
	  fprintf(cgiOut, "    alert('���������');\n");
	  fprintf(cgiOut, "    return;\n");
	  fprintf(cgiOut, "  }\n");
	  fprintf(cgiOut, "  if(ObjHtml.obj.value.Trim().length < 1)\n");
	  fprintf(cgiOut, "  {\n");
	  fprintf(cgiOut, "    alert('����������');\n");
	  fprintf(cgiOut, "    return;\n");
	  fprintf(cgiOut, "  }\n");
	  fprintf(cgiOut, "  object = ObjHtml.tel.value + '//' + ObjHtml.obj.value;\n");
	  fprintf(cgiOut, "}\n");
	  fprintf(cgiOut, "else\n");
	  fprintf(cgiOut, "{\n");
	  fprintf(cgiOut, "  if(ObjHtml.obj.value.Trim().length < 1)\n");
	  fprintf(cgiOut, "  {\n");
	  fprintf(cgiOut, "    alert('����������');\n");
	  fprintf(cgiOut, "    return;\n");
	  fprintf(cgiOut, "  }\n");
	  fprintf(cgiOut, "  object = ObjHtml.obj.value;\n");
	  fprintf(cgiOut, "}\n"); 
	}
	//����ģʽ
	else if(0 == strcmp(isflag2, "1"))
	{
		fprintf(cgiOut, "var isflag = '3';\n");
		fprintf(cgiOut, "if(ObjHtml.obj_insert.value.Trim().length < 1)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('����д����ֵ');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "for(var i=0; i<ObjHtml.obj_insert.value.length; i++)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(isNaN(ObjHtml.obj_insert.value.charAt(i)))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('����ֵ���Ƿ��ַ�!');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "obj_insert = StrLeftFillZero(ObjHtml.obj_insert.value.Trim(), 4);\n");
		if(0 == strcmp(isobject, "1"))
		{
			fprintf(cgiOut, "if(ObjHtml.obj.value.Trim().length < 1)\n");
	  	fprintf(cgiOut, "{\n");
	  	fprintf(cgiOut, "  alert('����������');\n");
	  	fprintf(cgiOut, "  return;\n");
	  	fprintf(cgiOut, "}\n");
	  	fprintf(cgiOut, "object = ObjHtml.obj.value;\n");
		}
	}
  fprintf(cgiOut, "  if(object.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    object = ' ';\n");
	fprintf(cgiOut, "  }\n");  
	fprintf(cgiOut, "  var len = object.len();\n");	
	fprintf(cgiOut, "  if(len > 256)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�������ݳ��ȹ���!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
  fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      reqSend = new XMLHttpRequest();\n");
  fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
  fprintf(cgiOut, "      reqSend = new ActiveXObject('Microsoft.XMLHTTP');\n");
  fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqSend.onreadystatechange = callbackSendName;\n");
	fprintf(cgiOut, "    var url = 'device_topo.cgi?cmd=10&id=%s&sn=%s&object='+object+'&obj_insert='+obj_insert+'&isflag='+isflag;\n", id, sn);
	fprintf(cgiOut, "    reqSend.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqSend.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqSend.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackSendName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqSend.readyState;\n");
	fprintf(cgiOut, "  if(state==4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqSend.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('����:[%s], ���:['+resp+']');\n", cmdname);
	fprintf(cgiOut, "        if(resp.indexOf('�ɹ�') >= 0 || resp.indexOf('�ύ�ɹ�') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "  				 parent.closeDiv();\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</script>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_call(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	return 0;	
}

void SelForAct()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = {0};
	sprintf(sql, "select a.id, a.cname, a.self_id, b.composition, b.ctype1, b.ctype2 from device_detail a, device_info b where substr(a.id,1,6) = b.id and b.ctype1 = '%s' order by a.id", ctype1);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_selforact, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
	  err_msg(2);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_selforact(void *data, int n_columns, char **col_values, char **col_names)
{
	printf("%s#%s#%s#%s#%s#%s@\n", col_values[0], col_values[1], col_values[2], col_values[3], col_values[4], col_values[5]);
	return 0;	
}

int sqlite3_exec_callback_selforupd(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != data && 0 == strncmp((char *)data, col_values[2], 2))
	{
		fprintf(cgiOut, "<option value='%s#%s#%s#%s#%s#%s' selected>%s</option>\n", col_values[0], col_values[1], col_values[2], col_values[3], col_values[4], col_values[5], col_values[1]);
	}
	else
	{
		fprintf(cgiOut, "<option value='%s#%s#%s#%s#%s#%s'>%s</option>\n", col_values[0], col_values[1], col_values[2], col_values[3], col_values[4], col_values[5], col_values[1]);
	}
	return 0;
}

//��������
char *StrLeftFillZero(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	char zero[20] = {0};
	int FillLen = len - strlen(strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(zero, "0");
	}
	strcat(FillStr, zero);
	strcat(FillStr, strData);
	return FillStr;
}

char *StrRightFillSpace(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	int FillLen = len - strlen(strData);
	strcat(FillStr, strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(FillStr, " ");
	}
	return FillStr;
}

//�����߳�
int MsgSend(int flag)
{	
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	//������װ
	BYTE outbuf[2048] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	int len = 0;
	switch(flag)
	{
		case 1://�豸����			
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002002");
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(upper, 10));
				strcat(pdata, StrRightFillSpace(dev_type, 2));
				strcat(pdata, StrRightFillSpace(upper_channel, 2));
				strcat(pdata, StrRightFillSpace(self_id, 20));
				strcat(pdata, StrRightFillSpace(cname, 30));
				strcat(pdata, StrRightFillSpace(brief, 20));
				strcat(pdata, StrRightFillSpace(private_attr, 255));
				strcat(pdata, StrRightFillSpace(preset, 128));
				strcat(pdata, StrRightFillSpace(memo, 128));
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 2 + 2 + 20 + 30 + 20 + 255 + 128 + 128;
			break;
		case 2://�豸�༭
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002003");
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(upper, 10));
				strcat(pdata, StrRightFillSpace(dev_type, 2));
				strcat(pdata, StrRightFillSpace(upper_channel, 2));
				strcat(pdata, StrRightFillSpace(self_id, 20));
				strcat(pdata, StrRightFillSpace(cname, 30));
				strcat(pdata, StrRightFillSpace(brief, 20));
				strcat(pdata, StrRightFillSpace(private_attr, 255));
				strcat(pdata, StrRightFillSpace(preset, 128));
				strcat(pdata, StrRightFillSpace(memo, 128));
				len = MSGHDRLEN + 20 + 8 + 10 + 10 + 2 + 2 + 20 + 30 + 20 + 255 + 128 + 128;
			break;	
		case 3://�豸ɾ��
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002004");
				strcat(pdata, StrRightFillSpace(id, 10));
				len = MSGHDRLEN + 20 + 8 + 10;
			break;
		case 4://�����༭
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002006");
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 8));
				strcat(pdata, StrRightFillSpace(cmdname, 20));
				strcat(pdata, StrRightFillSpace(status, 1));
				strcat(pdata, StrRightFillSpace(v_private_attr, 255));
				strcat(pdata, StrRightFillSpace(v_id, 10));
				strcat(pdata, StrRightFillSpace(v_sn, 8));
				len = MSGHDRLEN + 20 + 8 + 10 + 8 + 20 + 1 + 255 + 10 + 8;
			break;
		case 5://����ִ��
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00003002");
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 8));
				strcat(pdata, StrRightFillSpace("admin", 10));
				strcat(pdata, StrRightFillSpace(object, 256));
				len = MSGHDRLEN + 20 + 8 + 10 + 8 + 10 + 256;
			break;
		case 6://�豸ģʽ��ѯ
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002022");
				strcat(pdata, id);
				len = MSGHDRLEN + 20 + 8 + strlen(id);
	}
	
	//AddMsg((BYTE *)outbuf, 1024);
	
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	
	char *ip = getLocalIP();
	
	//����
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	pSock->SetCompletion();
		
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return SYS_STATUS_FORMAT_ERROR;
	}
	
	char szBuf[512] = {0};
	if(true == pSock->IsPending(30000))
	{
	 	if((len = pSock->Recv(szBuf, 512)) <= 0) 
		{
			pSock->EndSocket();
			return SYS_STATUS_SYS_BUSY;
		}
			
		//���շ���
		pMsgHdr = (PMsgHdr)szBuf;
		char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
		char result[5] = {0};
		strncpy(result, pmsg+20, 4);
		switch(flag)
		{
			case 6://�豸ģʽ��ѯ
					memset(realmode, 0, sizeof(realmode));
					strncpy(realmode, pmsg+28, 4096);
				break;
		}
		pSock->EndSocket();
		return atoi(result);
	}
	else
	{
		pSock->EndSocket();
		return SYS_STATUS_TIMEOUT;
	}
	
	//�ر�����
	pSock->EndSocket();
	return SYS_STATUS_FAILED;
}
