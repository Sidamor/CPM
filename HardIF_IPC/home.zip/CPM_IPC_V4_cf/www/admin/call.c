#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include "util.h"
#include <unistd.h>    
#include <fcntl.h>
#include <dirent.h> 
#include <sys/stat.h>

//��������
char Sql[1024] = {0};
int count = 0;
char cmd[4] = {0};
int total_size = 0;

//��call
char sn[5] = {0};					//���
char cname[20] = {0};			//����
char route[128] = {0};    //·��
char memo[128] = {0};     //��ע
  
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);

static void QueryData();//��ѯ
static void DelData();//ɾ��
static void UpdData();//����
static int UpdCall();//��������
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_cnt(void *data, int n_columns, char **col_values, char **col_names);
static void SingleQuery();//������ѯ
static void AddData();//����
static int AddTrue();//����
static void getMaxSn();
static int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names);
static int getDiskSize();

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	int resp = 0;
	int UdpResp = 0;
	switch(ret)
	{
		case 0:
			count = 0;
			switch(atoi(cmd))
			{		
				case 12://ɾ��
					DelData();
					sprintf(cmd, "%s", "0");
				case 0://��ѯ
					QueryData();
					break;
				case 2://��������
					SingleQuery();
					break;
				case 11://���»�����Ϣ
					UpdData();
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 13://��������				
					UdpResp = UpdCall();
					if(0 == UdpResp)
					{
						fprintf(cgiOut, "<script language='javascript'>alert('�������³ɹ�!');</script>\n");
					}
					else if(2 == UdpResp)
					{
						fprintf(cgiOut, "<script language='javascript'>alert('��������ʧ��,�ļ�����С�� 1M!');</script>\n");
					}
					else if(5 == UdpResp)
					{
						fprintf(cgiOut, "<script language='javascript'>alert('��������ʧ��,�洢�ռ�20M����!');</script>\n");
					}
					else
					{
						fprintf(cgiOut, "<script language='javascript'>alert('��������ʧ��,�����²���!');</script>\n");
					}	
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
				case 1://����
					AddData();
					break;
				case 10://����
					resp = AddTrue();
					if(0 == resp)
					{
						fprintf(cgiOut, "<script language='javascript'>alert('�ϴ��ɹ�');</script>\n");
					}
					else if(2 == resp)
					{
						fprintf(cgiOut, "<script language='javascript'>alert('�ϴ�ʧ��,�ļ�����С�� 1M!');</script>\n");
					}
					else if(5 == resp)
					{
						fprintf(cgiOut, "<script language='javascript'>alert('�ϴ�ʧ��,�洢�ռ�20M����!');</script>\n");
					}
					else
					{
						fprintf(cgiOut, "<script language='javascript'>alert('�ϴ�ʧ��,�����²���!');</script>\n");
					}
					sprintf(cmd, "%s", "0");
					QueryData();
					break;
			}		
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){parent.location = '../../index.html';}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('1')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{  
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("cname", cname, sizeof(cname));
	cgiFormString("route", route, sizeof(route));
	cgiFormString("memo", memo, sizeof(memo));	
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{	
		case 0://��ѯ	
      strcat(Sql, "select t.sn, t.cname, t.route, t.memo from call t order by t.sn");
			break;
		case 10://����
      strcat(Sql, "insert into call(sn, cname, route, memo)values('");
      strcat(Sql, sn);
      strcat(Sql, "', '");
      strcat(Sql, cname);
      strcat(Sql, "', '");
      strcat(Sql, route);
      strcat(Sql, "', '");
      strcat(Sql, memo);
      strcat(Sql, "')");
			break;
		case 11://����
			strcat(Sql, "update call set cname = '");
			strcat(Sql, cname);
			strcat(Sql, "', memo = '");
			strcat(Sql, memo);
			strcat(Sql, "' where sn = '");
			strcat(Sql, sn);
			strcat(Sql, "'");
			break;
		case 12://ɾ��
			strcat(Sql, "delete from call where sn = '");
			strcat(Sql, sn);
			strcat(Sql, "'");
			break;
	}
	return Sql;
}

//��ѯ
void QueryData()
{
  fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-������Ϣ</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "</HEAD>\n");

	//��ֹ�Ҽ�
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};  </SCRIPT>\n");

	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"call\" action=\"call.cgi\" method=\"post\" target=\"mainFrame\">\n");

	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/call.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	fprintf(cgiOut, "<table width=\"80%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");

	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='100%%' align='right'><img src=\"../../skin/images/mini_button_add.gif\" style='cursor:hand;' onClick='doAdd()'/></td>\n");
	fprintf(cgiOut, "</tr>\n");

	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='100%%' align='center'>\n");
	fprintf(cgiOut, "<table width=\"100%%\" border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='10%%' align='center' class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "<td width='20%%' align='center' class=\"table_deep_blue\">�� ��</td>\n");
	fprintf(cgiOut, "<td width='40%%' align='center' class=\"table_deep_blue\">�� ע</td>\n");
	fprintf(cgiOut, "<td width='10%%' align='center' class=\"table_deep_blue\">ɾ ��</td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	/*************************���ݿ����*********************/
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	//�����ݿ�
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	//�ر����ݿ�
	sqlite3_close(db);
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</td>\n");
	fprintf(cgiOut, "</tr>\n");

	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  location = 'call.cgi?cmd=1';\n");
	fprintf(cgiOut, "}\n");

	fprintf(cgiOut, "function doDelete(pSn, pRoute)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(confirm('ȷ��ɾ��?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    location = 'call.cgi?cmd=12&sn='+pSn+'&route='+pRoute;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int sqlite3_exec_callback_cnt(void *data, int n_columns, char **col_values, char **col_names)
{
	count++;
	return 0;
}

void DelData()
{
	//ɾ��ǰ�ж�TASK_INFO��DEVICE_AGENT 
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[1024] = {0};
	sprintf(sql, "select a.id from task_info a where a.id = '010401' and a.sn = '0003' and a.cdata like '%%//%s' ", sn);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cnt, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	
	memset(sql, 0, sizeof(sql));
	sprintf(sql, "select a.d_id from device_agent a where a.d_id = '010401' and a.d_cmd = '0003' and a.object like '%%//%s' ", sn);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_cnt, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	
	if(count > 0)
	{
		fprintf(cgiOut, "<SCRIPT>alert('ʧ��,��ʱ������������ð�������Ƶ,������ɾ��!');</SCRIPT>\n");
	}
	else
	{
		//ִ��ɾ��
		char excu[60] = {0};
		sprintf(excu, "rm -rf %s", route);
		int ret = system(excu);
		if(0 == ret)
		{
			int rc;
			char * zErrMsg = 0;
			char * sql = getSql(atoi(cmd));
			sqlite3 *db = open_db(DB_PATH);
			rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
			if(rc != SQLITE_OK )
			{
			  err_msg(1);
			}
			sqlite3_close(db);
		}
	}
}

void UpdData()
{
	int rc;
	char * zErrMsg = 0;
	char * sql = getSql(atoi(cmd));
	//�����ݿ�
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	//�ر����ݿ�
	sqlite3_close(db);
}

int UpdCall()
{
	//��������
	int getDiskSize_ret = getDiskSize();
	if(0 != getDiskSize_ret)
	{
		return 1;
	}
	
	if((total_size/1024)/1024 >= 20)
	{
		return 5;
	}
	
	cgiFilePtr file;  
	int targetFile;  
	mode_t mode;
	char name[128];
	char fileNameOnServer[64] = {0};
	strcat(fileNameOnServer, "/home/CPM/audio_files/");
	
	char buffer[2048];
	int size;
	int got;  
	
	char fimename[10] = {0};
	strcat(fimename, "route");

	//·����ȡ
	if(cgiFormFileName(fimename, name, sizeof(name)) != cgiFormSuccess)
	{    
		return 1;
	}
	
	//��С
	cgiFormFileSize(fimename, &size);
	if(size/1024 > 1024)
	{
		return 2;
	}
	
	if(cgiFormFileOpen(fimename, &file) != cgiFormSuccess)
	{    
		return 3;
	}	

	//��ȡ�ļ���
	strcat(fileNameOnServer, sn);
	strcat(fileNameOnServer, ".wav");
	
	memset(route, 0, sizeof(route));
	memcpy(route, fileNameOnServer, 128);
	
	mode = S_IRWXU|S_IRGRP|S_IROTH;
	targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode); 
	if(targetFile < 0)
	{   
		int ret = system("mkdir /home/CPM/audio_files"); 
		if(0 == ret)
			targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode);
		else
			return 4;
	}
	
	while(cgiFormFileRead(file, buffer, 2048, &got) == cgiFormSuccess)
	{    
		if(got > 0) 
		{
			write(targetFile, buffer, got);   
		} 
	}
	
	cgiFormFileClose(file); 
	close(targetFile);
	
	//���»�����Ϣ
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, getSql(11), &sqlite3_exec_callback, 0, &zErrMsg);
	if( rc!=SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
	return 0;
}

//��ѯ����
int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{  
	count++;
	if(count%2 == 0)
	{
		fprintf(cgiOut, "<tr class='table_blue' height='30' valign='middle'>\n");
	}
	else
	{
		fprintf(cgiOut, "<tr class='table_white_l' height='30' valign='middle'>\n");
	}
	fprintf(cgiOut, "<td width='10%%' align='center'><a href='call.cgi?cmd=2&sn=%s&cname=%s&memo=%s' target='mainFrame'><font color=red>%s</font></a></td>\n", col_values[0], col_values[1], col_values[3], col_values[0]);
	fprintf(cgiOut, "<td width='20%%' align='left'>%s</td>\n", col_values[1]);
	fprintf(cgiOut, "<td width='40%%' align='left'>%s&nbsp</td>\n", col_values[3]);
	fprintf(cgiOut, "<td width='10%%' align='center' style='cursor:hand;color:red;' title='���ɾ��' onClick=\"doDelete('%s', '%s')\">ɾ ��</td>\n", col_values[0], col_values[2]);
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

void SingleQuery()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-��������</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "</HEAD>\n");

	//��ֹ�Ҽ�
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};  </SCRIPT>\n");

	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"call\" action=\"call.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");

	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/call.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	
	fprintf(cgiOut, "<table width=\"50%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right'><img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doEdit()'><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	
	fprintf(cgiOut, "<table width=\"50%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "<td width='70%%' align='left'>%s<input type='hidden' id='sn' name='sn' value='%s'></td>\n", sn, sn);
	fprintf(cgiOut, "</tr>\n");

	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "<td width='70%%' align='left'><input type='text' id='cname' name='cname' value='%s' style='width:90%%;height:25px;' maxlength=10></td>\n", cname);
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "<td width='70%%' align='left'><input id='route' name='route' type='file' title='��Ƶ�ļ��ϴ�' value='���' style='width:60%%;height:20px'><font color=red>(��С�� 1M)</font></td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='30%%' align='center'>�� ע</td>\n");
	fprintf(cgiOut, "<td width='70%%' align='left'><input type='text' id='memo' name='memo' value='%s' style='width:90%%;height:25px;' maxlength=128></td>\n", memo);
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='11'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");

	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	fprintf(cgiOut, "function doReturn(){location = 'call.cgi?cmd=0';}\n");

	fprintf(cgiOut, "function doEdit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(call.cname.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д����');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
		
	fprintf(cgiOut, "  if(call.route.value.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    call.cmd.value = '11';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(call.route.value.indexOf('.wav') == -1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('��֧��.wav��ʽ�ļ�!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    call.cmd.value = '13';\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  if(confirm('ȷ�ϱ༭?'))\n");
	fprintf(cgiOut, "  {\n");	
	fprintf(cgiOut, "    call.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

void AddData()
{
	fprintf(cgiOut, "<HTML><HEAD>\n");
	fprintf(cgiOut, "<TITLE>���´���������ƽ̨-��������</TITLE>\n");
	fprintf(cgiOut, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\"/>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/>\n");
	fprintf(cgiOut, "</HEAD>\n");

	//��ֹ�Ҽ�
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};  </SCRIPT>\n");

	fprintf(cgiOut, "<BODY style=\"background:#CADFFF\">\n");
	fprintf(cgiOut, "<form name=\"call\" action=\"call.cgi\" method=\"post\" target=\"mainFrame\" enctype='multipart/form-data'>\n");

	fprintf(cgiOut, "<div id=\"down_bg_2\">\n");
	fprintf(cgiOut, "<div id=\"cap\"><img src=\"../../skin/images/call.gif\"/></div><br>\n");
	fprintf(cgiOut, "<div id=\"right_table_center\">\n");
	
	fprintf(cgiOut, "<table width=\"50%%\" style='margin:auto;' border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "    <td width='100%%' align='right'><img style=\"cursor:hand\" src=\"../skin/images/mini_button_submit.gif\" onclick='doAdd()'><img style=\"cursor:hand\" src=\"../skin/images/button10.gif\" onclick='doReturn()'></td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "</table>\n");
	
	fprintf(cgiOut, "<table width=\"50%%\" style='margin:auto;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\">\n");
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "<td width='70%%' align='left'>**</td>\n");
	fprintf(cgiOut, "</tr>\n");

	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "<td width='70%%' align='left'><input type='text' id='cname' name='cname' value='' style='width:90%%;height:20px;' maxlength=50></td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='30%%' align='center'>�� ��</td>\n");
	fprintf(cgiOut, "<td width='70%%' align='left'><input id='route' name='route' type='file' title='��Ƶ�ļ��ϴ�' value='���' style='width:60%%;height:20px'><font color=red>(��С�� 1M)</font></td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "<tr height='30' valign='middle'>\n");
	fprintf(cgiOut, "<td width='30%%' align='center'>�� ע</td>\n");
	fprintf(cgiOut, "<td width='70%%' align='left'><input type='text' id='memo' name='memo' value='' style='width:90%%;height:20px;' maxlength=128></td>\n");
	fprintf(cgiOut, "</tr>\n");
	
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<input type='hidden' name='cmd' value='10'>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");

	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	/*
	fprintf(cgiOut, "function ShowSize(files)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var fso,f;\n");
	fprintf(cgiOut, "  fso = new ActiveXObject('Scripting.FileSystemObject');\n");
	fprintf(cgiOut, "  f = fso.GetFile(files);\n");
	fprintf(cgiOut, "  alert(f.size/1024)\n");
	fprintf(cgiOut, "}\n");
	*/
	fprintf(cgiOut, "function doAdd()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(call.cname.value.length < 1){alert('����д����!');return;}\n");
	fprintf(cgiOut, "  if(call.route.value.length < 1){alert('��ѡ���ļ�!');return;}\n");
	fprintf(cgiOut, "  if(call.route.value.indexOf('.wav') == -1){alert('��֧��.wav��ʽ�ļ�!');return;}\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    call.submit();\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "function doReturn(){location = 'call.cgi?cmd=0';}\n");
	
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
}

int AddTrue()
{
	int getDiskSize_ret = getDiskSize();
	if(0 != getDiskSize_ret)
	{
		return 1;
	}
	
	//fprintf(cgiOut, "<script language='javascript'>alert('%d');</script>\n", total_size);
	if((total_size/1024)/1024 >= 20)
	{
		return 5;
	}
	
	cgiFilePtr file;  
	int targetFile;  
	mode_t mode;
	char name[128];
	char fileNameOnServer[64] = {0};
	strcat(fileNameOnServer, "/home/CPM/audio_files/");
	
	char buffer[2048];
	int size;
	int got;  
	
	char fimename[10] = {0};
	strcat(fimename, "route");

	//·����ȡ
	if(cgiFormFileName(fimename, name, sizeof(name)) != cgiFormSuccess)
	{    
		return 1;
	}
	
	//��С
	cgiFormFileSize(fimename, &size);
	if(size/1024 > 1024)
	{
		return 2;
	}
	
	if(cgiFormFileOpen(fimename, &file) != cgiFormSuccess)
	{    
		return 3;
	}
	
	//��ȡsn
	getMaxSn();

	//��ȡ�ļ���
	strcat(fileNameOnServer, sn);
	strcat(fileNameOnServer, ".wav");
	
	memset(route, 0, sizeof(route));
	memcpy(route, fileNameOnServer, 128);
	
	mode = S_IRWXU|S_IRGRP|S_IROTH;
	targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode); 
	if(targetFile < 0)
	{   
		int ret = system("mkdir /home/CPM/audio_files"); 
		if(0 == ret)
			targetFile = open(fileNameOnServer, O_RDWR|O_CREAT|O_TRUNC|O_APPEND, mode);
		else
			return 4;
	}
	
	while(cgiFormFileRead(file, buffer, 2048, &got) == cgiFormSuccess)
	{    
		if(got > 0) 
		{
			write(targetFile, buffer, got);   
		} 
	}
	
	cgiFormFileClose(file); 
	close(targetFile); 
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);		
	
	rc = sqlite3_exec(db, getSql(10), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	return 0;
}

void getMaxSn()
{
	
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	char sql[128] = "select max(t.sn)+1 from call t";
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_add, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	
	sqlite3_close(db);
	
}

int sqlite3_exec_callback_add(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL == col_values[0] || strlen(col_values[0]) == 0)
	{
		memcpy(sn, "1", 5);
	}
	else
	{
		memcpy(sn, col_values[0], 5);
	}
	
	return 0;
}

int getDiskSize()
{
	DIR *d;
  struct dirent *de; 
  struct stat buf; 
  int exists;
 
  d = opendir("/home/CPM/audio_files");
  if(d == NULL)
  { 
  	int ret = system("mkdir /home/CPM/audio_files"); 
		if(0 == ret)
			d = opendir("/home/CPM/audio_files");
		else
			return 1;
  } 
	
  total_size = 0;
   
  for(de = readdir(d); de != NULL; de = readdir(d))
  {
  	char filename[60] = {0};
  	sprintf(filename, "/home/CPM/audio_files/%s", de->d_name);
    exists = stat(filename, &buf); 
    if(0 == strcmp(de->d_name, ".") || 0 == strcmp(de->d_name, "..") || 0 != exists) 
    { 
      continue;
    }
    total_size += buf.st_size; 
  } 
  closedir(d);
  
  return 0;
}
