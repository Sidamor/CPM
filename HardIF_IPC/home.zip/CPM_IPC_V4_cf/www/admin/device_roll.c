#include <stdio.h>
#include <cgic.h>
#include "session.h"
#include "sqlite3.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "cgic.h"
#include "ClsTcp.h"
#include "Md5.h"
#include "Shared.h"
#include "util.h"

//��������
char Sql[1024] = {0};
char cmd[4] = {0};
int cnt = 0;
char FillStr[1024] = {0};
char GetName[128] = {0};
//device_roll
char id[11] = {0};						//���
char sn[5] = {0};							//���
char attr_name[21] = {0};     //����
char s_define[129] = {0};	    //״̬����
char private_attr[256] = {0};	//˽�����Դ��
char standard[61] = {0};      //��׼��Χ
char defence[21] = {0};			  //�������
char sta_show[2] = {0};       //�Ƿ���ʾ��ǰ����״̬
char status[2] = {0};	        //����״̬
char v_id[11] = {0};					//������
char v_sn[5] = {0};						//������
char value_limit[65] = {0};   //ֵ���ж�
char level[2] = {0};
char fromtype[2] = {0};
char cdata[256] = {0};        //��ʼֵ
//��������
static void getHtmlData();
static char *getSql(int pCmd);
void err_msg(int pType);
char *StrRightFillSpace(char *strData, int len);
char *getStatusName(int pStatus);
void AddMsg(unsigned char *str,int num);
//��ѯ
static void QueryData();
static int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_attr_dev(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_agent(void *data, int n_columns, char **col_values, char **col_names);
static int sqlite3_exec_callback_outset(void *data, int n_columns, char **col_values, char **col_names);
//�ύ
static void AttrSubmit();
static int sqlite3_exec_callback_sta_show(void *data, int n_columns, char **col_values, char **col_names);
//�ɼ�����
static void QueryAttr();
static int sqlite3_exec_callback_queryattr(void *data, int n_columns, char **col_values, char **col_names);
//���ó�ʼֵ
static void doInitValue();
//��ȡ����
char *getCName(int pCType, char *pId, char *pSN);
static int sqlite3_exec_callback_getname(void *data, int n_columns, char **col_values, char **col_names);
//ͨѶ
char *getLocalIP();
static int MsgSend(int flag);

int cgiMain()
{
	cgiHeaderContentType("text/html;charset=gb2312");
	getHtmlData();

	//��֤
	char session_id[17] = {0};
	cgiCookieString("session_id", session_id, sizeof(session_id));
	int ret = start_session(session_id, PCS_WEB);
	switch(ret)
	{
		case 0:
			cnt = 0;
			switch(atoi(cmd))
			{
				case 0://��ѯ
					QueryData();
					break;
				case 1://�ύ
					AttrSubmit();
					break;
				case 2://��ѯ�ɼ�����
					QueryAttr();
					break;
				case 3://���ó�ʼֵ
					doInitValue();
					break;
			}
			break;
		case 1:
			fprintf(cgiOut, "<script language='javascript'>parent.location = '../index.html';</script>\n");
			break;
		case 2:
			fprintf(cgiOut, "<script language='javascript'>\n");
			fprintf(cgiOut, "function doOut(pIndex){\n");
			fprintf(cgiOut, "alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
			fprintf(cgiOut, "if(pIndex == '1'){window.parent.location = '../index.html';}\n");
			fprintf(cgiOut, "if(pIndex == '2'){window.open('../index.html', '_top');}\n");
			fprintf(cgiOut, "}\n");
			fprintf(cgiOut, "doOut('2')\n");
			fprintf(cgiOut, "</script>\n");
			break;
	}
	return 0;
}

static void getHtmlData()
{
	cgiFormString("cmd", cmd, sizeof(cmd));
	cgiFormString("id", id, sizeof(id));
	cgiFormString("sn", sn, sizeof(sn));
	cgiFormString("attr_name", attr_name, sizeof(attr_name));
	cgiFormString("s_define", s_define, sizeof(s_define));
	cgiFormString("private_attr", private_attr, sizeof(private_attr));
	cgiFormString("standard", standard, sizeof(standard));
	cgiFormString("defence", defence, sizeof(defence));
	cgiFormString("sta_show", sta_show, sizeof(sta_show));
	cgiFormString("status", status, sizeof(status));
	cgiFormString("v_id", v_id, sizeof(v_id));
	cgiFormString("v_sn", v_sn, sizeof(v_sn));
	cgiFormString("value_limit", value_limit, sizeof(value_limit));
	
	cgiFormString("level", level, sizeof(level));
	cgiFormString("fromtype", fromtype, sizeof(fromtype));
	cgiFormString("cdata", cdata, sizeof(cdata));
}

static char *getSql(int pCmd)
{
	memset(Sql, 0, sizeof(Sql));
	switch(pCmd)
	{
		case 0://��ѯ
      strcat(Sql, "select a.id, a.sn, a.private_attr, a.standard, a.defence, a.v_id, a.v_sn, a.sta_show, a.attr_name, a.s_define, a.status, b.private_attr, b.ctype, c.cname, a.value_limit from device_roll a, device_attr b, device_detail c where substr(a.id,1,6) = b.id and a.sn = b.sn and a.id = c.id and a.id = '");
      strcat(Sql, id);
      strcat(Sql, "' and a.sn = '");
      strcat(Sql, sn);
      strcat(Sql, "'");
			break;
	}
	return Sql;
}

void QueryData()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);	
	rc = sqlite3_exec(db, getSql(0), &sqlite3_exec_callback, 0, &zErrMsg);
	if(rc != SQLITE_OK )
	{
	  err_msg(1);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "<html>\n");
	fprintf(cgiOut, "<head> \n");
	fprintf(cgiOut, "<META http-equiv=Content-Type content=\"text/html; charset=gb2312\">\n");
	fprintf(cgiOut, "<title>��Ѳ����</title>\n");
	fprintf(cgiOut, "<link type=\"text/css\" href=\"../skin/css/style.css\" rel=\"stylesheet\"/> \n");
	fprintf(cgiOut, "<script type=\"text/javascript\" src=\"../skin/js/util.js\"></script>\n");
	fprintf(cgiOut, "<SCRIPT language=javascript>document.oncontextmenu=function(){window.event.returnValue=false;};</SCRIPT>\n");	
	fprintf(cgiOut, "<style type='text/css'>\n");
	fprintf(cgiOut, "html,body {height:100%%; margin:0px; font-size:12px;}\n");
	fprintf(cgiOut, ".mydiv\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  background-color: #e0e6ed;\n");
	fprintf(cgiOut, "  border: 1px solid green;\n");
	fprintf(cgiOut, "  text-align: center;\n");
	fprintf(cgiOut, "  line-height: 40px;\n");
	fprintf(cgiOut, "  font-size: 12px;\n");
	fprintf(cgiOut, "  font-weight: bold;\n");
	fprintf(cgiOut, "  z-index:999;\n");
	fprintf(cgiOut, "  width: 100%%;\n");
	fprintf(cgiOut, "  height:100%%;\n");
	fprintf(cgiOut, "  left:0px;\n");
	fprintf(cgiOut, "  top:0px;\n");
	fprintf(cgiOut, "  position:fixed!important;\n");
	fprintf(cgiOut, "  position:absolute;\n");
	fprintf(cgiOut, "  _top:expression(eval(document.compatMode && document.compatMode=='CSS1Compat') ? documentElement.scrollTop + (document.documentElement.clientHeight-this.offsetHeight)/2 : document.body.scrollTop + (document.body.clientHeight - this.clientHeight)/2);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "#container{height:100%%}\n");
	fprintf(cgiOut, ".mesWindow{border:#C7C5C6 1px solid;background:#CADFFF;}\n");
	fprintf(cgiOut, ".mesWindowTop{background:#3ea3f9;padding:5px;margin:0;font-weight:bold;text-align:left;font-size:12px; clear:both; line-height:1.5em; position:relative; clear:both;}\n");
	fprintf(cgiOut, ".mesWindowTop span{ position:absolute; right:5px; top:3px;}\n");
	fprintf(cgiOut, ".mesWindowContent{margin:4px;font-size:12px; clear:both;}\n");
	fprintf(cgiOut, ".mesWindow .close{height:15px;width:28px; cursor:pointer;text-decoration:underline;background:#fff}\n");
	fprintf(cgiOut, "</style>\n");
	fprintf(cgiOut, "</head>\n");
	fprintf(cgiOut, "<BODY style=\"background:#e0e6ed\">\n");
	fprintf(cgiOut, "<form name=\"device_roll\" action=\"device_roll.cgi\" method=\"post\" target=\"mainFrame\">\n");
	fprintf(cgiOut, "<table width=\"98%%\" align='center' style='margin:auto;margin-top:5px;' border=1 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='25%%' align='center'>�ɼ�����</td>\n");
	fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='attr_name' value='%s' style='width:220px;height:20px;' maxlength=10>\n", col_values[8]);
	fprintf(cgiOut, "      <img src='../skin/images/edit.png'  style='cursor:hand;position:absolute;margin-top:2px;' title='���ó�ʼֵ' onclick=\"doInitValue('%s', '%s', '%s')\">\n", col_values[0], col_values[1], col_values[10]);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='25%%' align='center'>�ɼ�״̬</td>\n");
	fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
	if(0 == strcmp(col_values[10], "0"))
	{
		fprintf(cgiOut, "    <input type='checkbox' name='status' value='0'>\n");
	}
	else
	{
		fprintf(cgiOut, "    <input type='checkbox' name='status' value='1' checked>\n");
	}
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	if(strstr(col_values[11], "interval"))
	{
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='25%%' align='center'>�ɼ�����</td>\n");
		fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
		fprintf(cgiOut, "      <input type='text' name='interval' value='%s' style='width:100px;height:20px' maxlength=10>����\n", define_sscanf(col_values[2], "interval="));
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	
	if(strstr(col_values[11], "defence"))
	{
		memset(defence, 0, sizeof(defence));
		memcpy(defence, col_values[4], 21);
		char beg[10] = {0};
	  char end[10] = {0};
	  if(strlen(defence) > 0 )
	  {
	  	beg[0] = defence[0];
	  	beg[1] = defence[1];
	  	beg[2] = defence[2];
	  	beg[3] = defence[3];
	  	beg[4] = '\0';
	  	
	  	end[0] = defence[5];
	  	end[1] = defence[6];
	  	end[2] = defence[7];
	  	end[3] = defence[8];
	  	end[4] = '\0';
	  }
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='25%%' align='center'>�������</td>\n");
		fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
		fprintf(cgiOut, "      <select name='defence_beg' style='width:100px;height:25px'>\n");
		fprintf(cgiOut, "				 <option value='' %s>�����</option>\n",  0 == strlen(defence)?"selected":"");
  	fprintf(cgiOut, "				 <option value='0000' %s>0��</option>\n", 0 == strcmp(beg, "0000")?"selected":"");
  	fprintf(cgiOut, "        <option value='0030' %s>0��30��</option>\n", 0 == strcmp(beg, "0030")?"selected":"");
  	fprintf(cgiOut, "        <option value='0100' %s>1��</option>\n", 0 == strcmp(beg, "0100")?"selected":"");
  	fprintf(cgiOut, "        <option value='0130' %s>1��30��</option>\n", 0 == strcmp(beg, "0130")?"selected":"");
  	fprintf(cgiOut, "        <option value='0200' %s>2��</option>\n", 0 == strcmp(beg, "0200")?"selected":"");
  	fprintf(cgiOut, "        <option value='0230' %s>2��30��</option>\n", 0 == strcmp(beg, "0230")?"selected":"");
  	fprintf(cgiOut, "        <option value='0300' %s>3��</option>\n", 0 == strcmp(beg, "0300")?"selected":"");
  	fprintf(cgiOut, "        <option value='0330' %s>3��30��</option>\n", 0 == strcmp(beg, "0330")?"selected":"");
  	fprintf(cgiOut, "        <option value='0400' %s>4��</option>\n", 0 == strcmp(beg, "0400")?"selected":"");
  	fprintf(cgiOut, "        <option value='0430' %s>4��30��</option>\n", 0 == strcmp(beg, "0430")?"selected":"");
  	fprintf(cgiOut, "        <option value='0500' %s>5��</option>\n", 0 == strcmp(beg, "0500")?"selected":"");
  	fprintf(cgiOut, "        <option value='0530' %s>5��30��</option>\n", 0 == strcmp(beg, "0530")?"selected":"");
  	fprintf(cgiOut, "        <option value='0600' %s>6��</option>\n", 0 == strcmp(beg, "0600")?"selected":"");
  	fprintf(cgiOut, "        <option value='0630' %s>6��30��</option>\n", 0 == strcmp(beg, "0630")?"selected":"");
  	fprintf(cgiOut, "        <option value='0700' %s>7��</option>\n", 0 == strcmp(beg, "0700")?"selected":"");
  	fprintf(cgiOut, "        <option value='0730' %s>7��30��</option>\n", 0 == strcmp(beg, "0730")?"selected":"");
  	fprintf(cgiOut, "        <option value='0800' %s>8��</option>\n", 0 == strcmp(beg, "0800")?"selected":"");
  	fprintf(cgiOut, "        <option value='0830' %s>8��30��</option>\n", 0 == strcmp(beg, "0830")?"selected":"");
  	fprintf(cgiOut, "        <option value='0900' %s>9��</option>\n", 0 == strcmp(beg, "0900")?"selected":"");
  	fprintf(cgiOut, "        <option value='0930' %s>9��30��</option>\n", 0 == strcmp(beg, "0930")?"selected":"");
  	fprintf(cgiOut, "        <option value='1000' %s>10��</option>\n", 0 == strcmp(beg, "1000")?"selected":"");
  	fprintf(cgiOut, "        <option value='1030' %s>10��30��</option>\n", 0 == strcmp(beg, "1030")?"selected":"");
  	fprintf(cgiOut, "        <option value='1100' %s>11��</option>\n", 0 == strcmp(beg, "1100")?"selected":"");
  	fprintf(cgiOut, "        <option value='1130' %s>11��30��</option>\n", 0 == strcmp(beg, "1130")?"selected":"");
  	fprintf(cgiOut, "        <option value='1200' %s>12��</option>\n", 0 == strcmp(beg, "1200")?"selected":"");
  	fprintf(cgiOut, "        <option value='1230' %s>12��30��</option>\n", 0 == strcmp(beg, "1230")?"selected":"");
  	fprintf(cgiOut, "        <option value='1300' %s>13��</option>\n", 0 == strcmp(beg, "1300")?"selected":"");
  	fprintf(cgiOut, "        <option value='1330' %s>13��30��</option>\n", 0 == strcmp(beg, "1330")?"selected":"");
  	fprintf(cgiOut, "        <option value='1400' %s>14��</option>\n", 0 == strcmp(beg, "1400")?"selected":"");
  	fprintf(cgiOut, "        <option value='1430' %s>14��30��</option>\n", 0 == strcmp(beg, "1430")?"selected":"");
  	fprintf(cgiOut, "        <option value='1500' %s>15��</option>\n", 0 == strcmp(beg, "1500")?"selected":"");
  	fprintf(cgiOut, "        <option value='1530' %s>15��30��</option>\n", 0 == strcmp(beg, "1530")?"selected":"");
  	fprintf(cgiOut, "        <option value='1600' %s>16��</option>\n", 0 == strcmp(beg, "1600")?"selected":"");
  	fprintf(cgiOut, "        <option value='1630' %s>16��30��</option>\n", 0 == strcmp(beg, "1630")?"selected":"");
  	fprintf(cgiOut, "        <option value='1700' %s>17��</option>\n", 0 == strcmp(beg, "1700")?"selected":"");
  	fprintf(cgiOut, "        <option value='1730' %s>17��30��</option>\n", 0 == strcmp(beg, "1730")?"selected":"");
  	fprintf(cgiOut, "        <option value='1800' %s>18��</option>\n", 0 == strcmp(beg, "1800")?"selected":"");
  	fprintf(cgiOut, "        <option value='1830' %s>18��30��</option>\n", 0 == strcmp(beg, "1830")?"selected":"");
  	fprintf(cgiOut, "        <option value='1900' %s>19��</option>\n", 0 == strcmp(beg, "1900")?"selected":"");
  	fprintf(cgiOut, "        <option value='1930' %s>19��30��</option>\n", 0 == strcmp(beg, "1930")?"selected":"");
  	fprintf(cgiOut, "        <option value='2000' %s>20��</option>\n", 0 == strcmp(beg, "2000")?"selected":"");
  	fprintf(cgiOut, "        <option value='2030' %s>20��30��</option>\n", 0 == strcmp(beg, "2030")?"selected":"");
  	fprintf(cgiOut, "        <option value='2100' %s>21��</option>\n", 0 == strcmp(beg, "2100")?"selected":"");
  	fprintf(cgiOut, "        <option value='2130' %s>21��30��</option>\n", 0 == strcmp(beg, "2130")?"selected":"");
  	fprintf(cgiOut, "        <option value='2200' %s>22��</option>\n", 0 == strcmp(beg, "2200")?"selected":"");
  	fprintf(cgiOut, "        <option value='2230' %s>22��30��</option>\n", 0 == strcmp(beg, "2230")?"selected":"");
  	fprintf(cgiOut, "        <option value='2300' %s>23��</option>\n", 0 == strcmp(beg, "2300")?"selected":"");
  	fprintf(cgiOut, "        <option value='2330' %s>23��30��</option>\n", 0 == strcmp(beg, "2330")?"selected":"");
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "      ~\n");
		fprintf(cgiOut, "      <select name='defence_end' style='width:100px;height:25px'>\n");
		fprintf(cgiOut, "        <option value='' %s>�����</option>\n",  0 == strlen(defence)?"selected":"");
  	fprintf(cgiOut, "        <option value='0000' %s>0��</option>\n", 0 == strcmp(end, "0000")?"selected":"");
  	fprintf(cgiOut, "        <option value='0030' %s>0��30��</option>\n", 0 == strcmp(end, "0030")?"selected":"");
  	fprintf(cgiOut, "        <option value='0100' %s>1��</option>\n", 0 == strcmp(end, "0100")?"selected":"");
  	fprintf(cgiOut, "        <option value='0130' %s>1��30��</option>\n", 0 == strcmp(end, "0130")?"selected":"");
  	fprintf(cgiOut, "        <option value='0200' %s>2��</option>\n", 0 == strcmp(end, "0200")?"selected":"");
  	fprintf(cgiOut, "        <option value='0230' %s>2��30��</option>\n", 0 == strcmp(end, "0230")?"selected":"");
  	fprintf(cgiOut, "        <option value='0300' %s>3��</option>\n", 0 == strcmp(end, "0300")?"selected":"");
  	fprintf(cgiOut, "        <option value='0330' %s>3��30��</option>\n", 0 == strcmp(end, "0330")?"selected":"");
  	fprintf(cgiOut, "        <option value='0400' %s>4��</option>\n", 0 == strcmp(end, "0400")?"selected":"");
  	fprintf(cgiOut, "        <option value='0430' %s>4��30��</option>\n", 0 == strcmp(end, "0430")?"selected":"");
  	fprintf(cgiOut, "        <option value='0500' %s>5��</option>\n", 0 == strcmp(end, "0500")?"selected":"");
  	fprintf(cgiOut, "        <option value='0530' %s>5��30��</option>\n", 0 == strcmp(end, "0530")?"selected":"");
  	fprintf(cgiOut, "        <option value='0600' %s>6��</option>\n", 0 == strcmp(end, "0600")?"selected":"");
  	fprintf(cgiOut, "        <option value='0630' %s>6��30��</option>\n", 0 == strcmp(end, "0630")?"selected":"");
  	fprintf(cgiOut, "        <option value='0700' %s>7��</option>\n", 0 == strcmp(end, "0700")?"selected":"");
  	fprintf(cgiOut, "        <option value='0730' %s>7��30��</option>\n", 0 == strcmp(end, "0730")?"selected":"");
  	fprintf(cgiOut, "        <option value='0800' %s>8��</option>\n", 0 == strcmp(end, "0800")?"selected":"");
  	fprintf(cgiOut, "        <option value='0830' %s>8��30��</option>\n", 0 == strcmp(end, "0830")?"selected":"");
  	fprintf(cgiOut, "        <option value='0900' %s>9��</option>\n", 0 == strcmp(end, "0900")?"selected":"");
  	fprintf(cgiOut, "        <option value='0930' %s>9��30��</option>\n", 0 == strcmp(end, "0930")?"selected":"");
  	fprintf(cgiOut, "        <option value='1000' %s>10��</option>\n", 0 == strcmp(end, "1000")?"selected":"");
  	fprintf(cgiOut, "        <option value='1030' %s>10��30��</option>\n", 0 == strcmp(end, "1030")?"selected":"");
  	fprintf(cgiOut, "        <option value='1100' %s>11��</option>\n", 0 == strcmp(end, "1100")?"selected":"");
  	fprintf(cgiOut, "        <option value='1130' %s>11��30��</option>\n", 0 == strcmp(end, "1130")?"selected":"");
  	fprintf(cgiOut, "        <option value='1200' %s>12��</option>\n", 0 == strcmp(end, "1200")?"selected":"");
  	fprintf(cgiOut, "        <option value='1230' %s>12��30��</option>\n", 0 == strcmp(end, "1230")?"selected":"");
  	fprintf(cgiOut, "        <option value='1300' %s>13��</option>\n", 0 == strcmp(end, "1300")?"selected":"");
  	fprintf(cgiOut, "        <option value='1330' %s>13��30��</option>\n", 0 == strcmp(end, "1330")?"selected":"");
  	fprintf(cgiOut, "        <option value='1400' %s>14��</option>\n", 0 == strcmp(end, "1400")?"selected":"");
  	fprintf(cgiOut, "        <option value='1430' %s>14��30��</option>\n", 0 == strcmp(end, "1430")?"selected":"");
  	fprintf(cgiOut, "        <option value='1500' %s>15��</option>\n", 0 == strcmp(end, "1500")?"selected":"");
  	fprintf(cgiOut, "        <option value='1530' %s>15��30��</option>\n", 0 == strcmp(end, "1530")?"selected":"");
  	fprintf(cgiOut, "        <option value='1600' %s>16��</option>\n", 0 == strcmp(end, "1600")?"selected":"");
  	fprintf(cgiOut, "        <option value='1630' %s>16��30��</option>\n", 0 == strcmp(end, "1630")?"selected":"");
  	fprintf(cgiOut, "        <option value='1700' %s>17��</option>\n", 0 == strcmp(end, "1700")?"selected":"");
  	fprintf(cgiOut, "        <option value='1730' %s>17��30��</option>\n", 0 == strcmp(end, "1730")?"selected":"");
  	fprintf(cgiOut, "        <option value='1800' %s>18��</option>\n", 0 == strcmp(end, "1800")?"selected":"");
  	fprintf(cgiOut, "        <option value='1830' %s>18��30��</option>\n", 0 == strcmp(end, "1830")?"selected":"");
  	fprintf(cgiOut, "        <option value='1900' %s>19��</option>\n", 0 == strcmp(end, "1900")?"selected":"");
  	fprintf(cgiOut, "        <option value='1930' %s>19��30��</option>\n", 0 == strcmp(end, "1930")?"selected":"");
  	fprintf(cgiOut, "        <option value='2000' %s>20��</option>\n", 0 == strcmp(end, "2000")?"selected":"");
  	fprintf(cgiOut, "        <option value='2030' %s>20��30��</option>\n", 0 == strcmp(end, "2030")?"selected":"");
  	fprintf(cgiOut, "        <option value='2100' %s>21��</option>\n", 0 == strcmp(end, "2100")?"selected":"");
  	fprintf(cgiOut, "        <option value='2130' %s>21��30��</option>\n", 0 == strcmp(end, "2130")?"selected":"");
  	fprintf(cgiOut, "        <option value='2200' %s>22��</option>\n", 0 == strcmp(end, "2200")?"selected":"");
  	fprintf(cgiOut, "        <option value='2230' %s>22��30��</option>\n", 0 == strcmp(end, "2230")?"selected":"");
  	fprintf(cgiOut, "        <option value='2300' %s>23��</option>\n", 0 == strcmp(end, "2300")?"selected":"");
  	fprintf(cgiOut, "        <option value='2330' %s>23��30��</option>\n", 0 == strcmp(end, "2330")?"selected":"");
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	
	fprintf(cgiOut, "  <tr height='50'>\n");
	fprintf(cgiOut, "    <td width='25%%' align='center'>ֵ��Χ</td>\n");
	fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "      1.\n");
	fprintf(cgiOut, "      <select id='value_0' name='value_0' style='width:68px;height:20px;' onchange='doValueChange(this.value)'>\n");
	fprintf(cgiOut, "        <option value='9'>������</option>\n");
	fprintf(cgiOut, "        <option value='0'>������</option>\n");
	fprintf(cgiOut, "        <option value='1'>������</option>\n");
	fprintf(cgiOut, "        <option value='2'>�ݼ���</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "      <font id='value_1' style='display:none;'></font>\n");
	fprintf(cgiOut, "      <input type='text' id='value_2' name='value_2' style='width:51px;height:18px;display:none;' maxlength=20>\n");
	fprintf(cgiOut, "      ~\n");
	fprintf(cgiOut, "      <input type='text' id='value_3' name='value_3' style='width:51px;height:18px;display:none;' maxlength=20>\n");
	fprintf(cgiOut, "      <select id='value_4' name='value_4' style='width:110px;height:20px;display:none;'>\n");
	fprintf(cgiOut, "        <option value='0'>�Ƿ����ݲ�����</option>\n");
	fprintf(cgiOut, "        <option value='1'>�Ƿ������账��</option>\n");
	fprintf(cgiOut, "      </select>\n");
	fprintf(cgiOut, "      <br>\n");
	fprintf(cgiOut, "      2.\n");
	fprintf(cgiOut, "      ���� <input type='text' id='value_5' name='value_5' style='width:35px;height:18px;' maxlength=4> ��δ�ɼ�����������������\n");
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	if(strstr(col_values[11], "standard"))
	{
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='25%%' align='center'>��׼��Χ</td>\n");
		fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
		fprintf(cgiOut, "      <input type='text' name='standard' value='%s' style='width:220px;height:20px' maxlength=30>\n", col_values[3]);
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	
	fprintf(cgiOut, "  <tr height='30'>\n");
	fprintf(cgiOut, "    <td width='25%%' align='center'>״̬����</td>\n");
	fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
	fprintf(cgiOut, "      <input type='text' name='s_define' value='%s' style='width:220px;height:20px' maxlength=60>\n", col_values[9]);
	fprintf(cgiOut, "    </td>\n");
	fprintf(cgiOut, "  </tr>\n");
	
	if(strstr(col_values[11], "isUpload"))
	{
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='25%%' align='center'>�Ƿ��ϴ�</td>\n");
		fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
		fprintf(cgiOut, "      <select name='isUpload' style='width:100px;height:25px'>\n");
		fprintf(cgiOut, "        <option value='0' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[2], "isUpload="), "0")?"selected":"");
		fprintf(cgiOut, "        <option value='1' %s>��</option>\n", 0 == strcmp(define_sscanf(col_values[2], "isUpload="), "1")?"selected":"");
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	
	//��Ѳת��
	if(0 == strcmp(col_values[12], "1"))
	{
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='25%%' align='center'>��Ѳת��</td>\n");
		fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
		fprintf(cgiOut, "      <select name='v_id' id='v_id' style='width:120px;height:25px' onchange='doChange(this.value);'>\n");
		
		int rc;
		char * zErrMsg = 0;
		char sql1[1024] = {0};
		sprintf(sql1, "select a.id, a.cname from device_detail a, device_roll b where a.id = b.id and a.id <> '%s' group by a.id", id);
		sqlite3 *db = open_db(DB_PATH);	
		rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_attr_dev, col_values[5], &zErrMsg);
		if(rc != SQLITE_OK)
		{
		  err_msg(1);
		}
		sqlite3_close(db);
		
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "      ��\n");
		fprintf(cgiOut, "      <select name='v_sn' id='v_sn' style='width:120px;height:25px'>\n");
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	else
	{
		fprintf(cgiOut, "  <input type='hidden' name='v_id' value=''>\n");
		fprintf(cgiOut, "  <input type='hidden' name='v_sn' value=''>\n");
	}
	
	//�Ƿ���ʾ��ǰ�Զ���״̬
	if(NULL != col_values[9] && strlen(col_values[9]) > 0)
	{
		fprintf(cgiOut, "  <tr height='30'>\n");
		fprintf(cgiOut, "    <td width='25%%' align='center'>�Ƿ���ʾ</td>\n");
		fprintf(cgiOut, "    <td width='75%%' align='left'>\n");
		fprintf(cgiOut, "      <select name='sta_show' id='sta_show' style='width:120px;height:25px'>\n");
		fprintf(cgiOut, "        <option value='0' %s>����ʾΪ��Ԫ״̬</option>\n", 0 == strcmp(col_values[7], "0")?"selected":"");
		fprintf(cgiOut, "        <option value='1' %s>��ʾΪ��Ԫ״̬</option>\n",   0 == strcmp(col_values[7], "1")?"selected":"");
		fprintf(cgiOut, "      </select>\n");
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	else
	{
		fprintf(cgiOut, "  <input type='hidden' name='sta_show' value='0'>\n");
	}
	
	if(strstr(col_values[11], "agent"))
	{
		fprintf(cgiOut, "  <tr height='80'>\n");
		fprintf(cgiOut, "    <td width='100%%' align='left' colspan=2>\n");
		fprintf(cgiOut, "      <table width=\"100%%\" border=0 cellPadding=0 cellSpacing=0 bordercolor=\"#3491D6\" borderColorDark=\"#ffffff\"> \n");
		fprintf(cgiOut, "        <tr height='30'>\n");
		fprintf(cgiOut, "          <td width='100%%' align=left>\n");
		
		int rc;
		char * zErrMsg = 0;
		char sql1[1024] = {0};
		sqlite3 *db = open_db(DB_PATH);
		//�����Ƿ񿪷�
		sprintf(sql1, "select t.status from out_set t where t.id = '0001' and t.status = '1'");		
		rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_outset, 0, &zErrMsg);
		if(cnt > 0)
		{
			fprintf(cgiOut, "          &nbsp;&nbsp;<img src='../skin/images/device_cmdadd.png' style='cursor:hand' title='��������' onclick=\"doAgentAdd('1', '', '%s', '%s', '%s', '%s', '%s')\">\n", id, sn, col_values[10], col_values[13], col_values[8]);
		}
		else
		{
			fprintf(cgiOut, "          &nbsp;&nbsp;<img src='../skin/images/device_cmdadd_gray.gif' title='��������'>\n");
		}
		fprintf(cgiOut, "          </td>\n");
		fprintf(cgiOut, "        </tr>\n");
		
		//��������
		cnt = 0;
		memset(sql1, 0, sizeof(sql1));
		sprintf(sql1, "select a.seq, a.id, a.sn, a.condition, a.valibtime, a.interval, a.d_id, a.d_cmd, a.object, a.ctype, b.cname, c.cname, d.cmdname, e.attr_name from device_agent a, device_detail b, device_detail c, device_act d, device_roll e where a.id = b.id and a.d_id = c.id and a.d_id = d.id and a.d_cmd = d.sn and a.id = e.id and a.sn = e.sn and a.id = '%s' and a.sn = '%s' and a.ctype = '0'", id, sn);		
		rc = sqlite3_exec(db, sql1, &sqlite3_exec_callback_agent, col_values[10], &zErrMsg);
		if(rc != SQLITE_OK)
		{
		  err_msg(1);
		}
		sqlite3_close(db);
		
		if(0 == cnt)
		{
			fprintf(cgiOut, "      <tr height='30'>\n");
			fprintf(cgiOut, "        <td width='100%%' align=left>&nbsp;&nbsp;��</td>\n");
			fprintf(cgiOut, "      </tr>\n");
		}
		fprintf(cgiOut, "      </table>\n");	
		fprintf(cgiOut, "    </td>\n");
		fprintf(cgiOut, "  </tr>\n");
	}
	fprintf(cgiOut, "</table>\n");
	fprintf(cgiOut, "<div style='text-align:center;margin-top:2px;'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doSubmit()' src='../skin/images/mini_button_submit.gif'>\n");
	fprintf(cgiOut, "  <img style='cursor:hand' onClick='doCancel()' src='../skin/images/button10.gif'>\n");
	fprintf(cgiOut, "</div>\n");
	fprintf(cgiOut, "<div id='agentDiv' class='mydiv' style='display:none;margin:auto'></div>\n");
	fprintf(cgiOut, "</form>\n");
	fprintf(cgiOut, "</BODY>\n");
	fprintf(cgiOut, "<SCRIPT LANGUAGE=javascript>\n");
	//����
	fprintf(cgiOut, "function doCancel()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  parent.closeDiv();\n");
	fprintf(cgiOut, "}\n");
	
	//��ʼֵ
	fprintf(cgiOut, "function doInitValue(pId, pSN, pStatus)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(pStatus == '0')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�ɼ�����δ�ڲɼ���,��������,�����ó�ʼֵ');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var messContent = '';\n");
	fprintf(cgiOut, "  messContent += \"<div style='text-align:center;margin:25px;'>\";\n");
	fprintf(cgiOut, "  messContent += \"  <input type='text' id='cdata' name='cdata' style='width:150px;height:20px;' maxlength=128>\";\n");
	fprintf(cgiOut, "  messContent += \"  <input type='button' value='�ύ' onclick=doInitValueAdd('\"+pId+\"','\"+pSN+\"')>\";\n");
	fprintf(cgiOut, "  messContent += \"</div>\";\n");
	fprintf(cgiOut, "  showMessageBox('���ó�ʼֵ', messContent , 300, 150);\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function doInitValueAdd(pId, pSN)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(document.getElementById('cdata').value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д��ʼֵ');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(confirm('ȷ������?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqInit = new XMLHttpRequest();\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      reqInit = new ActiveXObject('Microsoft.XMLHTTP');\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    reqInit.onreadystatechange = function()\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      var state = reqInit.readyState;\n");
	fprintf(cgiOut, "      if(state == 4)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var resp = reqInit.responseText;\n");
	fprintf(cgiOut, "        if(null != resp && resp.indexOf('0000') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('���óɹ�');\n");
	fprintf(cgiOut, "          closeWindow();\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        else\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          alert('����ʧ��,�����²���');\n");
	fprintf(cgiOut, "          return;\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    };\n");
	fprintf(cgiOut, "    var url = 'device_roll.cgi?cmd=3&id='+pId+'&sn='+pSN+'&cdata='+document.getElementById('cdata').value+'&currtime='+new Date();\n");
	fprintf(cgiOut, "    reqInit.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqInit.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqInit.send(null);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	//ֵ��Χ
	fprintf(cgiOut, "var str_value_limit = '%s';\n", col_values[14]);
	fprintf(cgiOut, "function doValueChange(pSel)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  switch(parseInt(pSel))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    case 9:\n");
	fprintf(cgiOut, "        document.getElementById('value_1').style.display = 'none';\n");
	fprintf(cgiOut, "        document.getElementById('value_1').innerHTML = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_2').style.display = 'none';\n");
	fprintf(cgiOut, "        document.getElementById('value_3').style.display = 'none';\n");
	fprintf(cgiOut, "        document.getElementById('value_4').style.display = 'none';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 0:\n");
	fprintf(cgiOut, "        document.getElementById('value_1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_1').innerHTML = '����:';\n");
	fprintf(cgiOut, "        document.getElementById('value_2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_4').style.display = '';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 1:\n");
	fprintf(cgiOut, "        document.getElementById('value_1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_1').innerHTML = '����:';\n");
	fprintf(cgiOut, "        document.getElementById('value_2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_4').style.display = '';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "    case 2:\n");
	fprintf(cgiOut, "        document.getElementById('value_1').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_1').innerHTML = '����:';\n");
	fprintf(cgiOut, "        document.getElementById('value_2').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_3').style.display = '';\n");
	fprintf(cgiOut, "        document.getElementById('value_4').style.display = '';\n");
	fprintf(cgiOut, "      break;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	
	fprintf(cgiOut, "var list_value_limit = str_value_limit.split(';');\n");
	fprintf(cgiOut, "if(list_value_limit[0].Trim().length < 1)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var list = document.getElementById('value_0').options;\n");
	fprintf(cgiOut, "  for(var i=0; i<list.length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(list[i].value == '9')\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      list[i].selected = true;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('value_2').value = '';\n");
	fprintf(cgiOut, "  document.getElementById('value_3').value = '';\n");
	fprintf(cgiOut, "  if(list_value_limit.length <= 1)\n");
	fprintf(cgiOut, "    document.getElementById('value_5').value = '';\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "    document.getElementById('value_5').value = list_value_limit[1];\n");
	fprintf(cgiOut, "  doValueChange('9');\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "else\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var sublist_value_limit = list_value_limit[0].split(',');\n");
	fprintf(cgiOut, "  var list = document.getElementById('value_0').options;\n");
	fprintf(cgiOut, "  for(var i=0; i<list.length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(list[i].value == sublist_value_limit[0])\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      list[i].selected = true;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('value_2').value = sublist_value_limit[1];\n");
	fprintf(cgiOut, "  document.getElementById('value_3').value = sublist_value_limit[2];\n");
	fprintf(cgiOut, "  var list4 = document.getElementById('value_4').options;\n");
	fprintf(cgiOut, "  for(var i=0; i<list4.length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(list4[i].value == sublist_value_limit[3])\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      list4[i].selected = true;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  document.getElementById('value_5').value = list_value_limit[1];\n");
	fprintf(cgiOut, "  doValueChange(sublist_value_limit[0]);\n");
	fprintf(cgiOut, "}\n");
	
	//��������
	fprintf(cgiOut, "function doChange(pId)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var length = document.getElementById('v_sn').length;\n");
	fprintf(cgiOut, "  for(var i=0; i<length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('v_sn').remove(0);\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(pId.length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(window.XMLHttpRequest){reqChg = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "  else if(window.ActiveXObject){reqChg = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "  reqChg.onreadystatechange = callbackChangeName;\n");
	fprintf(cgiOut, "  var url = 'device_roll.cgi?cmd=2&id='+pId+'&currtime='+new Date();\n");
	fprintf(cgiOut, "	 reqChg.open(\"get\",url);\n");
	fprintf(cgiOut, "  reqChg.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "  reqChg.send(null);\n");
	fprintf(cgiOut, "  return true;\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackChangeName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqChg.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqChg.responseText;\n");	
	fprintf(cgiOut, "    if(resp != null && resp.length > 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        var list = resp.split('#');\n");
	fprintf(cgiOut, "        for(var i=0; i<list.length && list[i].length>0; i++)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          var sublist = list[i].split(',');\n");
	fprintf(cgiOut, "      		 var objOption = document.createElement('OPTION');\n");
	fprintf(cgiOut, "      		 objOption.value = sublist[0];\n");
	fprintf(cgiOut, "      		 objOption.text  = sublist[1];\n");
	fprintf(cgiOut, "      		 document.getElementById('v_sn').add(objOption);\n");
	fprintf(cgiOut, "          if('%s' == sublist[0])\n", col_values[6]);
	fprintf(cgiOut, "          {\n");
	fprintf(cgiOut, "            objOption.selected = true;\n");
	fprintf(cgiOut, "          }\n");
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	if(0 == strcmp(col_values[12], "1"))
	{
		fprintf(cgiOut, "doChange(device_roll.v_id.value);\n");
	}
	
	//�༭
	fprintf(cgiOut, "var reqEdit = null;\n");
	fprintf(cgiOut, "function doSubmit()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(device_roll.attr_name.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('����д�ɼ���������!');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  var Private_Attr = '';\n");
	if(strstr(col_values[11], "interval"))
	{
		fprintf(cgiOut, "if(device_roll.interval.value.Trim().length < 1)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('������ɼ�����');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "for(var i=0; i<device_roll.interval.value.Trim().length; i++)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  if(isNaN(device_roll.interval.value.charAt(i)))\n");
		fprintf(cgiOut, "  {\n");
		fprintf(cgiOut, "    alert('�ɼ��������뺬�Ƿ��ַ�');\n");
		fprintf(cgiOut, "    return;\n");
		fprintf(cgiOut, "  }\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "if(device_roll.interval.value.Trim() < 100)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('�ɼ������벻С��100����');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "Private_Attr += 'interval='+device_roll.interval.value.Trim()+',';\n");	
	}
	
	if(strstr(col_values[11], "isUpload"))
	{
		fprintf(cgiOut, "Private_Attr += 'isUpload='+device_roll.isUpload.value+',';\n");
	}
	
	fprintf(cgiOut, "  var Defence = '';\n");
	if(strstr(col_values[11], "defence"))
	{
		fprintf(cgiOut, "if(device_roll.defence_beg.value == '' && device_roll.defence_end.value == '')\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  Defence = '';\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "else if(device_roll.defence_beg.value != '' && device_roll.defence_end.value != '')\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  Defence = device_roll.defence_beg.value + ';' + device_roll.defence_end.value;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "else\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('������ϲ���,��ʼ�ͽ�������Ϊ[�����];��ʱ��β���,��ѡ��ʼ�����ʱ��');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");	
	}
	
	fprintf(cgiOut, "  var Status = '';\n");
	fprintf(cgiOut, "  if(device_roll.status.checked == false)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Status = '0';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    Status = '1';\n");
	fprintf(cgiOut, "  }\n");
	
	fprintf(cgiOut, "  var value_limit = '';\n");
	fprintf(cgiOut, "  if(device_roll.value_0.value == '9')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    value_limit += ' ;';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(device_roll.value_2.value.Trim().length < 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('��������Сֵ');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<device_roll.value_2.value.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(device_roll.value_2.value.charAt(0) == '-' && device_roll.value_2.value.charAt(1) == '.')\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('������Сֵ����������������Сֵ!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(device_roll.value_2.value.charAt(0) == '.' || device_roll.value_2.value.charAt(device_roll.value_2.value.length-1) == '.' || device_roll.value_2.value.charAt(device_roll.value_2.value.length-1) == '-')\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('������Сֵ����������������Сֵ!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(device_roll.value_2.value.charAt(i) == '-' && 0 != i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('������Сֵ����������������Сֵ!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(device_roll.value_2.value.charAt(i) != '.' && device_roll.value_2.value.charAt(i) != '-' && isNaN(device_roll.value_2.value.charAt(i)))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('������Сֵ����������������Сֵ!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(device_roll.value_3.value.Trim().length < 1)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('���������ֵ');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    for(var i=0; i<device_roll.value_3.value.length; i++)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(device_roll.value_3.value.charAt(0) == '-' && device_roll.value_3.value.charAt(1) == '.')\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('�������ֵ�����������������ֵ!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(device_roll.value_3.value.charAt(0) == '.' || device_roll.value_3.value.charAt(device_roll.value_3.value.length-1) == '.' || device_roll.value_3.value.charAt(device_roll.value_3.value.length-1) == '-')\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('�������ֵ�����������������ֵ!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(device_roll.value_3.value.charAt(i) == '-' && 0 != i)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('�������ֵ�����������������ֵ!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      if(device_roll.value_3.value.charAt(i) != '.' && device_roll.value_3.value.charAt(i) != '-' && isNaN(device_roll.value_3.value.charAt(i)))\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('�������ֵ�����������������ֵ!');\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(parseFloat(device_roll.value_2.value.Trim()) > parseFloat(device_roll.value_3.value.Trim()))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('��Сֵ���ô������ֵ!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    value_limit += device_roll.value_0.value;\n");
	fprintf(cgiOut, "    value_limit += ',';\n");
	fprintf(cgiOut, "    value_limit += device_roll.value_2.value;\n");
	fprintf(cgiOut, "    value_limit += ',';\n");
	fprintf(cgiOut, "    value_limit += device_roll.value_3.value;\n");
	fprintf(cgiOut, "    value_limit += ',';\n");
	fprintf(cgiOut, "    value_limit += device_roll.value_4.value;\n");
	fprintf(cgiOut, "    value_limit += ';';\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_roll.value_5.value.Trim().length < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�����������жϴ���');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  for(var i=0; i<device_roll.value_5.value.Trim().length; i++)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(device_roll.value_5.value.charAt(0) == '0')\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('���������жϴ����������������������жϴ���!');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "    if(isNaN(device_roll.value_5.value.charAt(i)))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      alert('�����жϴ������뺬�Ƿ��ַ�');\n");
	fprintf(cgiOut, "      return;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if(device_roll.value_5.value.Trim() < 1)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('�����жϴ�����С��1��');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  value_limit += device_roll.value_5.value.Trim() + ';';\n");
	
	fprintf(cgiOut, "  var Standard = '';\n");
	if(strstr(col_values[11], "standard"))
	{
		fprintf(cgiOut, "Standard = device_roll.standard.value;\n");
	}
	
	if(0 == strcmp(col_values[12], "1"))
	{
		fprintf(cgiOut, "if(device_roll.v_id.value.length < 1)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('��ǰΪ�����������ѡ��ʵ������ɼ��豸');\n");
		fprintf(cgiOut, "  return;\n");
		fprintf(cgiOut, "}\n");
		fprintf(cgiOut, "if(device_roll.v_sn.value.length < 1)\n");
		fprintf(cgiOut, "{\n");
		fprintf(cgiOut, "  alert('��ǰΪ�����������ѡ��ʵ������ɼ��豸');\n");
		fprintf(cgiOut, "  return\n");
		fprintf(cgiOut, "}\n");
	}
	
	fprintf(cgiOut, "  if(confirm('ȷ���༭?'))\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(window.XMLHttpRequest){reqEdit = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "    else if(window.ActiveXObject){reqEdit = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "    reqEdit.onreadystatechange = callbackEditName;\n");			
	fprintf(cgiOut, "    var url = 'device_roll.cgi?cmd=1&id=%s&sn=%s&private_attr='+Private_Attr+'&standard='+Standard+'&defence='+Defence+'&status='+Status+'&v_id='+device_roll.v_id.value+'&v_sn='+device_roll.v_sn.value+'&sta_show='+device_roll.sta_show.value+'&attr_name='+device_roll.attr_name.value.Trim()+'&s_define='+device_roll.s_define.value+'&value_limit='+value_limit+'&currtime='+new Date();\n", id, sn);
	fprintf(cgiOut, "    reqEdit.open(\"get\",url);\n");
	fprintf(cgiOut, "    reqEdit.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "    reqEdit.send(null);\n");
	fprintf(cgiOut, "    return true;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackEditName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqEdit.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqEdit.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "        if(resp.indexOf('�ɹ�') >= 0 || resp.indexOf('�ύ�ɹ�') >= 0)\n");
	fprintf(cgiOut, "        {\n");	
	if(0 == strcmp(fromtype, "1"))
	{
	  fprintf(cgiOut, "        parent.location = 'device_detail.cgi?cmd=4&id=%s&level=%s';\n", id, level);
	}
	else if(0 == strcmp(fromtype, "2"))
	{
		fprintf(cgiOut, "        parent.location = 'device_topo.cgi?cmd=4&id=%s&level=%s';\n", id, level);
	}
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	//�رմ���
	fprintf(cgiOut, "function closeDiv()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('agentDiv').style.display = 'none';\n");
	fprintf(cgiOut, "}\n");
	//�����༭
	fprintf(cgiOut, "function doCondition(pSeq)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  document.getElementById('agentDiv').style.display = 'block';\n");
	fprintf(cgiOut, "  var url = 'device_agent.cgi?cmd=7&seq='+pSeq;\n");
	fprintf(cgiOut, "  document.getElementById('agentDiv').innerHTML = \"<iframe id='agentFrame' name='agentFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "}\n");	
	//���ӡ��༭��ɾ��
	fprintf(cgiOut, "function doAgentAdd(pCmd, pSeq, pId, pSN, pStatus, pCName, pAttr_Name)\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  if(pStatus == '0')\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    alert('��ǰ�ɼ�����δ�ڲɼ���,��������,����������');\n");
	fprintf(cgiOut, "    return;\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  if('3' == pCmd)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    if(confirm('ȷ��ɾ����ǰ��������?'))\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(window.XMLHttpRequest){reqDel = new XMLHttpRequest();}\n");
	fprintf(cgiOut, "      else if(window.ActiveXObject){reqDel = new ActiveXObject('Microsoft.XMLHTTP');}\n");
	fprintf(cgiOut, "      reqDel.onreadystatechange = callbackDelName;\n");		
	fprintf(cgiOut, "      var url = 'device_agent.cgi?cmd=3&seq='+pSeq+'&id='+pId+'&sn='+pSN+'&acttype=3&currtime='+new Date();\n");
	fprintf(cgiOut, "      reqDel.open(\"get\",url);\n");
	fprintf(cgiOut, "      reqDel.setRequestHeader('If-Modified-Since', '0');\n");
	fprintf(cgiOut, "      reqDel.send(null);\n");
	fprintf(cgiOut, "      return true;\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "  else\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    document.getElementById('agentDiv').style.display = 'block';\n");
	fprintf(cgiOut, "    var url = 'device_agent.cgi?cmd='+pCmd+'&seq='+pSeq+'&id='+pId+'&sn='+pSN+'&acttype='+pCmd+'&cname='+pCName+'&attr_name='+pAttr_Name+'&level=%s&fromtype=%s';\n", level, fromtype);
	fprintf(cgiOut, "    document.getElementById('agentDiv').innerHTML = \"<iframe id='agentFrame' name='agentFrame' src='\"+url+\"' width='99%%' height='100%%' frameborder=0 scrolling='no'></iframe>\";\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "function callbackDelName()\n");
	fprintf(cgiOut, "{\n");
	fprintf(cgiOut, "  var state = reqDel.readyState;\n");
	fprintf(cgiOut, "  if(state == 4)\n");
	fprintf(cgiOut, "  {\n");
	fprintf(cgiOut, "    var resp = reqDel.responseText;\n");
	fprintf(cgiOut, "    if(resp != null && resp.length > 0)\n");
	fprintf(cgiOut, "    {\n");
	fprintf(cgiOut, "      if(resp.indexOf('���µ���') < 0)\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert(resp);\n");
	fprintf(cgiOut, "        if(resp.indexOf('�ɹ�') >= 0 || resp.indexOf('�ύ�ɹ�') >= 0)\n");
	fprintf(cgiOut, "        {\n");
	fprintf(cgiOut, "          location = 'device_roll.cgi?cmd=0&id=%s&sn=%s&level=%s&fromtype=%s';\n", id, sn, level, fromtype);
	fprintf(cgiOut, "        }\n");
	fprintf(cgiOut, "        return;\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "      else\n");
	fprintf(cgiOut, "      {\n");
	fprintf(cgiOut, "        alert('���ڹ涨ҳ�泬ʱʱ�������κβ����������˺�ͬһʱ������һ�ص���룬Ϊ�������ʻ���ȫ�������µ���!');\n");
	fprintf(cgiOut, "        window.open( '../index.html', '_top');\n");
	fprintf(cgiOut, "      }\n");
	fprintf(cgiOut, "    }\n");
	fprintf(cgiOut, "  }\n");
	fprintf(cgiOut, "}\n");
	fprintf(cgiOut, "</SCRIPT>\n");
	fprintf(cgiOut, "</HTML>\n");
	return 0;
}

int sqlite3_exec_callback_attr_dev(void *data, int n_columns, char **col_values, char **col_names)
{
	if(NULL != (char *)data && 0 == strcmp(col_values[0], (char *)data))
	{
		fprintf(cgiOut, "<option value='%s' selected>%s</option>\n", col_values[0], col_values[1]);
	}
	else
	{
		fprintf(cgiOut, "<option value='%s'>%s</option>\n", col_values[0], col_values[1]);
	}
	return 0;
}

int sqlite3_exec_callback_agent(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	char ConDL[1024] = {0};
	char ConDS[128] = {0};
	if(NULL != col_values[3] && strlen(col_values[3]) > 0)
	{
		int i = 0;
		char* split_result = NULL;
    char* savePtr = NULL;
    split_result = strtok_r(col_values[3], "@", &savePtr);
    while(NULL != split_result)
		{
			i++;
			char con_id[11] = {0};
			char con_sn[5]  = {0};
			char con1[2]    = {0};
			char con2[60]   = {0};
			char con3[2]    = {0};
			char con4[30]   = {0};
			char con_idname[128] = {0};
			char con2_idname[128]= {0};
			strncpy(con_id, split_result+1, 10);
			strncpy(con_sn, split_result+11, 4);
			strncpy(con1, split_result+15, 1);
			strncpy(con2, split_result+16, 60);
			
			memcpy(con_idname, getCName(1, con_id, con_sn), 128);
			if(strstr(con2, "P") && (strstr(con2, "+") || strstr(con2, "-") || strstr(con2, "��") || strstr(con2, "��")))
			{
				memset(con2, 0, sizeof(con2));
				strncpy(con2, split_result+16, 15);	
				strncpy(con3, split_result+31, 1);
				strncpy(con4, split_result+32, 30);
			}
			memcpy(con2_idname, con2, 128);
			if(strstr(con2_idname, "P") && NULL != con3 && NULL != con4 && strlen(con3) > 0 && strlen(con4) > 0)
			{
				memset(con2_idname, 0, sizeof(con2_idname));
				memcpy(con2_idname, getCName(2, con2, ""), 128);
			}		
			
			if(1 == i)
			{
				strcat(ConDS, con_idname);
				strcat(ConDS, " ");
				strcat(ConDS, con1);
				strcat(ConDS, " ");
				strcat(ConDS, con2_idname);
				strcat(ConDS, con3);
				strcat(ConDS, con4);
				strcat(ConDS, " ...");
				
				strcat(ConDL, con_idname);
				strcat(ConDL, " ");
				strcat(ConDL, con1);
				strcat(ConDL, " ");
				strcat(ConDL, con2_idname);
				strcat(ConDL, con3);
				strcat(ConDL, con4);
				strcat(ConDL, " ");
			}
			else
			{
				strcat(ConDL, "���� ");		
				strcat(ConDL, con_idname);
				strcat(ConDL, " ");
				strcat(ConDL, con1);
				strcat(ConDL, " ");
				strcat(ConDL, con2_idname);
				strcat(ConDL, con3);
				strcat(ConDL, con4);
				strcat(ConDL, " ");
			}
			split_result = strtok_r(NULL, "@", &savePtr);
		}	
	}
	
	char objValue[512] = {0};
	/*
	if(0 == strcmp(col_values[6], "0011040001") && 0 == strcmp(col_values[7], "00020001"))
	{
		char objTel[512] = {0};
		char objCal[128] = {0};
		char objCalName[128] = {0};
		int i = 0;
		char* split_result = NULL;
    char* savePtr = NULL;
    split_result = strtok_r(col_values[8], "//", &savePtr);
    while(NULL != split_result)
		{		
			switch(i)
			{
				case 0:
						strcat(objTel, split_result);
					break;
				case 1:
						strcat(objCal, split_result);
					break;
			}
			i++;
			split_result = strtok_r(NULL, "//", &savePtr);
		}		
		if(NULL != objCal && strlen(objCal) > 0)
		{
			memcpy(objCalName, getCName(3, objCal, ""), 128);
		}
		strcat(objValue, objTel);
		strcat(objValue, "//");
		strcat(objValue, objCalName);
	}
	else
	{
		strcat(objValue, col_values[8]);
	}
	*/
	strcat(objValue, col_values[8]);
	
	fprintf(cgiOut, "<tr height='30'>\n");
	fprintf(cgiOut, "  <td width='100%%' align=left>\n");
	fprintf(cgiOut, "    &nbsp;&nbsp;%d.��[<a href='#' onclick=\"doCondition('%s')\" title='%s'><U>%s</U></a>]ʱ��%s %s %s\n", cnt, col_values[0], ConDL, ConDS, col_values[11], col_values[12], objValue);
	fprintf(cgiOut, "    <img src='../skin/images/agent_edit.gif' onclick=\"doAgentAdd('2', '%s', '%s', '%s', '%s', '%s', '%s')\" style='cursor:hand' title='�༭����'>\n", col_values[0], id, sn, (char *)data, col_values[10], col_values[13]);
	fprintf(cgiOut, "    <img src='../skin/images/cmddel.gif'     onclick=\"doAgentAdd('3', '%s', '%s', '%s', '%s', '%s', '%s')\" style='cursor:hand' title='ɾ������'>\n", col_values[0], id, sn, (char *)data, col_values[10], col_values[13]);
	fprintf(cgiOut, "  </td>\n");
	fprintf(cgiOut, "</tr>\n");
	return 0;
}

int sqlite3_exec_callback_outset(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

void AttrSubmit()
{
	//״̬��ʾ�ж�
	if(0 == strcmp(sta_show, "1") && 0 == strcmp(status, "1"))
	{
		int rc;
		char * zErrMsg = 0;
		sqlite3 *db = open_db(DB_PATH);
		char sql[128] = {0};
		sprintf(sql, "select a.id from device_roll a where a.id = '%s' and a.sn <> '%s' and a.sta_show = '1'", id, sn);
		rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_sta_show, 0, &zErrMsg);
		if(rc != SQLITE_OK)
		{
			err_msg(2);
		}
		sqlite3_close(db);
	}
	if(cnt > 0)
	{
		printf("ʧ��,ֻ������ʾһ����Ԫ״̬!\n");
	}
	else
	{
		int ret = MsgSend(0);
		printf("%s\n", getStatusName(ret));
	}
}

int sqlite3_exec_callback_sta_show(void *data, int n_columns, char **col_values, char **col_names)
{
	cnt++;
	return 0;
}

void QueryAttr()
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	char sql[256] = "select a.sn, a.attr_name from device_roll a, device_attr b where substr(a.id,1,6) = b.id and a.sn = b.sn and a.id = '";
	strcat(sql, id);
	strcat(sql, "' and b.ctype = '0' order by a.sn");
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_queryattr, 0, &zErrMsg);
	if(rc != SQLITE_OK)
	{
		err_msg(2);
	}
	sqlite3_close(db);
}

int sqlite3_exec_callback_queryattr(void *data, int n_columns, char **col_values, char **col_names)
{
	fprintf(cgiOut, "%s,%s#", col_values[0], col_values[1]);
	return 0;
}

//���ó�ʼֵ
void doInitValue()
{
	int rc;
	char * zErrMsg = 0;
	char sqlinsert[1024] = {0};
	sprintf(sqlinsert, "insert into DATA(ID, CTYPE, CTIME, VALUE)values('%s', '%s',  datetime('now', '+8 hour'), '%s')", id, sn, cdata);
	
	sqlite3 *db = open_db(DB_PATH);
	rc = sqlite3_exec(db, sqlinsert, NULL, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
		printf("3006\n");
	else
		printf("0000\n");
		
	sqlite3_close(db);
}

//��ȡ����
char *getCName(int pCType, char *pId, char *pSN)
{
	int rc;
	char * zErrMsg = 0;
	sqlite3 *db = open_db(DB_PATH);
	
	char sql[512] = {0};
	switch(pCType)
	{
		case 1:
				strcat(sql, "select a.attr_name from device_roll a where a.id = '");
				strcat(sql, pId);
				strcat(sql, "' and a.sn = '");
				strcat(sql, pSN);
				strcat(sql, "'");
			break;
		case 2:
				strcat(sql, "select '[' || b.cname || ']�ɼ���[' || a.Attr_Name || ']' as cname from device_roll a, device_detail b where a.id = b.id and ('P' || a.id || a.sn) = '");
				strcat(sql, pId);
				strcat(sql, "'");
			break;
		case 3:
				strcat(sql, "select a.cname from call a where a.sn = '");
				strcat(sql, pId);
				strcat(sql, "'");
			break;
	}
	
	memset(GetName, 0, sizeof(GetName));
	rc = sqlite3_exec(db, sql, &sqlite3_exec_callback_getname, 0, &zErrMsg);
	if(rc!=SQLITE_OK)
	{
		err_msg(1);
	}
	sqlite3_close(db);
	
	return GetName;
}

int sqlite3_exec_callback_getname(void *data, int n_columns, char **col_values, char **col_names)
{
	memcpy(GetName, col_values[0], 128);
	return 0;
}

char *StrRightFillSpace(char *strData, int len)
{
	memset(FillStr, 0, sizeof(FillStr));
	int FillLen = len - strlen(strData);
	strcat(FillStr, strData);
	int i=0;
	for(i=0; i < FillLen; i++)
	{
		strcat(FillStr, " ");
	}
	return FillStr;
}

//�����߳�
int MsgSend(int flag)
{	
	ClsTCPClientSocket* pSock = new ClsTCPClientSocket();
	if(NULL == pSock)
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	//������װ
	BYTE outbuf[2048] = {0};
	PMsgHdr pMsgHdr = (PMsgHdr)outbuf;
	char* pdata = (char*)pMsgHdr + MSGHDRLEN;
	int len = 0;
	switch(flag)
	{
		case 0://��ѵ�����༭
				strcat(pdata, StrRightFillSpace(" ", 20));
				strcat(pdata, "00002005");
				strcat(pdata, StrRightFillSpace(id, 10));
				strcat(pdata, StrRightFillSpace(sn, 4));		
				strcat(pdata, StrRightFillSpace(defence, 20));
				strcat(pdata, StrRightFillSpace(standard, 60));
				strcat(pdata, StrRightFillSpace(private_attr, 255));
				strcat(pdata, StrRightFillSpace(v_id, 10));
				strcat(pdata, StrRightFillSpace(v_sn, 4));
				strcat(pdata, StrRightFillSpace(sta_show, 1));
				strcat(pdata, StrRightFillSpace(s_define, 128));
				strcat(pdata, StrRightFillSpace(attr_name, 20));
				strcat(pdata, StrRightFillSpace(status, 1));
				strcat(pdata, StrRightFillSpace(value_limit, 64));
				len = MSGHDRLEN + 20 + 8 + 10 + 4 + 20 + 60 + 255 + 10 + 4 + 1 + 128 + 20 + 1 + 64;
			break;
	}
	
	//AddMsg((BYTE *)outbuf, 1024);
	pMsgHdr->unMsgLen = len;
	pMsgHdr->unMsgCode = COMM_SUBMIT;
	pMsgHdr->unStatus = 0;
	pMsgHdr->unMsgSeq = 0;
	
	char *ip = getLocalIP();
	
	//����
	pSock->Connect(ip, 31020);
	if(!pSock->IsConnected())
	{
		return SYS_STATUS_SYS_BUSY;
	}
	
	pSock->SetCompletion();
		
	int sendlen = pSock->Send((void*)outbuf, len);
	if(len != sendlen)
	{
		pSock->EndSocket();
		return SYS_STATUS_FORMAT_ERROR;
	}
	
	char szBuf[512] = {0};
	if(true == pSock->IsPending(30000))
	{
	 	if((len = pSock->Recv(szBuf, 512)) <= 0) 
		{
			pSock->EndSocket();
			return SYS_STATUS_SYS_BUSY;
		}
		
		//���շ���
		pMsgHdr = (PMsgHdr)szBuf;
		char* pmsg = (char*)pMsgHdr + MSGHDRLEN;
		char result[5] = {0};
		strncpy(result, pmsg+20, 4);
		pSock->EndSocket();
		return atoi(result);
	}
	else
	{
		pSock->EndSocket();
		return SYS_STATUS_TIMEOUT;
	}
	
	//�ر�����
	pSock->EndSocket();
	return SYS_STATUS_FAILED;
}
