// JavaScript Document
function switchWidthScreen(){
	var widthdiv=document.getElementById("player");
	var heightdiv=document.getElementById("flash");
	var btnwidthdiv=document.getElementById("btnwidth");
    if(btnwidthdiv.innerHTML=="宽屏"){
		widthdiv.style.width="90%";
		heightdiv.style.height="450px";
		btnwidthdiv.innerHTML="窄屏";
	}
	else{
		widthdiv.style.width="50%";
		heightdiv.style.height="350px";
		btnwidthdiv.innerHTML="宽屏";
	}
	btnwidthdiv.blur();
	return false;
}
function switchFullScreen(){
	var widthdiv=document.getElementById("player");
	var heightdiv=document.getElementById("flash");
	var btnfulldiv=document.getElementById("btnfull");
    if(btnfulldiv.innerHTML=="全屏"){
		widthdiv.style.width="100%";
		heightdiv.style.height="600px";
		btnfulldiv.innerHTML="恢复";
	}
	else{
		widthdiv.style.width="50%";
		heightdiv.style.height="350px";
		btnfulldiv.innerHTML="全屏";
	}
	btnfulldiv.blur();
	return false;
}
function closeInf(){
	var infodiv=document.getElementById("playinf");
	var btnclosediv=document.getElementById("btnclose");
	if(infodiv.style.display=="block"){
		infodiv.style.display="none";
		btnclosediv.innerHTML="打开视频信息";
	}
	else{
		infodiv.style.display="block";
		btnclosediv.innerHTML="关闭视频信息";
	}
	btnclosediv.blur();
	return false;
}