/*
 * 使用方法：
 * 
 * 1.引用 jquery-1.2.6.js
 * 2.引用 jqDnR.js
 * 3.引用 jquery.topology-1.0.js
 * 4.添加 效果页面中添加 <div id="board" style="width:640px;height:480px;"></div>
 * 5.运行 showTopology(ajaxurl); 获得拓扑 ajaxurl 返回对象为NodeList结构的json对象文本
 * 
 */

//获得画板
var mainBoard;
var mbWidth;
var mbHeight;
var mbLeft;
var mbTop;

//获得画板
function checkBoard()
{
	mainBoard = document.getElementById("board");
	mbWidth = mainBoard.style.width.replace("px","")*1;
	mbHeight = mainBoard.style.height.replace("px","")*1;
	mbLeft = mainBoard.style.left.replace("px","")*1;
	mbTop = mainBoard.style.top.replace("px","")*1;
}


//添加节点信息
function createNode(nodeId, nodeName, fatherId, imgUrl, stateFlag, level, statusname, titlevalue)
{
	//重复节点过滤
	if(document.getElementById(nodeId))
	{
		return;
	}
	
	//在画板上添加新的节点
	var objHtml = "<div id=\""+nodeId+"\" level=\""+level+"\" fatherId=\""+fatherId+"\"></div>";
	mainBoard.innerHTML = mainBoard.innerHTML + objHtml;
	
	//创建所有的节点
	var nodeObj = document.getElementById(nodeId);
	try
	{
		nodeObj.style.position='absolute';
		nodeObj.style.top='0px';
		nodeObj.style.left='0px';
		nodeObj.style.zIndex=2;
		nodeObj.style.width = "100px";
  	nodeObj.style.height ="60px";
  	switch(parseInt(level))
  	{
  		case 0:
  		case 1:
  				nodeObj.innerHTML ="<img style='width:40px;height:40px;' src=\""+imgUrl+"\" /><br>"+nodeName+"<br>"+statusname;
  			break;
  		case 2:
  				nodeObj.innerHTML ="<img style='width:40px;height:40px;' src=\""+imgUrl+"\" onmousedown=\"doDefence('"+nodeId+"',"+stateFlag+");\" title=\""+titlevalue+"\"/><br>"+nodeName+"<br>"+statusname; 	
  			break;
  	}				  	
	}catch(e)
	{
		//alert(nodeObj);	
	}
}

function drawNow(fromX, fromY, toX, toY, lineIndex) 
{        
  var strElement = "<div style='position:absolute;left:"+fromX+"px;top:"+fromY+"px;'><v:Line from='" + fromX + "," + fromY + "' to='" + toX + "," + toY + "' id='line" + lineIndex + "' strokecolor='#2a2d2d'></v:Line></div>";
  mainBoard.innerHTML = mainBoard.innerHTML + strElement;
}

//画连接节点的层
function drawLine(node, level, subCnt)
{
	try
	{		
		var nodeObj_1 = document.getElementById(node);
		var obj1Width = nodeObj_1.style.width.replace("px","")*1;
		var obj1Height = nodeObj_1.style.height.replace("px","")*1;
		var obj1Left = nodeObj_1.style.left.replace("px","")*1;
		var obj1Top = nodeObj_1.style.top.replace("px","")*1;
		if('0' == level)
		{
			//drawNow(obj1Left+obj1Width/2, (obj1Top+obj1Height), obj1Left+obj1Width/2, (obj1Top+obj1Height)+150, 0);
		}
		if('1' == level)
		{
			//与上级节点连接
			drawNow(80, (obj1Top+obj1Height/2), obj1Left+30, (obj1Top+obj1Height/2), 1);
			
			//与下级节点连接
			drawNow(obj1Left+obj1Width-30, (obj1Top+obj1Height/2), obj1Left+obj1Width, (obj1Top+obj1Height/2), 1);
			
			//载点总个数
			var cnt = 0;
			if(subCnt%4 == 0)
				cnt = subCnt/4;
			else
				cnt = parseInt(subCnt/4)+1;
				
			//依据个数画高
			drawNow(obj1Left+obj1Width, (obj1Top+obj1Height/2), obj1Left+obj1Width, (obj1Top+obj1Height/2)+cnt*120, 1);
			
			//依据个数画横线条数
			for(var i=1; i<=cnt; i++)
			{
				drawNow(obj1Left+obj1Width, (obj1Top+obj1Height/2)+(i-1)*120, obj1Left+obj1Width+550, (obj1Top+obj1Height/2)+(i-1)*120, 1);
			}
		}
		if('2' == level)
		{
			//与上级节点连接
			drawNow(obj1Left+obj1Width/2, obj1Top-30, obj1Left+obj1Width/2, obj1Top, 2);
		}
	}catch(e)
	{
	}
}
