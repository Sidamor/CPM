/***********************************************************
*	ģ������: DES.h
*	�� �� ��: ������
*	��Ƶ�λ: ���ݰ��´�Ӧ�������о���
*   ��������: 2003-12-15
*	������: DES/3DES�㷨��ʵ�֣�
*	�� �� ��:
*	�޸�����:
*	�޸�����:
************************************************************/

#ifndef __INC_DES_H
#define	__INC_DES_H


#pragma pack(push, 1)

typedef unsigned char BYTE;
typedef unsigned short WORD;

typedef struct CBC_ST
{
	BYTE macKey[16];
	BYTE macBuf[8];
	BYTE macDest[8];
	BYTE macTemp[8];
	BYTE macCount;
} CBC_ST;

#pragma pack(pop)

void vHardwareDES(BYTE  *pbKey, BYTE *pbIn, BYTE *pbOut, BYTE bOp);
void vHardware3DES(BYTE  *pbKey1, BYTE  *pbKey2, BYTE *pbIn, BYTE *pbOut, BYTE bOp);

void DES_CBC(BYTE temp[8], BYTE src[8], BYTE key[8], BYTE dest[8], BYTE op);
void TripleDES_CBC(BYTE temp[8], BYTE src[8], BYTE key[16], BYTE dest[8], BYTE op);
void TripleDES_ECB(BYTE src[8], BYTE key[16], BYTE dest[8], BYTE op);

void TDESCBC_Begin(CBC_ST *mac, BYTE op);
void TDESCBC_Data(BYTE *data, BYTE len);
BYTE TDESCBC_End(BYTE fix, BYTE *padTo);

void MAC_Begin(CBC_ST *mac);
void MAC_Data(BYTE  *data, WORD len);
void MAC_End(BYTE result[4], BYTE fix);


int RunDesCBC(void *Data, int DataLen, BYTE key[8], BYTE bOp);
int Run3DesCBC(void *Data, int DataLen, BYTE key[16], BYTE bOp);

int RunDesECB(void *Data, int DataLen, BYTE key[8], BYTE bOp);
int Run3DesECB(void *Data, int DataLen, BYTE key[16], BYTE bOp);


#endif /* __INC_DES_H */
