/* SSSC_DES.H
 *
 * DES and Triple-DES and MAC head file
 * 
 * copy right 2002
 * write by Alex Liu
 * 2002.5
 */


#define ENCRYPT	0	/* MODE == encrypt */
#define DECRYPT	1	/* MODE == decrypt */

#define ECB	0		/* Encrypt mode ECB */
#define CBC	1		/* Encrypt mode CBC */

/* A useful alias on 68000-ish machines, but NOT USED HERE. */
#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/

typedef union {
	unsigned long  blok[2];
	unsigned short word[4];
	unsigned char  byte[8];
} M68K;

void deskey(unsigned char *, short);
/*		      hexkey[8]     MODE
 * Sets the internal key register according to the hexadecimal
 * key contained in the 8 bytes of hexkey, according to the DES,
 * for encryption or decryption according to MODE.
 */

void usekey(unsigned long *);
/*		    cookedkey[32]
 * Loads the internal key register with the data in cookedkey.
 */

void cpkey(unsigned long *);
/*		   cookedkey[32]
 * Copies the contents of the internal key register into the storage
 * located at &cookedkey[0].
 */

void des(unsigned char *, unsigned char *);
/*		    from[8]	      to[8]
 * Encrypts/Decrypts (according to the key currently loaded in the
 * internal key register) one block of eight bytes at address 'from'
 * into the block at address 'to'.  They can be the same.
 */

unsigned short Do2DESMAC(unsigned char *cpEnter,unsigned char *cpKey,unsigned char *cpResult,short nEnterLen);
unsigned short Do2DES(unsigned char *cpEnter,unsigned char *cpKey,unsigned char cDESMode,unsigned char cOperate,unsigned char *cpResult,unsigned short nEnterLen);
unsigned short DoDESMAC(unsigned char *cpEnter,unsigned char *cpKey,unsigned char *cpResult,short nEnterLen);
unsigned short DoDES(unsigned char *cpEnter,unsigned char *cpKey,unsigned char cDESMode,unsigned char cOperate,unsigned char *cpResult,short nEnterLen);
void Ddes(unsigned char *from, unsigned char *into);
void des2key(unsigned char *hexkey,short  mode);
//static void desfunc(register unsigned long *block, register unsigned long *keys);
//static void unscrun(register unsigned long *outof, register unsigned char *into);
//static void scrunch(register unsigned char *outof, register unsigned long *into);
//static void cookey (register unsigned long *raw1);

#ifdef __cplusplus
}
#endif /*__cplusplus*/
